"""Controllo aggiornamenti da manifest remoto (latest.json)."""

from __future__ import annotations

import json
import ssl
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from bootstrap import bundle_root, config_dir, install_root

from updater.version_utils import version_gt

# URL produzione (fallback se il template nel bundle non è leggibile).
PRODUCTION_MANIFEST_URL = (
    "https://raw.githubusercontent.com/Matteo-Furani/progeo-updates/"
    "main/ProgeoView/stable/latest.json"
)
TEST_MANIFEST_URL = (
    "https://raw.githubusercontent.com/Matteo-Furani/progeo-updates/"
    "main/ProgeoView/test/latest.json"
)
CHANNEL_MANIFEST_URLS: dict[str, str] = {
    "stable": PRODUCTION_MANIFEST_URL,
    "test": TEST_MANIFEST_URL,
}


def manifest_url_for_channel(channel: str) -> str:
    key = str(channel or "stable").strip().lower() or "stable"
    return CHANNEL_MANIFEST_URLS.get(key, PRODUCTION_MANIFEST_URL)

# Host/path tipici dei placeholder lasciati da install/config vecchie.
_PLACEHOLDER_HOST_MARKERS = (
    "example.com",
    "example.org",
    "example.net",
)
_PLACEHOLDER_URL_MARKERS = (
    "changeme",
    "your_manifest",
    "your-manifest",
    "todo",
    "replace_me",
)


def _update_settings_path() -> Path:
    return config_dir() / "update.json"


def _read_json_object(path: Path) -> dict[str, Any] | None:
    """Legge un oggetto JSON; tollera BOM UTF-8 (PowerShell Set-Content)."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return None
    return raw if isinstance(raw, dict) else None


def default_manifest_url() -> str:
    """Preferisce config/update.json del bundle; altrimenti URL produzione noto."""
    for root in (bundle_root(), install_root()):
        path = root / "config" / "update.json"
        if not path.is_file():
            continue
        raw = _read_json_object(path)
        if not raw:
            continue
        url = str(raw.get("manifest_url") or "").strip()
        if url and not is_placeholder_manifest_url(url):
            return url
    return PRODUCTION_MANIFEST_URL


def is_placeholder_manifest_url(url: str) -> bool:
    """True se l'URL non è usabile in produzione (vuoto / example.com / stub)."""
    text = str(url or "").strip()
    if not text:
        return True
    lower = text.lower()
    if any(marker in lower for marker in _PLACEHOLDER_URL_MARKERS):
        return True
    try:
        parsed = urlparse(text)
    except Exception:
        return True
    scheme = (parsed.scheme or "").lower()
    if scheme in {"", "file"}:
        # file:// è valido per test locali: non è un placeholder.
        return scheme == ""
    if scheme not in {"http", "https"}:
        return True
    host = (parsed.hostname or "").lower()
    if not host:
        return True
    if any(marker in host for marker in _PLACEHOLDER_HOST_MARKERS):
        return True
    return False


def migrate_update_settings() -> bool:
    """
    Corregge update.json utente se manifest_url è assente/placeholder.

    Utile dopo reinstall: AppData sopravvive alla disinstallazione e può
    contenere ancora https://example.com/... dalle prime build.
    Ritorna True se ha scritto su disco.
    """
    path = _update_settings_path()
    settings = default_update_settings()
    existing: dict[str, Any] = {}
    unreadable = False
    if path.is_file():
        raw = _read_json_object(path)
        if raw is not None:
            existing = raw
            settings.update(raw)
        else:
            # File corrotto/illeggibile (es. encoding): riscrivi default.
            unreadable = True

    current = str(settings.get("manifest_url") or "").strip()
    if not unreadable and not is_placeholder_manifest_url(current):
        return False

    settings["manifest_url"] = default_manifest_url()
    # Conserva le altre chiavi già presenti nel file utente.
    merged = dict(existing)
    merged.update(settings)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(merged, indent=2) + "\n", encoding="utf-8")
    except OSError:
        return False
    return True


def default_update_settings() -> dict[str, Any]:
    return {
        "enabled": True,
        "check_on_startup": True,
        "channel": "stable",
        "manifest_url": PRODUCTION_MANIFEST_URL,
        "timeout_s": 8.0,
        "prefer_patch": True,
    }


def load_update_settings() -> dict[str, Any]:
    migrate_update_settings()
    path = _update_settings_path()
    defaults = default_update_settings()
    if path.is_file():
        raw = _read_json_object(path)
        if raw is not None:
            defaults.update(raw)
    # Cintura e bretelle: mai restituire un placeholder a runtime.
    if is_placeholder_manifest_url(str(defaults.get("manifest_url") or "")):
        defaults["manifest_url"] = default_manifest_url()
    return defaults


def save_update_settings(settings: dict[str, Any]) -> Path:
    path = _update_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    merged = default_update_settings()
    merged.update(settings)
    if is_placeholder_manifest_url(str(merged.get("manifest_url") or "")):
        merged["manifest_url"] = default_manifest_url()
    path.write_text(json.dumps(merged, indent=2) + "\n", encoding="utf-8")
    return path


def _fetch_json(url: str, *, timeout_s: float) -> dict[str, Any] | None:
    if not url.strip():
        return None
    parsed = urlparse(url)
    if parsed.scheme in {"", "file"}:
        # Supporto path locale / file:///C:/path/latest.json per test.
        if parsed.scheme == "file":
            path_str = urllib.request.url2pathname(parsed.path)
            if parsed.netloc:
                local = Path(f"\\\\{parsed.netloc}{path_str}")
            else:
                local = Path(path_str)
        else:
            local = Path(url)
        if not local.is_file():
            return None
        try:
            payload = json.loads(local.read_text(encoding="utf-8"))
        except Exception:
            return None
        return payload if isinstance(payload, dict) else None

    req = urllib.request.Request(
        url,
        headers={"User-Agent": "ProgeoView-Updater/1.0"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=float(timeout_s)) as resp:
            data = resp.read()
    except (urllib.error.URLError, ssl.SSLError, TimeoutError, ValueError):
        return None
    try:
        payload = json.loads(data.decode("utf-8"))
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def check_for_update(
    *,
    local_version: str,
    channel: str | None = None,
    manifest_url: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """
    Confronta la versione locale con il manifest remoto.

    ``channel`` / ``manifest_url`` sovrascrivono solo questa chiamata
    (non modificano config/update.json). Utile per Alt+F → canale test.

    Con ``force=True`` (canale test) offre l'update anche a parità di versione,
    così puoi ritestare lo stesso build.

    Ritorna dict con chiavi:
      update_available, latest_version, local_version, release_notes,
      installer (url, sha256, size_bytes), patch (opzionale),
      strategy ('patch'|'installer'|''), error, channel
    """
    settings = load_update_settings()
    channel_key = str(channel or settings.get("channel") or "stable").strip().lower()
    if manifest_url is not None and str(manifest_url).strip():
        resolved_url = str(manifest_url).strip()
    elif channel is not None:
        resolved_url = manifest_url_for_channel(channel_key)
    else:
        resolved_url = str(settings.get("manifest_url") or "").strip()

    result: dict[str, Any] = {
        "update_available": False,
        "local_version": str(local_version),
        "latest_version": str(local_version),
        "release_notes": "",
        "installer": None,
        "patch": None,
        "strategy": "",
        "error": None,
        "manifest_url": resolved_url,
        "channel": channel_key,
        "is_test_channel": channel_key == "test",
    }
    # Controllo one-shot su canale test: ignora "enabled: false" dello stable.
    if channel is None and not bool(settings.get("enabled", True)):
        result["error"] = "disabled"
        return result

    if not resolved_url:
        result["error"] = "manifest_url_missing"
        return result

    manifest = _fetch_json(resolved_url, timeout_s=float(settings.get("timeout_s", 8.0)))
    if manifest is None:
        result["error"] = "manifest_unavailable"
        return result

    remote_version = str(manifest.get("version") or "").strip()
    if not remote_version:
        result["error"] = "invalid_manifest"
        return result

    result["latest_version"] = remote_version
    result["release_notes"] = str(manifest.get("release_notes") or "").strip()
    result["installer"] = manifest.get("installer")
    result["patches"] = manifest.get("patches")
    result["patch"] = manifest.get("patch")
    result["patch_chain"] = []
    available = version_gt(remote_version, local_version)
    result["update_available"] = available
    if available or force:
        from updater.patch_chain import collect_patch_edges, resolve_patch_chain

        edges = collect_patch_edges(manifest)
        chain = resolve_patch_chain(
            local_version=str(local_version),
            latest_version=remote_version,
            edges=edges,
        )
        result["patch_chain"] = chain
        # Compat UI/legacy: espone la prima patch; run_update usa tutta la catena.
        if chain:
            result["patch"] = dict(chain[0])
        from updater.apply_update import choose_update_strategy

        result["strategy"] = choose_update_strategy(
            result,
            prefer_patch=bool(settings.get("prefer_patch", True)),
        )
        # Se prefer_patch ma nessuna catena risolvibile → prova installer.
        if result["strategy"] == "" and isinstance(result.get("installer"), dict):
            if result["installer"].get("url"):
                result["strategy"] = "installer"
        # force (Alt+F): offri download se c'è qualcosa di applicabile.
        if force and not available and result["strategy"]:
            result["update_available"] = True
    return result


def write_local_version(version: str, *, product: str = "ProgeoView") -> None:
    path = config_dir() / "version.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    # utf-8 senza BOM: alcuni build frozen falliscono con BOM → versione 0.0.0.
    path.write_bytes(
        (
            json.dumps({"version": str(version), "product": product}, indent=2)
            + "\n"
        ).encode("utf-8")
    )


def read_local_version(*, default: str = "0.0.0") -> str:
    path = local_version_path()
    try:
        # utf-8-sig: tollera BOM da vecchi helper bat/PowerShell.
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return str(data.get("version") or default)
    except Exception:
        return default


def local_version_path() -> Path:
    """Preferisce config utente; fallback install/bundle (sola lettura)."""
    from bootstrap import bundle_root

    user_cfg = config_dir(create=False) / "version.json"
    if user_cfg.is_file():
        return user_cfg
    for candidate in (
        install_root() / "config" / "version.json",
        bundle_root() / "config" / "version.json",
    ):
        if candidate.is_file():
            return candidate
    return user_cfg
