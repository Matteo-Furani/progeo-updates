"""Confronto versioni semver semplificato (major.minor.patch)."""

from __future__ import annotations


def parse_version(value: str) -> tuple[int, ...]:
    text = str(value or "").strip()
    if not text:
        return (0, 0, 0)
    parts: list[int] = []
    for chunk in text.split("."):
        chunk = chunk.split("-", 1)[0].strip()
        try:
            parts.append(int(chunk))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def version_gt(left: str, right: str) -> bool:
    return parse_version(left) > parse_version(right)


def version_gte(left: str, right: str) -> bool:
    return parse_version(left) >= parse_version(right)


def version_eq(left: str, right: str) -> bool:
    return parse_version(left) == parse_version(right)
