"""PyQt6 Cross batch GUI: spike train + correlazione interna/esterna."""

from __future__ import annotations

import argparse
import sys
import threading
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))
from bootstrap import setup_project_paths

setup_project_paths()

from core.obspy_bootstrap import ensure_obspy_colormaps

ensure_obspy_colormaps()

import numpy as np
from PyQt6 import QtCore, QtGui, QtWidgets

import pandas as pd

from core.filter_runner import apply_filter_to_stream
from spike_pipeline import apply_spike_pipeline
from cross_pipeline import (
    apply_cross_pipeline,
    apply_trace_delay_ms,
    restore_corr_stream_timing,
    DEFAULT_CORR_AGC_MS,
    DEFAULT_CORR_MUTE_MS,
    DEFAULT_CORR_NORMALIZE,
    DEFAULT_CORR_PRE_PICK_ONLY,
)
from cross_correlation import correlate_template
from stream_io import read_stream, save_filtered_stream
from external_xcorr import run_external_correlation
from core.convertitore import convert_segy_file

SUPPORTED_SUFFIXES = {".sgy", ".segy", ".dat"}
MAX_TEMPLATE_CORR_SECONDS = 2.0

class _Invoker(QtCore.QObject):
    """Smista senza bloccare le chiamate verso il thread principale."""

    triggered = QtCore.pyqtSignal(object)

    def __init__(self, parent: Optional[QtCore.QObject] = None) -> None:
        super().__init__(parent)
        self.triggered.connect(self._handle)

    @QtCore.pyqtSlot(object)
    def _handle(self, func) -> None:
        if callable(func):
            func()

@dataclass #Variabili Utente Gui
class BatchOptions:
    input_format: str
    output_format: str
    filter_type: str
    freq: Optional[float]
    freq_min: Optional[float]
    freq_max: Optional[float]
    corners: int
    zerophase: bool
    ftype: str
    rp: Optional[float]
    rs: Optional[float]
    sampling_rate: Optional[float]
    save_filtered: bool
    save_spike_full: bool
    save_spike_trace: bool
    smoothing_ms: float
    threshold_method: str
    percentile: float
    sigma_scale: float
    dead_time_ms: float
    window_ms: Optional[float]
    peak_polarity: str
    polarity_window_ms: Optional[float]
    pre_shift_ms: float
    akaike_window_ms: Optional[float]
    mer_window_ms: Optional[float]
    mer_ratio_min: Optional[float]
    kurtosis_window_ms: Optional[float]
    kurtosis_min: Optional[float]
    corr_mute_ms: float
    corr_agc_ms: float
    corr_normalize: str
    corr_pre_pick_only: bool
    corr_cut_ms: float
    corr_reference_trace: int
    non_shot_delay_ms: float
    corr_mode: str
    external_trace_path: Optional[Path]
    external_trace_number: int
    corr_window_ms: float
    external_corr_auto_center: bool
    base_output_dir: Path


class CrossWindow(QtWidgets.QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Cross")
        self.resize(1200, 820)
        icon_path = Path(__file__).with_name("wacker.ico")
        if icon_path.exists():
            self.setWindowIcon(QtGui.QIcon(str(icon_path)))

        self.instructions: Dict[str, int] = {}
        self.file_map: Dict[str, str] = {}
        self._processing = False
        self._corr_processing = False

        self._input_format = "SEGY"
        self._output_format = "SEGY"

        self._build_ui()
        self._invoker = _Invoker(self)

    # ----------------------------- UI ------------------
    def _build_ui(self) -> None:
        central = QtWidgets.QWidget(self)
        self.setCentralWidget(central)

        layout = QtWidgets.QVBoxLayout(central)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        layout.addLayout(self._build_io_row())
        layout.addWidget(self._build_filter_section())
        layout.addWidget(self._build_spike_section())
        layout.addWidget(self._build_table_section(), stretch=1)
        layout.addWidget(self._build_corr_section())
        layout.addWidget(self._build_log_section(), stretch=1)

        self.status_label = QtWidgets.QLabel("Pronto")
        self.status_label.setFrameShape(QtWidgets.QFrame.Shape.Panel)
        self.status_label.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        self.status_label.setMinimumHeight(28)
        self.status_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignVCenter)
        layout.addWidget(self.status_label)

    def _build_excel_section(self) -> QtWidgets.QGroupBox:
        box = QtWidgets.QGroupBox("File Excel shot")
        grid = QtWidgets.QGridLayout(box)
        grid.setColumnStretch(0, 1)

        self.excel_edit = QtWidgets.QLineEdit()
        self.excel_edit.setPlaceholderText("Percorso file Excel")
        grid.addWidget(self.excel_edit, 0, 0)

        browse = QtWidgets.QPushButton("Sfoglia")
        browse.setToolTip("Selezionala il file Excel con gli shot. Il file deve avere come prima colonna titolo 'file' e la seconda 'shot'.")
        browse.clicked.connect(self._choose_excel)
        grid.addWidget(browse, 0, 1)

        reload_btn = QtWidgets.QPushButton("Ricarica")
        reload_btn.clicked.connect(self._reload_excel)
        grid.addWidget(reload_btn, 0, 2)

        return box

    def _build_source_section(self) -> QtWidgets.QGroupBox:
        box = QtWidgets.QGroupBox("Cartella File SGY")
        grid = QtWidgets.QGridLayout(box)
        grid.setColumnStretch(0, 1)

        self.source_edit = QtWidgets.QLineEdit()
        self.source_edit.setPlaceholderText("Cartella sorgente file SGY")
        grid.addWidget(self.source_edit, 0, 0)

        browse = QtWidgets.QPushButton("Sfoglia")
        browse.setToolTip("Seleziona la cartella in cui sono tutti i file SGY da crosscorrelare")
        browse.clicked.connect(self._choose_source_dir)
        grid.addWidget(browse, 0, 1)

        auto = QtWidgets.QPushButton("Associa automaticamente")
        auto.setToolTip("Caricati i file puoi auto associare i valori del file excel con i file SGY")
        auto.clicked.connect(self._auto_associate_from_folder)
        grid.addWidget(auto, 0, 2)

        return box

    def _build_output_section(self) -> QtWidgets.QGroupBox:
        box = QtWidgets.QGroupBox("Cartella output")
        grid = QtWidgets.QGridLayout(box)
        grid.setColumnStretch(0, 1)

        self.output_edit = QtWidgets.QLineEdit()
        self.output_edit.setPlaceholderText("Cartella output per i risultati")
        grid.addWidget(self.output_edit, 0, 0)

        browse = QtWidgets.QPushButton("Sfoglia")
        browse.setToolTip("Seleziona la cartella in cui verrà inserito l'output della crosscorrelazione. Verrà automaticaemnte creata una nuova cartella in cui saranno inseriti i nuovi file")
        browse.clicked.connect(self._choose_output_dir)
        grid.addWidget(browse, 0, 1)
        return box

    def _build_io_row(self) -> QtWidgets.QHBoxLayout:
        row = QtWidgets.QHBoxLayout()
        row.setSpacing(12)
        row.addWidget(self._build_excel_section(), 1)
        row.addWidget(self._build_source_section(), 1)
        row.addWidget(self._build_output_section(), 1)
        return row
        
    def _build_filter_section(self) -> QtWidgets.QGroupBox:
        box = QtWidgets.QGroupBox("Parametri filtro")
        grid = QtWidgets.QGridLayout(box)
        grid.setHorizontalSpacing(12)

        self.filter_combo = QtWidgets.QComboBox()
        for label, key in (
            ("Nessuno", "none"),
            ("Passa-basso", "lowpass"),
            ("Passa-alto", "highpass"),
            ("Passa-banda", "bandpass"),
            ("Elimina-banda", "bandstop"),
            ("Inviluppo", "envelope"),
        ):
            self.filter_combo.addItem(label, key)
        filter_label = QtWidgets.QLabel("Filtro:")
        filter_label.setToolTip("Seleziona il filtro da applicare al sismogramma")
        grid.addWidget(filter_label, 0, 0)
        grid.addWidget(self.filter_combo, 0, 1)

        self.freq_label = QtWidgets.QLabel("Freq (Hz):")
        self.freq_edit = QtWidgets.QLineEdit()
        self.freq_edit.setPlaceholderText("Freq. di taglio")
        grid.addWidget(self.freq_label, 0, 2)
        grid.addWidget(self.freq_edit, 0, 3)

        self.freq_band_label = QtWidgets.QLabel("Freq min/max (Hz):")
        self.freq_min_edit = QtWidgets.QLineEdit()
        self.freq_max_edit = QtWidgets.QLineEdit()
        self.freq_min_edit.setPlaceholderText("Minimo")
        self.freq_max_edit.setPlaceholderText("Massimo")
        grid.addWidget(self.freq_band_label, 0, 2)
        grid.addWidget(self.freq_min_edit, 0, 3)
        grid.addWidget(self.freq_max_edit, 0, 4)

        self.corners_edit = QtWidgets.QLineEdit("4")
        conrners_label = QtWidgets.QLabel("Pendenza filtro:")
        conrners_label.setToolTip("Determina quanto ripidamente il filtro attenua le frequenze fuori banda; valori maggiori = pendenza più ripida")
        grid.addWidget(conrners_label, 1, 2)
        grid.addWidget(self.corners_edit, 1, 3)

        self.save_filtered_check = QtWidgets.QCheckBox("Salva stream ")
        self.save_filtered_check.setChecked(False)
        grid.addWidget(self.save_filtered_check, 2, 4, 2, 2)

        self.zerophase_check = QtWidgets.QCheckBox("Fase zero")
        self.zerophase_check.setChecked(True)
        grid.addWidget(self.zerophase_check, 2, 5, 2, 2)

        self.filter_shot_only_check = QtWidgets.QCheckBox("Filtra solo traccia shot")
        self.filter_shot_only_check.setToolTip(
            "Se attivo, il filtro viene applicato solo alla traccia dello shot."
        )
        grid.addWidget(self.filter_shot_only_check, 2, 6)

        self.ftype_combo = QtWidgets.QComboBox()
        self.ftype_combo.addItems([
            "Butterworth",
            "Chebyshev I",
            "Chebyshev II",
            "Ellittico (Ellip)",
        ])
        grid.addWidget(QtWidgets.QLabel("Tipo filtro:"), 1, 0)
        grid.addWidget(self.ftype_combo, 1, 1)

        self.sampling_rate_edit = QtWidgets.QLineEdit()
        grid.addWidget(QtWidgets.QLabel("Frequenza di campionamento:"), 1, 4)
        grid.addWidget(self.sampling_rate_edit, 1, 5)

        self.rp_label = QtWidgets.QLabel("Rp (dB):")
        self.rp_edit = QtWidgets.QLineEdit()
        self.rs_label = QtWidgets.QLabel("Rs (dB):")
        self.rs_edit = QtWidgets.QLineEdit()
        self.rp_label.setToolTip("Ondulazione ammessa nella banda passante (Chebyshev I / ellittico).")
        self.rs_label.setToolTip("Attenuazione minima richiesta in banda stop (Chebyshev II / ellittico).")
        grid.addWidget(self.rp_label, 2, 0)
        grid.addWidget(self.rp_edit, 2, 1)
        grid.addWidget(self.rs_label, 2, 2)
        grid.addWidget(self.rs_edit, 2, 3)

        self.filter_combo.currentIndexChanged.connect(
            lambda _i: self._update_filter_controls(self._combo_data(self.filter_combo))
        )
        self._update_filter_controls(self._combo_data(self.filter_combo))
        self.ftype_combo.currentTextChanged.connect(self._update_ftype_controls)
        self._update_ftype_controls(self.ftype_combo.currentText())
        return box

    def _build_spike_section(self) -> QtWidgets.QGroupBox:
        box = QtWidgets.QGroupBox("Opzioni spike train")
        grid = QtWidgets.QGridLayout(box)
        grid.setHorizontalSpacing(12)

        self.smoothing_edit = QtWidgets.QLineEdit("5.0")
        grid.addWidget(QtWidgets.QLabel("Smussamento (ms):"), 0, 0)
        grid.addWidget(self.smoothing_edit, 0, 1)

        self.threshold_combo = QtWidgets.QComboBox()
        self.threshold_combo.addItem("Percentile", "percentile")
        self.threshold_combo.addItem("Sigma", "sigma")
        grid.addWidget(QtWidgets.QLabel("Metodo soglia:"), 0, 2)
        grid.addWidget(self.threshold_combo, 0, 3)

        self.percentile_edit = QtWidgets.QLineEdit("85.0")
        grid.addWidget(QtWidgets.QLabel("Percentile:"), 0, 4)
        grid.addWidget(self.percentile_edit, 0, 5)

        self.sigma_scale_edit = QtWidgets.QLineEdit("1.0")
        grid.addWidget(QtWidgets.QLabel("Scala sigma:"), 0, 6)
        grid.addWidget(self.sigma_scale_edit, 0, 7)

        self.dead_time_edit = QtWidgets.QLineEdit("65.0")
        self.window_edit = QtWidgets.QLineEdit()
        grid.addWidget(QtWidgets.QLabel("Tempo morto (ms):"), 1, 0)
        grid.addWidget(self.dead_time_edit, 1, 1)
        grid.addWidget(QtWidgets.QLabel("Finestra fissa (ms):"), 1, 2)
        grid.addWidget(self.window_edit, 1, 3)

        self.save_spike_full_check = QtWidgets.QCheckBox("Salva stream completo con spike")
        self.save_spike_full_check.setChecked(True)
        grid.addWidget(self.save_spike_full_check, 1, 4, 1, 2)

        self.save_spike_trace_check = QtWidgets.QCheckBox("Salva sola traccia spike")
        self.save_spike_trace_check.setChecked(True)
        grid.addWidget(self.save_spike_trace_check, 1, 6, 1, 2)

        self.polarity_combo = QtWidgets.QComboBox()
        self.polarity_combo.addItem("Tutti", "all")
        self.polarity_combo.addItem("Positivi", "positive")
        self.polarity_combo.addItem("Negativi", "negative")
        grid.addWidget(QtWidgets.QLabel("Polarità picchi:"), 2, 0)
        grid.addWidget(self.polarity_combo, 2, 1)

        self.polarity_window_edit = QtWidgets.QLineEdit()
        grid.addWidget(QtWidgets.QLabel("Finestra polarità (ms):"), 2, 2)
        grid.addWidget(self.polarity_window_edit, 2, 3)

        self.pre_shift_edit = QtWidgets.QLineEdit("0.0")
        grid.addWidget(QtWidgets.QLabel("Anticipo spike (ms):"), 2, 4)
        grid.addWidget(self.pre_shift_edit, 2, 5)

        self.akaike_window_edit = QtWidgets.QLineEdit()
        grid.addWidget(QtWidgets.QLabel("Finestra Akaike (ms):"), 2, 6)
        grid.addWidget(self.akaike_window_edit, 2, 7)

        self.mer_window_edit = QtWidgets.QLineEdit()
        self.mer_ratio_edit = QtWidgets.QLineEdit()
        grid.addWidget(QtWidgets.QLabel("Finestra MER (ms):"), 3, 0)
        grid.addWidget(self.mer_window_edit, 3, 1)
        grid.addWidget(QtWidgets.QLabel("Rapporto MER min:"), 3, 2)
        grid.addWidget(self.mer_ratio_edit, 3, 3)

        self.kurt_window_edit = QtWidgets.QLineEdit()
        self.kurt_min_edit = QtWidgets.QLineEdit()
        grid.addWidget(QtWidgets.QLabel("Finestra kurtosi (ms):"), 3, 4)
        grid.addWidget(self.kurt_window_edit, 3, 5)
        grid.addWidget(QtWidgets.QLabel("Kurtosi min:"), 3, 6)
        grid.addWidget(self.kurt_min_edit, 3, 7)
        return box
    
    def _build_table_section(self) -> QtWidgets.QGroupBox:
        box = QtWidgets.QGroupBox("File e shot")
        vbox = QtWidgets.QVBoxLayout(box)

        self.table = QtWidgets.QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Numero file", "Shot/Traccia", "File associato"])
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection)
        vbox.addWidget(self.table, stretch=1)

        btn_row = QtWidgets.QHBoxLayout()
        self.associate_btn = QtWidgets.QPushButton("Associa...")
        self.associate_btn.clicked.connect(self._associate_selected_file)
        btn_row.addWidget(self.associate_btn)

        self.remove_btn = QtWidgets.QPushButton("Rimuovi")
        self.remove_btn.clicked.connect(self._clear_selected_file)
        btn_row.addWidget(self.remove_btn)

        self.auto_btn = QtWidgets.QPushButton("Associa automaticamente")
        self.auto_btn.clicked.connect(self._auto_associate_from_folder)
        btn_row.addWidget(self.auto_btn)
        vbox.addLayout(btn_row)
        return box

    def _build_corr_section(self) -> QtWidgets.QGroupBox:
        box = QtWidgets.QGroupBox("Opzioni correlazione")
        grid = QtWidgets.QGridLayout(box)
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(10)

        mode_row = QtWidgets.QHBoxLayout()
        mode_row.addWidget(QtWidgets.QLabel("Metodo:"))
        self.mode_spike_radio = QtWidgets.QRadioButton("Spike train")
        self.mode_spike_radio.setChecked(True)
        self.mode_template_radio = QtWidgets.QRadioButton("Traccia interna")
        self.mode_external_radio = QtWidgets.QRadioButton("Traccia esterna")
        mode_row.addWidget(self.mode_spike_radio)
        mode_row.addWidget(self.mode_template_radio)
        mode_row.addWidget(self.mode_external_radio)
        mode_row.addStretch()
        grid.addLayout(mode_row, 0, 0, 1, 6)

        self.corr_mode_group = QtWidgets.QButtonGroup(box)
        self.corr_mode_group.addButton(self.mode_spike_radio, 0)
        self.corr_mode_group.addButton(self.mode_template_radio, 1)
        self.corr_mode_group.addButton(self.mode_external_radio, 2)

        self.corr_prepick_check = QtWidgets.QCheckBox("Ignora porzione prima del primo pick")
        self.corr_prepick_check.setChecked(DEFAULT_CORR_PRE_PICK_ONLY)
        self.corr_prepick_check.setToolTip(
            "Valido solo per Spike train: azzera i campioni prima del primo pick."
        )
        grid.addWidget(self.corr_prepick_check, 1, 0, 1, 3)

        self.corr_trace_label = QtWidgets.QLabel("Traccia da correlare:")
        self.corr_trace_label.setToolTip(
            "Numero della traccia da usare come riferimento (solo Spike train)."
        )
        self.corr_trace_spin = QtWidgets.QSpinBox()
        self.corr_trace_spin.setRange(1, 10000)
        self.corr_trace_spin.setValue(1)
        grid.addWidget(self.corr_trace_label, 2, 0)
        grid.addWidget(self.corr_trace_spin, 2, 1)

        self.corr_cut_label = QtWidgets.QLabel("Taglio sismogramma (ms):")
        self.corr_cut_edit = QtWidgets.QLineEdit("0.0")
        grid.addWidget(self.corr_cut_label, 3, 0)
        grid.addWidget(self.corr_cut_edit, 3, 1)

        delay_label = QtWidgets.QLabel("Ritardo altre tracce (ms):")
        delay_label.setToolTip(
            "Prima della correlazione ritarda tutte le tracce tranne la shot del valore "
            "inserito. Dopo la correlazione: 100 ms su tutte le tracce del file correlato "
            "e 100 ms + questo valore sulla shot, per riallineare il sismogramma. 0 = disattivato."
        )
        grid.addWidget(delay_label, 4, 0)
        self.corr_non_shot_delay_edit = QtWidgets.QLineEdit("0.0")
        grid.addWidget(self.corr_non_shot_delay_edit, 4, 1)

        self.external_path_widget = QtWidgets.QWidget()
        ext_row = QtWidgets.QHBoxLayout(self.external_path_widget)
        ext_row.setContentsMargins(0, 0, 0, 0)
        ext_row.setSpacing(8)
        self.external_path_label = QtWidgets.QLabel("File pilota:")
        ext_row.addWidget(self.external_path_label)
        self.external_path_edit = QtWidgets.QLineEdit()
        self.external_path_edit.setPlaceholderText(
            "Percorso file pilota (opzionale per traccia interna)"
        )
        ext_row.addWidget(self.external_path_edit, stretch=1)
        self.external_path_button = QtWidgets.QPushButton("...")
        self.external_path_button.clicked.connect(self._choose_external_trace)
        self.external_path_button.setFixedSize(30, 24)
        ext_row.addWidget(self.external_path_button)
        grid.addWidget(self.external_path_widget, 5, 0, 1, 6)

        self.external_opts_widget = QtWidgets.QWidget()
        ext_opts = QtWidgets.QGridLayout(self.external_opts_widget)
        ext_opts.setContentsMargins(0, 0, 0, 0)
        ext_opts.setHorizontalSpacing(12)
        self.external_trace_label = QtWidgets.QLabel("Traccia pilota n.:")
        self.external_trace_spin = QtWidgets.QSpinBox()
        self.external_trace_spin.setRange(1, 9999)
        self.external_trace_spin.setValue(1)
        ext_opts.addWidget(self.external_trace_label, 0, 0)
        ext_opts.addWidget(self.external_trace_spin, 0, 1)
        self.corr_window_label = QtWidgets.QLabel("Finestra correlazione (ms):")
        self.corr_window_label.setToolTip("Durata massima del sismogramma generato dalla correlazione.")
        self.corr_window_edit = QtWidgets.QLineEdit("2000")
        ext_opts.addWidget(self.corr_window_label, 0, 2)
        ext_opts.addWidget(self.corr_window_edit, 0, 3)
        self.external_auto_center_check = QtWidgets.QCheckBox("Centratura automatica")
        self.external_auto_center_check.setChecked(True)
        ext_opts.addWidget(self.external_auto_center_check, 0, 4)
        grid.addWidget(self.external_opts_widget, 6, 0, 1, 6)

        self.start_batch_btn = QtWidgets.QPushButton("Avvia elaborazione")
        self.start_batch_btn.setMinimumHeight(36)
        self.start_batch_btn.clicked.connect(self._start_processing)
        grid.addWidget(self.start_batch_btn, 7, 0, 1, 3)

        self.start_corr_btn = QtWidgets.QPushButton("Genera sismogrammi correlati")
        self.start_corr_btn.setMinimumHeight(36)
        self.start_corr_btn.clicked.connect(self._start_correlation_batch)
        grid.addWidget(self.start_corr_btn, 7, 3, 1, 3)

        self._corr_spike_only_widgets = [
            self.corr_prepick_check,
            self.corr_trace_label,
            self.corr_trace_spin,
            self.corr_cut_label,
            self.corr_cut_edit,
        ]
        self._corr_template_external_widgets = [
            self.external_path_label,
            self.external_path_edit,
            self.external_path_button,
            self.external_trace_label,
            self.external_trace_spin,
            self.corr_window_label,
            self.corr_window_edit,
        ]
        self._corr_external_only_widgets = [
            self.external_auto_center_check,
        ]

        for radio in (
            self.mode_spike_radio,
            self.mode_template_radio,
            self.mode_external_radio,
        ):
            radio.toggled.connect(self._update_corr_mode_controls)
        self._update_corr_mode_controls()
        return box

    def _build_log_section(self) -> QtWidgets.QGroupBox:
        box = QtWidgets.QGroupBox("Registro operazioni")
        vbox = QtWidgets.QVBoxLayout(box)
        self.log_edit = QtWidgets.QPlainTextEdit()
        self.log_edit.setReadOnly(True)
        self.log_edit.setMinimumHeight(140)
        font = QtGui.QFont("Consolas", 10)
        self.log_edit.setFont(font)
        vbox.addWidget(self.log_edit, stretch=1)
        return box
    
    # ----------------------------------------------------------- handlers ----

    def _choose_excel(self) -> None:
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Seleziona file Excel (colonne: numero file, shot)",
            "",
            "Excel (*.xlsx *.xls);;Tutti i file (*.*)",
        )
        if path:
            self.excel_edit.setText(path)
            self._reload_excel()

    def _reload_excel(self) -> None:
        path = self.excel_edit.text().strip()
        if not path:
            QtWidgets.QMessageBox.warning(self, "Nessun file", "Seleziona prima l'Excel.")
            return
        
        if pd is None:
            QtWidgets.QMessageBox.critical(
                self,
                "pandas mancante",
                "Installa 'pandas' e 'openpyxl' per importare l'Excel.\n"
                "Esegui: pip install pandas openpyxl",
            )
            return
        
        excel_path = Path(path)
        if not excel_path.exists():
            QtWidgets.QMessageBox.critical(self, "File inesistente", f"{excel_path} non trovato.")
            return
       
        try:
            df = pd.read_excel(excel_path, header=None).iloc[:, :2]
        except Exception as exc: 
            QtWidgets.QMessageBox.critical(self, "Errore lettura Excel", str(exc))
            return
        
        df.columns = ["file", "shot"]
        instructions: Dict[str, int] = {}
        errors = []
        for _, row in df.iterrows():
            try:
                file_id = normalize_file_identifier(row["file"])
                shot = normalize_shot(row["shot"])
            except ValueError as exc:
                errors.append(str(exc))
                continue

            if file_id in instructions:
                errors.append(f"Numero file duplicato: {file_id}")
                continue

            instructions[file_id] = shot

        if not instructions:
            QtWidgets.QMessageBox.critical(self, "Excel non valido", "Nessuna riga utilizzabile e stata importata.")
            return
        
        self.instructions = instructions
        self.file_map = {k: v for k, v in self.file_map.items() if k in instructions}
        self._refresh_table()
        self._log(f"Importate {len(instructions)} righe da {excel_path.name}.")
        if errors:
            self._log("Righe ignorate:\n - " + "\n - ".join(errors[:5]))

    def _choose_source_dir(self) -> None:
        dialog = QtWidgets.QFileDialog(self, "Scegli cartella con i file SEG-Y")
        dialog.setFileMode(QtWidgets.QFileDialog.FileMode.Directory)
        dialog.setOption(QtWidgets.QFileDialog.Option.ShowDirsOnly, False)
        #dialog.setOption(QtWidgets.QFileDialog.Option.DontUseNativeDialog, True)
        current = self.source_edit.text().strip()
        if current:
            dialog.setDirectory(current)
        if dialog.exec():
            selected = dialog.selectedFiles()
            if selected:
                self.source_edit.setText(selected[0])

    def _choose_output_dir(self) -> None:
        path = QtWidgets.QFileDialog.getExistingDirectory(self, "Scegli cartella di destinazione")
        if path:
            self.output_edit.setText(path)

    def _choose_external_trace(self) -> None:
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Scegli traccia esterna per la correlazione",
            self.source_edit.text(),
            "SEG-Y / DAT (*.sgy *.segy *.dat);;Tutti i file (*.*)",
        )
        if path:
            self.external_path_edit.setText(path)

    def _associate_selected_file(self) -> None:
        row = self.table.currentRow()
        if row < 0:
            QtWidgets.QMessageBox.information(self, "Nessuna riga", "Seleziona un numero file prima di associare.")
            return
        
        file_item = self.table.item(row, 0)
        if file_item is None:
            return
        
        file_id = file_item.text()
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            f"Scegli file per {file_id}",
            self.source_edit.text(),
            "SEG-Y / DAT (*.sgy *.segy *.dat);;Tutti i file (*.*)",
        )

        if path:
            self.file_map[file_id] = path
            self._refresh_table()
            self._log(f"Associato {Path(path).name} al file {file_id}.")

    def _clear_selected_file(self) -> None:
        row = self.table.currentRow()
        if row < 0:
            return
        
        file_item = self.table.item(row, 0)
        if file_item is None:
            return
        
        file_id = file_item.text()
        if file_id in self.file_map:
            del self.file_map[file_id]
            self._refresh_table()
            self._log(f"Associazione rimossa per {file_id}.")

    def _auto_associate_from_folder(self) -> None:
        if not self.instructions:
            QtWidgets.QMessageBox.information(self, "Nessun dato", "Carica prima l'Excel.")
            return
        
        folder_str = self.source_edit.text().strip()
        if not folder_str:
            QtWidgets.QMessageBox.information(self, "Cartella mancante", "Seleziona una cartella sorgente.")
            return
        
        folder = Path(folder_str)
        if not folder.is_dir():
            QtWidgets.QMessageBox.critical(self, "Percorso non valido", f"{folder} non e una cartella.")
            return
        
        candidates: Dict[str, Path] = {}
        duplicate = False
        for path in folder.rglob("*"):
            if not path.is_file():
                continue

            if path.suffix.lower() not in SUPPORTED_SUFFIXES:
                continue

            key = path.stem.casefold()
            if key in candidates:
                duplicate = True
                continue

            candidates[key] = path
        associated = 0
        missing = []

        for file_id in self.instructions:
            path = candidates.get(file_id.casefold())
            if path is None:
                missing.append(file_id)
                continue

            self.file_map[file_id] = str(path)
            associated += 1
        self._refresh_table()
        msg = f"Associazione automatica completata: {associated} file collegati."
        if missing:
            msg += f" Mancano: {', '.join(missing[:5])}"
            if len(missing) > 5:
                msg += "..."
        self._log(msg)
        if duplicate:
            self._log("Attenzione: trovati file con nomi duplicati, e stata usata la prima occorrenza.")

    # ----------------------------------------------------------- processing ----

    def _start_processing(self) -> None:
        if self._processing:
            return
        
        if not self.instructions:
            QtWidgets.QMessageBox.warning(self, "Istruzioni mancanti", "Importa prima il file Excel con gli shot.")
            return
        
        missing = [fid for fid in self.instructions if fid not in self.file_map]
        if missing:
            QtWidgets.QMessageBox.critical(
                self,
                "Associazioni incomplete",
                "Associa tutti i file prima di procedere.\n"
                f"Mancano: {', '.join(missing[:5])}"
                + ("..." if len(missing) > 5 else ""),
            )
            return
        
        output_dir = self.output_edit.text().strip()
        if not output_dir:
            QtWidgets.QMessageBox.warning(self, "Cartella mancante", "Indica una cartella di output.")
            return
        
        try:
            options = self._collect_batch_options(Path(output_dir))
        except ValueError as exc:
            QtWidgets.QMessageBox.critical(self, "Parametri non validi", str(exc))
            return
        
        options.base_output_dir.mkdir(parents=True, exist_ok=True)
        self._processing = True
        self.start_batch_btn.setEnabled(False)
        self.status_label.setText("Elaborazione in corso...")
        self._log("=== Avvio batch Syspike ===")
        threading.Thread(target=self._run_batch, args=(options,), daemon=True).start()

    def _start_correlation_batch(self) -> None:
        if self._processing or self._corr_processing:
            return
        
        if not self.instructions:
            QtWidgets.QMessageBox.warning(
                self, "Istruzioni mancanti", "Importa prima il file Excel con gli shot.")
            return
        
        missing = [fid for fid in self.instructions if fid not in self.file_map]
        if missing:
            QtWidgets.QMessageBox.critical(
                self,
                "Associazioni incomplete",
                "Associa tutti i file prima di procedere.\n"
                f"Mancano: {', '.join(missing[:5])}"
                + ("..." if len(missing) > 5 else ""),
            )
            return
        
        output_dir = self.output_edit.text().strip()
        if not output_dir:
            QtWidgets.QMessageBox.warning(self, "Cartella mancante", "Indica una cartella di output.")
            return
        
        try:
            options = self._collect_batch_options(Path(output_dir), require_outputs=False)
        except ValueError as exc:
            QtWidgets.QMessageBox.critical(self, "Parametri non validi", str(exc))
            return
        
        options.base_output_dir.mkdir(parents=True, exist_ok=True)
        self._corr_processing = True
        self.start_corr_btn.setEnabled(False)
        self.status_label.setText("Correlazione in corso...")
        self._log("=== Avvio batch correlazione ===")
        threading.Thread(target=self._run_correlation_batch, args=(options,), daemon=True).start()

    def _combo_data(self, combo: QtWidgets.QComboBox, default: str = "") -> str:
        raw = combo.currentData()
        if raw is None or raw == "":
            text = (combo.currentText() or "").strip()
            return text or default
        return str(raw)

    def _collect_batch_options(self, output_dir: Path, *, require_outputs: bool = True) -> BatchOptions:

        filter_type = self._combo_data(self.filter_combo, "none")
        freq = parse_optional_float(self.freq_edit.text())
        freq_min = parse_optional_float(self.freq_min_edit.text())
        freq_max = parse_optional_float(self.freq_max_edit.text())
        corners = parse_int(self.corners_edit.text(), "corners", minimum=1)
        sampling_rate = parse_optional_float(self.sampling_rate_edit.text())
        rp = parse_optional_float(self.rp_edit.text())
        rs = parse_optional_float(self.rs_edit.text())

        if filter_type in {"lowpass", "highpass"} and freq is None:
            raise ValueError("Specificare 'Freq (Hz)' per il filtro selezionato.")
        if filter_type in {"bandpass", "bandstop"}:
            if freq_min is None or freq_max is None:
                raise ValueError("Per i filtri banda indicare freq min e max.")
            if freq_min >= freq_max:
                raise ValueError("Freq min deve essere < freq max.")

        smoothing = parse_float(self.smoothing_edit.text(), "Smussamento (ms)", minimum=0.0)
        percentile = parse_float(self.percentile_edit.text(), "Percentile", minimum=0.0)
        if not 0 <= percentile <= 100:
            raise ValueError("Il percentile deve essere tra 0 e 100.")
        sigma_scale = parse_float(self.sigma_scale_edit.text(), "Scala sigma", minimum=0.0)
        dead_time = parse_float(self.dead_time_edit.text(), "Tempo morto (ms)", minimum=0.0)
        window_ms = parse_optional_float(self.window_edit.text())
        if window_ms is not None and window_ms <= 0:
            raise ValueError("La finestra fissa deve essere > 0 ms.")
        peak_polarity = self._combo_data(self.polarity_combo, "all")
        if peak_polarity not in {"all", "positive", "negative"}:
            raise ValueError("Polarità picchi non valida.")
        polarity_window = parse_optional_float(self.polarity_window_edit.text())
        if polarity_window is not None and polarity_window < 0:
            raise ValueError("La finestra polarità deve essere >= 0 ms.")
        pre_shift_raw = self.pre_shift_edit.text()
        if pre_shift_raw.strip():
            pre_shift_ms = parse_float(pre_shift_raw, "Anticipo spike (ms)")
        else:
            pre_shift_ms = 0.0
        akaike_window = parse_optional_float(self.akaike_window_edit.text())
        if akaike_window is not None and akaike_window <= 0:
            raise ValueError("La finestra Akaike deve essere > 0 ms.")
        mer_window = parse_optional_float(self.mer_window_edit.text())
        if mer_window is not None and mer_window <= 0:
            raise ValueError("La finestra MER deve essere > 0 ms.")
        mer_ratio = parse_optional_float(self.mer_ratio_edit.text())
        if mer_ratio is not None and mer_ratio <= 0:
            raise ValueError("MER ratio deve essere > 0.")
        kurt_window = parse_optional_float(self.kurt_window_edit.text())
        if kurt_window is not None and kurt_window <= 0:
            raise ValueError("La finestra kurtosi deve essere > 0 ms.")
        kurt_min = parse_optional_float(self.kurt_min_edit.text())
        if kurt_min is not None and kurt_min <= 0:
            raise ValueError("Kurtosi minima deve essere > 0.")

        corr_cut_ms = parse_float(
            self.corr_cut_edit.text() or "0.0",
            "Taglio iniziale (ms)",
            minimum=0.0,
        )
        non_shot_delay_raw = (self.corr_non_shot_delay_edit.text() or "0.0").strip()
        if non_shot_delay_raw:
            non_shot_delay_ms = parse_float(
                non_shot_delay_raw,
                "Ritardo altre tracce (ms)",
                minimum=0.0,
            )
        else:
            non_shot_delay_ms = 0.0
        corr_reference_trace = int(self.corr_trace_spin.value())
        corr_mode = self._current_corr_mode()
        external_trace_path = None
        external_trace_number = int(self.external_trace_spin.value())
        corr_window_ms = parse_float(
            self.corr_window_edit.text() or "2000",
            "Finestra correlazione (ms)",
            minimum=1.0,
        )
        external_corr_auto_center = self.external_auto_center_check.isChecked()

        external_path_str = self.external_path_edit.text().strip()
        if external_path_str:
            path = Path(external_path_str)
            if not path.exists():
                raise ValueError(f"File pilota non trovato: {path}")
            external_trace_path = path
        elif corr_mode == "external":
            raise ValueError("Per la correlazione con traccia esterna seleziona il file pilota.")

        if (
            require_outputs
            and not self.save_filtered_check.isChecked()
            and not self.save_spike_full_check.isChecked()
            and not self.save_spike_trace_check.isChecked()
        ):
            raise ValueError("Seleziona almeno un output (filtrato o spike).")

        return BatchOptions(
            input_format=self._input_format,
            output_format=self._output_format,
            filter_type=filter_type,
            freq=freq,
            freq_min=freq_min,
            freq_max=freq_max,
            corners=corners,
            zerophase=self.zerophase_check.isChecked(),
            ftype=self._ftype_key(self.ftype_combo.currentText()),
            rp=rp,
            rs=rs,
            sampling_rate=sampling_rate,
            save_filtered=self.save_filtered_check.isChecked(),
            save_spike_full=self.save_spike_full_check.isChecked(),
            save_spike_trace=self.save_spike_trace_check.isChecked(),
            smoothing_ms=smoothing,
            threshold_method=self._combo_data(self.threshold_combo, "percentile"),
            percentile=percentile,
            sigma_scale=sigma_scale,
            dead_time_ms=dead_time,
            window_ms=window_ms,
            peak_polarity=peak_polarity,
            polarity_window_ms=polarity_window,
            pre_shift_ms=pre_shift_ms,
            akaike_window_ms=akaike_window,
            mer_window_ms=mer_window,
            mer_ratio_min=mer_ratio,
            kurtosis_window_ms=kurt_window,
            kurtosis_min=kurt_min,
            corr_mute_ms=DEFAULT_CORR_MUTE_MS,
            corr_agc_ms=DEFAULT_CORR_AGC_MS,
            corr_normalize=DEFAULT_CORR_NORMALIZE,
            corr_pre_pick_only=self.corr_prepick_check.isChecked(),
            corr_cut_ms=corr_cut_ms,
            corr_reference_trace=corr_reference_trace,
            non_shot_delay_ms=non_shot_delay_ms,
            corr_mode=corr_mode,
            external_trace_path=external_trace_path,
            external_trace_number=external_trace_number,
            corr_window_ms=corr_window_ms,
            external_corr_auto_center=external_corr_auto_center,
            base_output_dir=output_dir,
        )

    def _current_corr_mode(self) -> str:
        if self.mode_template_radio.isChecked():
            return "template"
        if self.mode_external_radio.isChecked():
            return "external"
        return "spike"

    def _update_corr_mode_controls(self) -> None:
        if not hasattr(self, "_corr_spike_only_widgets"):
            return
        mode = self._current_corr_mode()
        show_spike = mode == "spike"
        show_template = mode == "template"
        show_external = mode == "external"

        for widget in self._corr_spike_only_widgets:
            widget.setVisible(show_spike)

        show_template_or_external = show_template or show_external
        for widget in self._corr_template_external_widgets:
            widget.setVisible(show_template_or_external)

        for widget in self._corr_external_only_widgets:
            widget.setVisible(show_external)

        self.external_path_widget.setVisible(show_template_or_external)
        self.external_opts_widget.setVisible(show_template_or_external)

    def _update_filter_controls(self, filter_type: str) -> None:
        filter_type = (filter_type or "").lower()
        show_single = filter_type in {"lowpass", "highpass"}
        show_band = filter_type in {"bandpass", "bandstop"}

        self.freq_label.setVisible(show_single)
        self.freq_edit.setVisible(show_single)

        self.freq_band_label.setVisible(show_band)
        self.freq_min_edit.setVisible(show_band)
        self.freq_max_edit.setVisible(show_band)

    def _update_ftype_controls(self, ftype: str | None = None) -> None:
        if ftype is None and hasattr(self, "ftype_combo"):
            ftype = self.ftype_combo.currentText()
        normalized = self._ftype_key(ftype)
        show_rp = normalized in {"cheby1", "chebyshev1", "ellip", "elliptic", "cauer"}
        show_rs = normalized in {"cheby2", "chebyshev2", "ellip", "elliptic", "cauer"}

        self.rp_label.setVisible(show_rp)
        self.rp_edit.setVisible(show_rp)
        self.rs_label.setVisible(show_rs)
        self.rs_edit.setVisible(show_rs)

    def _ftype_key(self, value: str | None) -> str:
        mapping = {
            "butterworth": "butter",
            "chebyshev i": "cheby1",
            "chebyshev ii": "cheby2",
            "ellittico (ellip)": "ellip",
            "elliptic": "ellip",
        }
        normalized = (value or "").strip().lower()
        return mapping.get(normalized, normalized or "butter")
    
    def _run_batch(self, options: BatchOptions) -> None:
        processed = 0
        try:
            for file_id, shot in self.instructions.items():
                path_str = self.file_map.get(file_id)
                if not path_str:
                    self._log_async(f"[{file_id}] Nessun file associato; salto.")
                    continue

                source = Path(path_str)
                if not source.exists():
                    self._log_async(f"[{file_id}] File inesistente: {source}")
                    continue

                self._log_async(f"[{file_id}] Elaborazione {source.name} (shot {shot})")
                
                try:
                    stream = read_stream(source, fmt=options.input_format)
                except Exception as exc:
                    self._log_async(f"[{file_id}] ERRORE lettura: {exc}")
                    continue

                filtered_path = (
                    options.base_output_dir / "filtered" / f"{source.stem}_filtered.sgy"
                    if options.save_filtered
                    else None)
                
                spike_full_path = (
                    options.base_output_dir
                    / "spike_full"
                    / f"{source.stem}_spike_full.sgy"
                    if options.save_spike_full
                    else None
                )
                spike_trace_path = (
                    options.base_output_dir
                    / "spike_trace"
                    / f"{source.stem}_spike_trace.sgy"
                    if options.save_spike_trace
                    else None
                )
                if filtered_path:
                    filtered_path.parent.mkdir(parents=True, exist_ok=True)
                if spike_full_path:
                    spike_full_path.parent.mkdir(parents=True, exist_ok=True)
                if spike_trace_path:
                    spike_trace_path.parent.mkdir(parents=True, exist_ok=True)

                args = self._build_cli_args(
                    options,
                    shot,
                    filtered_path,
                    spike_full_path,
                    spike_trace_path,
                )

                try:
                    apply_filter_to_stream(stream, args)
                except Exception as exc:
                    self._log_async(f"[{file_id}] ERRORE filtro: {exc}")
                    continue

                if args.save_filtered:
                    try:
                        save_filtered_stream(
                            stream,
                            Path(args.save_filtered),
                            args.save_format or args.format,
                        )
                    except Exception as exc:
                        self._log_async(
                            f"[{file_id}] ERRORE salvataggio filtrato: {exc}"
                        )
                        continue

                if args.spike_output or args.spike_trace_only_output:
                    try:
                        apply_spike_pipeline(stream, args, shot)
                    except Exception as exc:
                        self._log_async(f"[{file_id}] ERRORE spike: {exc}")
                        continue

                processed += 1
                outputs = []
                if args.save_filtered:
                    outputs.append(Path(args.save_filtered).name)
                if args.spike_output:
                    outputs.append(Path(args.spike_output).name)
                if args.spike_trace_only_output:
                    outputs.append(Path(args.spike_trace_only_output).name)
                self._log_async(f"[{file_id}] Completato. File generati: {', '.join(outputs)}")

            summary = (f"Batch concluso: {processed}/{len(self.instructions)} file riusciti.")
            self._log_async(summary)
            self._set_status_async(summary)
        except Exception as exc:  
            self._log_async(f"Batch interrotto per errore inatteso: {exc}")
            self._set_status_async("Errore batch - controlla il log.")
        finally:
            self._processing = False
            self._invoke_main(lambda: self.start_batch_btn.setEnabled(True))

    def _apply_non_shot_delay_ms(
        self,
        stream,
        shot: int,
        delay_ms: float,
        file_id: str,
    ) -> None:
        """Ritarda nel tempo le tracce diverse dalla shot (stessa lunghezza, zeri in testa)."""
        if delay_ms <= 0:
            return
        shot_idx = shot - 1
        n = len(stream)
        if not (0 <= shot_idx < n):
            self._log_async(
                f"[{file_id}] Ritardo non-shot: shot {shot} fuori range ({n} tracce), salto ritardo."
            )
            return
        count = 0
        for idx in range(n):
            if idx == shot_idx:
                continue
            trace = stream[idx]
            if apply_trace_delay_ms(trace, delay_ms):
                count += 1
            else:
                self._log_async(
                    f"[{file_id}] Ritardo non-shot: traccia {idx + 1} non modificata "
                    f"(delta assente o ritardo nullo)."
                )
        self._log_async(
            f"[{file_id}] Ritardo {delay_ms:.2f} ms su {count} tracce (non-shot); "
            f"dopo la correlazione: 100 ms su tutte, shot 100 + {delay_ms:.2f} ms."
        )

    def _run_correlation_batch(self, options: BatchOptions) -> None:
        processed = 0
        try:
            for file_id, shot in self.instructions.items():
                path_str = self.file_map.get(file_id)
                if not path_str:
                    self._log_async(f"[{file_id}] Nessun file associato; salto.")
                    continue
                source = Path(path_str)
                if not source.exists():
                    self._log_async(f"[{file_id}] File inesistente: {source}")
                    continue
                self._log_async(f"[{file_id}] Correlazione {source.name} (shot {shot})")
                try:
                    stream = read_stream(source, fmt=options.input_format)
                except Exception as exc:
                    self._log_async(f"[{file_id}] ERRORE lettura: {exc}")
                    continue

                if not stream:
                    self._log_async(f"[{file_id}] ERRORE lettura: stream vuoto.")
                    continue

                if not self._validate_trace_index(shot, len(stream), "shot", file_id):
                    continue

                if options.non_shot_delay_ms > 0:
                    self._apply_non_shot_delay_ms(
                        stream, shot, options.non_shot_delay_ms, file_id
                    )

                mode = options.corr_mode
                if mode == "template":
                    if self._run_template_correlation_file(
                        file_id, shot, source, stream, options
                    ):
                        processed += 1
                elif mode == "external":
                    if self._run_external_correlation_file(
                        file_id, shot, source, stream, options
                    ):
                        processed += 1
                else:
                    spike_corr_path = (
                        options.base_output_dir
                        / "spike_corr"
                        / f"{source.stem}_spike_corr.sgy"
                    )
                    spike_corr_path.parent.mkdir(parents=True, exist_ok=True)

                    args = self._build_corr_cli_args(options, shot, spike_corr_path)

                    try:
                        apply_filter_to_stream(stream, args)
                    except Exception as exc:
                        self._log_async(f"[{file_id}] ERRORE filtro: {exc}")
                        continue

                    try:
                        apply_cross_pipeline(stream, args, shot)
                    except Exception as exc:
                        self._log_async(f"[{file_id}] ERRORE correlazione: {exc}")
                        continue

                    if not spike_corr_path.exists():
                        self._log_async(
                            f"[{file_id}] Correlazione non prodotta: file output mancante."
                        )
                        continue

                    self._convert_segy_to_seg2(spike_corr_path, file_id)
                    processed += 1
                    self._log_async(
                        f"[{file_id}] Correlazione spike completata -> {spike_corr_path.stem}.sg2"
                    )

            summary = (f"Correlazione conclusa: {processed}/{len(self.instructions)} file riusciti.")
            self._log_async(summary)
            self._set_status_async(summary)
        except Exception as exc:
            self._log_async(f"Correlazione interrotta per errore inatteso: {exc}")
            self._set_status_async("Errore correlazione - controlla il log.")
        finally:
            self._corr_processing = False
            self._invoke_main(lambda: self.start_corr_btn.setEnabled(True))

    def _run_template_correlation_file(
        self,
        file_id: str,
        shot: int,
        source: Path,
        stream,
        options: BatchOptions,
    ) -> bool:
        corr_path = (
            options.base_output_dir
            / "xcorr_template"
            / f"{source.stem}_xcorr.sgy"
        )
        corr_path.parent.mkdir(parents=True, exist_ok=True)
        args = self._build_corr_cli_args(options, shot, corr_path)

        working_stream = stream.copy()
        try:
            apply_filter_to_stream(working_stream, args)
        except Exception as exc:
            self._log_async(f"[{file_id}] ERRORE filtro: {exc}")
            return False

        template_trace = self._resolve_template_trace(
            working_stream, shot, options, args, file_id
        )
        if template_trace is None:
            return False

        correlated_stream = self._run_template_correlation(
            working_stream, template_trace, options, file_id
        )
        if correlated_stream is None:
            return False

        if options.non_shot_delay_ms > 0:
            restore_corr_stream_timing(
                correlated_stream, shot, options.non_shot_delay_ms
            )

        try:
            save_filtered_stream(
                correlated_stream,
                corr_path,
                args.save_format or args.format,
            )
        except Exception as exc:
            self._log_async(f"[{file_id}] ERRORE salvataggio correlato: {exc}")
            return False

        self._convert_segy_to_seg2(corr_path, file_id)
        self._log_async(f"[{file_id}] Correlazione (traccia interna) completata.")
        return True

    def _run_external_correlation_file(
        self,
        file_id: str,
        shot: int,
        source: Path,
        stream,
        options: BatchOptions,
    ) -> bool:
        external_path = options.external_trace_path
        if external_path is None:
            self._log_async(
                f"[{file_id}] ERRORE correlazione esterna: nessun file pilota selezionato."
            )
            return False

        out_dir = options.base_output_dir / "xcorr_external"
        out_dir.mkdir(parents=True, exist_ok=True)
        tag = f"{source.stem}_with_{external_path.stem}"

        tmp_dir = out_dir / "_tmp"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        gather_path = tmp_dir / f"{source.stem}_gather.sgy"
        try:
            save_filtered_stream(stream, gather_path, options.input_format)
        except Exception as exc:
            self._log_async(f"[{file_id}] ERRORE preparazione gather: {exc}")
            return False

        try:
            result = run_external_correlation(
                gather_path,
                external_path,
                template_trace_index=options.external_trace_number,
                input_format=options.input_format,
                output_dir=out_dir,
                tag=tag,
                norm="l2",
                lag_window_ms=options.corr_window_ms,
                auto_center=options.external_corr_auto_center,
                write_npy=False,
                write_summary=False,
                write_segy_file=True,
            )
        except Exception as exc:
            self._log_async(f"[{file_id}] ERRORE correlazione esterna: {exc}")
            return False
        finally:
            with suppress(FileNotFoundError):
                gather_path.unlink()

        segy_path = result.get("segy_path")
        if not segy_path:
            self._log_async(f"[{file_id}] Correlazione esterna: output SEG-Y mancante.")
            return False

        segy_path = Path(segy_path)
        if options.non_shot_delay_ms > 0:
            try:
                corr_stream = read_stream(segy_path, fmt=options.input_format)
                restore_corr_stream_timing(
                    corr_stream, shot, options.non_shot_delay_ms
                )
                save_filtered_stream(corr_stream, segy_path, options.input_format)
            except Exception as exc:
                self._log_async(
                    f"[{file_id}] WARNING ripristino timing post-corr: {exc}"
                )

        self._convert_segy_to_seg2(segy_path, file_id)
        self._log_async(f"[{file_id}] Correlazione (traccia esterna) completata.")
        return True

    def _resolve_template_trace(
        self,
        stream,
        shot: int,
        options: BatchOptions,
        args: argparse.Namespace,
        file_id: str,
    ):
        if options.external_trace_path is None:
            shot_idx = shot - 1
            if not (0 <= shot_idx < len(stream)):
                self._log_async(f"[{file_id}] ERRORE template: shot {shot} fuori range.")
                return None
            return stream[shot_idx]

        try:
            template_stream = read_stream(
                options.external_trace_path, fmt=options.input_format
            )
        except Exception as exc:
            self._log_async(
                f"[{file_id}] ERRORE lettura template esterno "
                f"({options.external_trace_path}): {exc}"
            )
            return None

        if not template_stream:
            self._log_async(f"[{file_id}] ERRORE template esterno: file vuoto.")
            return None

        idx = options.external_trace_number - 1
        if not (0 <= idx < len(template_stream)):
            self._log_async(
                f"[{file_id}] ERRORE template esterno: indice "
                f"{options.external_trace_number} non valido."
            )
            return None

        template_args = argparse.Namespace(**vars(args))
        setattr(template_args, "save_filtered", None)
        setattr(template_args, "spike_output", None)
        setattr(template_args, "spike_trace_only_output", None)
        setattr(template_args, "spike_correlated_output", None)
        try:
            apply_filter_to_stream(template_stream, template_args)
        except Exception as exc:
            self._log_async(f"[{file_id}] ERRORE filtro template esterno: {exc}")
            return None

        template_trace = template_stream[idx]
        base_dt = getattr(stream[0].stats, "delta", None)
        template_dt = getattr(template_trace.stats, "delta", None)
        if base_dt in (None, 0) or template_dt in (None, 0):
            self._log_async(f"[{file_id}] ERRORE template: delta non valido.")
            return None
        if abs(float(base_dt) - float(template_dt)) > max(
            1e-9, 1e-6 * abs(float(base_dt))
        ):
            self._log_async(
                f"[{file_id}] ERRORE template: sampling diverso "
                f"({float(base_dt):.6f}s vs {float(template_dt):.6f}s)."
            )
            return None
        return template_trace

    def _run_template_correlation(
        self,
        stream,
        template_trace,
        options: BatchOptions,
        file_id: str,
    ):
        template_data = np.asarray(template_trace.data, dtype=np.float64)
        if template_data.size == 0:
            self._log_async(f"[{file_id}] ERRORE template: dati vuoti.")
            return None

        template_dt = getattr(template_trace.stats, "delta", None)
        if template_dt in (None, 0):
            self._log_async(f"[{file_id}] ERRORE template: delta non valido.")
            return None
        template_dt = float(template_dt)

        correlated = stream.copy()
        template_len = template_data.size
        for idx, trace in enumerate(correlated, start=1):
            data = np.asarray(trace.data, dtype=np.float64)
            dt = getattr(trace.stats, "delta", None)
            if dt in (None, 0):
                self._log_async(
                    f"[{file_id}] ERRORE correlazione: delta mancante sulla traccia {idx}."
                )
                return None
            dt = float(dt)
            if abs(dt - template_dt) > max(1e-9, 1e-6 * abs(template_dt)):
                self._log_async(
                    f"[{file_id}] ERRORE correlazione: sampling mismatch "
                    f"(traccia {idx} {dt:.6f}s vs template {template_dt:.6f}s)."
                )
                return None
            try:
                cc = correlate_template(
                    data,
                    template_data,
                    mode="full",
                    normalize="full",
                    demean=True,
                    method="auto",
                )
            except Exception as exc:
                self._log_async(
                    f"[{file_id}] ERRORE correlate_template sulla traccia {idx}: {exc}"
                )
                return None

            zero_idx = template_len - 1
            corr_window_seconds = (
                options.corr_window_ms * 1e-3
                if options.corr_window_ms > 0
                else MAX_TEMPLATE_CORR_SECONDS
            )
            max_samples = max(1, int(round(corr_window_seconds / dt)))
            end_idx = zero_idx + max_samples
            segment = cc[zero_idx:end_idx]
            if segment.size < max_samples:
                segment = np.pad(
                    segment,
                    (0, max_samples - segment.size),
                    mode="constant",
                    constant_values=0.0,
                )
            trace.data = np.asarray(segment, dtype=np.float32)
            trace.stats.npts = trace.data.size
        return correlated

    def _validate_trace_index(
        self, trace_number: int, total_traces: int, label: str, file_id: str
    ) -> bool:
        if total_traces <= 0:
            self._log_async(f"[{file_id}] ERRORE {label}: stream senza tracce.")
            return False
        if not (1 <= trace_number <= total_traces):
            self._log_async(
                f"[{file_id}] ERRORE {label}: {trace_number} fuori range "
                f"(tracce disponibili: 1-{total_traces})."
            )
            return False
        return True

    def _convert_segy_to_seg2(self, segy_path: Path, file_id: str) -> None:
        try:
            seg2_path = convert_segy_file(
                segy_path,
                output_path=segy_path.with_suffix(".sg2"),
            )
        except Exception as exc:
            self._log_async(
                f"[{file_id}] ERRORE conversione SEG-2 ({segy_path.name}): {exc}"
            )
            return
        with suppress(FileNotFoundError):
            Path(segy_path).unlink()
        self._log_async(f"[{file_id}] Output SEG-2 -> {Path(seg2_path).name}")

    def _build_cli_args(
        self,
        options: BatchOptions,
        shot: int,
        filtered_path: Optional[Path],
        spike_full_path: Optional[Path],
        spike_trace_path: Optional[Path],
    ) -> argparse.Namespace:
        return argparse.Namespace(
            filter=options.filter_type,
            freq=options.freq,
            freq_min=options.freq_min,
            freq_max=options.freq_max,
            corners=options.corners,
            zerophase=options.zerophase,
            ftype=options.ftype,
            rp=options.rp,
            rs=options.rs,
            sampling_rate=options.sampling_rate,
            save_filtered=str(filtered_path) if filtered_path else None,
            save_format=options.output_format,
            format=options.input_format,
            spike_output=str(spike_full_path) if spike_full_path else None,
            spike_trace_only_output=str(spike_trace_path) if spike_trace_path else None,
            spike_trace=shot,
            filter_target_trace=shot if self.filter_shot_only_check.isChecked() else None,
            spike_smoothing_ms=options.smoothing_ms,
            spike_threshold_method=options.threshold_method,
            spike_percentile=options.percentile,
            spike_sigma_scale=options.sigma_scale,
            spike_dead_time_ms=options.dead_time_ms,
            spike_window_ms=options.window_ms,
            spike_peak_polarity=options.peak_polarity,
            spike_polarity_window_ms=options.polarity_window_ms,
            spike_pre_shift_ms=options.pre_shift_ms,
            spike_akaike_window_ms=options.akaike_window_ms,
            spike_mer_window_ms=options.mer_window_ms,
            spike_mer_ratio_min=options.mer_ratio_min,
            spike_kurtosis_window_ms=options.kurtosis_window_ms,
            spike_kurtosis_min=options.kurtosis_min,
        )

    def _build_corr_cli_args(
        self,
        options: BatchOptions,
        shot: int,
        spike_corr_path: Path,
    ) -> argparse.Namespace:
        return argparse.Namespace(
            filter=options.filter_type,
            freq=options.freq,
            freq_min=options.freq_min,
            freq_max=options.freq_max,
            corners=options.corners,
            zerophase=options.zerophase,
            ftype=options.ftype,
            rp=options.rp,
            rs=options.rs,
            sampling_rate=options.sampling_rate,
            save_filtered=None,
            save_format=options.output_format,
            format=options.input_format,
            spike_output=None,
            spike_trace_only_output=None,
            spike_correlated_output=str(spike_corr_path),
            # Legacy batch from Excel must correlate on the shot trace for each file.
            spike_trace=shot,
            filter_target_trace=shot if self.filter_shot_only_check.isChecked() else None,
            spike_smoothing_ms=options.smoothing_ms,
            spike_threshold_method=options.threshold_method,
            spike_percentile=options.percentile,
            spike_sigma_scale=options.sigma_scale,
            spike_dead_time_ms=options.dead_time_ms,
            spike_window_ms=options.window_ms,
            spike_peak_polarity=options.peak_polarity,
            spike_polarity_window_ms=options.polarity_window_ms,
            spike_pre_shift_ms=options.pre_shift_ms,
            spike_akaike_window_ms=options.akaike_window_ms,
            spike_mer_window_ms=options.mer_window_ms,
            spike_mer_ratio_min=options.mer_ratio_min,
            spike_kurtosis_window_ms=options.kurtosis_window_ms,
            spike_kurtosis_min=options.kurtosis_min,
            corr_mute_ms=options.corr_mute_ms,
            corr_agc_ms=options.corr_agc_ms,
            corr_normalize=options.corr_normalize,
            corr_pre_pick_only=options.corr_pre_pick_only,
            corr_cut_ms=options.corr_cut_ms,
            non_shot_delay_ms=options.non_shot_delay_ms,
        )
        
    # ----------------------------------------------------------- utilities ----
    def _refresh_table(self) -> None:
        self.table.setRowCount(0)
        associated = 0
        for file_id in sorted(self.instructions, key=lambda x: (len(x), x)):
            shot = self.instructions[file_id]
            path = self.file_map.get(file_id, "")
            if path:
                associated += 1
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [file_id, str(shot), path]
            for col, value in enumerate(values):
                item = QtWidgets.QTableWidgetItem(value)
                if col < 2:
                    item.setTextAlignment(
                        QtCore.Qt.AlignmentFlag.AlignCenter
                        | QtCore.Qt.AlignmentFlag.AlignVCenter
                    )
                color = QtGui.QColor("#146c43") if path else QtGui.QColor("#c0392b")
                item.setForeground(QtGui.QBrush(color))
                self.table.setItem(row, col, item)
        self.status_label.setText(f"{len(self.instructions)} righe totali - {associated} file associati")

    def _log(self, message: str) -> None:
        self.log_edit.appendPlainText(message)
        cursor = self.log_edit.textCursor()
        cursor.movePosition(QtGui.QTextCursor.MoveOperation.End)
        self.log_edit.setTextCursor(cursor)

    def _log_async(self, message: str) -> None:
        self._invoke_main(lambda: self._log(message))

    def _set_status_async(self, message: str) -> None:
        self._invoke_main(lambda: self.status_label.setText(message))

    def _invoke_main(self, callback) -> None:
        self._invoker.triggered.emit(callback)
    

def normalize_file_identifier(value) -> str:
    if isinstance(value, str):
        normalized = value.strip()
        if not normalized:
            raise ValueError("Numero file vuoto.")
        return normalized
    if isinstance(value, (int, float)):
        if isinstance(value, float):
            if value != value:
                raise ValueError("Numero file mancante.")
            if value.is_integer():
                return str(int(value))
        return str(value)
    raise ValueError(f"Numero file non valido: {value!r}")


def normalize_shot(value) -> int:
    if isinstance(value, (int, float)):
        if isinstance(value, float):
            if value != value:
                raise ValueError("Shot mancante.")
            if not value.is_integer():
                raise ValueError(f"Shot non intero: {value}")
            value = int(value)
        return int(value)
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            raise ValueError("Shot vuoto.")
        return int(stripped)
    raise ValueError(f"Shot non valido: {value!r}")


def parse_optional_float(raw: str) -> Optional[float]:
    raw = raw.strip()
    if not raw:
        return None
    return float(raw)


def parse_float(raw: str, label: str, *, minimum: Optional[float] = None) -> float:
    value = float(raw.strip())
    if minimum is not None and value < minimum:
        raise ValueError(f"{label} deve essere >= {minimum}.")
    return value


def parse_int(raw: str, label: str, *, minimum: Optional[int] = None) -> int:
    value = int(raw.strip())
    if minimum is not None and value < minimum:
        raise ValueError(f"{label} deve essere >= {minimum}.")
    return value


def main() -> None:
    from app.theme import apply_application_theme

    app = QtWidgets.QApplication(sys.argv)
    apply_application_theme(app)
    window = CrossWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
