"""Applica aggiornamenti: installer Inno Setup (consigliato) o patch zip."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from collections.abc import Callable
from pathlib import Path
from typing import Any

from bootstrap import install_root, is_frozen

from updater.download import ProgressCallback, download_file, sha256_file
from updater.version_service import write_local_version


def default_exe_name() -> str:
    if is_frozen():
        return Path(sys.executable).name
    # Suite menu di default in packaging/manifest.json → ProgeoView
    return "ProgeoView.exe"


def _spawn_detached(
    command: list[str],
    *,
    cwd: Path | None = None,
    hide_window: bool = True,
) -> None:
    creationflags = 0
    if os.name == "nt":
        creationflags = (
            subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
        )
        # CREATE_NO_WINDOW nasconde anche il prompt UAC in alcuni casi:
        # per apply_patch.ps1 tenere hide_window=False.
        if hide_window:
            creationflags |= getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    subprocess.Popen(
        command,
        cwd=str(cwd) if cwd else None,
        creationflags=creationflags,
        close_fds=True,
    )


def apply_installer_update(
    installer_info: dict[str, Any],
    *,
    target_version: str,
    progress: ProgressCallback | None = None,
    exit_after: bool = True,
    restart_app: bool = True,
    exe_name: str | None = None,
    install_dir: Path | None = None,
) -> Path:
    """
    Scarica l'installer e lo avvia in modalità silenziosa.
    L'app corrente deve uscire subito dopo questa chiamata (exit_after=True).
    """
    url = str(installer_info.get("url") or "").strip()
    if not url:
        raise RuntimeError("URL installer mancante nel manifest")
    sha = str(installer_info.get("sha256") or "").strip() or None
    timeout_s = float(installer_info.get("timeout_s", 600.0))

    tmp_dir = Path(tempfile.gettempdir()) / "ProgeoView_update"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    setup_path = tmp_dir / "ProgeoView_Setup.exe"
    download_file(
        url,
        setup_path,
        expected_sha256=sha,
        timeout_s=timeout_s,
        progress=progress,
    )

    args = [
        str(setup_path),
        "/VERYSILENT",
        "/SUPPRESSMSGBOXES",
        "/NORESTART",
        "/CLOSEAPPLICATIONS",
        "/RESTARTAPPLICATIONS",
    ]
    _spawn_detached(args)

    # /RESTARTAPPLICATIONS di Inno non sempre riparte se l'app è già uscita:
    # watcher che attende la fine del setup e rilancia l'exe.
    if restart_app:
        target_install = (
            Path(install_dir) if install_dir is not None else install_root()
        )
        exe = exe_name or default_exe_name()
        watcher = tmp_dir / "restart_after_setup.ps1"
        install_s = str(target_install).replace("'", "''")
        exe_s = str(exe).replace("'", "''")
        setup_s = str(setup_path).replace("'", "''")
        watcher.write_text(
            f"""#requires -Version 5
$ErrorActionPreference = 'SilentlyContinue'
$Setup = '{setup_s}'
$InstallDir = '{install_s}'
$ExeName = '{exe_s}'
$deadline = (Get-Date).AddMinutes(30)
while ((Get-Date) -lt $deadline) {{
  $setupProc = Get-Process | Where-Object {{ $_.Path -and ($_.Path -eq $Setup) }}
  if (-not $setupProc) {{ break }}
  Start-Sleep -Seconds 2
}}
Start-Sleep -Seconds 2
$exePath = Join-Path $InstallDir $ExeName
if (Test-Path -LiteralPath $exePath) {{
  Start-Process -FilePath $exePath -WorkingDirectory $InstallDir
}}
""",
            encoding="utf-8",
        )
        _spawn_detached(
            [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(watcher),
            ]
        )

    write_local_version(target_version)
    if exit_after:
        sys.exit(0)
    return setup_path


def _write_patch_helper_script(
    script_path: Path,
    *,
    install_dir: Path,
    staging_dir: Path,
    exe_name: str,
    target_version: str,
    restart: bool,
) -> Path:
    """
    Scrive apply_patch.ps1 con elevazione UAC affidabile (Program Files).

    Ritorna il path dello script da eseguire.
    """
    # Path assoluti lunghi: short-path (MATTEO~1) + UAC elevati possono fallire.
    install_s = str(Path(install_dir).resolve())
    staging_s = str(Path(staging_dir).resolve())
    exe_s = str(exe_name)
    ver_s = str(target_version)
    restart_s = "1" if restart else "0"
    # PowerShell here-string: escape solo `$` che non devono espandersi in Python.
    # Nota: con -Verb RunAs, -ArgumentList DEVE essere una stringa unica
    # (un array passa solo il primo elemento → elevazione a vuoto, patch non applicata).
    # Non usare la variabile automatica $args.
    ps = f"""#requires -Version 5
$ErrorActionPreference = 'Stop'
$InstallDir = '{install_s.replace("'", "''")}'
$Staging = '{staging_s.replace("'", "''")}'
$ExeName = '{exe_s.replace("'", "''")}'
$TargetVer = '{ver_s.replace("'", "''")}'
$DoRestart = '{restart_s}'
$LogDir = Join-Path $env:LOCALAPPDATA 'ProgeoView\\logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$LogPath = Join-Path $LogDir 'patch_apply.log'
function Write-PatchLog([string]$Msg) {{
  $line = "{{0:s}} {{1}}" -f (Get-Date), $Msg
  Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
  Write-Host $Msg
}}

function Test-IsAdmin {{
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p = New-Object Security.Principal.WindowsPrincipal($id)
  return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}}

Write-PatchLog "Helper avviato (admin=$(Test-IsAdmin)) target=$TargetVer install=$InstallDir"

if (-not (Test-IsAdmin)) {{
  Write-PatchLog 'Richiedo privilegi amministratore (UAC)...'
  $scriptPath = $MyInvocation.MyCommand.Path
  if (-not $scriptPath) {{
    Write-PatchLog 'ERRORE: path script sconosciuto, impossibile elevare.'
    Start-Sleep -Seconds 5
    exit 1
  }}
  # Stringa unica: obbligatoria con -Verb RunAs.
  $argLine = "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`""
  try {{
    $p = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argLine -Wait -PassThru
    $code = if ($null -ne $p) {{ $p.ExitCode }} else {{ 1 }}
    Write-PatchLog "Elevazione terminata exit=$code"
    exit $code
  }} catch {{
    Write-PatchLog "UAC negato o fallito: $_"
    Start-Sleep -Seconds 5
    exit 1
  }}
}}

Write-PatchLog 'Attendo chiusura ProgeoView...'
$waitDeadline = (Get-Date).AddMinutes(5)
$procName = [IO.Path]::GetFileNameWithoutExtension($ExeName)
while (Get-Process -Name $procName -ErrorAction SilentlyContinue) {{
  if ((Get-Date) -gt $waitDeadline) {{
    Write-PatchLog "ERRORE: $procName ancora in esecuzione dopo 5 min"
    Start-Sleep -Seconds 5
    exit 1
  }}
  Start-Sleep -Seconds 1
}}

Write-PatchLog 'Applicazione patch (robocopy)...'
if (-not (Test-Path -LiteralPath $Staging)) {{
  Write-PatchLog "Staging mancante: $Staging"
  Start-Sleep -Seconds 5
  exit 1
}}
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
$rc = 0
& robocopy $Staging $InstallDir /E /IS /IT /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
$rc = $LASTEXITCODE
if ($rc -ge 8) {{
  Write-PatchLog "ERRORE robocopy exit=$rc su $InstallDir"
  Start-Sleep -Seconds 6
  exit 1
}}
Write-PatchLog "robocopy ok exit=$rc"

# UTF-8 senza BOM: l'exe frozen con json.loads(utf-8) altrimenti vede 0.0.0.
$verObj = "{{`n  `"version`": `"$TargetVer`",`n  `"product`": `"ProgeoView`"`n}}`n"
$utf8NoBom = New-Object System.Text.UTF8Encoding $false
function Write-VersionFile([string]$Path) {{
  $dir = Split-Path -Parent $Path
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  [System.IO.File]::WriteAllText($Path, $verObj, $utf8NoBom)
  Write-PatchLog "version.json -> $Path"
}}
Write-VersionFile (Join-Path $InstallDir 'config\\version.json')
if (Test-Path -LiteralPath (Join-Path $InstallDir '_internal')) {{
  Write-VersionFile (Join-Path $InstallDir '_internal\\config\\version.json')
}}
Write-VersionFile (Join-Path $env:LOCALAPPDATA 'ProgeoView\\config\\version.json')

Write-PatchLog "Patch applicata: v$TargetVer"
if ($DoRestart -eq '1') {{
  $exePath = Join-Path $InstallDir $ExeName
  if (Test-Path -LiteralPath $exePath) {{
    # Breve pausa: antivirus / handle file dopo robocopy.
    Start-Sleep -Seconds 1
    $started = $false
    for ($i = 0; $i -lt 6; $i++) {{
      try {{
        Start-Process -FilePath $exePath -WorkingDirectory $InstallDir -ErrorAction Stop
        $started = $true
        break
      }} catch {{
        Start-Sleep -Seconds 1
      }}
    }}
    if (-not $started) {{
      Write-PatchLog 'Riavvio automatico non riuscito. Avvia ProgeoView manualmente.'
      Start-Sleep -Seconds 4
    }} else {{
      Write-PatchLog 'Riavvio ProgeoView ok'
    }}
  }}
}}
exit 0
"""
    script_path = script_path.with_suffix(".ps1")
    script_path.write_text(ps, encoding="utf-8")
    return script_path


def _download_patch_payload(
    patch_info: dict[str, Any],
    *,
    work: Path,
    progress: ProgressCallback | None = None,
) -> Path:
    """Scarica/verifica uno zip patch e ritorna la cartella staging dei file."""
    url = str(patch_info.get("url") or "").strip()
    if not url:
        raise RuntimeError("URL patch mancante nel manifest")
    sha = str(patch_info.get("sha256") or "").strip() or None
    timeout_s = float(patch_info.get("timeout_s", 300.0))

    work.mkdir(parents=True, exist_ok=True)
    zip_path = work / "patch.zip"
    download_file(
        url,
        zip_path,
        expected_sha256=sha,
        timeout_s=timeout_s,
        progress=progress,
    )

    extract_dir = work / "extract"
    if extract_dir.exists():
        shutil.rmtree(extract_dir, ignore_errors=True)
    extract_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(extract_dir)

    manifest_path = extract_dir / "patch.json"
    if not manifest_path.is_file():
        raise RuntimeError("patch.json mancante nello zip")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    staging = work / "staging"
    if staging.exists():
        shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True, exist_ok=True)

    files = manifest.get("files") or []
    if not isinstance(files, list) or not files:
        raise RuntimeError("patch.json: lista files vuota o non valida")

    for entry in files:
        if not isinstance(entry, dict):
            continue
        rel = str(entry.get("path") or "").replace("\\", "/").lstrip("/")
        if not rel or ".." in Path(rel).parts:
            raise RuntimeError(f"Percorso patch non valido: {rel}")
        src = extract_dir / "payload" / rel
        if not src.is_file():
            raise RuntimeError(f"File payload mancante: {rel}")
        expected = str(entry.get("sha256") or "").strip().lower()
        if expected and sha256_file(src).lower() != expected:
            raise RuntimeError(f"Checksum payload non valido: {rel}")
        dest = staging / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(src.read_bytes())
    return staging


def apply_patch_update(
    patch_info: dict[str, Any],
    *,
    local_version: str,
    target_version: str,
    exe_name: str | None = None,
    install_dir: Path | None = None,
    progress: ProgressCallback | None = None,
    exit_after: bool = True,
    restart_app: bool = True,
    spawn_helper: bool = True,
) -> Path:
    """
    Scarica uno zip patch, verifica manifest interno e applica i file.

    In produzione: staging + batch post-uscita (exe bloccato).
    In test: ``spawn_helper=False`` copia direttamente in ``install_dir``.
    """
    from updater.patch_chain import patch_compatible_with_local

    # Accetta from_version stringa/lista/null (jolly).
    check_info = dict(patch_info)
    if not check_info.get("to_version"):
        check_info["to_version"] = target_version
    if not patch_compatible_with_local(check_info, local_version):
        req = check_info.get("from_version")
        raise RuntimeError(
            f"Patch non compatibile: richiede {req!r}, installato {local_version}"
        )

    work = Path(tempfile.gettempdir()) / "ProgeoView_patch"
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    staging = _download_patch_payload(patch_info, work=work, progress=progress)

    target_install = Path(install_dir) if install_dir is not None else install_root()
    exe = exe_name or default_exe_name()

    # version.json anche nello staging (copiato da xcopy).
    cfg_stage = staging / "config"
    cfg_stage.mkdir(parents=True, exist_ok=True)
    (cfg_stage / "version.json").write_text(
        json.dumps(
            {"version": str(target_version), "product": "ProgeoView"},
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    if not spawn_helper:
        for src in staging.rglob("*"):
            if not src.is_file():
                continue
            rel = src.relative_to(staging)
            dest = target_install / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(src.read_bytes())
        # Solo dopo copia riuscita.
        write_local_version(target_version)
        return staging

    helper = _write_patch_helper_script(
        work / "apply_patch.ps1",
        install_dir=target_install,
        staging_dir=staging,
        exe_name=exe,
        target_version=target_version,
        restart=bool(restart_app),
    )
    # Non aggiornare AppData qui: lo fa lo script solo se robocopy riesce (con UAC).
    # Finestra visibile: altrimenti UAC / errori restano silenziosi.
    _spawn_detached(
        [
            "powershell.exe",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(helper),
        ],
        hide_window=False,
    )
    if exit_after:
        sys.exit(0)
    return staging


def choose_update_strategy(
    update_info: dict[str, Any],
    *,
    prefer_patch: bool = True,
) -> str:
    """Ritorna 'patch', 'installer' o '' (nessun aggiornamento)."""
    if not update_info.get("update_available"):
        return ""
    installer = update_info.get("installer")
    chain = update_info.get("patch_chain")
    if prefer_patch and isinstance(chain, list) and chain:
        return "patch"
    patch = update_info.get("patch")
    local_version = str(update_info.get("local_version") or "").strip()
    if prefer_patch and isinstance(patch, dict) and patch.get("url"):
        from updater.patch_chain import patch_compatible_with_local

        info = dict(patch)
        if not info.get("to_version"):
            info["to_version"] = str(update_info.get("latest_version") or "")
        if patch_compatible_with_local(info, local_version):
            return "patch"
    if isinstance(installer, dict) and installer.get("url"):
        return "installer"
    return ""


def apply_patch_chain(
    chain: list[dict[str, Any]],
    *,
    local_version: str,
    target_version: str,
    exe_name: str | None = None,
    install_dir: Path | None = None,
    progress: ProgressCallback | None = None,
    exit_after: bool = True,
    restart_app: bool = True,
    spawn_helper: bool = True,
    status: Callable[[str], None] | None = None,
) -> Path:
    """
    Scarica e applica in ordine tutte le patch della catena.

    I file delle patch successive sovrascrivono quelli precedenti nello staging;
    un solo riavvio al termine con la versione finale.
    """
    if not chain:
        raise RuntimeError("Catena patch vuota")

    from updater.patch_chain import patch_compatible_with_local

    if len(chain) == 1:
        if status:
            status("Download patch…")
        return apply_patch_update(
            dict(chain[0]),
            local_version=local_version,
            target_version=target_version,
            exe_name=exe_name,
            install_dir=install_dir,
            progress=progress,
            exit_after=exit_after,
            restart_app=restart_app,
            spawn_helper=spawn_helper,
        )

    work = Path(tempfile.gettempdir()) / "ProgeoView_patch"
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    merged = work / "staging"
    merged.mkdir(parents=True, exist_ok=True)

    current = str(local_version)
    total_steps = len(chain)
    for idx, step in enumerate(chain, start=1):
        step = dict(step)
        step_to = str(step.get("to_version") or target_version).strip()
        if not step.get("to_version"):
            step["to_version"] = step_to
        if not patch_compatible_with_local(step, current):
            raise RuntimeError(
                f"Catena interrotta allo step {idx}: "
                f"richiede {step.get('from_version')!r}, attuale {current}"
            )
        if status:
            status(f"Download patch {idx}/{total_steps} ({current} → {step_to})…")

        def _prog(done: int, total: int | None, _idx=idx, _n=total_steps) -> None:
            if progress is None:
                return
            if total:
                base = (_idx - 1) * 1000
                frac = int(1000 * done / max(total, 1))
                progress(base + frac, _n * 1000)
            else:
                progress(_idx - 1, _n)

        step_work = work / f"step_{idx}"
        step_staging = _download_patch_payload(step, work=step_work, progress=_prog)
        for src in step_staging.rglob("*"):
            if not src.is_file():
                continue
            rel = src.relative_to(step_staging)
            dest = merged / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(src.read_bytes())
        current = step_to

    target_install = Path(install_dir) if install_dir is not None else install_root()
    exe = exe_name or default_exe_name()
    cfg_stage = merged / "config"
    cfg_stage.mkdir(parents=True, exist_ok=True)
    (cfg_stage / "version.json").write_text(
        json.dumps(
            {"version": str(target_version), "product": "ProgeoView"},
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    if not spawn_helper:
        for src in merged.rglob("*"):
            if not src.is_file():
                continue
            rel = src.relative_to(merged)
            dest = target_install / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(src.read_bytes())
        write_local_version(target_version)
        return merged

    if status:
        status("Applicazione aggiornamenti…")
    helper = _write_patch_helper_script(
        work / "apply_patch.ps1",
        install_dir=target_install,
        staging_dir=merged,
        exe_name=exe,
        target_version=target_version,
        restart=bool(restart_app),
    )
    _spawn_detached(
        [
            "powershell.exe",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(helper),
        ],
        hide_window=False,
    )
    if exit_after:
        sys.exit(0)
    return merged


def run_update(
    update_info: dict[str, Any],
    *,
    progress: ProgressCallback | None = None,
    exit_after: bool = True,
    status: Callable[[str], None] | None = None,
) -> str:
    """
    Esegue la strategia scelta. Ritorna 'patch' o 'installer'.
    """
    strategy = str(update_info.get("strategy") or "").strip()
    if not strategy:
        strategy = choose_update_strategy(update_info)
    if not strategy:
        raise RuntimeError("Nessuna strategia di aggiornamento disponibile")

    local_version = str(update_info.get("local_version") or "")
    target_version = str(update_info.get("latest_version") or "")

    if strategy == "patch":
        chain = update_info.get("patch_chain")
        if isinstance(chain, list) and chain:
            apply_patch_chain(
                list(chain),
                local_version=local_version,
                target_version=target_version,
                progress=progress,
                exit_after=exit_after,
                status=status,
            )
            return "patch"
        if status:
            status("Download patch…")
        apply_patch_update(
            dict(update_info.get("patch") or {}),
            local_version=local_version,
            target_version=target_version,
            progress=progress,
            exit_after=exit_after,
        )
        return "patch"

    if strategy == "installer":
        if status:
            status("Download installer…")
        apply_installer_update(
            dict(update_info.get("installer") or {}),
            target_version=target_version,
            progress=progress,
            exit_after=exit_after,
            restart_app=True,
        )
        return "installer"

    raise RuntimeError(f"Strategia sconosciuta: {strategy}")
