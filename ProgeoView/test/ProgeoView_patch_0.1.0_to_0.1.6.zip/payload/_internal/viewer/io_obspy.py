"""
Lettura sismogrammi via ObsPy (SEG-Y, SEG-2, .dat) e configurazione pyqtgraph.

Espone `obspy_read`, reader diretti SEG-Y/SEG-2 e helper per il rilevamento formato.
"""

from __future__ import annotations

import importlib
from pathlib import Path

import pyqtgraph as pg

from core.obspy_bootstrap import (
    ensure_obspy_cdll_loader,
    ensure_obspy_colormaps,
    suppress_known_obspy_seg2_warnings,
)

suppress_known_obspy_seg2_warnings()
ensure_obspy_cdll_loader()
ensure_obspy_colormaps()

SEG2_MAGIC = b"U:"


def detect_seismic_format(path: Path | str) -> str:
    """Rileva SEG-2 (magic ``U:``), MRG (``.mrg``) oppure assume SEG-Y."""
    p = Path(path)
    if p.suffix.lower() == ".mrg":
        return "MRG"
    with p.open("rb") as fh:
        magic = fh.read(2)
    if magic == SEG2_MAGIC:
        return "SEG2"
    return "SEGY"


def preferred_seismic_formats(path: Path) -> list[str]:
    """
    Ordine di tentativo lettura in base all'estensione.
    Per ``.dat`` usa il magic byte; altrimenti prova anche il formato alternativo.
    """
    ext = path.suffix.lower()
    if ext in {".sgy", ".segy"}:
        return ["SEGY"]
    if ext in {".sg2", ".seg2"}:
        return ["SEG2"]
    if ext == ".mrg":
        return ["MRG"]
    if ext == ".dat":
        primary = detect_seismic_format(path)
        secondary = "SEG2" if primary == "SEGY" else "SEGY"
        return [primary, secondary]
    return []

def _prepare_obspy_segy_plugins() -> None:
    try:
        importlib.import_module("obspy.io.segy")
        importlib.import_module("obspy.io.segy.core")
        importlib.import_module("obspy.io.segy.segy")
    except Exception as exc:  # pragma: no cover - diagnostics only
        print(f"[VIEWER] Avviso: plugin SEG-Y non disponibili ({exc})", flush=True)


_prepare_obspy_segy_plugins()


try:
    # OpenGL + centinaia di PlotCurveItem spesso rende pan/zoom più lenti; raster Qt è più fluido qui.
    pg.setConfigOptions(useOpenGL=False, antialias=False)
except Exception:
    pass
pg.setConfigOptions(background="#f5f5f5", foreground="#202124")

try:
    from obspy import read as obspy_read  # type: ignore
    from obspy import Stream as ObspyStream  # type: ignore
except ImportError:  # pragma: no cover - handled at runtime
    obspy_read = None
    ObspyStream = None

try:
    from obspy.io.segy.core import _read_segy as _direct_read_segy  # type: ignore
except ImportError:  # pragma: no cover
    _direct_read_segy = None

try:
    from obspy.io.seg2.seg2 import _read_seg2 as _direct_read_seg2  # type: ignore
except ImportError:  # pragma: no cover
    _direct_read_seg2 = None


def coerce_to_stream(obj: object) -> ObspyStream | None:
    if obj is None or ObspyStream is None:
        return obj if isinstance(obj, ObspyStream) else None
    if isinstance(obj, ObspyStream):
        return obj
    for attr in ("to_obspy", "to_stream"):
        convert = getattr(obj, attr, None)
        if callable(convert):
            try:
                maybe = convert()
            except Exception:
                continue
            if isinstance(maybe, ObspyStream):
                return maybe
    return None
