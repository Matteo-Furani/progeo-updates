from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from PyQt6 import QtWidgets

from main_window import SiesviewWindow


def cross_tracer_entry() -> Path:
    """Entry CrossTracer.py (cartella sorella di ProgeoView)."""
    # app/windows/tool_windows.py → Programmi/CrossTracer/CrossTracer.py
    return Path(__file__).resolve().parents[3] / "CrossTracer" / "CrossTracer.py"


def launch_cross_tracer(parent: QtWidgets.QWidget | None = None) -> bool:
    """Avvia CrossTracer (stack) in un processo separato (PyQt5)."""
    entry = cross_tracer_entry()
    if not entry.is_file():
        QtWidgets.QMessageBox.warning(
            parent,
            "Stack",
            f"Non trovo CrossTracer:\n{entry}",
        )
        return False
    try:
        creationflags = 0
        if sys.platform == "win32":
            creationflags = (
                subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
                | getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
            )
        subprocess.Popen(
            [sys.executable, str(entry)],
            cwd=str(entry.parent),
            creationflags=creationflags,
        )
    except Exception as exc:
        QtWidgets.QMessageBox.critical(
            parent,
            "Stack",
            f"Impossibile avviare CrossTracer:\n{exc}",
        )
        return False
    return True


class BaseToolWindow(QtWidgets.QMainWindow):
    def __init__(self, title: str, subtitle: str) -> None:
        super().__init__()
        self.setWindowTitle(title)
        self.resize(820, 520)

        central = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(central)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        title_label = QtWidgets.QLabel(title)
        title_label.setStyleSheet("font-size: 20px; font-weight: 700; color: #e8eaed;")
        layout.addWidget(title_label)

        subtitle_label = QtWidgets.QLabel(subtitle)
        subtitle_label.setWordWrap(True)
        subtitle_label.setStyleSheet("font-size: 13px; color: #9aa3b2;")
        layout.addWidget(subtitle_label)

        layout.addStretch(1)
        self.setCentralWidget(central)


class VisualizerWindow(SiesviewWindow):
    """Visualizzatore Siesview integrato nel menu ProgeoView."""


class ProjectManagerWindow(BaseToolWindow):
    def __init__(self) -> None:
        super().__init__(
            "Gestione progetti",
            "Finestra dedicata ad apertura progetto, dataset recenti e metadati.",
        )


class ProcessingWindow(BaseToolWindow):
    def __init__(self) -> None:
        super().__init__(
            "Strumenti di elaborazione",
            "Area per filtri, elaborazione batch, esportazione e pipeline.",
        )


def CrossWindow(*args, **kwargs):
    """Cross-correlazione batch (import lazy: evita caricare ObsPy al solo menu)."""
    from core.obspy_bootstrap import ensure_obspy_colormaps

    ensure_obspy_colormaps()
    from cross import CrossWindow as _CrossWindow

    return _CrossWindow(*args, **kwargs)


class SpikePickWindow(BaseToolWindow):
    def __init__(self) -> None:
        super().__init__(
            "SysPick",
            "Strumenti di selezione spike, correlazione e analisi arrivi.",
        )
