"""Risoluzione catena di patch da versione locale a latest."""

from __future__ import annotations

from collections import deque
from typing import Any

from updater.version_utils import parse_version, version_eq, version_gt


def _normalize_patch_entry(raw: Any) -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None
    url = str(raw.get("url") or "").strip()
    if not url:
        return None
    from_v = raw.get("from_version")
    to_v = str(raw.get("to_version") or raw.get("version") or "").strip()
    # from_version può essere stringa, lista, o null (qualsiasi → to)
    from_list: list[str | None]
    if from_v is None or from_v == "":
        from_list = [None]
    elif isinstance(from_v, (list, tuple)):
        from_list = []
        for item in from_v:
            text = str(item or "").strip()
            from_list.append(text or None)
        if not from_list:
            from_list = [None]
    else:
        text = str(from_v).strip()
        from_list = [text or None]

    base = {
        "url": url,
        "sha256": str(raw.get("sha256") or "").strip(),
        "size_bytes": int(raw.get("size_bytes") or 0),
        "timeout_s": float(raw.get("timeout_s") or 300.0),
        "to_version": to_v,
        "release_notes": str(raw.get("release_notes") or "").strip(),
    }
    # Espandi in un entry per ogni from (stesso artifact).
    # Il caller usa collect_patch_edges.
    return {"_from_list": from_list, **base}


def collect_patch_edges(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    """
    Estrae gli archi patch dal manifest.

    Supporta:
      - patches: [ {from_version, to_version, url, ...}, ... ]
      - patch: {from_version, to_version?, url, ...}  (legacy)
      - from_version come stringa, lista, o null
    """
    edges: list[dict[str, Any]] = []
    latest = str(manifest.get("version") or "").strip()

    raw_list = manifest.get("patches")
    if isinstance(raw_list, list):
        for item in raw_list:
            norm = _normalize_patch_entry(item)
            if not norm:
                continue
            to_v = str(norm.get("to_version") or latest).strip() or latest
            for from_v in norm.get("_from_list") or [None]:
                edge = {
                    "from_version": from_v,
                    "to_version": to_v,
                    "url": norm["url"],
                    "sha256": norm["sha256"],
                    "size_bytes": norm["size_bytes"],
                    "timeout_s": norm["timeout_s"],
                    "release_notes": norm.get("release_notes") or "",
                }
                edges.append(edge)

    legacy = manifest.get("patch")
    if isinstance(legacy, dict) and legacy.get("url"):
        norm = _normalize_patch_entry(legacy)
        if norm:
            to_v = str(norm.get("to_version") or latest).strip() or latest
            for from_v in norm.get("_from_list") or [None]:
                edge = {
                    "from_version": from_v,
                    "to_version": to_v,
                    "url": norm["url"],
                    "sha256": norm["sha256"],
                    "size_bytes": norm["size_bytes"],
                    "timeout_s": norm["timeout_s"],
                    "release_notes": norm.get("release_notes") or "",
                }
                # Evita duplicati esatti.
                if edge not in edges:
                    edges.append(edge)
    return edges


def resolve_patch_chain(
    *,
    local_version: str,
    latest_version: str,
    edges: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """
    Trova la catena più corta di patch da local a latest (BFS).

    Un arco con from_version=None è un "jolly": applicabile da qualsiasi
    versione strettamente minore di to_version.
    """
    local = str(local_version or "").strip()
    latest = str(latest_version or "").strip()
    if not local or not latest or not version_gt(latest, local):
        return []

    # Indice: from_key -> list[edge]; from_key "" = jolly
    by_from: dict[str, list[dict[str, Any]]] = {}
    for edge in edges:
        to_v = str(edge.get("to_version") or "").strip()
        if not to_v:
            continue
        from_v = edge.get("from_version")
        key = "" if from_v is None else str(from_v).strip()
        by_from.setdefault(key, []).append(edge)

    # BFS su nodi versione
    queue: deque[str] = deque([local])
    prev: dict[str, tuple[str, dict[str, Any]] | None] = {local: None}

    while queue:
        current = queue.popleft()
        if version_eq(current, latest):
            break
        candidates = list(by_from.get(current, []))
        # Jolly applicabili da current se current < to
        for edge in by_from.get("", []):
            to_v = str(edge.get("to_version") or "")
            if version_gt(to_v, current):
                candidates.append(edge)
        for edge in candidates:
            to_v = str(edge.get("to_version") or "").strip()
            if not to_v or to_v in prev:
                continue
            if not version_gt(to_v, current):
                continue
            prev[to_v] = (current, edge)
            queue.append(to_v)

    if latest not in prev and not any(version_eq(k, latest) for k in prev):
        # Cerca chiave equivalente semver
        match = next((k for k in prev if version_eq(k, latest)), None)
        if match is None:
            return []
        latest = match

    if latest not in prev:
        return []

    chain: list[dict[str, Any]] = []
    node = latest
    while True:
        step = prev.get(node)
        if step is None:
            break
        parent, edge = step
        chain.append(edge)
        node = parent
    chain.reverse()
    return chain


def patch_compatible_with_local(patch: dict[str, Any], local_version: str) -> bool:
    """True se la singola patch è applicabile alla versione locale."""
    from_v = patch.get("from_version")
    to_v = str(patch.get("to_version") or "").strip()
    local = str(local_version or "").strip()
    if to_v and not version_gt(to_v, local) and not version_eq(to_v, local):
        # to <= local e non uguale gestito fuori; se to < local inutile
        if to_v and parse_version(to_v) < parse_version(local):
            return False
    if from_v is None or str(from_v).strip() == "":
        return bool(to_v) and version_gt(to_v, local)
    if isinstance(from_v, (list, tuple)):
        return any(version_eq(str(v), local) for v in from_v if str(v).strip())
    return version_eq(str(from_v), local)
