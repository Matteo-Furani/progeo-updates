from __future__ import annotations

import ctypes
import importlib.machinery
import importlib.util
import os
from pathlib import Path
import sys
import warnings
from typing import Iterable, List, Sequence


def suppress_known_obspy_seg2_warnings() -> None:
    """
    Silenzia solo i UserWarning noti e ripetitivi del reader SEG-2 ObsPy.
    Non tocca eccezioni né warning di altri moduli.
    """
    for message in (
        r"Many companies use custom defined SEG2 header variables",
        r"Non-zero value found in Trace's 'DELAY' field",
    ):
        warnings.filterwarnings(
            "ignore",
            category=UserWarning,
            module=r"obspy\.io\.seg2\.seg2",
            message=message,
        )


suppress_known_obspy_seg2_warnings()


def _dedupe(existing: Iterable[Path]) -> list[Path]:
    seen: set[str] = set()
    ordered: list[Path] = []
    for entry in existing:
        try:
            resolved = entry.resolve()
        except Exception:
            resolved = entry
        key = str(resolved).lower()
        if key in seen:
            continue
        seen.add(key)
        ordered.append(resolved)
    return ordered


def _candidate_roots() -> list[Path]:
    roots: list[Path] = []
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        roots.append(Path(meipass))
    module_dir = Path(__file__).resolve().parent
    roots.append(module_dir)
    roots.append(module_dir.parent)
    exe_dir = Path(sys.executable).resolve().parent if getattr(sys, "executable", None) else None
    if exe_dir:
        roots.append(exe_dir)
    cwd = Path.cwd()
    roots.append(cwd)
    return _dedupe([path for path in roots if path.exists()])


def _candidate_obspy_lib_dirs() -> list[Path]:
    candidates: list[Path] = []
    for root in _candidate_roots():
        candidates.append(root / "obspy" / "lib")
        candidates.append(root / "_internal" / "obspy" / "lib")
        candidates.append(root / "_internal_viewer" / "obspy" / "lib")
        candidates.append(root / "_internal" / "_internal" / "obspy" / "lib")
        candidates.append(root / "embedded_viewer" / "obspy" / "lib")
    env = os.environ.get("OBSPY_LIB_HINT")
    if env:
        candidates.append(Path(env))
    return _dedupe([path for path in candidates if path.exists()])


def ensure_obspy_cdll_loader() -> bool:
    """
    Ensures ObsPy can locate its compiled SEG-Y helpers when running from a
    PyInstaller bundle. Returns True if at least one candidate directory was
    registered.
    """
    try:
        from obspy.core.util import libnames as _libnames  # type: ignore
    except Exception:
        return False

    if getattr(_libnames, "_pyinstaller_patch", False):
        return bool(getattr(_libnames, "_pyinstaller_candidates", []))

    candidates = _candidate_obspy_lib_dirs()
    if not candidates:
        return False

    original_loader = _libnames._load_cdll  # type: ignore[attr-defined]

    def _patched_loader(name: str):
        errors: list[str] = []
        for directory in candidates:
            for ext in importlib.machinery.EXTENSION_SUFFIXES:
                libpath = (directory / f"{name}{ext}")
                if not libpath.exists():
                    continue
                try:
                    return ctypes.CDLL(str(libpath))
                except Exception as exc:  # pragma: no cover - diagnostics only
                    errors.append(f"{libpath}: {exc}")
        try:
            return original_loader(name)
        except Exception as exc:
            if errors:
                raise RuntimeError(
                    "Impossibile caricare la libreria ObsPy richiesta.\n"
                    + "\n".join(errors)
                ) from exc
            raise

    _libnames._load_cdll = _patched_loader  # type: ignore[assignment]
    _libnames._pyinstaller_patch = True
    _libnames._pyinstaller_candidates = candidates
    return True


_CM_READY = False


def ensure_obspy_colormaps() -> None:
    """
    Garantisce che ``obspy.imaging.cm`` veda ``obspy/imaging/data/*.npz``.

    In build frozen PyInstaller carica spesso ``cm.py`` dal PYZ: allora
    ``inspect.getfile`` non punta alla cartella ``data`` sul disco e
    si ottiene ``KeyError: 'viridis'`` all'import di ``obspy.signal``.
    """
    global _CM_READY
    if _CM_READY:
        return

    existing = sys.modules.get("obspy.imaging.cm")
    if existing is not None and getattr(existing, "obspy_sequential", None) is not None:
        _CM_READY = True
        return

    if not getattr(sys, "frozen", False):
        _CM_READY = True
        return

    meipass = Path(getattr(sys, "_MEIPASS", "") or "")
    cm_py = meipass / "obspy" / "imaging" / "cm.py"
    data_dir = meipass / "obspy" / "imaging" / "data"
    if not cm_py.is_file() or not data_dir.is_dir():
        try:
            import obspy.imaging.cm  # noqa: F401
        except Exception:
            pass
        _CM_READY = True
        return

    import obspy  # noqa: F401
    import obspy.imaging  # noqa: F401

    broken = sys.modules.get("obspy.imaging.cm")
    if broken is not None and getattr(broken, "obspy_sequential", None) is None:
        del sys.modules["obspy.imaging.cm"]

    if "obspy.imaging.cm" not in sys.modules:
        spec = importlib.util.spec_from_file_location("obspy.imaging.cm", cm_py)
        if spec is None or spec.loader is None:
            _CM_READY = True
            return
        module = importlib.util.module_from_spec(spec)
        sys.modules["obspy.imaging.cm"] = module
        try:
            spec.loader.exec_module(module)
        except Exception:
            sys.modules.pop("obspy.imaging.cm", None)
            raise

    _CM_READY = True


__all__ = [
    "ensure_obspy_cdll_loader",
    "ensure_obspy_colormaps",
    "suppress_known_obspy_seg2_warnings",
]
