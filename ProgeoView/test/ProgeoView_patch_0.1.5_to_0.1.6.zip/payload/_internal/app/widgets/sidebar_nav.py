"""Sidebar navigazione collassabile per il menu Progeo."""

from __future__ import annotations

from pathlib import Path

from PyQt6 import QtCore, QtGui, QtWidgets

_ICONS_DIR = Path(__file__).resolve().parents[1] / "assets" / "icons"

_SIDEBAR_BG = "#14171f"
_ITEM_HOVER = "rgba(255, 255, 255, 0.06)"
_ITEM_PRESSED = "rgba(255, 255, 255, 0.10)"
_TEXT = "#f5f5f7"
_MUTED = "#8e8e93"


def resolve_nav_icon(
    icon_name: str,
    accent: str,
    *,
    size: int = 22,
) -> QtGui.QIcon:
    """Carica l'icona da assets/icons; se manca, genera un placeholder colorato."""
    for ext in (".png", ".svg", ".ico"):
        path = _ICONS_DIR / f"{icon_name}{ext}"
        if path.is_file():
            icon = QtGui.QIcon(str(path))
            if not icon.isNull():
                return icon
    return _placeholder_icon(icon_name, accent, size=size)


def _placeholder_icon(icon_name: str, accent: str, *, size: int) -> QtGui.QIcon:
    """Icona temporanea: riquadro arrotondato + iniziale (o simbolo noto)."""
    pm = QtGui.QPixmap(size, size)
    pm.fill(QtCore.Qt.GlobalColor.transparent)
    painter = QtGui.QPainter(pm)
    painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)

    color = QtGui.QColor(accent)
    if not color.isValid():
        color = QtGui.QColor("#5eb3f6")
    bg = QtGui.QColor(color)
    bg.setAlpha(40)
    painter.setPen(QtCore.Qt.PenStyle.NoPen)
    painter.setBrush(bg)
    radius = max(4.0, size * 0.28)
    painter.drawRoundedRect(0.5, 0.5, size - 1.0, size - 1.0, radius, radius)

    painter.setPen(QtGui.QPen(color, max(1.4, size * 0.08)))
    painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
    margin = size * 0.22
    _draw_placeholder_glyph(painter, icon_name, QtCore.QRectF(margin, margin, size - 2 * margin, size - 2 * margin), color)

    painter.end()
    return QtGui.QIcon(pm)


def _draw_placeholder_glyph(
    painter: QtGui.QPainter,
    icon_name: str,
    rect: QtCore.QRectF,
    color: QtGui.QColor,
) -> None:
    key = (icon_name or "").lower()
    painter.save()
    painter.setPen(QtGui.QPen(color, max(1.2, rect.width() * 0.12), QtCore.Qt.PenStyle.SolidLine, QtCore.Qt.PenCapStyle.RoundCap, QtCore.Qt.PenJoinStyle.RoundJoin))
    painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)

    if key in ("siesview", "wave", "waveform"):
        # Onda stilizzata
        path = QtGui.QPainterPath()
        mid_y = rect.center().y()
        path.moveTo(rect.left(), mid_y)
        path.cubicTo(
            rect.left() + rect.width() * 0.25,
            rect.top(),
            rect.left() + rect.width() * 0.35,
            rect.bottom(),
            rect.center().x(),
            mid_y,
        )
        path.cubicTo(
            rect.center().x() + rect.width() * 0.15,
            rect.top(),
            rect.left() + rect.width() * 0.75,
            rect.bottom(),
            rect.right(),
            mid_y,
        )
        painter.drawPath(path)
    elif key in ("cross", "link", "xcorr"):
        painter.drawLine(rect.topLeft(), rect.bottomRight())
        painter.drawLine(rect.topRight(), rect.bottomLeft())
    elif key in ("stack", "layers"):
        w, h = rect.width(), rect.height()
        for i, dy in enumerate((-0.18, 0.0, 0.18)):
            r = QtCore.QRectF(
                rect.left() + w * 0.08,
                rect.center().y() + h * dy - h * 0.12,
                w * 0.84,
                h * 0.24,
            )
            painter.drawRoundedRect(r, 2, 2)
    elif key in ("merge", "folder", "project"):
        painter.drawRoundedRect(rect.adjusted(0, rect.height() * 0.15, 0, 0), 2, 2)
        tab = QtCore.QRectF(rect.left(), rect.top(), rect.width() * 0.45, rect.height() * 0.28)
        painter.drawRoundedRect(tab, 2, 2)
    elif key in ("utils", "utilita", "tools", "gear"):
        painter.drawEllipse(rect.adjusted(rect.width() * 0.12, rect.height() * 0.12, -rect.width() * 0.12, -rect.height() * 0.12))
        painter.drawEllipse(rect.center(), rect.width() * 0.12, rect.height() * 0.12)
    elif key in ("update", "download"):
        cx = rect.center().x()
        painter.drawLine(QtCore.QPointF(cx, rect.top()), QtCore.QPointF(cx, rect.bottom() - rect.height() * 0.2))
        tip = rect.bottom() - rect.height() * 0.15
        painter.drawLine(QtCore.QPointF(cx, tip + rect.height() * 0.05), QtCore.QPointF(cx - rect.width() * 0.28, tip - rect.height() * 0.25))
        painter.drawLine(QtCore.QPointF(cx, tip + rect.height() * 0.05), QtCore.QPointF(cx + rect.width() * 0.28, tip - rect.height() * 0.25))
        painter.drawLine(QtCore.QPointF(rect.left(), rect.bottom()), QtCore.QPointF(rect.right(), rect.bottom()))
    elif key in ("collapse", "expand", "menu"):
        y1 = rect.top() + rect.height() * 0.2
        y2 = rect.center().y()
        y3 = rect.bottom() - rect.height() * 0.2
        painter.drawLine(QtCore.QPointF(rect.left(), y1), QtCore.QPointF(rect.right(), y1))
        painter.drawLine(QtCore.QPointF(rect.left(), y2), QtCore.QPointF(rect.right(), y2))
        painter.drawLine(QtCore.QPointF(rect.left(), y3), QtCore.QPointF(rect.right(), y3))
    else:
        letter = (icon_name[:1] or "?").upper()
        font = QtGui.QFont("Segoe UI")
        font.setBold(True)
        font.setPixelSize(max(10, int(rect.height() * 0.75)))
        painter.setFont(font)
        painter.setPen(color)
        painter.drawText(rect, int(QtCore.Qt.AlignmentFlag.AlignCenter), letter)

    painter.restore()


class SidebarNavItem(QtWidgets.QFrame):
    """Voce di navigazione: icona sempre visibile, testo solo se espansa."""

    clicked = QtCore.pyqtSignal()

    def __init__(
        self,
        *,
        label: str,
        description: str,
        accent: str,
        icon_name: str,
        enabled: bool = True,
        parent: QtWidgets.QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._label = label
        self._description = description
        self._accent = accent
        self._enabled = enabled
        self._expanded = True
        self._hovered = False
        self._pressed = False

        self.setObjectName("SidebarNavItem")
        self.setCursor(
            QtGui.QCursor(
                QtCore.Qt.CursorShape.PointingHandCursor
                if enabled
                else QtCore.Qt.CursorShape.ArrowCursor
            )
        )
        self.setToolTip(description if enabled else f"{label} — prossimamente")

        self._root = QtWidgets.QHBoxLayout(self)
        self._root.setContentsMargins(8, 4, 8, 4)
        self._root.setSpacing(8)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Fixed,
        )

        self._icon_label = QtWidgets.QLabel()
        self._icon_label.setFixedSize(28, 28)
        self._icon_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self._icon_label.setAttribute(
            QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True
        )
        icon = resolve_nav_icon(icon_name, accent, size=22)
        self._icon_label.setPixmap(icon.pixmap(22, 22))
        self._root.addWidget(self._icon_label, 0, QtCore.Qt.AlignmentFlag.AlignVCenter)

        text_col = QtWidgets.QVBoxLayout()
        text_col.setContentsMargins(0, 0, 0, 0)
        text_col.setSpacing(0)

        self._title = QtWidgets.QLabel(label)
        self._title.setStyleSheet(
            f"font-size: 12px; font-weight: 600; color: {_TEXT}; background: transparent;"
        )
        self._title.setAttribute(
            QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True
        )

        self._subtitle = QtWidgets.QLabel(description)
        self._subtitle.setStyleSheet(
            f"font-size: 9px; font-weight: 400; color: {_MUTED}; background: transparent;"
        )
        self._subtitle.setAttribute(
            QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True
        )

        text_col.addWidget(self._title)
        text_col.addWidget(self._subtitle)
        self._text_host = QtWidgets.QWidget()
        self._text_host.setLayout(text_col)
        self._text_host.setAttribute(
            QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True
        )
        self._root.addWidget(self._text_host, 1)

        if not enabled:
            effect = QtWidgets.QGraphicsOpacityEffect(self)
            effect.setOpacity(0.42)
            self.setGraphicsEffect(effect)

        self.set_expanded(True)

    def set_expanded(self, expanded: bool) -> None:
        self._expanded = bool(expanded)
        self._text_host.setVisible(self._expanded)
        if self._expanded:
            self.setFixedHeight(46)
            # Margine sinistro lascia spazio alla barra accent disegnata.
            self._root.setContentsMargins(12, 5, 10, 5)
            self._root.setSpacing(8)
            self._root.setAlignment(QtCore.Qt.AlignmentFlag.AlignVCenter)
        else:
            self.setFixedHeight(40)
            self._root.setContentsMargins(0, 3, 0, 3)
            self._root.setSpacing(0)
            self._root.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.setToolTip(
            (
                f"{self._label} — prossimamente"
                if not self._enabled
                else f"{self._label}\n{self._description}"
            )
            if not self._expanded
            else (self._description if self._enabled else f"{self._label} — prossimamente")
        )
        self._refresh_style()
        self.update()

    def _refresh_style(self) -> None:
        # Sfondo trasparente: disegniamo noi in paintEvent (accent pulito).
        self.setStyleSheet(
            "SidebarNavItem { background: transparent; border: none; }"
        )

    def paintEvent(self, event: QtGui.QPaintEvent) -> None:  # type: ignore[override]
        del event
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        rect = QtCore.QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        radius = 11.0 if self._expanded else 10.0

        if self._expanded:
            if self._pressed and self._enabled:
                bg = QtGui.QColor("#38383d")
            elif self._hovered and self._enabled:
                bg = QtGui.QColor("#2f2f34")
            else:
                bg = QtGui.QColor("#252528")
        else:
            if self._pressed and self._enabled:
                bg = QtGui.QColor(255, 255, 255, 26)
            elif self._hovered and self._enabled:
                bg = QtGui.QColor(255, 255, 255, 15)
            else:
                bg = QtGui.QColor(0, 0, 0, 0)

        path = QtGui.QPainterPath()
        path.addRoundedRect(rect, radius, radius)
        if bg.alpha() > 0:
            painter.fillPath(path, bg)

        if self._expanded:
            painter.save()
            painter.setClipPath(path)
            accent = QtGui.QColor(self._accent)
            painter.fillRect(
                QtCore.QRectF(rect.left(), rect.top(), 3.0, rect.height()),
                accent,
            )
            painter.restore()
            pen = QtGui.QPen(QtGui.QColor(255, 255, 255, 18))
            pen.setWidthF(1.0)
            painter.setPen(pen)
            painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(rect, radius, radius)

        painter.end()

    def enterEvent(self, event: QtCore.QEvent) -> None:  # type: ignore[override]
        self._hovered = True
        self._refresh_style()
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event: QtCore.QEvent) -> None:  # type: ignore[override]
        self._hovered = False
        self._pressed = False
        self._refresh_style()
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event: QtGui.QMouseEvent) -> None:  # type: ignore[override]
        if event.button() == QtCore.Qt.MouseButton.LeftButton and self._enabled:
            self._pressed = True
            self._refresh_style()
            self.update()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent) -> None:  # type: ignore[override]
        if (
            event.button() == QtCore.Qt.MouseButton.LeftButton
            and self._enabled
            and self.rect().contains(event.pos())
        ):
            self.clicked.emit()
        self._pressed = False
        self._refresh_style()
        self.update()
        super().mouseReleaseEvent(event)


class SidebarToggleButton(QtWidgets.QToolButton):
    def __init__(self, parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent)
        self.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        self.setAutoRaise(True)
        self.setStyleSheet(
            f"""
            QToolButton {{
                background: transparent;
                border: 1px solid transparent;
                border-radius: 9px;
                padding: 4px;
            }}
            QToolButton:hover {{
                background: {_ITEM_HOVER};
                border: 1px solid rgba(255, 255, 255, 0.10);
            }}
            """
        )
        self.set_expanded(False)

    def set_expanded(self, expanded: bool) -> None:
        size = 32 if expanded else 40
        self.setFixedSize(size, size)
        # Colore icona gestito da MainMenuWindow._refresh_update_ui (blu se update).
        current = self.icon()
        if current.isNull():
            self.setIcon(resolve_nav_icon("menu", "#9a9aa1", size=18))
        self.setIconSize(QtCore.QSize(18, 18))
        tip = self.toolTip()
        if not tip or tip in {"Comprimi menu", "Espandi menu"}:
            self.setToolTip("Comprimi menu" if expanded else "Espandi menu")
