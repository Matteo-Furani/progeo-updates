"""Export file velocità (morfologia + griglia FBP) in Excel, .geo o testo."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from PyQt6 import QtWidgets

from dromocrona_grid_data import (
    SHOT_EPS_MS,
    DromocronaGridData,
    prepare_dromocrona_grid_for_export,
    sort_dromocrona_grid_by_shot_order,
)
from export.dromocrona_fbp_export import _dromocrona_missing_fill, _dromocrona_shot_fill
from morphology import LineMorphology


@dataclass(frozen=True)
class VelocityShotRow:
    file_index: int
    position_m: float
    elevation_m: float


@dataclass(frozen=True)
class VelocityGeophoneRow:
    channel: int
    distance_m: float
    elevation_m: float
    fbp_ms: tuple[float | None, ...]


@dataclass(frozen=True)
class VelocityExportData:
    n_geophones: int
    n_files: int
    shot_channels: tuple[int, ...]
    shot_rows: tuple[VelocityShotRow, ...]
    geophone_rows: tuple[VelocityGeophoneRow, ...]


def morphology_has_velocity_export(morphology: LineMorphology | None) -> bool:
    return morphology is not None and bool(morphology.geophones)


def suggested_velocity_export_filename(
    morphology: LineMorphology,
    *,
    folder: Path | None = None,
    extension: str = ".geo",
) -> str:
    ext = str(extension).lower()
    if not ext.startswith("."):
        ext = f".{ext}"
    if morphology.line_id is not None:
        base = f"P{int(morphology.line_id)}"
    elif folder is not None and folder.name.strip():
        base = folder.name.strip().rstrip("-")
    else:
        base = morphology.source_path.stem.strip() or "linea"
    if ext == ".geo":
        return f"GEO {base}.geo"
    if ext == ".xlsx":
        return f"{base}-vel.xlsx"
    return f"{base}-vel{ext}"


def _format_distance_m(value: float) -> str:
    return f"{float(value):.2f}"


def _format_elevation_m(value: float) -> str:
    return f"{float(value):.2f}"


def _format_fbp_ms(value: float | None) -> str:
    if value is None:
        return "0.00"
    val = float(value)
    if abs(val) <= SHOT_EPS_MS:
        return "0.00"
    return f"{val:.2f}"


def _fbp_numeric(value: float | None) -> float | None:
    if value is None:
        return 0.0
    val = float(value)
    if abs(val) <= SHOT_EPS_MS:
        return 0.0
    return round(val, 2)


def _is_fbp_zero(value: float | None) -> bool:
    if value is None:
        return True
    return abs(float(value)) <= SHOT_EPS_MS


def _geophone_channels_for_export(
    morphology: LineMorphology,
    grid: DromocronaGridData,
) -> list[int]:
    channels: set[int] = set(int(ch) for ch in grid.row_channels if int(ch) > 0)
    for geo in morphology.geophones:
        ch = int(geo.source_id) if int(geo.source_id) > 0 else int(geo.trace_idx) + 1
        if ch > 0:
            channels.add(ch)
    if not channels:
        raise ValueError("Nessun geofono disponibile per l'export.")
    return sorted(channels)


def _grid_values_by_channel(
    grid: DromocronaGridData,
) -> dict[int, tuple[float | None, ...]]:
    out: dict[int, tuple[float | None, ...]] = {}
    for row_idx, ch in enumerate(grid.row_channels):
        if row_idx < len(grid.values):
            out[int(ch)] = grid.values[row_idx]
    return out


def build_velocity_export_data(
    morphology: LineMorphology,
    grid: DromocronaGridData,
) -> VelocityExportData:
    if not morphology_has_velocity_export(morphology):
        raise ValueError("Carica prima la morfologia della linea.")
    if not grid.column_labels:
        raise ValueError("Nessun file .fbp da esportare.")

    n_files = len(grid.column_labels)
    channels = _geophone_channels_for_export(morphology, grid)
    values_by_ch = _grid_values_by_channel(grid)

    shot_rows: list[VelocityShotRow] = []
    shot_channels: list[int] = []
    for file_idx in range(n_files):
        shot_ch = (
            int(grid.shot_channels[file_idx]) if file_idx < len(grid.shot_channels) else 0
        )
        if shot_ch <= 0:
            min_ch: int | None = None
            min_val: float | None = None
            for row_idx, ch in enumerate(grid.row_channels):
                if row_idx >= len(grid.values):
                    break
                row_vals = grid.values[row_idx]
                val = row_vals[file_idx] if file_idx < len(row_vals) else None
                if val is None or _is_fbp_zero(val):
                    continue
                fval = float(val)
                if min_val is None or fval < min_val:
                    min_val = fval
                    min_ch = int(ch)
            if min_ch is not None and min_ch > 0:
                shot_ch = min_ch
        shot_channels.append(int(shot_ch))
        shot_trace = max(0, shot_ch - 1)
        shot_rows.append(
            VelocityShotRow(
                file_index=file_idx + 1,
                position_m=float(morphology.cumulative_m_for_trace(shot_trace)),
                elevation_m=float(morphology.elevation_m_for_trace(shot_trace)),
            )
        )

    geophone_rows: list[VelocityGeophoneRow] = []
    for ch in channels:
        trace_idx = int(ch) - 1
        row_vals = values_by_ch.get(int(ch), (None,) * n_files)
        geophone_rows.append(
            VelocityGeophoneRow(
                channel=int(ch),
                distance_m=float(morphology.cumulative_m_for_trace(trace_idx)),
                elevation_m=float(morphology.elevation_m_for_trace(trace_idx)),
                fbp_ms=tuple(
                    row_vals[file_idx] if file_idx < len(row_vals) else None
                    for file_idx in range(n_files)
                ),
            )
        )

    return VelocityExportData(
        n_geophones=len(channels),
        n_files=n_files,
        shot_channels=tuple(shot_channels),
        shot_rows=tuple(shot_rows),
        geophone_rows=tuple(geophone_rows),
    )


def build_velocity_export_lines(data: VelocityExportData) -> list[str]:
    lines: list[str] = [f"{data.n_geophones}\t{data.n_files}"]
    for shot in data.shot_rows:
        lines.append(
            "\t".join(
                (
                    str(shot.file_index),
                    _format_distance_m(shot.position_m),
                    _format_elevation_m(shot.elevation_m),
                )
            )
        )
    for geo in data.geophone_rows:
        parts = [
            _format_distance_m(geo.distance_m),
            _format_elevation_m(geo.elevation_m),
        ]
        parts.extend(_format_fbp_ms(val) for val in geo.fbp_ms)
        lines.append("\t".join(parts))
    return lines


def export_velocity_text_file(output_path: Path, data: VelocityExportData) -> None:
    lines = build_velocity_export_lines(data)
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def export_velocity_excel_file(output_path: Path, data: VelocityExportData) -> None:
    try:
        from openpyxl import Workbook
    except ImportError as exc:
        raise RuntimeError(
            "Serve openpyxl per l'export Excel.\nEsegui: pip install openpyxl"
        ) from exc

    shot_fill = _dromocrona_shot_fill()
    missing_fill = _dromocrona_missing_fill()
    wb = Workbook()
    ws = wb.active
    ws.title = "Velocità"

    ws.cell(row=1, column=1, value=int(data.n_geophones))
    ws.cell(row=1, column=2, value=int(data.n_files))

    excel_row = 2
    for shot in data.shot_rows:
        ws.cell(row=excel_row, column=1, value=int(shot.file_index))
        ws.cell(row=excel_row, column=2, value=round(float(shot.position_m), 2))
        ws.cell(row=excel_row, column=3, value=round(float(shot.elevation_m), 2))
        excel_row += 1

    for geo in data.geophone_rows:
        ws.cell(row=excel_row, column=1, value=round(float(geo.distance_m), 2))
        ws.cell(row=excel_row, column=2, value=round(float(geo.elevation_m), 2))
        for file_idx, val in enumerate(geo.fbp_ms):
            cell = ws.cell(row=excel_row, column=3 + file_idx)
            numeric = _fbp_numeric(val)
            cell.value = numeric
            if not _is_fbp_zero(val):
                continue
            shot_ch = (
                int(data.shot_channels[file_idx])
                if file_idx < len(data.shot_channels)
                else 0
            )
            if shot_ch > 0 and int(geo.channel) == shot_ch:
                cell.fill = shot_fill
            else:
                cell.fill = missing_fill
        excel_row += 1

    wb.save(output_path)


def prompt_velocity_export_file_order(
    parent: QtWidgets.QWidget | None,
    *,
    n_files: int,
    first_label: str = "",
    last_label: str = "",
) -> bool | None:
    """
    Chiede se mantenere o invertire l'ordine dei file in uscita.

    Ritorna True = stesso ordine, False = invertito, None = annullato.
    """
    dlg = QtWidgets.QDialog(parent)
    dlg.setWindowTitle("Ordine file in export")
    dlg.setMinimumWidth(480)

    intro = QtWidgets.QLabel(
        "L'ordine dei file in export segue la posizione dello shot (0), "
        "non il nome file: il primo 0 resta in alto a sinistra.\n"
        "Se la linea è stata acquisita al contrario, puoi invertire quell'ordine."
    )
    intro.setWordWrap(True)

    same = QtWidgets.QRadioButton(
        "Ordine shot crescente — primo 0 in alto a sinistra"
    )
    reversed_btn = QtWidgets.QRadioButton(
        "Ordine shot invertito — primo 0 in basso a sinistra"
    )
    same.setChecked(True)

    detail_parts: list[str] = []
    if n_files > 0:
        detail_parts.append(f"{n_files} file .fbp")
    if first_label and last_label and n_files >= 2:
        detail_parts.append(
            f"Con ordine invertito: «{last_label}» diventa colonna 1, "
            f"«{first_label}» diventa colonna {n_files}."
        )
    detail = QtWidgets.QLabel(" — ".join(detail_parts) if detail_parts else "")
    detail.setWordWrap(True)
    detail.setStyleSheet("color: #9aa3b2;")

    buttons = QtWidgets.QDialogButtonBox(
        QtWidgets.QDialogButtonBox.StandardButton.Ok
        | QtWidgets.QDialogButtonBox.StandardButton.Cancel
    )
    buttons.accepted.connect(dlg.accept)
    buttons.rejected.connect(dlg.reject)

    layout = QtWidgets.QVBoxLayout(dlg)
    layout.addWidget(intro)
    layout.addWidget(same)
    layout.addWidget(reversed_btn)
    if detail.text():
        layout.addWidget(detail)
    layout.addWidget(buttons)

    if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
        return None
    return bool(same.isChecked())


def export_velocity_morphology_file(
    output_path: Path,
    morphology: LineMorphology,
    grid: DromocronaGridData,
    *,
    reverse_file_order: bool = False,
) -> None:
    """Esporta in Excel (.xlsx), GEO (.geo) o testo (.txt) in base all'estensione."""
    export_grid = prepare_dromocrona_grid_for_export(
        grid, reverse_file_order=reverse_file_order
    )
    data = build_velocity_export_data(morphology, export_grid)
    suffix = output_path.suffix.lower()
    if suffix == ".xlsx":
        export_velocity_excel_file(output_path, data)
    elif suffix in {".geo", ".txt"}:
        export_velocity_text_file(output_path, data)
    else:
        raise ValueError(
            "Formato non supportato. Usa estensione .xlsx, .geo o .txt."
        )
