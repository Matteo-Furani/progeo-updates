from __future__ import annotations

import os
from typing import Any

from PyQt6 import QtCore, QtGui, QtWidgets

from app.app_icon import apply_app_icon, load_app_icon
from app.widgets.custom_buttons import BaseMenuButton, DangerActionButton
from app.widgets.sidebar_nav import SidebarNavItem, SidebarToggleButton, resolve_nav_icon
from app.windows.tool_windows import (
    ProcessingWindow,
    ProjectManagerWindow,
    CrossWindow,
    VisualizerWindow,
    launch_cross_tracer,
)

# (id_icona, label, description, accent, factory|"stack", enabled)
# Icone finali: metti file in app/assets/icons/<id>.png (o .svg)
_MENU_ENTRIES: list[tuple[str, str, str, str, object, bool]] = [
    ("siesview", "Siesview", "Visualizzazione tracce", "#5eb3f6", VisualizerWindow, True),
    ("cross", "Cross", "Correlazione", "#6ee7b7", CrossWindow, True),
    ("stack", "Stack", "Stack tracce (CrossTracer)", "#c4a1ff", "stack", False),
    ("merge", "Merge", "Gestione progetti", "#f0b86e", ProjectManagerWindow, False),
    ("utils", "Utilità", "Elaborazioni e strumenti", "#94a3b8", ProcessingWindow, False),
]

_EXPANDED_WIDTH = 236
_COLLAPSED_WIDTH = 60
_EXPANDED_HEIGHT = 300
_COLLAPSED_HEIGHT = 252


def _brand_title_font(pixel_size: int = 18) -> QtGui.QFont:
    """Sans geometrico esteso, vicino al logo ufficiale PROGEO (Bank Gothic / Eurostile)."""
    for family in ("Bahnschrift", "Agency FB", "Verdana", "Segoe UI"):
        font = QtGui.QFont(family)
        if family != "Segoe UI" and not font.exactMatch():
            continue
        font.setStyleHint(QtGui.QFont.StyleHint.SansSerif)
        font.setWeight(QtGui.QFont.Weight.Bold)
        font.setPixelSize(pixel_size)
        # Allarga le lettere come nel logo (extended / square).
        font.setStretch(122 if family == "Bahnschrift" else 110)
        font.setLetterSpacing(QtGui.QFont.SpacingType.AbsoluteSpacing, 1.2)
        font.setCapitalization(QtGui.QFont.Capitalization.AllUppercase)
        return font
    font = QtGui.QFont()
    font.setBold(True)
    font.setPixelSize(pixel_size)
    font.setStretch(120)
    font.setCapitalization(QtGui.QFont.Capitalization.AllUppercase)
    return font

_UPDATE_ICON_ACTIVE = "#5eb3f6"
_UPDATE_ICON_IDLE = "#c8c8d0"
_UPDATE_BTN_ACTIVE_STYLE = """
QPushButton {
    color: #d7efff;
    border: 1px solid rgba(126, 200, 255, 0.55);
    font-size: 13px;
    font-weight: 600;
}
QPushButton:hover {
    background-color: rgba(126, 200, 255, 0.16);
    color: #ffffff;
    border: 1px solid rgba(126, 200, 255, 0.75);
}
"""
_UPDATE_BTN_IDLE_STYLE = """
QPushButton {
    color: #e8e8ed;
    border: 1px solid rgba(255, 255, 255, 0.16);
    font-size: 13px;
    font-weight: 600;
}
QPushButton:hover {
    background-color: rgba(255, 255, 255, 0.08);
    color: #ffffff;
    border: 1px solid rgba(255, 255, 255, 0.28);
}
"""


class _WindowDragArea(QtWidgets.QWidget):
    """Trascina la finestra a mano (niente title bar Windows → niente glitch)."""

    def __init__(
        self,
        parent: QtWidgets.QWidget | None = None,
        *,
        show_grip: bool = True,
    ) -> None:
        super().__init__(parent)
        self._show_grip = show_grip
        self._dragging = False
        self._press_global = QtCore.QPoint()
        self._origin = QtCore.QPoint()
        self.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.SizeAllCursor))
        self.setToolTip("Trascina per spostare")
        if show_grip:
            self.setFixedHeight(22)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Preferred,
        )

    def mousePressEvent(self, event: QtGui.QMouseEvent) -> None:  # type: ignore[override]
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            win = self.window()
            self._dragging = True
            self._press_global = event.globalPosition().toPoint()
            self._origin = win.pos() if win is not None else QtCore.QPoint()
            self.grabMouse()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QtGui.QMouseEvent) -> None:  # type: ignore[override]
        if self._dragging:
            delta = event.globalPosition().toPoint() - self._press_global
            win = self.window()
            if win is not None:
                win.move(self._origin + delta)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent) -> None:  # type: ignore[override]
        if self._dragging and event.button() == QtCore.Qt.MouseButton.LeftButton:
            self._dragging = False
            if QtWidgets.QWidget.mouseGrabber() is self:
                self.releaseMouse()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def paintEvent(self, event: QtGui.QPaintEvent) -> None:  # type: ignore[override]
        del event
        if not self._show_grip:
            return
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        painter.setPen(QtCore.Qt.PenStyle.NoPen)
        painter.setBrush(QtGui.QColor(255, 255, 255, 55))
        cx = self.width() / 2.0
        cy = self.height() / 2.0
        for dx in (-6.0, 0.0, 6.0):
            painter.drawEllipse(QtCore.QPointF(cx + dx, cy), 1.6, 1.6)
        painter.end()


_MENU_STYLESHEET = """
QMainWindow {
    background: transparent;
}
QWidget#MenuShell {
    background: qlineargradient(
        x1:0, y1:0, x2:0, y2:1,
        stop:0 #11131a,
        stop:0.45 #171a22,
        stop:1 #1d212b
    );
    border: 1px solid rgba(255, 255, 255, 0.10);
    border-radius: 14px;
}
QWidget {
    color: #f5f5f7;
}
"""


class MainMenuWindow(QtWidgets.QMainWindow):
    def __init__(
        self,
        local_version: str,
        update_available: bool = False,
        latest_version: str = "",
        update_info: dict[str, Any] | None = None,
    ) -> None:
        super().__init__()
        self.setWindowTitle("Progeo")
        self.setWindowFlags(
            QtCore.Qt.WindowType.Window
            | QtCore.Qt.WindowType.FramelessWindowHint
            | QtCore.Qt.WindowType.WindowSystemMenuHint
        )
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self._expanded = False
        self.setFixedSize(_COLLAPSED_WIDTH, _COLLAPSED_HEIGHT)
        self.setStyleSheet(_MENU_STYLESHEET)
        apply_app_icon(None, self)

        self._child_windows: list[QtWidgets.QWidget] = []
        self._nav_items: list[SidebarNavItem] = []
        self._update_info: dict[str, Any] = dict(update_info or {})
        self._local_version = str(local_version)
        self._update_available = bool(
            update_available or self._update_info.get("update_available")
        )
        self._latest_version = str(
            latest_version
            or self._update_info.get("latest_version")
            or local_version
        )
        self._app_icon = load_app_icon()

        shell = QtWidgets.QWidget()
        shell.setObjectName("MenuShell")
        self._root = QtWidgets.QVBoxLayout(shell)
        self._root.setContentsMargins(6, 10, 6, 10)
        self._root.setSpacing(0)

        # Chrome espanso: grip + chiudi. In rail l'icona è sotto, a tutta larghezza.
        chrome = QtWidgets.QHBoxLayout()
        chrome.setContentsMargins(4, 2, 4, 2)
        chrome.setSpacing(4)
        self._drag_grip = _WindowDragArea(show_grip=True)
        chrome.addWidget(self._drag_grip, 1)

        self._win_close_btn = QtWidgets.QToolButton()
        self._win_close_btn.setText("✕")
        self._win_close_btn.setCursor(
            QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        )
        self._win_close_btn.setFixedSize(24, 24)
        self._win_close_btn.setToolTip("Chiudi")
        self._win_close_btn.setStyleSheet(
            """
            QToolButton {
                color: #9a9aa1;
                background: transparent;
                border: none;
                border-radius: 6px;
                font-size: 12px;
            }
            QToolButton:hover {
                color: #ffffff;
                background: rgba(255, 105, 97, 0.35);
            }
            """
        )
        self._win_close_btn.clicked.connect(self.close)
        chrome.addWidget(self._win_close_btn, 0, QtCore.Qt.AlignmentFlag.AlignVCenter)
        self._root.addLayout(chrome)

        # Badge icona (rail): grande e centrata, anche trascinabile
        self._app_badge_host = _WindowDragArea(show_grip=False)
        self._app_badge_host.setFixedHeight(42)
        self._app_badge_host.setToolTip("Progeo — trascina per spostare")
        badge_row = QtWidgets.QHBoxLayout(self._app_badge_host)
        badge_row.setContentsMargins(0, 2, 0, 2)
        badge_row.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self._app_badge = QtWidgets.QLabel()
        self._app_badge.setFixedSize(32, 32)
        self._app_badge.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self._app_badge.setStyleSheet("background: transparent;")
        self._app_badge.setAttribute(
            QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True
        )
        if self._app_icon is not None:
            self._app_badge.setPixmap(
                self._app_icon.pixmap(QtCore.QSize(32, 32))
            )
        badge_row.addWidget(self._app_badge)
        self._root.addWidget(self._app_badge_host)

        # Header brand (solo espanso) + toggle
        self._header = QtWidgets.QHBoxLayout()
        self._header.setContentsMargins(2, 4, 2, 0)
        self._header.setSpacing(6)

        self._brand_icon = QtWidgets.QLabel()
        self._brand_icon.setFixedSize(32, 32)
        self._brand_icon.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self._brand_icon.setStyleSheet("background: transparent;")
        self._brand_icon.setAttribute(
            QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True
        )
        if self._app_icon is not None:
            self._brand_icon.setPixmap(
                self._app_icon.pixmap(QtCore.QSize(32, 32))
            )

        self._brand_block = QtWidgets.QWidget()
        brand_col = QtWidgets.QVBoxLayout(self._brand_block)
        brand_col.setContentsMargins(0, 0, 0, 0)
        brand_col.setSpacing(0)

        # Stile vicino al logo ufficiale: maiuscolo, geometrico, arancio brand.
        self._brand_title = QtWidgets.QLabel("PROGEO")
        self._brand_title.setFont(_brand_title_font(17))
        self._brand_title.setStyleSheet(
            "color: #e0893a; background: transparent; padding: 0;"
        )
        self._brand_title.setMinimumHeight(22)
        self._brand_title.setAttribute(
            QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True
        )
        brand_col.addWidget(self._brand_title)

        self._brand_sub = QtWidgets.QLabel("Suite strumenti sismici")
        self._brand_sub.setStyleSheet(
            "font-size: 10px; color: #9a9aa1; background: transparent;"
        )
        self._brand_sub.setAttribute(
            QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, True
        )
        brand_col.addWidget(self._brand_sub)

        # Brand trascinabile: icona + testi
        self._brand_drag = _WindowDragArea(show_grip=False)
        self._brand_drag.setMinimumHeight(44)
        brand_host = QtWidgets.QHBoxLayout(self._brand_drag)
        brand_host.setContentsMargins(0, 0, 0, 0)
        brand_host.setSpacing(8)
        brand_host.addWidget(self._brand_icon, 0, QtCore.Qt.AlignmentFlag.AlignVCenter)
        brand_host.addWidget(self._brand_block, 1)
        self._header.addWidget(self._brand_drag, 1)

        self._toggle_btn = SidebarToggleButton()
        self._toggle_btn.clicked.connect(self._toggle_expanded)
        self._header.addWidget(
            self._toggle_btn, 0, QtCore.Qt.AlignmentFlag.AlignTop
        )
        self._root.addLayout(self._header)

        self._accent_line = QtWidgets.QFrame()
        self._accent_line.setFixedHeight(2)
        self._accent_line.setStyleSheet(
            "background: qlineargradient("
            "x1:0, y1:0, x2:1, y2:0, "
            "stop:0 rgba(224, 137, 58, 0.0), "
            "stop:0.5 rgba(224, 137, 58, 0.70), "
            "stop:1 rgba(224, 137, 58, 0.0)"
            "); border: none; border-radius: 1px; margin: 6px 2px 4px 2px;"
        )
        self._root.addWidget(self._accent_line)

        self._nav_host = QtWidgets.QVBoxLayout()
        self._nav_host.setContentsMargins(0, 0, 0, 0)
        self._nav_host.setSpacing(7)
        for icon_name, label, description, accent, action, enabled in _MENU_ENTRIES:
            # Non implementati: nascosti finché non li abilitiamo in _MENU_ENTRIES.
            if not enabled:
                continue
            item = SidebarNavItem(
                label=label,
                description=description,
                accent=accent,
                icon_name=icon_name,
                enabled=True,
            )
            item.clicked.connect(lambda act=action: self._open_action(act))
            self._nav_host.addWidget(item)
            self._nav_items.append(item)
        self._root.addLayout(self._nav_host)

        self._drag_fill = _WindowDragArea(show_grip=False)
        self._root.addWidget(self._drag_fill, 1)

        # Spazio sopra Aggiorna: più largo a menu compresso (distanza dai bottoni nav).
        self._update_gap = QtWidgets.QWidget()
        self._update_gap.setFixedHeight(14)
        self._update_gap.setStyleSheet("background: transparent;")
        self._root.addWidget(self._update_gap)

        self._update_btn = BaseMenuButton("Aggiorna Progeo")
        self._update_btn.setIconSize(QtCore.QSize(13, 13))
        self._update_btn.clicked.connect(self._on_update_clicked)
        self._root.addWidget(self._update_btn)
        self._root.addSpacing(6)

        self._close_btn = DangerActionButton("Chiudi menu")
        self._close_btn.clicked.connect(self.close)
        self._root.addWidget(self._close_btn)

        # Versione in basso a sinistra
        self._version_label = QtWidgets.QLabel(f"v{self._local_version}")
        self._version_label.setAlignment(
            QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignVCenter
        )
        self._version_label.setStyleSheet(
            "font-size: 10px; color: #6f6f78; background: transparent; "
            "padding: 6px 2px 0 2px;"
        )
        self._root.addWidget(self._version_label)

        self.setCentralWidget(shell)
        self._apply_expanded_state(animate=False)
        self._refresh_update_ui()
        self._install_test_update_shortcut()
        # Avviso soft dopo che la finestra è visibile (non blocca l'uso).
        QtCore.QTimer.singleShot(500, self._maybe_notify_update_available)

    def _install_test_update_shortcut(self) -> None:
        """Alt+F: controlla canale TEST (progeo-updates/ProgeoView/test)."""
        sc = QtGui.QShortcut(QtGui.QKeySequence("Alt+F"), self)
        sc.setContext(QtCore.Qt.ShortcutContext.WindowShortcut)
        sc.activated.connect(self._on_test_update_requested)
        self._test_update_shortcut = sc

    def _on_test_update_requested(self) -> None:
        from updater.update_dialog import prompt_and_apply_update
        from updater.version_service import check_for_update, read_local_version

        QtWidgets.QToolTip.showText(
            QtGui.QCursor.pos(),
            "Controllo aggiornamento TEST…",
            self,
            QtCore.QRect(),
            1500,
        )
        info = check_for_update(
            local_version=read_local_version(),
            channel="test",
            force=True,
        )
        notes = str(info.get("release_notes") or "").strip()
        if notes and not notes.startswith("[TEST]"):
            info["release_notes"] = f"[TEST]\n{notes}"
        elif not notes:
            info["release_notes"] = (
                "[TEST]\nPacchetto dal canale test (non ufficiale)."
            )
        if prompt_and_apply_update(self, info):
            self._quit_for_update()

    def _quit_for_update(self) -> None:
        """Chiude subito l'app così lo script patch può applicare e riavviare."""
        app = QtWidgets.QApplication.instance()
        if app is not None:
            app.closeAllWindows()
            app.quit()
        # Fallback se qualche finestra blocca il quit pulito.
        QtCore.QTimer.singleShot(800, lambda: os._exit(0))

    def _refresh_update_ui(self) -> None:
        """Icona blu se c'è update, scura altrimenti — leggibile anche a menu compresso."""
        available = bool(self._update_available)
        accent = _UPDATE_ICON_ACTIVE if available else _UPDATE_ICON_IDLE
        icon_size = 16 if self._expanded else 13
        base = self._update_btn.styleSheet()
        # Rimuovi stili update precedenti e riapplica.
        marker = "/* update-state */"
        if marker in base:
            base = base.split(marker)[0].rstrip()
        state_css = _UPDATE_BTN_ACTIVE_STYLE if available else _UPDATE_BTN_IDLE_STYLE
        # A menu compresso: padding ridotto così il bottone resta compatto.
        size_css = (
            "QPushButton { padding: 6px 12px; border-radius: 9px; }"
            if self._expanded
            else "QPushButton { padding: 2px; border-radius: 6px; }"
        )
        self._update_btn.setStyleSheet(
            f"{base}\n{marker}\n{state_css}\n{size_css}"
        )
        self._update_btn.setIconSize(QtCore.QSize(icon_size, icon_size))
        self._update_btn.setIcon(resolve_nav_icon("update", accent, size=icon_size))

        if available:
            tip = f"Aggiornamento {self._latest_version} disponibile"
            self._version_label.setToolTip(tip)
            self._version_label.setStyleSheet(
                "font-size: 10px; color: #5eb3f6; background: transparent; "
                "padding: 6px 2px 0 2px;"
            )
            if self._expanded:
                self._update_btn.setText(f"Aggiorna a v{self._latest_version}")
                self._update_btn.setToolTip(tip)
            else:
                self._update_btn.setText("")
                self._update_btn.setToolTip(tip)
        else:
            self._version_label.setToolTip("")
            self._version_label.setStyleSheet(
                "font-size: 10px; color: #6f6f78; background: transparent; "
                "padding: 6px 2px 0 2px;"
            )
            if self._expanded:
                self._update_btn.setText("Aggiorna Progeo")
                self._update_btn.setToolTip("Nessun aggiornamento disponibile")
            else:
                self._update_btn.setText("")
                self._update_btn.setToolTip("Nessun aggiornamento disponibile")

        # Freccia espandi: blu solo se c'è un update (segnale anche a menu chiuso).
        toggle = getattr(self, "_toggle_btn", None)
        if toggle is not None:
            toggle_color = _UPDATE_ICON_ACTIVE if available else "#9a9aa1"
            size = 18
            toggle.setIcon(resolve_nav_icon("menu", toggle_color, size=size))
            if available:
                toggle.setToolTip(
                    f"Espandi menu — aggiornamento {self._latest_version} disponibile"
                    if not self._expanded
                    else f"Comprimi menu — aggiornamento {self._latest_version} disponibile"
                )
            else:
                toggle.setToolTip(
                    "Espandi menu" if not self._expanded else "Comprimi menu"
                )

    def _maybe_notify_update_available(self) -> None:
        """Avviso leggero all'avvio (non modale): una volta per versione remota."""
        if not self._update_available or not self.isVisible():
            return
        latest = str(self._latest_version or "").strip()
        if not latest:
            return
        settings = QtCore.QSettings("Progeo", "ProgeoView")
        seen = str(settings.value("update/notified_version", "") or "")
        if seen == latest:
            return
        settings.setValue("update/notified_version", latest)

        box = QtWidgets.QMessageBox(self)
        box.setIcon(QtWidgets.QMessageBox.Icon.Information)
        box.setWindowTitle("Aggiornamento disponibile")
        box.setText(f"È disponibile ProgeoView {latest}.")
        box.setInformativeText(
            "Quando vuoi, usa Aggiorna nel menu (icona blu)."
        )
        box.setStandardButtons(QtWidgets.QMessageBox.StandardButton.Ok)
        box.setDefaultButton(QtWidgets.QMessageBox.StandardButton.Ok)
        # Non-modale: non blocca l'uso del menu.
        box.open()

    def _toggle_expanded(self) -> None:
        self._expanded = not self._expanded
        self._apply_expanded_state(animate=True)

    def _apply_expanded_state(self, *, animate: bool) -> None:
        target_w = _EXPANDED_WIDTH if self._expanded else _COLLAPSED_WIDTH
        target_h = _EXPANDED_HEIGHT if self._expanded else _COLLAPSED_HEIGHT

        self._brand_drag.setVisible(self._expanded)
        self._accent_line.setVisible(self._expanded)
        self._toggle_btn.set_expanded(self._expanded)
        self._close_btn.setVisible(self._expanded)
        # Rail: icona Progeo grande; espanso: icona nel brand header.
        self._app_badge_host.setVisible(not self._expanded)

        if self._expanded:
            self._root.setContentsMargins(12, 8, 12, 10)
            self._nav_host.setSpacing(4)
            self._header.setContentsMargins(0, 2, 0, 0)
            self._header.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)
            self._drag_grip.setVisible(True)
            self._update_gap.setFixedHeight(4)
            self._update_btn.setMinimumHeight(30)
            self._update_btn.setMaximumHeight(30)
            self._update_btn.setIconSize(QtCore.QSize(16, 16))
            self._close_btn.setMinimumHeight(28)
            self._close_btn.setMaximumHeight(28)
            self._close_btn.setText("Chiudi menu")
        else:
            self._root.setContentsMargins(5, 6, 5, 8)
            self._nav_host.setSpacing(2)
            self._header.setContentsMargins(0, 2, 0, 2)
            self._header.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
            self._drag_grip.setVisible(True)
            self._update_gap.setFixedHeight(14)
            self._update_btn.setFixedHeight(22)
            self._update_btn.setIconSize(QtCore.QSize(13, 13))

        self._refresh_update_ui()

        for item in self._nav_items:
            item.set_expanded(self._expanded)

        if animate:
            group = QtCore.QParallelAnimationGroup(self)
            for prop, end in (
                (b"minimumWidth", target_w),
                (b"maximumWidth", target_w),
                (b"minimumHeight", target_h),
                (b"maximumHeight", target_h),
            ):
                anim = QtCore.QPropertyAnimation(self, prop, group)
                anim.setDuration(170)
                start = (
                    self.width()
                    if prop in (b"minimumWidth", b"maximumWidth")
                    else self.height()
                )
                anim.setStartValue(start)
                anim.setEndValue(end)
                anim.setEasingCurve(QtCore.QEasingCurve.Type.OutCubic)
                group.addAnimation(anim)

            def _lock() -> None:
                self.setFixedSize(target_w, target_h)

            group.finished.connect(_lock)
            self._size_anim = group
            group.start()
        else:
            self.setFixedSize(target_w, target_h)

    def _on_update_clicked(self) -> None:
        from updater.update_dialog import prompt_and_apply_update
        from updater.version_service import check_for_update, read_local_version

        info = self._update_info
        if not info.get("update_available"):
            info = check_for_update(local_version=read_local_version())
            self._update_info = info
            self._update_available = bool(info.get("update_available"))
            self._latest_version = str(
                info.get("latest_version") or self._local_version
            )
            self._refresh_update_ui()

        if prompt_and_apply_update(self, info):
            self._quit_for_update()

    def _open_action(self, action: object) -> None:
        if action == "stack":
            launch_cross_tracer(self)
            return
        if callable(action):
            self._open_window(action())

    def _open_window(self, window: QtWidgets.QWidget) -> None:
        self._child_windows.append(window)
        window.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, True)
        window.destroyed.connect(lambda *_: self._cleanup_closed_windows())
        try:
            from app.app_icon import apply_app_icon

            apply_app_icon(None, window)
        except Exception:
            pass
        window.show()
        window.raise_()
        window.activateWindow()

    def _cleanup_closed_windows(self) -> None:
        self._child_windows = [w for w in self._child_windows if w is not None]
