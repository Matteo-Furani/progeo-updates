"""Analisi reciproco automatica per il monitor dromocrone FBP (Siesview)."""

from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from constants import natural_sort_key


SHOT_DROMOCRONA_EPS_MS = 1e-6
FBP_MISSING_PICK_LINE = "0\t0.000000\t0"  # legacy; non usare — preferire fbp_missing_pick_line()
DEFAULT_RECIPROCAL_TOLERANCE_MS = 5.0


def fbp_missing_pick_line(trace_idx: int) -> str:
    """Riga .fbp per pick assente, con canale 1-based conservato.

    Non usare ``0\\t0.000000\\t0``: azzera il canale e corrompe la mappa
    traccia→riga usata dal salvataggio dal monitor dromocrona.
    """
    return f"{max(0, int(trace_idx)) + 1}\t0.000000\t0"


def is_missing_fbp_pick(
    trace_idx: int,
    t_ms: float,
    *,
    shot_trace_idx: int | None = None,
    shot_eps_ms: float = SHOT_DROMOCRONA_EPS_MS,
) -> bool:
    """True se il valore rappresenta un pick assente (riga ``0\\t0.000000\\t0``), non lo shot."""
    if not math.isfinite(float(t_ms)):
        return True
    if float(t_ms) > float(shot_eps_ms):
        return False
    if shot_trace_idx is not None and int(trace_idx) == int(shot_trace_idx):
        return False
    return True


@dataclass(frozen=True)
class ReciprocalToleranceBands:
    """Fasce distanza (n° tracce tra shot) → soglia tempo (ms) per FAIL reciproco.

    Default storico: dist≤12 → 2.0 ms; dist≤24 → 3.5 ms; oltre → 5.0 ms.
    """

    dist_near: float = 12.0
    dist_mid: float = 24.0
    tol_near_ms: float = 2.0
    tol_mid_ms: float = 3.5
    tol_far_ms: float = 5.0

    def normalized(self) -> "ReciprocalToleranceBands":
        dist_near = max(0.0, float(self.dist_near))
        dist_mid = max(dist_near, float(self.dist_mid))
        return ReciprocalToleranceBands(
            dist_near=dist_near,
            dist_mid=dist_mid,
            tol_near_ms=max(0.0, float(self.tol_near_ms)),
            tol_mid_ms=max(0.0, float(self.tol_mid_ms)),
            tol_far_ms=max(0.0, float(self.tol_far_ms)),
        )

    def tolerance_for_distance(self, dist: float) -> float:
        d = abs(float(dist))
        if d <= float(self.dist_near):
            return float(self.tol_near_ms)
        if d <= float(self.dist_mid):
            return float(self.tol_mid_ms)
        return float(self.tol_far_ms)

    def as_cache_key(self) -> tuple[float, float, float, float, float]:
        b = self.normalized()
        return (
            float(b.dist_near),
            float(b.dist_mid),
            float(b.tol_near_ms),
            float(b.tol_mid_ms),
            float(b.tol_far_ms),
        )

    def to_dict(self) -> dict[str, float]:
        b = self.normalized()
        return {
            "dist_near": float(b.dist_near),
            "dist_mid": float(b.dist_mid),
            "tol_near_ms": float(b.tol_near_ms),
            "tol_mid_ms": float(b.tol_mid_ms),
            "tol_far_ms": float(b.tol_far_ms),
        }

    @classmethod
    def from_dict(cls, data: object | None) -> "ReciprocalToleranceBands":
        if isinstance(data, ReciprocalToleranceBands):
            return data.normalized()
        if not isinstance(data, dict):
            return DEFAULT_RECIPROCAL_TOLERANCE_BANDS
        return ReciprocalToleranceBands(
            dist_near=float(data.get("dist_near", 12.0)),
            dist_mid=float(data.get("dist_mid", 24.0)),
            tol_near_ms=float(data.get("tol_near_ms", 2.0)),
            tol_mid_ms=float(data.get("tol_mid_ms", 3.5)),
            tol_far_ms=float(data.get("tol_far_ms", 5.0)),
        ).normalized()


DEFAULT_RECIPROCAL_TOLERANCE_BANDS = ReciprocalToleranceBands()


@dataclass(frozen=True)
class ShotDetectionResult:
    """Posizione shot rilevata o letta da registry."""

    shot_channel: int
    shot_trace_idx: int
    method: str
    note: str = ""

    @property
    def is_valid(self) -> bool:
        return self.shot_channel > 0


@dataclass(frozen=True)
class DromocronaSeriesSnapshot:
    """Serie dromocrona pronta per il confronto reciproco."""

    label: str
    trace_idx: np.ndarray
    x_display: np.ndarray
    dromocrona_ms: np.ndarray
    shot_trace_idx: int


@dataclass(frozen=True)
class ReciprocalQuickResult:
    """Controllo a rettangolo (due angoli interni opposti)."""

    shot_a_label: str
    shot_b_label: str
    trace_pos_a: int
    trace_pos_b: int
    t_a_at_pos_a: float
    t_b_at_pos_b: float
    t_b_at_pos_a: float
    t_a_at_pos_b: float
    corner_delta_ms: float
    tolerance_ms: float
    passed: bool

    @property
    def failed_trace_on_series_a(self) -> int:
        return int(self.trace_pos_b)

    @property
    def failed_trace_on_series_b(self) -> int:
        return int(self.trace_pos_a)


@dataclass(frozen=True)
class ReciprocalPairResult:
    """Controllo diretto: dromocrona di riferimento (A) vs ogni altra dromocrona (B)."""

    series_idx_a: int
    series_idx_b: int
    neighbor_offset: int
    trace_pos_a: int
    trace_pos_b: int
    result: ReciprocalQuickResult


def _fbp_registry_key(name: str) -> str:
    text = str(name).strip().lower()
    if text.endswith(".fbp"):
        return text
    return f"{text}.fbp"


def parse_fbp_line(raw: str, line_no: int) -> tuple[int, int, float] | None:
    """Interpreta una riga .fbp: (canale, traccia_0based, tempo_ms)."""
    line = raw.strip()
    if not line or line.startswith("#"):
        return None
    parts = line.split()
    if len(parts) < 2:
        return None
    channel_no = 0
    if len(parts) >= 3:
        try:
            channel_no = int(float(parts[0].replace(",", ".")))
        except Exception:
            channel_no = 0
        time_token = parts[1]
    else:
        time_token = parts[0]
    try:
        t_val = float(time_token.replace(",", "."))
    except Exception:
        t_val = 0.0
    if channel_no > 0:
        trace_idx = channel_no - 1
    else:
        trace_idx = int(line_no)
    return int(channel_no), int(trace_idx), float(t_val)


@dataclass(frozen=True)
class FbpParsedCache:
    """Contenuto parsato di un .fbp (una sola lettura disco)."""

    by_channel: dict[int, float]
    by_trace_positive: dict[int, float]
    parsed_rows: tuple[tuple[int, int, int, float], ...]
    placeholder_line_nos: tuple[int, ...]
    explicit_zero_traces: tuple[int, ...]
    n_lines: int
    samples_by_trace: tuple[tuple[int, int], ...]
    raw_lines: tuple[str, ...]


_fbp_parse_cache: dict[str, tuple[float, FbpParsedCache]] = {}


def _fbp_cache_key(fbp_path: Path) -> str:
    try:
        return str(fbp_path.resolve())
    except Exception:
        return str(fbp_path)


def invalidate_fbp_parse_cache(fbp_path: Path | None = None) -> None:
    """Invalida la cache parse .fbp (tutto o un solo file dopo scrittura)."""
    if fbp_path is None:
        _fbp_parse_cache.clear()
        return
    _fbp_parse_cache.pop(_fbp_cache_key(fbp_path), None)


def _parse_fbp_file(fbp_path: Path) -> FbpParsedCache | None:
    """Legge e parsa un .fbp una volta; risultato in cache fino a modifica file."""
    if not fbp_path.is_file():
        invalidate_fbp_parse_cache(fbp_path)
        return None
    key = _fbp_cache_key(fbp_path)
    try:
        mtime = float(fbp_path.stat().st_mtime)
    except Exception:
        mtime = -1.0
    hit = _fbp_parse_cache.get(key)
    if hit is not None and hit[0] == mtime:
        return hit[1]
    try:
        lines = fbp_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return None

    by_channel: dict[int, float] = {}
    by_trace_positive: dict[int, float] = {}
    parsed_rows: list[tuple[int, int, int, float]] = []
    placeholder_line_nos: list[int] = []
    explicit_zero_traces: list[int] = []
    samples_by_trace: dict[int, int] = {}

    data_line_no = 0
    for line_no, raw in enumerate(lines):
        parsed = parse_fbp_line(raw, data_line_no)
        if parsed is None:
            continue
        channel_no, trace_idx, t_ms = parsed
        if channel_no == 0:
            data_line_no += 1
        parts = raw.strip().split()
        if len(parts) >= 2:
            sample_token = parts[2] if len(parts) >= 3 else parts[1]
            try:
                samples_by_trace[int(trace_idx)] = int(
                    float(sample_token.replace(",", "."))
                )
            except ValueError:
                pass
        if channel_no == 0 and abs(t_ms) <= SHOT_DROMOCRONA_EPS_MS:
            placeholder_line_nos.append(int(line_no))
            continue
        parsed_rows.append(
            (int(line_no), int(channel_no), int(trace_idx), float(t_ms))
        )
        if channel_no > 0 and abs(t_ms) <= SHOT_DROMOCRONA_EPS_MS:
            explicit_zero_traces.append(int(trace_idx))
        if math.isfinite(t_ms) and t_ms > SHOT_DROMOCRONA_EPS_MS:
            prev_tr = by_trace_positive.get(trace_idx)
            if prev_tr is None or float(t_ms) < prev_tr:
                by_trace_positive[int(trace_idx)] = float(t_ms)
            ch = int(channel_no) if channel_no > 0 else int(trace_idx) + 1
            if ch > 0:
                prev_ch = by_channel.get(ch)
                if prev_ch is None or float(t_ms) < prev_ch:
                    by_channel[ch] = float(t_ms)

    if not parsed_rows:
        return None

    cached = FbpParsedCache(
        by_channel=by_channel,
        by_trace_positive=by_trace_positive,
        parsed_rows=tuple(parsed_rows),
        placeholder_line_nos=tuple(placeholder_line_nos),
        explicit_zero_traces=tuple(explicit_zero_traces),
        n_lines=len(lines),
        samples_by_trace=tuple(sorted(samples_by_trace.items())),
        raw_lines=tuple(lines),
    )
    _fbp_parse_cache[key] = (mtime, cached)
    return cached


def _fbp_line_by_trace_from_lines(lines: list[str] | tuple[str, ...]) -> dict[int, int]:
    """Mappa traccia 0-based → indice riga nel file (per scrittura in-place).

    Le righe con canale > 0 vincolano l'indice. I placeholder ``0\\t0\\t0``
    (pick mancante senza canale) occupano i buchi sequenziali, senza
    sovrascrivere i canali reali. Il formato a 2 colonne resta sequenziale.
    """
    mapping: dict[int, int] = {}
    placeholders: list[int] = []
    data_line_no = 0
    for line_no, raw in enumerate(lines):
        parsed = parse_fbp_line(raw, data_line_no)
        if parsed is None:
            continue
        channel_no, _trace_idx, _t_ms = parsed
        if int(channel_no) > 0:
            mapping[int(channel_no) - 1] = int(line_no)
        else:
            placeholders.append(int(line_no))
            data_line_no += 1
    if not mapping:
        return {i: int(line_no) for i, line_no in enumerate(placeholders)}
    next_tr = 0
    for line_no in placeholders:
        while next_tr in mapping:
            next_tr += 1
        mapping[next_tr] = int(line_no)
        next_tr += 1
    return mapping


def _fbp_effective_n_traces(
    n_lines: int,
    samples: dict[int, int],
    line_by_trace: dict[int, int] | None = None,
) -> int:
    """Numero tracce effettivo (righe file vs indici canale più alti)."""
    n = int(n_lines)
    if samples:
        n = max(n, max(samples.keys()) + 1)
    if line_by_trace:
        n = max(n, max(line_by_trace.keys()) + 1)
    return n


def fbp_disk_export_meta(
    fbp_path: Path,
) -> tuple[float | None, int, dict[int, int]]:
    """Riferimento assoluto, numero righe e campioni (da cache parse)."""
    template = fbp_disk_write_template(fbp_path)
    if template is None:
        return None, 0, {}
    ref, n_lines, samples, _lines, line_by_trace = template
    n_traces = _fbp_effective_n_traces(n_lines, samples, line_by_trace)
    return ref, n_traces, samples


def fbp_disk_write_template(
    fbp_path: Path,
) -> tuple[float | None, int, dict[int, int], list[str], dict[int, int]] | None:
    """Template completo per riscrittura rapida .fbp (righe + mappa traccia→riga)."""
    parsed = _parse_fbp_file(fbp_path)
    if parsed is None:
        return None
    ref = fbp_display_reference_abs_ms(fbp_path)
    if ref is None:
        positives = [
            float(t)
            for t in parsed.by_trace_positive.values()
            if math.isfinite(float(t)) and float(t) > 0.0
        ]
        ref = float(min(positives)) if positives else 0.0
    lines = list(parsed.raw_lines)
    samples = {int(k): int(v) for k, v in parsed.samples_by_trace}
    line_by_trace = _fbp_line_by_trace_from_lines(lines)
    n_traces = _fbp_effective_n_traces(int(parsed.n_lines), samples, line_by_trace)
    return ref, n_traces, samples, lines, line_by_trace


def _positive_fbp_rows_from_path(
    fbp_path: Path,
) -> tuple[list[int], np.ndarray] | None:
    parsed = _parse_fbp_file(fbp_path)
    if parsed is None or len(parsed.by_trace_positive) < 2:
        return None
    idx_sorted = sorted(parsed.by_trace_positive.keys())
    times = [parsed.by_trace_positive[i] for i in idx_sorted]
    return idx_sorted, np.asarray(times, dtype=np.float64)


def _shot_reference_abs_ms(
    idx_sorted: list[int],
    times_ms: np.ndarray,
    *,
    shot_trace_idx: int | None = None,
) -> float | None:
    """Tempo assoluto di riferimento = minimo positivo (allineato a build_relative_profile)."""
    if len(idx_sorted) < 2 or times_ms.size < 2:
        return None
    x = np.asarray(idx_sorted, dtype=np.float64)
    t = np.asarray(times_ms, dtype=np.float64)
    finite = np.isfinite(x) & np.isfinite(t) & (t > 0.0)
    if np.count_nonzero(finite) < 2:
        return None
    x = x[finite]
    t = t[finite]
    if x.size < 2:
        return None
    min_pos = int(np.argmin(t))
    shot_pos = min_pos
    if shot_trace_idx is not None:
        shot_matches = np.where(np.abs(x - float(shot_trace_idx)) <= 1e-12)[0]
        if shot_matches.size > 0:
            cand = int(shot_matches[0])
            if float(t[cand]) <= float(t[min_pos]) + 1e-6:
                shot_pos = cand
    return float(t[shot_pos])


def resolve_display_shot_for_fbp_path(fbp_path: Path) -> ShotDetectionResult:
    """Riferimento visualizzazione monitor/griglia: minimo tempo (copia-incolla)."""
    auto = detect_shot_from_fbp_path(fbp_path)
    if auto is not None and auto.is_valid:
        return auto
    return ShotDetectionResult(
        shot_channel=0,
        shot_trace_idx=0,
        method="unknown",
        note="non rilevato",
    )


def fbp_display_reference_abs_ms(fbp_path: Path) -> float | None:
    """shot_t per monitor/griglia (minimo tempo nel .fbp, come copia-incolla)."""
    packed = _positive_fbp_rows_from_path(fbp_path)
    if packed is None:
        return None
    idx_sorted, times = packed
    shot = resolve_display_shot_for_fbp_path(fbp_path)
    shot_tr = shot.shot_trace_idx if shot.is_valid else None
    return _shot_reference_abs_ms(idx_sorted, times, shot_trace_idx=shot_tr)


def fbp_relative_to_absolute_ms(
    fbp_path: Path,
    time_rel_ms: float,
    *,
    registry: dict[str, int] | None = None,
    shot_abs_ref_ms: float | None = None,
) -> float | None:
    """Converte dromocrona monitor (vs minimo) nel tempo assoluto del .fbp."""
    del registry
    if shot_abs_ref_ms is not None:
        try:
            ref = float(shot_abs_ref_ms)
        except (TypeError, ValueError):
            ref = float("nan")
        if math.isfinite(ref):
            return float(ref) + float(time_rel_ms)
    shot_t = fbp_display_reference_abs_ms(fbp_path)
    if shot_t is None:
        return None
    return float(shot_t + float(time_rel_ms))


def build_relative_profile(
    idx_sorted: list[int],
    times_ms: np.ndarray,
    *,
    shot_trace_idx: int | None = None,
) -> tuple[np.ndarray, np.ndarray, int] | None:
    """Profilo tempi relativi al minimo positivo (convenzione copia-incolla).

    Lo shot di registro, se imposto, viene usato come riferimento solo se il suo
    tempo è il minimo (o entro eps). Altrimenti si usa il minimo reale: usare un
    tempo shot più alto farebbe scendere gli altri punti sottozero / a y=0.
    """
    if len(idx_sorted) < 2 or times_ms.size < 2:
        return None
    x = np.asarray(idx_sorted, dtype=np.float64)
    t = np.asarray(times_ms, dtype=np.float64)
    finite = np.isfinite(x) & np.isfinite(t) & (t > 0.0)
    if np.count_nonzero(finite) < 2:
        return None
    x = x[finite]
    t = t[finite]
    if x.size < 2:
        return None
    min_pos = int(np.argmin(t))
    shot_pos = min_pos
    if shot_trace_idx is not None:
        shot_matches = np.where(np.abs(x - float(shot_trace_idx)) <= 1e-12)[0]
        if shot_matches.size > 0:
            cand = int(shot_matches[0])
            # Accetta lo shot imposto solo se non è più tardi del minimo.
            if float(t[cand]) <= float(t[min_pos]) + 1e-6:
                shot_pos = cand
    shot_x = float(x[shot_pos])
    shot_t = float(t[shot_pos])
    dt_ms_rel = np.maximum(0.0, t - shot_t)
    dt_ms_rel[np.abs(x - shot_x) <= 1e-12] = 0.0
    return x, dt_ms_rel, int(round(shot_x))


def detect_shot_from_parsed(parsed: FbpParsedCache) -> ShotDetectionResult | None:
    """Rileva shot da contenuto già parsato (nessuna I/O)."""
    if not parsed.parsed_rows:
        return None

    if len(parsed.explicit_zero_traces) == 1:
        tr = int(parsed.explicit_zero_traces[0])
        return ShotDetectionResult(
            shot_channel=tr + 1,
            shot_trace_idx=tr,
            method="explicit_zero",
            note="tempo 0.000 sulla colonna canale",
        )

    if parsed.by_trace_positive:
        tr = min(parsed.by_trace_positive, key=lambda key: parsed.by_trace_positive[key])
        return ShotDetectionResult(
            shot_channel=int(tr) + 1,
            shot_trace_idx=int(tr),
            method="copy_paste_min",
            note="minimo tempo (come copia-incolla)",
        )

    for pl_line in parsed.placeholder_line_nos:
        for line_no, channel_no, trace_idx, _t_val in parsed.parsed_rows:
            if line_no <= pl_line or channel_no <= 0:
                continue
            return ShotDetectionResult(
                shot_channel=int(channel_no),
                shot_trace_idx=int(trace_idx),
                method="placeholder_next",
                note="riga 0\\t0.000000\\t0 seguita da canale",
            )

    return None


def detect_shot_from_fbp_path(fbp_path: Path) -> ShotDetectionResult | None:
    """Tenta di individuare lo shot in un .fbp (strategie multiple)."""
    parsed = _parse_fbp_file(fbp_path)
    if parsed is None:
        return None
    return detect_shot_from_parsed(parsed)


def resolve_shot_for_fbp_path(
    fbp_path: Path,
    registry: dict[str, int] | None = None,
) -> ShotDetectionResult:
    """Registry manuale > rilevamento automatico."""
    key = _fbp_registry_key(fbp_path.name)
    reg = registry or {}
    if key in reg:
        channel = int(reg[key])
        return ShotDetectionResult(
            shot_channel=channel,
            shot_trace_idx=max(0, channel - 1),
            method="registry",
            note="shot in sessione",
        )
    auto = detect_shot_from_fbp_path(fbp_path)
    if auto is not None and auto.is_valid:
        return auto
    return ShotDetectionResult(
        shot_channel=0,
        shot_trace_idx=0,
        method="unknown",
        note="non rilevato",
    )


def load_fbp_relative_profile(
    fbp_path: Path,
    *,
    registry: dict[str, int] | None = None,
    shot_channel: int | None = None,
) -> tuple[np.ndarray, np.ndarray, ShotDetectionResult] | None:
    """Carica .fbp con dromocrone visualizzate (t − t_min, convenzione copia-incolla)."""
    parsed = _parse_fbp_file(fbp_path)
    if parsed is None or len(parsed.by_trace_positive) < 2:
        return None
    idx_sorted = sorted(parsed.by_trace_positive.keys())
    times = [parsed.by_trace_positive[i] for i in idx_sorted]
    if len(idx_sorted) < 2:
        return None

    if shot_channel is not None and int(shot_channel) > 0:
        shot = ShotDetectionResult(
            shot_channel=int(shot_channel),
            shot_trace_idx=int(shot_channel) - 1,
            method="forced",
            note="canale imposto",
        )
    elif registry:
        shot = resolve_shot_for_fbp_path(fbp_path, registry)
    else:
        shot = resolve_display_shot_for_fbp_path(fbp_path)

    built = build_relative_profile(
        idx_sorted,
        np.asarray(times, dtype=np.float64),
        shot_trace_idx=shot.shot_trace_idx if shot.is_valid else None,
    )
    if built is None:
        return None
    x, y_rel, shot_trace = built
    if shot.is_valid and int(shot.shot_trace_idx) == int(shot_trace):
        shot = ShotDetectionResult(
            shot_channel=int(shot.shot_channel),
            shot_trace_idx=int(shot_trace),
            method=shot.method,
            note=shot.note,
        )
    else:
        shot = ShotDetectionResult(
            shot_channel=int(shot_trace) + 1,
            shot_trace_idx=int(shot_trace),
            method="copy_paste_min",
            note="riferimento = minimo tempo (evita y sottozero)",
        )
    return x, y_rel, shot


def _fbp_channel_time_map(fbp_path: Path) -> dict[int, float] | None:
    parsed = _parse_fbp_file(fbp_path)
    if parsed is None or not parsed.by_channel:
        return None
    return dict(parsed.by_channel)


def load_fbp_seismogram_dromocrona_column(
    fbp_path: Path,
    *,
    registry: dict[str, int] | None = None,
) -> tuple[dict[int, float], ShotDetectionResult] | None:
    """
    Colonna griglia = tempo assoluto nel .fbp meno t_min (copia-incolla).

    Coerente con il monitor dromocrone; il file .fbp resta con tempi assoluti.
    """
    by_channel = _fbp_channel_time_map(fbp_path)
    if not by_channel:
        return None

    shot = resolve_shot_for_fbp_path(fbp_path, registry)
    shot_t = fbp_display_reference_abs_ms(fbp_path)
    if shot_t is None:
        shot_t = float(min(by_channel.values()))
    if not shot.is_valid:
        shot_ch = min(
            ch for ch, t in by_channel.items() if abs(t - shot_t) <= 1e-9
        )
        shot = ShotDetectionResult(
            shot_channel=int(shot_ch),
            shot_trace_idx=int(shot_ch) - 1,
            method="fallback_min",
            note="riferimento minimo assoluto",
        )

    out = {ch: float(t_abs) - float(shot_t) for ch, t_abs in by_channel.items()}
    return out, shot


def iter_fbp_trace_absolute_times(
    fbp_path: Path,
) -> tuple[dict[int, float], int]:
    """Mappa traccia→tempo assoluto (ms) per ogni riga dati del .fbp; pick mancante = 0."""
    parsed = _parse_fbp_file(fbp_path)
    if parsed is not None:
        raw_lines = list(parsed.raw_lines)
        samples = {int(k): int(v) for k, v in parsed.samples_by_trace}
    else:
        if not fbp_path.is_file():
            return {}, 0
        try:
            raw_lines = fbp_path.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            return {}, 0
        if not raw_lines:
            return {}, 0
        samples = {}
        data_line = 0
        for raw in raw_lines:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parsed_line = parse_fbp_line(raw, data_line)
            if parsed_line is None:
                continue
            _ch, trace_idx, _t_ms = parsed_line
            parts = line.split()
            if len(parts) >= 2:
                sample_token = parts[2] if len(parts) >= 3 else parts[1]
                try:
                    samples[int(trace_idx)] = int(float(sample_token.replace(",", ".")))
                except ValueError:
                    pass
            data_line += 1

    abs_by_trace: dict[int, float] = {}
    data_line = 0
    for raw in raw_lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        channel_no = 0
        if len(parts) >= 3:
            try:
                channel_no = int(float(parts[0].replace(",", ".")))
            except Exception:
                channel_no = 0
            time_token = parts[1]
        else:
            time_token = parts[0]
        try:
            t_ms = float(time_token.replace(",", "."))
        except Exception:
            t_ms = 0.0
        if channel_no == 0 and abs(t_ms) <= SHOT_DROMOCRONA_EPS_MS:
            abs_by_trace[int(data_line)] = 0.0
        elif channel_no > 0:
            tr = int(channel_no) - 1
            if abs(t_ms) <= SHOT_DROMOCRONA_EPS_MS:
                abs_by_trace[int(tr)] = 0.0
            else:
                abs_by_trace[int(tr)] = float(t_ms)
        else:
            if abs(t_ms) <= SHOT_DROMOCRONA_EPS_MS:
                abs_by_trace[int(data_line)] = 0.0
            else:
                abs_by_trace[int(data_line)] = float(t_ms)
        data_line += 1
    line_by_trace = _fbp_line_by_trace_from_lines(raw_lines)
    n_traces = _fbp_effective_n_traces(len(raw_lines), samples, line_by_trace)
    if n_traces <= 0:
        n_traces = int(data_line)
    else:
        n_traces = max(int(n_traces), int(data_line))
    for tr in range(n_traces):
        abs_by_trace.setdefault(int(tr), 0.0)
    return abs_by_trace, int(n_traces)


def load_fbp_full_dromocrona_column(
    fbp_path: Path,
    *,
    registry: dict[str, int] | None = None,
) -> tuple[dict[int, float], int, ShotDetectionResult] | None:
    """Colonna griglia completa: include 0.0 per pick mancanti (riga ``0\\t0.000000\\t0``)."""
    abs_map, n_traces = iter_fbp_trace_absolute_times(fbp_path)
    if n_traces <= 0:
        return None
    shot = resolve_shot_for_fbp_path(fbp_path, registry)
    shot_t = fbp_display_reference_abs_ms(fbp_path)
    if shot_t is None:
        positive = [float(t) for t in abs_map.values() if float(t) > SHOT_DROMOCRONA_EPS_MS]
        shot_t = float(min(positive)) if positive else 0.0
    if not shot.is_valid:
        if positive := [tr for tr, t in abs_map.items() if float(t) > SHOT_DROMOCRONA_EPS_MS]:
            shot_tr = int(min(positive, key=lambda k: float(abs_map[k])))
            shot = ShotDetectionResult(
                shot_channel=int(shot_tr) + 1,
                shot_trace_idx=int(shot_tr),
                method="fallback_min",
                note="riferimento minimo assoluto",
            )
        else:
            shot = ShotDetectionResult(
                shot_channel=0,
                shot_trace_idx=0,
                method="unknown",
                note="non rilevato",
            )
    channel_map: dict[int, float] = {}
    for tr in range(n_traces):
        ch = int(tr) + 1
        t_abs = float(abs_map.get(int(tr), 0.0))
        if t_abs > SHOT_DROMOCRONA_EPS_MS:
            channel_map[ch] = float(t_abs) - float(shot_t)
        else:
            channel_map[ch] = 0.0
    return channel_map, int(n_traces), shot


def load_fbp_full_absolute_column(
    fbp_path: Path,
    *,
    registry: dict[str, int] | None = None,
) -> tuple[dict[int, float], int, ShotDetectionResult] | None:
    """Tempi assoluti per ogni traccia; pick mancante = 0.0 ms."""
    abs_map, n_traces = iter_fbp_trace_absolute_times(fbp_path)
    if n_traces <= 0:
        return None
    shot = resolve_shot_for_fbp_path(fbp_path, registry)
    if not shot.is_valid:
        positive = [
            tr for tr, t in abs_map.items() if float(t) > SHOT_DROMOCRONA_EPS_MS
        ]
        if positive:
            shot_tr = int(min(positive, key=lambda k: float(abs_map[k])))
            shot = ShotDetectionResult(
                shot_channel=int(shot_tr) + 1,
                shot_trace_idx=int(shot_tr),
                method="fallback_min",
                note="riferimento minimo assoluto",
            )
    channel_map = {int(tr) + 1: float(abs_map.get(int(tr), 0.0)) for tr in range(n_traces)}
    return channel_map, int(n_traces), shot


def build_shot_registry_for_folder(
    _folder: Path,
    fbp_paths: list[Path],
) -> dict[str, int]:
    """Costruisce il registry shot in memoria (nessun file nella cartella dati)."""
    out: dict[str, int] = {}
    for fbp_path in sorted(fbp_paths, key=lambda p: natural_sort_key(p.name)):
        key = _fbp_registry_key(fbp_path.name)
        auto = detect_shot_from_fbp_path(fbp_path)
        if auto is not None and auto.is_valid:
            out[key] = int(auto.shot_channel)
    return out


def _dromocrona_series_snapshot_from_meta_arrays(
    meta: dict[str, object],
    *,
    label: str,
) -> DromocronaSeriesSnapshot | None:
    trace_raw = meta.get("trace_idx")
    y_raw = meta.get("y")
    if trace_raw is None or y_raw is None:
        return None
    trace_idx = np.asarray(trace_raw, dtype=np.int64).ravel()
    dromocrona_ms = np.asarray(y_raw, dtype=np.float64).ravel()
    if trace_idx.size == 0 or dromocrona_ms.size == 0:
        return None
    n = min(trace_idx.size, dromocrona_ms.size)
    trace_idx = trace_idx[:n]
    dromocrona_ms = dromocrona_ms[:n]
    mask = np.isfinite(dromocrona_ms) & (trace_idx >= 0)
    if not np.any(mask):
        return None
    trace_idx = trace_idx[mask]
    dromocrona_ms = dromocrona_ms[mask]
    shot_raw = meta.get("shot_trace_idx")
    if shot_raw is not None:
        shot_trace_idx = int(shot_raw)
    else:
        zero_mask = dromocrona_ms <= SHOT_DROMOCRONA_EPS_MS
        if np.any(zero_mask):
            shot_trace_idx = int(trace_idx[int(np.argmax(zero_mask))])
        else:
            shot_trace_idx = int(trace_idx[int(np.argmin(dromocrona_ms))])
    pick_mask = np.array(
        [
            not is_missing_fbp_pick(
                int(tr),
                float(t),
                shot_trace_idx=int(shot_trace_idx),
            )
            for tr, t in zip(trace_idx, dromocrona_ms)
        ],
        dtype=bool,
    )
    if not np.any(pick_mask):
        return None
    trace_idx = trace_idx[pick_mask]
    dromocrona_ms = dromocrona_ms[pick_mask]
    x_raw = meta.get("x")
    if x_raw is not None:
        x_full = np.asarray(x_raw, dtype=np.float64).ravel()[:n][mask]
        x_display = x_full[pick_mask]
    else:
        x_display = trace_idx.astype(np.float64) + 1.0
    return DromocronaSeriesSnapshot(
        label=label,
        trace_idx=trace_idx,
        x_display=x_display,
        dromocrona_ms=dromocrona_ms,
        shot_trace_idx=shot_trace_idx,
    )


def dromocrona_series_snapshot_from_meta(
    meta: dict[str, object],
    *,
    shot_registry: dict[str, int] | None = None,
    prefer_memory: bool = False,
) -> DromocronaSeriesSnapshot | None:
    """
    Snapshot per controllo reciproco (stessi tempi della griglia/monitor: t − t_min).

    prefer_memory: usa i punti già in memoria nel monitor (es. auto-fix iterativo).
    """
    label = str(meta.get("label") or meta.get("source_path") or "shot")
    if prefer_memory:
        snap = _dromocrona_series_snapshot_from_meta_arrays(meta, label=label)
        if snap is not None:
            return snap
    source = meta.get("source_path")
    if source is not None:
        path = Path(source)
        if path.is_file():
            registry = shot_registry if shot_registry is not None else {}
            loaded = load_fbp_seismogram_dromocrona_column(
                path,
                registry=registry,
            )
            if loaded is not None:
                channel_map, shot = loaded
                if channel_map:
                    channels = sorted(channel_map.keys())
                    trace_idx = np.asarray([ch - 1 for ch in channels], dtype=np.int64)
                    dromocrona_ms = np.asarray(
                        [float(channel_map[ch]) for ch in channels],
                        dtype=np.float64,
                    )
                    shot_trace_idx = (
                        int(shot.shot_trace_idx)
                        if shot.is_valid
                        else int(trace_idx[int(np.argmin(dromocrona_ms))])
                    )
                    x_raw = meta.get("x")
                    if x_raw is not None and np.asarray(x_raw).size >= trace_idx.size:
                        x_display = np.asarray(x_raw, dtype=np.float64).ravel()[: trace_idx.size]
                    else:
                        x_display = trace_idx.astype(np.float64) + 1.0
                    return DromocronaSeriesSnapshot(
                        label=label,
                        trace_idx=trace_idx,
                        x_display=x_display,
                        dromocrona_ms=dromocrona_ms,
                        shot_trace_idx=shot_trace_idx,
                    )

    return _dromocrona_series_snapshot_from_meta_arrays(meta, label=label)


def _snapshot_trace_map(snapshot: DromocronaSeriesSnapshot) -> dict[int, float]:
    shot_tr = int(snapshot.shot_trace_idx)
    out: dict[int, float] = {}
    for tr, t in zip(snapshot.trace_idx, snapshot.dromocrona_ms):
        if is_missing_fbp_pick(int(tr), float(t), shot_trace_idx=shot_tr):
            continue
        out[int(tr)] = float(t)
    return out


def compute_reciprocal_quick(
    series_a: DromocronaSeriesSnapshot,
    series_b: DromocronaSeriesSnapshot,
    trace_pos_a: int,
    trace_pos_b: int,
    *,
    tolerance_ms: float = DEFAULT_RECIPROCAL_TOLERANCE_MS,
) -> ReciprocalQuickResult | None:
    map_a = _snapshot_trace_map(series_a)
    map_b = _snapshot_trace_map(series_b)
    tr_a = int(trace_pos_a)
    tr_b = int(trace_pos_b)
    if tr_a not in map_a or tr_b not in map_b:
        return None
    t_a_at_a = map_a[tr_a]
    t_b_at_b = map_b[tr_b]
    t_b_at_a = map_b.get(tr_a)
    t_a_at_b = map_a.get(tr_b)
    if t_b_at_a is None or t_a_at_b is None:
        return None
    return _quick_from_corners(
        label_a=series_a.label,
        label_b=series_b.label,
        trace_a=tr_a,
        trace_b=tr_b,
        t_a_at_a=t_a_at_a,
        t_b_at_b=t_b_at_b,
        t_b_at_a=t_b_at_a,
        t_a_at_b=t_a_at_b,
        tolerance_ms=float(tolerance_ms),
    )


def _reciprocal_tolerance_vector(
    dist: np.ndarray,
    bands: ReciprocalToleranceBands | None = None,
) -> np.ndarray:
    cfg = (bands or DEFAULT_RECIPROCAL_TOLERANCE_BANDS).normalized()
    dist = np.asarray(dist, dtype=np.float64)
    return np.where(
        dist <= float(cfg.dist_near),
        float(cfg.tol_near_ms),
        np.where(
            dist <= float(cfg.dist_mid),
            float(cfg.tol_mid_ms),
            float(cfg.tol_far_ms),
        ),
    )


def _build_reciprocal_series_lut(
    indexed: list[tuple[int, DromocronaSeriesSnapshot]],
) -> tuple[np.ndarray, np.ndarray, list[int], list[str]]:
    """Matrice tempi [n_serie, max_traccia+1] con NaN dove manca il break."""
    n = len(indexed)
    max_tr = 0
    for _, snap in indexed:
        if snap.trace_idx.size:
            max_tr = max(max_tr, int(np.max(snap.trace_idx)))
        max_tr = max(max_tr, int(snap.shot_trace_idx), 0)
    lut = np.full((n, max_tr + 1), np.nan, dtype=np.float64)
    shots = np.empty(n, dtype=np.int64)
    series_idx = np.empty(n, dtype=np.int64)
    labels: list[str] = []
    for row, (idx, snap) in enumerate(indexed):
        tr = np.asarray(snap.trace_idx, dtype=np.int64).ravel()
        times = np.asarray(snap.dromocrona_ms, dtype=np.float64).ravel()
        shot_tr = int(snap.shot_trace_idx)
        if tr.size and times.size:
            n_pts = min(tr.size, times.size)
            for pt in range(n_pts):
                tr_i = int(tr[pt])
                t_i = float(times[pt])
                if is_missing_fbp_pick(tr_i, t_i, shot_trace_idx=shot_tr):
                    continue
                lut[row, tr_i] = t_i
        shots[row] = shot_tr
        series_idx[row] = int(idx)
        labels.append(str(snap.label))
    return lut, shots, series_idx.tolist(), labels


def _quick_from_corners(
    *,
    label_a: str,
    label_b: str,
    trace_a: int,
    trace_b: int,
    t_a_at_a: float,
    t_b_at_b: float,
    t_b_at_a: float,
    t_a_at_b: float,
    tolerance_ms: float,
) -> ReciprocalQuickResult:
    corner_delta = float(t_b_at_a - t_a_at_b)
    tol = float(tolerance_ms)
    return ReciprocalQuickResult(
        shot_a_label=label_a,
        shot_b_label=label_b,
        trace_pos_a=int(trace_a),
        trace_pos_b=int(trace_b),
        t_a_at_pos_a=float(t_a_at_a),
        t_b_at_pos_b=float(t_b_at_b),
        t_b_at_pos_a=float(t_b_at_a),
        t_a_at_pos_b=float(t_a_at_b),
        corner_delta_ms=corner_delta,
        tolerance_ms=tol,
        passed=abs(corner_delta) <= tol,
    )


def _compute_reciprocal_pairs_from_indexed(
    indexed: list[tuple[int, DromocronaSeriesSnapshot]],
    *,
    bands: ReciprocalToleranceBands | None = None,
) -> tuple[ReciprocalPairResult, ...]:
    """Calcolo vettoriale numpy: una passata sulle coppie non ordinate."""
    n = len(indexed)
    if n < 2:
        return ()
    lut, shots, _series_idx, labels = _build_reciprocal_series_lut(indexed)
    iu, ju = np.triu_indices(n, k=1)
    shot_i = shots[iu]
    shot_j = shots[ju]
    n_tr = int(lut.shape[1])
    in_range = (
        (shot_i >= 0)
        & (shot_j >= 0)
        & (shot_i < n_tr)
        & (shot_j < n_tr)
    )
    if n_tr <= 0 or not np.any(in_range):
        return ()
    shot_i_safe = np.clip(shot_i, 0, n_tr - 1)
    shot_j_safe = np.clip(shot_j, 0, n_tr - 1)
    t_a_a = lut[iu, shot_i_safe]
    t_b_b = lut[ju, shot_j_safe]
    t_b_a = lut[ju, shot_i_safe]
    t_a_b = lut[iu, shot_j_safe]
    valid = (
        in_range
        & np.isfinite(t_a_a)
        & np.isfinite(t_b_b)
        & np.isfinite(t_b_a)
        & np.isfinite(t_a_b)
    )
    if not np.any(valid):
        return ()
    dist = np.abs(shot_j.astype(np.float64) - shot_i.astype(np.float64))
    tol = _reciprocal_tolerance_vector(dist, bands)
    out: list[ReciprocalPairResult] = []
    for k in np.flatnonzero(valid):
        i_pos = int(iu[k])
        j_pos = int(ju[k])
        idx_i, snap_i = indexed[i_pos]
        idx_j, _snap_j = indexed[j_pos]
        trace_i = int(snap_i.shot_trace_idx)
        trace_j = int(shot_j[k])
        quick = _quick_from_corners(
            label_a=labels[i_pos],
            label_b=labels[j_pos],
            trace_a=trace_i,
            trace_b=trace_j,
            t_a_at_a=float(t_a_a[k]),
            t_b_at_b=float(t_b_b[k]),
            t_b_at_a=float(t_b_a[k]),
            t_a_at_b=float(t_a_b[k]),
            tolerance_ms=float(tol[k]),
        )
        out.append(
            _reciprocal_pair_from_quick(
                int(idx_i),
                int(idx_j),
                i_pos,
                j_pos,
                trace_i,
                trace_j,
                quick,
            )
        )
    return tuple(out)


def _reciprocal_pair_map_key(series_a: int, series_b: int) -> tuple[int, int]:
    """Chiave canonica per mappe: una sola entry per coppia non ordinata."""
    a, b = int(series_a), int(series_b)
    return (a, b) if a <= b else (b, a)


def _reciprocal_pair_from_quick(
    idx_a: int,
    idx_b: int,
    home_pos_a: int,
    home_pos_b: int,
    trace_a: int,
    trace_b: int,
    quick_ab: ReciprocalQuickResult,
) -> ReciprocalPairResult:
    """Un solo risultato per rettangolo (A→B); pass/fail e angoli FAIL sono simmetrici."""
    return ReciprocalPairResult(
        series_idx_a=int(idx_a),
        series_idx_b=int(idx_b),
        neighbor_offset=int(home_pos_b - home_pos_a),
        trace_pos_a=int(trace_a),
        trace_pos_b=int(trace_b),
        result=quick_ab,
    )


def reciprocal_tolerance_for_trace_distance(
    trace_pos_a: int,
    trace_pos_b: int,
    bands: ReciprocalToleranceBands | None = None,
) -> float:
    """Soglia dinamica per reciproco in base alla distanza tra shot."""
    cfg = (bands or DEFAULT_RECIPROCAL_TOLERANCE_BANDS).normalized()
    return cfg.tolerance_for_distance(abs(int(trace_pos_b) - int(trace_pos_a)))


def quick_failed_traces(
    quick: ReciprocalQuickResult | None,
    series_idx_a: int,
    series_idx_b: int,
) -> dict[int, set[int]]:
    if quick is None or quick.passed:
        return {series_idx_a: set(), series_idx_b: set()}
    return {
        series_idx_a: {quick.failed_trace_on_series_a},
        series_idx_b: {quick.failed_trace_on_series_b},
    }


def merge_failed_traces(*maps: dict[int, set[int]]) -> dict[int, set[int]]:
    merged: dict[int, set[int]] = {}
    for item in maps:
        for series_idx, traces in item.items():
            merged.setdefault(int(series_idx), set()).update(traces)
    return merged


def _indexed_snapshots_sorted_by_shot(
    metas: list[dict[str, object]],
    *,
    shot_registry: dict[str, int] | None = None,
    prefer_memory: bool = False,
) -> list[tuple[int, DromocronaSeriesSnapshot]]:
    indexed: list[tuple[int, DromocronaSeriesSnapshot]] = []
    for idx, meta in enumerate(metas):
        snap = dromocrona_series_snapshot_from_meta(
            meta,
            shot_registry=shot_registry,
            prefer_memory=prefer_memory,
        )
        if snap is not None:
            indexed.append((idx, snap))
    indexed.sort(key=lambda item: (int(item[1].shot_trace_idx), int(item[0])))
    return indexed


def compute_per_dromocrona_reciprocal_pairs(
    metas: list[dict[str, object]],
    *,
    tolerance_ms: float = DEFAULT_RECIPROCAL_TOLERANCE_MS,
    tolerance_bands: ReciprocalToleranceBands | None = None,
    shot_registry: dict[str, int] | None = None,
    prefer_memory: bool = False,
) -> tuple[ReciprocalPairResult, ...]:
    """Per ogni coppia non ordinata di dromocrona: un rettangolo reciproco."""
    del tolerance_ms
    indexed = _indexed_snapshots_sorted_by_shot(
        metas,
        shot_registry=shot_registry,
        prefer_memory=prefer_memory,
    )
    return _compute_reciprocal_pairs_from_indexed(indexed, bands=tolerance_bands)


def reciprocal_pairs_to_map(
    pairs: tuple[ReciprocalPairResult, ...],
) -> dict[tuple[int, int], ReciprocalPairResult]:
    out: dict[tuple[int, int], ReciprocalPairResult] = {}
    for pair in pairs:
        key = _reciprocal_pair_map_key(pair.series_idx_a, pair.series_idx_b)
        out[key] = pair
    return out


def reciprocal_pairs_from_map(
    pairs_map: dict[tuple[int, int], ReciprocalPairResult],
) -> tuple[ReciprocalPairResult, ...]:
    if not pairs_map:
        return ()
    return tuple(
        sorted(
            pairs_map.values(),
            key=lambda p: (int(p.series_idx_a), int(p.series_idx_b), int(p.neighbor_offset)),
        )
    )


def compute_reciprocal_pairs_map(
    metas: list[dict[str, object]],
    *,
    tolerance_ms: float = DEFAULT_RECIPROCAL_TOLERANCE_MS,
    tolerance_bands: ReciprocalToleranceBands | None = None,
    shot_registry: dict[str, int] | None = None,
    prefer_memory: bool = False,
) -> dict[tuple[int, int], ReciprocalPairResult]:
    return reciprocal_pairs_to_map(
        compute_per_dromocrona_reciprocal_pairs(
            metas,
            tolerance_ms=tolerance_ms,
            tolerance_bands=tolerance_bands,
            shot_registry=shot_registry,
            prefer_memory=prefer_memory,
        )
    )


def remap_reciprocal_pairs_map_columns(
    pairs_map: dict[tuple[int, int], ReciprocalPairResult],
    old_paths: tuple[str, ...] | list[str],
    new_paths: tuple[str, ...] | list[str],
) -> tuple[dict[tuple[int, int], ReciprocalPairResult], set[int]]:
    """Rimappa le chiavi colonna quando cambia l'elenco/ordine dei file.

    Ritorna ``(nuova_mappa, indici_nuovi)`` dove ``indici_nuovi`` sono le
    colonne presenti in ``new_paths`` ma non in ``old_paths`` (da patchare).
    Le coppie che coinvolgono file rimossi vengono scartate.
    """
    old_list = [str(p) for p in old_paths]
    new_list = [str(p) for p in new_paths]
    new_index = {p: i for i, p in enumerate(new_list) if p}
    old_to_new: dict[int, int] = {}
    for old_i, path in enumerate(old_list):
        if not path:
            continue
        new_i = new_index.get(path)
        if new_i is not None:
            old_to_new[int(old_i)] = int(new_i)
    old_paths_set = {p for p in old_list if p}
    new_cols = {
        int(i) for i, p in enumerate(new_list) if p and p not in old_paths_set
    }
    if not pairs_map:
        return {}, new_cols
    out: dict[tuple[int, int], ReciprocalPairResult] = {}
    for pair in pairs_map.values():
        na = old_to_new.get(int(pair.series_idx_a))
        nb = old_to_new.get(int(pair.series_idx_b))
        if na is None or nb is None or na == nb:
            continue
        key = _reciprocal_pair_map_key(na, nb)
        if key in out:
            continue
        # neighbor_offset ricalcolato al prossimo patch (qui solo preserva le coppie).
        out[key] = ReciprocalPairResult(
            series_idx_a=int(na),
            series_idx_b=int(nb),
            neighbor_offset=int(nb) - int(na),
            trace_pos_a=int(pair.trace_pos_a),
            trace_pos_b=int(pair.trace_pos_b),
            result=pair.result,
        )
    return out, new_cols


def patch_reciprocal_pairs_map(
    pairs_map: dict[tuple[int, int], ReciprocalPairResult],
    metas: list[dict[str, object]],
    affected_series: set[int],
    *,
    affected_traces_by_series: dict[int, set[int]] | None = None,
    tolerance_bands: ReciprocalToleranceBands | None = None,
    shot_registry: dict[str, int] | None = None,
    prefer_memory: bool = False,
) -> dict[tuple[int, int], ReciprocalPairResult]:
    """Ricalcola solo le coppie che coinvolgono le serie/tracce modificate.

    Se ``affected_traces_by_series`` è fornito (indici colonna → tracce),
    aggiorna solo i rettangoli i cui angoli usano quelle tracce:
    - traccia = shot della serie modificata → tutte le coppie della serie
    - traccia = shot di un'altra serie J → solo la coppia con J
    Altrimenti (comportamento storico): tutte le coppie della serie (O(k·n)).
    """
    if not affected_series or len(metas) < 2:
        return pairs_map
    indexed = _indexed_snapshots_sorted_by_shot(
        metas,
        shot_registry=shot_registry,
        prefer_memory=prefer_memory,
    )
    if len(indexed) < 2:
        pairs_map.clear()
        return pairs_map
    by_idx: dict[int, tuple[int, DromocronaSeriesSnapshot]] = {}
    for pos, (idx, snap) in enumerate(indexed):
        by_idx[int(idx)] = (int(pos), snap)
    active = {int(s) for s in affected_series if int(s) in by_idx}
    if not active:
        return pairs_map

    # Partner da ricalcolare per ogni colonna attiva.
    partners_by_col: dict[int, set[int]] = {k: set() for k in active}
    trace_filter = affected_traces_by_series or {}
    all_cols = list(by_idx.keys())
    for k in active:
        traces = trace_filter.get(int(k))
        shot_k = int(by_idx[k][1].shot_trace_idx)
        if traces is None or not traces or -1 in traces:
            # Nessun filtro tracce / sentinel: tutta la stella della serie.
            partners_by_col[k] = {j for j in all_cols if j != k}
            continue
        traces_i = {int(t) for t in traces}
        if shot_k in traces_i:
            partners_by_col[k] = {j for j in all_cols if j != k}
            continue
        for j in all_cols:
            if j == k:
                continue
            if int(by_idx[j][1].shot_trace_idx) in traces_i:
                partners_by_col[k].add(int(j))
        # Traccia mossa non è lo shot di nessuno: ricalcola tutta la stella,
        # altrimenti FAIL resta congelato (es. indici shot disallineati).
        if not partners_by_col[k]:
            partners_by_col[k] = {j for j in all_cols if j != k}

    done_pairs: set[tuple[int, int]] = set()
    for k, partners in partners_by_col.items():
        home_pos_k, snap_k = by_idx[k]
        trace_k = int(snap_k.shot_trace_idx)
        for j in partners:
            unordered = (k, j) if k < j else (j, k)
            if unordered in done_pairs:
                continue
            done_pairs.add(unordered)
            if j not in by_idx:
                continue
            home_pos_j, snap_j = by_idx[j]
            trace_j = int(snap_j.shot_trace_idx)
            tol = reciprocal_tolerance_for_trace_distance(
                trace_k, trace_j, bands=tolerance_bands
            )
            quick_kj = compute_reciprocal_quick(
                snap_k,
                snap_j,
                trace_k,
                trace_j,
                tolerance_ms=tol,
            )
            key = _reciprocal_pair_map_key(k, j)
            if quick_kj is None:
                pairs_map.pop(key, None)
                pairs_map.pop((k, j), None)
                pairs_map.pop((j, k), None)
                continue
            pairs_map.pop((k, j), None)
            pairs_map.pop((j, k), None)
            pairs_map[key] = _reciprocal_pair_from_quick(
                int(k),
                int(j),
                int(home_pos_k),
                int(home_pos_j),
                trace_k,
                trace_j,
                quick_kj,
            )
    return pairs_map


def compute_all_reciprocal_pairs(
    metas: list[dict[str, object]],
    *,
    tolerance_ms: float = DEFAULT_RECIPROCAL_TOLERANCE_MS,
    tolerance_bands: ReciprocalToleranceBands | None = None,
    shot_registry: dict[str, int] | None = None,
    prefer_memory: bool = False,
) -> tuple[ReciprocalPairResult, ...]:
    return compute_per_dromocrona_reciprocal_pairs(
        metas,
        tolerance_ms=tolerance_ms,
        tolerance_bands=tolerance_bands,
        shot_registry=shot_registry,
        prefer_memory=prefer_memory,
    )


def failed_traces_from_pairs(
    pairs: tuple[ReciprocalPairResult, ...],
) -> dict[int, set[int]]:
    maps: list[dict[int, set[int]]] = []
    for pair in pairs:
        if pair.result.passed:
            continue
        maps.append(
            quick_failed_traces(pair.result, pair.series_idx_a, pair.series_idx_b)
        )
    if not maps:
        return {}
    return merge_failed_traces(*maps)


def failed_trace_bands_from_pairs(
    pairs: tuple[ReciprocalPairResult, ...],
) -> tuple[
    dict[int, set[int]],
    dict[int, dict[int, float]],
    dict[int, dict[int, float]],
]:
    """Trace fallite, fascia soglia e Δ corner (ms) per serie.

    Per ogni traccia FAIL conserva il corner_delta con |Δ| massimo
    (utile per colorare i break sul sismogramma: Δ>0 / Δ<0).
    """
    fails = failed_traces_from_pairs(pairs)
    fail_bands_by_series: dict[int, dict[int, float]] = {}
    fail_deltas_by_series: dict[int, dict[int, float]] = {}
    for pair in pairs:
        if pair.result.passed:
            continue
        tol = float(pair.result.tolerance_ms)
        delta = float(pair.result.corner_delta_ms)
        series_a = int(pair.series_idx_a)
        series_b = int(pair.series_idx_b)
        trace_a = int(pair.result.failed_trace_on_series_a)
        trace_b = int(pair.result.failed_trace_on_series_b)
        map_a = fail_bands_by_series.setdefault(series_a, {})
        map_b = fail_bands_by_series.setdefault(series_b, {})
        prev_a = map_a.get(trace_a)
        prev_b = map_b.get(trace_b)
        map_a[trace_a] = tol if prev_a is None else min(float(prev_a), tol)
        map_b[trace_b] = tol if prev_b is None else min(float(prev_b), tol)

        delta_a = fail_deltas_by_series.setdefault(series_a, {})
        delta_b = fail_deltas_by_series.setdefault(series_b, {})
        old_a = delta_a.get(trace_a)
        old_b = delta_b.get(trace_b)
        if old_a is None or abs(delta) >= abs(float(old_a)):
            delta_a[trace_a] = delta
        if old_b is None or abs(delta) >= abs(float(old_b)):
            delta_b[trace_b] = delta
    return fails, fail_bands_by_series, fail_deltas_by_series


def _short_label(label: str) -> str:
    text = str(label).strip()
    if not text:
        return "—"
    try:
        return Path(text).stem
    except Exception:
        return text


def _reciprocal_failed_cell_tooltip(
    pair: ReciprocalPairResult,
    *,
    channel_1based: int,
    series_idx: int,
) -> str:
    """Tooltip per celle rosse: quale rettangolo e quale angolo del break."""
    quick = pair.result
    ch_a = int(quick.trace_pos_a) + 1
    ch_b = int(quick.trace_pos_b) + 1
    idx_a = int(pair.series_idx_a)
    idx_b = int(pair.series_idx_b)
    ref = _short_label(quick.shot_a_label)
    other = _short_label(quick.shot_b_label)
    if (int(channel_1based), int(series_idx)) == (ch_b, idx_a):
        role = f"angolo tVic@rif (geof. {ch_b} sulla colonna rif. {ref})"
    elif (int(channel_1based), int(series_idx)) == (ch_a, idx_b):
        role = f"angolo tRif@vic (geof. {ch_a} sulla colonna {other})"
    else:
        role = "break coinvolto nel confronto incrociato"
    return (
        f"• Rettangolo rif. {ref} → {other}: Δt={quick.corner_delta_ms:+.3f} ms "
        f"(soglia ±{quick.tolerance_ms:.1f}) — {role}"
    )


def format_reciprocal_cell_tooltip(
    mark: ReciprocalGridCellMark,
    *,
    geophone: int,
    column_label: str,
) -> str:
    """Dettaglio pannello griglia: solo rettangoli FAIL (gli OK non vengono elencati)."""
    if mark.failed and mark.failed_tooltip_lines:
        header = f"Geofono {geophone} · colonna {column_label}"
        return header + "\n" + "\n".join(mark.failed_tooltip_lines)
    return ""


@dataclass
class ReciprocalGridCellMark:
    """Evidenziazione celle nella griglia Excel dromocrone."""

    passed_compare: bool = False
    failed: bool = False
    failed_tooltip_lines: tuple[str, ...] = ()
    # Chiavi (geofono 1-based, indice colonna file) dell'angolo reciproco FAIL.
    partner_keys: tuple[tuple[int, int], ...] = ()

    def merged(self, other: ReciprocalGridCellMark) -> ReciprocalGridCellMark:
        fail_tips = tuple(
            dict.fromkeys(self.failed_tooltip_lines + other.failed_tooltip_lines)
        )
        partners = tuple(
            dict.fromkeys(self.partner_keys + other.partner_keys)
        )
        return ReciprocalGridCellMark(
            passed_compare=self.passed_compare or other.passed_compare,
            failed=self.failed or other.failed,
            failed_tooltip_lines=fail_tips,
            partner_keys=partners,
        )


def reciprocal_grid_marks_from_pairs(
    pairs: tuple[ReciprocalPairResult, ...],
) -> dict[tuple[int, int], ReciprocalGridCellMark]:
    """Colori/tooltip griglia a partire da coppie reciproche già calcolate."""
    marks: dict[tuple[int, int], ReciprocalGridCellMark] = {}

    def _put(
        channel_1based: int,
        series_idx: int,
        *,
        passed_compare: bool = False,
        failed: bool = False,
        failed_tip: str = "",
        partner: tuple[int, int] | None = None,
    ) -> None:
        if channel_1based <= 0 or series_idx < 0:
            return
        key = (int(channel_1based), int(series_idx))
        prev = marks.get(key, ReciprocalGridCellMark())
        fail_tips = prev.failed_tooltip_lines
        if failed_tip:
            fail_tips = tuple(dict.fromkeys(fail_tips + (failed_tip,)))
        partners = prev.partner_keys
        if partner is not None:
            partners = tuple(dict.fromkeys(partners + (partner,)))
        marks[key] = ReciprocalGridCellMark(
            passed_compare=prev.passed_compare or passed_compare,
            failed=prev.failed or failed,
            failed_tooltip_lines=fail_tips,
            partner_keys=partners,
        )

    for pair in pairs:
        quick = pair.result
        ch_a = int(quick.trace_pos_a) + 1
        ch_b = int(quick.trace_pos_b) + 1
        idx_a = int(pair.series_idx_a)
        idx_b = int(pair.series_idx_b)

        if quick.passed:
            _put(ch_a, idx_b, passed_compare=True)
            _put(ch_b, idx_a, passed_compare=True)
            continue

        fail_b_on_a = _reciprocal_failed_cell_tooltip(
            pair, channel_1based=ch_b, series_idx=idx_a
        )
        fail_a_on_b = _reciprocal_failed_cell_tooltip(
            pair, channel_1based=ch_a, series_idx=idx_b
        )
        # Angoli del rettangolo FAIL: ciascuno punta all'altro.
        _put(
            ch_b,
            idx_a,
            failed=True,
            failed_tip=fail_b_on_a,
            partner=(ch_a, idx_b),
        )
        _put(
            ch_a,
            idx_b,
            failed=True,
            failed_tip=fail_a_on_b,
            partner=(ch_b, idx_a),
        )

    return marks


def compute_reciprocal_column_shifts(
    failing_pairs: tuple[ReciprocalPairResult, ...],
    n_series: int,
    *,
    locked_columns: set[int] | frozenset[int] | None = None,
) -> np.ndarray:
    """Shift verticali per colonna (least-squares) con colonne fisse opzionali."""
    shifts = np.zeros(max(0, int(n_series)), dtype=np.float64)
    if n_series <= 0 or not failing_pairs:
        return shifts
    locked = frozenset(int(c) for c in (locked_columns or ()))
    direct_sums: dict[int, list[float]] = {}
    pending_rows: list[tuple[int, int, float]] = []
    for pair in failing_pairs:
        col_a = int(pair.series_idx_a)
        col_b = int(pair.series_idx_b)
        if col_a < 0 or col_b < 0 or col_a >= n_series or col_b >= n_series:
            continue
        target = -float(pair.result.corner_delta_ms)
        a_lock = col_a in locked
        b_lock = col_b in locked
        if a_lock and b_lock:
            continue
        if a_lock:
            direct_sums.setdefault(col_b, []).append(target)
        elif b_lock:
            direct_sums.setdefault(col_a, []).append(-target)
        else:
            pending_rows.append((col_a, col_b, target))

    def _apply_direct() -> None:
        for col, vals in direct_sums.items():
            if col in locked or not vals:
                continue
            shifts[int(col)] = float(np.mean(vals))

    def _propagate_from_known() -> bool:
        changed = False
        rows: list[tuple[int, int, float]] = []
        for col_a, col_b, target in pending_rows:
            a_known = col_a in direct_sums or col_a in locked
            b_known = col_b in direct_sums or col_b in locked
            if a_known and b_known:
                continue
            if a_known and not b_known:
                s_a = 0.0 if col_a in locked else shifts[int(col_a)]
                direct_sums.setdefault(col_b, []).append(float(target + s_a))
                changed = True
            elif b_known and not a_known:
                s_b = 0.0 if col_b in locked else shifts[int(col_b)]
                direct_sums.setdefault(col_a, []).append(float(-target + s_b))
                changed = True
            else:
                rows.append((col_a, col_b, target))
        pending_rows[:] = rows
        return changed

    _apply_direct()
    for _ in range(max(1, int(n_series))):
        if not _propagate_from_known():
            break
        _apply_direct()

    free_cols = sorted(
        c for c in range(n_series) if c not in locked and c not in direct_sums
    )
    if pending_rows and free_cols:
        index = {col: idx for idx, col in enumerate(free_cols)}
        valid_rows = [
            (col_a, col_b, target)
            for col_a, col_b, target in pending_rows
            if col_a in index and col_b in index
        ]
        if valid_rows:
            matrix = np.zeros((len(valid_rows), len(free_cols)), dtype=np.float64)
            targets = np.zeros(len(valid_rows), dtype=np.float64)
            for row_idx, (col_a, col_b, target) in enumerate(valid_rows):
                matrix[row_idx, index[col_a]] = -1.0
                matrix[row_idx, index[col_b]] = 1.0
                targets[row_idx] = target
            sol, *_ = np.linalg.lstsq(matrix, targets, rcond=None)
            for col, idx in index.items():
                shifts[int(col)] = float(sol[idx])
    for col in locked:
        shifts[int(col)] = 0.0
    return shifts


def _unique_reciprocal_equations(
    failing_pairs: tuple[ReciprocalPairResult, ...],
    n_series: int,
) -> list[tuple[int, int, float]]:
    """
    Costruisce equazioni uniche per coppie non ordinate:
    s[col_b] - s[col_a] ~= target_ms.
    """
    merged: dict[tuple[int, int], list[float]] = {}
    for pair in failing_pairs:
        col_a = int(pair.series_idx_a)
        col_b = int(pair.series_idx_b)
        if col_a < 0 or col_b < 0 or col_a >= n_series or col_b >= n_series:
            continue
        if col_a == col_b:
            continue
        target = -float(pair.result.corner_delta_ms)
        if col_a <= col_b:
            key = (col_a, col_b)
            val = target
        else:
            key = (col_b, col_a)
            val = -target
        merged.setdefault(key, []).append(float(val))
    out: list[tuple[int, int, float]] = []
    for (col_a, col_b), vals in merged.items():
        out.append((int(col_a), int(col_b), float(np.median(np.asarray(vals, dtype=np.float64)))))
    return out


def compute_reciprocal_column_shifts_robust(
    failing_pairs: tuple[ReciprocalPairResult, ...],
    n_series: int,
    *,
    locked_columns: set[int] | frozenset[int] | None = None,
    huber_delta_ms: float = 1.5,
    max_irls_iter: int = 10,
    ridge: float = 1e-6,
) -> np.ndarray:
    """Shift colonne robusto con IRLS+Huber (meno sensibile agli outlier)."""
    shifts = np.zeros(max(0, int(n_series)), dtype=np.float64)
    if n_series <= 0 or not failing_pairs:
        return shifts
    locked = frozenset(int(c) for c in (locked_columns or ()))
    free_cols = [c for c in range(int(n_series)) if c not in locked]
    if not free_cols:
        return shifts
    free_index = {col: idx for idx, col in enumerate(free_cols)}

    equations = _unique_reciprocal_equations(failing_pairs, int(n_series))
    rows: list[np.ndarray] = []
    targets: list[float] = []
    for col_a, col_b, target in equations:
        row = np.zeros(len(free_cols), dtype=np.float64)
        # s[col_b] - s[col_a] ~= target
        if col_b in free_index:
            row[free_index[col_b]] += 1.0
        if col_a in free_index:
            row[free_index[col_a]] -= 1.0
        if not np.any(row):
            continue
        rows.append(row)
        targets.append(float(target))
    if not rows:
        return shifts

    matrix = np.vstack(rows)
    y = np.asarray(targets, dtype=np.float64)
    x = np.zeros(len(free_cols), dtype=np.float64)
    delta = max(0.05, float(huber_delta_ms))
    lam = max(1e-12, float(ridge))

    for _ in range(max(1, int(max_irls_iter))):
        residual = matrix @ x - y
        abs_r = np.abs(residual)
        w = np.ones_like(abs_r)
        mask = abs_r > delta
        w[mask] = delta / abs_r[mask]
        w_sqrt = np.sqrt(w)
        mw = matrix * w_sqrt[:, None]
        yw = y * w_sqrt
        normal = mw.T @ mw + lam * np.eye(mw.shape[1], dtype=np.float64)
        rhs = mw.T @ yw
        try:
            x_new = np.linalg.solve(normal, rhs)
        except np.linalg.LinAlgError:
            x_new, *_ = np.linalg.lstsq(normal, rhs, rcond=None)
        if np.max(np.abs(x_new - x)) < 1e-4:
            x = x_new
            break
        x = x_new

    for col, idx in free_index.items():
        shifts[int(col)] = float(x[idx])
    for col in locked:
        shifts[int(col)] = 0.0
    return shifts


def compute_reciprocal_column_shifts_median(
    failing_pairs: tuple[ReciprocalPairResult, ...],
    n_series: int,
    *,
    locked_columns: set[int] | frozenset[int] | None = None,
    max_iter: int = 8,
) -> np.ndarray:
    """Shift colonne via mediana iterativa sulle equazioni reciproche."""
    shifts = np.zeros(max(0, int(n_series)), dtype=np.float64)
    if n_series <= 0 or not failing_pairs:
        return shifts
    locked = frozenset(int(c) for c in (locked_columns or ()))
    equations = _unique_reciprocal_equations(failing_pairs, int(n_series))
    if not equations:
        return shifts
    for _ in range(max(1, int(max_iter))):
        estimates: dict[int, list[float]] = {}
        for col_a, col_b, target in equations:
            # s[b] - s[a] ~= target
            if col_b not in locked:
                estimates.setdefault(col_b, []).append(float(target + shifts[int(col_a)]))
            if col_a not in locked:
                estimates.setdefault(col_a, []).append(float(-target + shifts[int(col_b)]))
        if not estimates:
            break
        max_delta = 0.0
        for col, vals in estimates.items():
            if not vals:
                continue
            new_s = float(np.median(np.asarray(vals, dtype=np.float64)))
            max_delta = max(max_delta, abs(new_s - float(shifts[int(col)])))
            shifts[int(col)] = new_s
        for col in locked:
            shifts[int(col)] = 0.0
        if max_delta < 1e-4:
            break
    return shifts


def compute_reciprocal_column_shifts_ransac(
    failing_pairs: tuple[ReciprocalPairResult, ...],
    n_series: int,
    *,
    locked_columns: set[int] | frozenset[int] | None = None,
    inlier_thresh_ms: float = 1.5,
    max_trials: int = 64,
    min_sample: int = 3,
    rng_seed: int = 42,
) -> np.ndarray:
    """Shift colonne con RANSAC sulle equazioni uniche (outlier-resistant)."""
    shifts = np.zeros(max(0, int(n_series)), dtype=np.float64)
    if n_series <= 0 or not failing_pairs:
        return shifts
    locked = frozenset(int(c) for c in (locked_columns or ()))
    free_cols = [c for c in range(int(n_series)) if c not in locked]
    if not free_cols:
        return shifts
    free_index = {col: idx for idx, col in enumerate(free_cols)}
    equations = _unique_reciprocal_equations(failing_pairs, int(n_series))
    rows: list[np.ndarray] = []
    targets: list[float] = []
    for col_a, col_b, target in equations:
        row = np.zeros(len(free_cols), dtype=np.float64)
        if col_b in free_index:
            row[free_index[col_b]] += 1.0
        if col_a in free_index:
            row[free_index[col_a]] -= 1.0
        if not np.any(row):
            continue
        rows.append(row)
        targets.append(float(target))
    if not rows:
        return shifts

    matrix = np.vstack(rows)
    y = np.asarray(targets, dtype=np.float64)
    n_eq = int(matrix.shape[0])
    n_free = int(matrix.shape[1])
    sample_n = max(int(min_sample), min(n_eq, max(2, n_free)))
    rng = np.random.default_rng(int(rng_seed))
    best_x: np.ndarray | None = None
    best_inliers = -1
    thresh = max(0.05, float(inlier_thresh_ms))

    def _solve_subset(idx: np.ndarray) -> np.ndarray | None:
        sub_m = matrix[idx]
        sub_y = y[idx]
        try:
            sol, *_ = np.linalg.lstsq(sub_m, sub_y, rcond=None)
        except np.linalg.LinAlgError:
            return None
        if sol.size != n_free or not np.all(np.isfinite(sol)):
            return None
        return sol.astype(np.float64, copy=False)

    trials = max(1, int(max_trials))
    for _ in range(trials):
        if n_eq <= sample_n:
            idx = np.arange(n_eq)
        else:
            idx = rng.choice(n_eq, size=sample_n, replace=False)
        x_cand = _solve_subset(idx)
        if x_cand is None:
            continue
        residual = np.abs(matrix @ x_cand - y)
        n_in = int(np.sum(residual <= thresh))
        if n_in > best_inliers:
            best_inliers = n_in
            best_x = x_cand
            if best_inliers >= n_eq:
                break

    if best_x is None:
        # fallback LS globale
        sol, *_ = np.linalg.lstsq(matrix, y, rcond=None)
        best_x = sol.astype(np.float64, copy=False)
    else:
        # raffina sugli inlier del miglior modello
        residual = np.abs(matrix @ best_x - y)
        inlier_mask = residual <= thresh
        if int(np.sum(inlier_mask)) >= max(2, min(sample_n, n_free)):
            refined = _solve_subset(np.flatnonzero(inlier_mask))
            if refined is not None:
                best_x = refined

    for col, idx in free_index.items():
        shifts[int(col)] = float(best_x[idx])
    for col in locked:
        shifts[int(col)] = 0.0
    return shifts


def compute_reciprocal_column_shifts_weighted_anchor(
    failing_pairs: tuple[ReciprocalPairResult, ...],
    n_series: int,
    *,
    locked_columns: set[int] | frozenset[int] | None = None,
    ridge: float = 1e-5,
) -> np.ndarray:
    """
    LS pesato: equazioni verso colonne locked/ancorate pesano di più;
    colonne con molti FAIL pesano di meno (lato debole più libero).
    """
    shifts = np.zeros(max(0, int(n_series)), dtype=np.float64)
    if n_series <= 0 or not failing_pairs:
        return shifts
    locked = frozenset(int(c) for c in (locked_columns or ()))
    free_cols = [c for c in range(int(n_series)) if c not in locked]
    if not free_cols:
        return shifts
    free_index = {col: idx for idx, col in enumerate(free_cols)}
    fail_counts = np.zeros(int(n_series), dtype=np.float64)
    for pair in failing_pairs:
        fail_counts[int(pair.series_idx_a)] += 1.0
        fail_counts[int(pair.series_idx_b)] += 1.0
    equations = _unique_reciprocal_equations(failing_pairs, int(n_series))
    rows: list[np.ndarray] = []
    targets: list[float] = []
    weights: list[float] = []
    for col_a, col_b, target in equations:
        row = np.zeros(len(free_cols), dtype=np.float64)
        if col_b in free_index:
            row[free_index[col_b]] += 1.0
        if col_a in free_index:
            row[free_index[col_a]] -= 1.0
        if not np.any(row):
            continue
        # peso alto se un lato è locked; basso se entrambi hanno tanti FAIL
        anchor_boost = 1.0
        if col_a in locked or col_b in locked:
            anchor_boost = 3.0
        soft = 1.0 + 0.35 * (
            float(fail_counts[int(col_a)]) + float(fail_counts[int(col_b)])
        )
        w = float(anchor_boost / soft)
        rows.append(row)
        targets.append(float(target))
        weights.append(max(0.05, w))
    if not rows:
        return shifts
    matrix = np.vstack(rows)
    y = np.asarray(targets, dtype=np.float64)
    w = np.asarray(weights, dtype=np.float64)
    w_sqrt = np.sqrt(w)
    mw = matrix * w_sqrt[:, None]
    yw = y * w_sqrt
    lam = max(1e-12, float(ridge))
    normal = mw.T @ mw + lam * np.eye(mw.shape[1], dtype=np.float64)
    rhs = mw.T @ yw
    try:
        x = np.linalg.solve(normal, rhs)
    except np.linalg.LinAlgError:
        x, *_ = np.linalg.lstsq(normal, rhs, rcond=None)
    for col, idx in free_index.items():
        shifts[int(col)] = float(x[idx])
    for col in locked:
        shifts[int(col)] = 0.0
    return shifts


def _column_fail_counts(
    failing_pairs: tuple[ReciprocalPairResult, ...],
    n_series: int,
) -> np.ndarray:
    counts = np.zeros(max(0, int(n_series)), dtype=np.int64)
    for pair in failing_pairs:
        ca = int(pair.series_idx_a)
        cb = int(pair.series_idx_b)
        if 0 <= ca < counts.size:
            counts[ca] += 1
        if 0 <= cb < counts.size:
            counts[cb] += 1
    return counts


def reciprocal_corner_point_deltas(
    pair: ReciprocalPairResult,
    *,
    locked_columns: set[int] | frozenset[int] | None = None,
) -> list[tuple[int, int, float]]:
    """Delta y (ms) sui due angoli del rettangolo reciproco per chiuderlo."""
    locked = frozenset(int(c) for c in (locked_columns or ()))
    col_a = int(pair.series_idx_a)
    col_b = int(pair.series_idx_b)
    delta = float(pair.result.corner_delta_ms)
    tr_on_a = int(pair.result.failed_trace_on_series_a)
    tr_on_b = int(pair.result.failed_trace_on_series_b)
    a_lock = col_a in locked
    b_lock = col_b in locked
    if a_lock and b_lock:
        return []
    if a_lock:
        return [(col_b, tr_on_b, -delta)]
    if b_lock:
        return [(col_a, tr_on_a, delta)]
    half = delta * 0.5
    return [(col_a, tr_on_a, half), (col_b, tr_on_b, -half)]


def reciprocal_corner_point_deltas_weak_side(
    pair: ReciprocalPairResult,
    fail_counts: np.ndarray | list[int] | tuple[int, ...],
    *,
    locked_columns: set[int] | frozenset[int] | None = None,
) -> list[tuple[int, int, float]]:
    """Chiude il FAIL spostando solo il lato con più FAIL (lato debole)."""
    locked = frozenset(int(c) for c in (locked_columns or ()))
    col_a = int(pair.series_idx_a)
    col_b = int(pair.series_idx_b)
    delta = float(pair.result.corner_delta_ms)
    tr_on_a = int(pair.result.failed_trace_on_series_a)
    tr_on_b = int(pair.result.failed_trace_on_series_b)
    a_lock = col_a in locked
    b_lock = col_b in locked
    if a_lock and b_lock:
        return []
    if a_lock:
        return [(col_b, tr_on_b, -delta)]
    if b_lock:
        return [(col_a, tr_on_a, delta)]
    counts = np.asarray(fail_counts, dtype=np.int64)
    fa = int(counts[col_a]) if 0 <= col_a < counts.size else 0
    fb = int(counts[col_b]) if 0 <= col_b < counts.size else 0
    if fa > fb:
        return [(col_a, tr_on_a, delta)]
    if fb > fa:
        return [(col_b, tr_on_b, -delta)]
    # tie → metà/metà
    half = delta * 0.5
    return [(col_a, tr_on_a, half), (col_b, tr_on_b, -half)]


def _auto_fix_smooth_point_deltas(
    metas: list[dict[str, object]],
    col_to_meta: dict[int, int],
    seed_deltas: dict[tuple[int, int], float],
    *,
    radius: int = 2,
    decay: float = 0.55,
    shot_eps_ms: float = SHOT_DROMOCRONA_EPS_MS,
) -> dict[tuple[int, int], float]:
    """
    Propaga correzioni puntuali lungo le tracce vicine della stessa colonna
    (smooth locale, utile sulle S con FAIL concentrati).
    seed_deltas: (col_idx, trace_idx) → delta_ms già applicabile.
    """
    out: dict[tuple[int, int], float] = dict(seed_deltas)
    rad = max(0, int(radius))
    if rad <= 0 or not seed_deltas:
        return out
    dec = float(np.clip(float(decay), 0.05, 0.95))
    for (col_idx, tr_idx), delta in list(seed_deltas.items()):
        meta_idx = col_to_meta.get(int(col_idx))
        if meta_idx is None:
            continue
        meta = metas[int(meta_idx)]
        for dist in range(1, rad + 1):
            w = float(dec ** dist)
            for neigh in (int(tr_idx) - dist, int(tr_idx) + dist):
                if neigh < 0:
                    continue
                pt = _auto_fix_series_point_index(meta, int(neigh))
                if pt < 0:
                    continue
                y = np.asarray(meta.get("y"), dtype=np.float64)
                if pt >= y.size:
                    continue
                if _auto_fix_is_shot_point(float(y[pt]), shot_eps_ms=shot_eps_ms):
                    continue
                key = (int(col_idx), int(neigh))
                # non sovrascrivere seed più forti
                prev = float(out.get(key, 0.0))
                cand = float(delta) * w
                if abs(cand) > abs(prev):
                    out[key] = cand
    return out


def _total_fail_abs_corner_delta(
    pairs: tuple[ReciprocalPairResult, ...],
) -> float:
    return float(
        sum(
            abs(float(pair.result.corner_delta_ms))
            for pair in pairs
            if not pair.result.passed
        )
    )


def reciprocal_pairs_for_fail_spot(
    pairs: tuple[ReciprocalPairResult, ...],
    column_idx: int,
    trace_idx: int,
) -> tuple[ReciprocalPairResult, ...]:
    """Coppie FAIL il cui angolo coincide con colonna/traccia indicati."""
    col = int(column_idx)
    tr = int(trace_idx)
    out: list[ReciprocalPairResult] = []
    for pair in pairs:
        if pair.result.passed:
            continue
        if (
            int(pair.series_idx_a) == col
            and int(pair.result.failed_trace_on_series_a) == tr
        ) or (
            int(pair.series_idx_b) == col
            and int(pair.result.failed_trace_on_series_b) == tr
        ):
            out.append(pair)
    return tuple(out)


def snap_reciprocal_fail_at_spot(
    series_meta: list[dict[str, object]],
    pairs: tuple[ReciprocalPairResult, ...],
    *,
    column_idx: int,
    trace_idx: int,
    shot_registry: dict[str, int] | None = None,
    prefer_memory: bool = True,
    tolerance_bands: ReciprocalToleranceBands | None = None,
    blend_corner: float = 1.0,
    max_step_corner: float = 2.0,
    shot_eps_ms: float = SHOT_DROMOCRONA_EPS_MS,
) -> dict[str, object]:
    """Chiude manualmente il reciproco FAIL sul punto scelto (nudge angoli)."""
    from dromocrona_grid_data import series_meta_index_to_column_map, sort_series_meta_by_shot_order

    matching = reciprocal_pairs_for_fail_spot(pairs, int(column_idx), int(trace_idx))
    if not matching:
        return {"status": "noop", "reason": "no_matching_fail"}

    bands = ReciprocalToleranceBands.from_dict(tolerance_bands)
    metas: list[dict[str, object]] = []
    for meta in series_meta:
        clone = dict(meta)
        clone["y"] = np.asarray(meta.get("y"), dtype=np.float64).copy()
        trace_raw = meta.get("trace_idx")
        if trace_raw is not None:
            clone["trace_idx"] = np.asarray(trace_raw, dtype=np.int64).copy()
        metas.append(clone)

    sorted_meta = sort_series_meta_by_shot_order(
        metas, shot_registry=shot_registry
    )
    col_to_meta = {
        int(col): int(orig)
        for orig, col in series_meta_index_to_column_map(
            metas, shot_registry=shot_registry
        ).items()
    }
    locked_columns = {
        int(col)
        for col, meta_idx in col_to_meta.items()
        if bool(metas[int(meta_idx)].get("auto_fix_locked"))
    }

    pair = max(
        matching,
        key=lambda p: abs(float(p.result.corner_delta_ms)),
    )
    touched: dict[tuple[int, int], float] = {}
    original_values: dict[tuple[int, int], float] = {}
    changed_cols: set[int] = set()
    for col_idx, tr_idx, delta_y in reciprocal_corner_point_deltas(
        pair, locked_columns=locked_columns
    ):
        applied = float(
            np.clip(float(delta_y) * float(blend_corner), -max_step_corner, max_step_corner)
        )
        if abs(applied) < 0.005:
            continue
        meta_idx = col_to_meta.get(int(col_idx))
        if meta_idx is None:
            continue
        if _auto_fix_nudge_point(
            metas[int(meta_idx)],
            int(meta_idx),
            int(tr_idx),
            applied,
            original_values=original_values,
            touched=touched,
            shot_eps_ms=shot_eps_ms,
        ):
            changed_cols.add(int(col_idx))

    if not touched:
        return {"status": "noop", "reason": "locked_or_too_small"}

    pairs_map = reciprocal_pairs_to_map(pairs)
    if changed_cols:
        pairs_map = patch_reciprocal_pairs_map(
            pairs_map,
            sorted_meta,
            changed_cols,
            shot_registry=shot_registry or {},
            prefer_memory=prefer_memory,
            tolerance_bands=bands,
        )

    pairs_after = reciprocal_pairs_from_map(pairs_map)
    updated_y: dict[int, list[float]] = {}
    for meta_idx, meta in enumerate(metas):
        y_arr = np.asarray(meta.get("y"), dtype=np.float64)
        updated_y[int(meta_idx)] = [float(v) for v in y_arr.tolist()]

    return {
        "status": "done",
        "method": "snap_fail",
        "pair": pair,
        "fails_before": int(sum(1 for p in pairs if not p.result.passed)),
        "fails_after": int(sum(1 for p in pairs_after if not p.result.passed)),
        "pairs": pairs_after,
        "pairs_map": pairs_map,
        "touched": {f"{a},{b}": float(v) for (a, b), v in touched.items()},
        "original_values": {
            f"{a},{b}": float(v) for (a, b), v in original_values.items()
        },
        "updated_y": {str(k): v for k, v in updated_y.items()},
        "point_touched_columns": sorted(int(c) for c in changed_cols),
    }


def format_reciprocal_tolerance_bands_label(
    bands: ReciprocalToleranceBands | None = None,
) -> str:
    cfg = (bands or DEFAULT_RECIPROCAL_TOLERANCE_BANDS).normalized()
    return (
        f"±{cfg.tol_near_ms:g}/±{cfg.tol_mid_ms:g}/±{cfg.tol_far_ms:g} ms"
    )


# Metodi auto-fix esposti in UI (chiave → etichetta). Ordine = priorità mostra.
RECIPROCAL_AUTO_FIX_METHODS: tuple[tuple[str, str], ...] = (
    ("hybrid", "Ibrido (shift + punti)"),
    ("hybrid_smooth", "Ibrido + smooth (cap)"),
    ("morph_prior", "Ibrido + prior morfologico"),
    ("median_shift", "Shift mediana"),
    ("ransac_shift", "Shift RANSAC"),
    ("robust_global", "Globale Huber"),
    ("graph_global", "Grafo globale"),
    ("weak_side", "Solo lato debole"),
    ("seed_propagate", "Propagazione da seed"),
    ("weighted_anchor", "Ancore pesate"),
    ("column_shift", "Solo shift colonna"),
    ("shot_shift", "Solo shift shot"),
)


def reciprocal_auto_fix_method_label(method: str) -> str:
    key = str(method or "hybrid").strip().lower()
    for mid, label in RECIPROCAL_AUTO_FIX_METHODS:
        if mid == key:
            return label
    return "Ibrido (shift + punti)"


def reciprocal_auto_fix_method_ids() -> frozenset[str]:
    return frozenset(mid for mid, _ in RECIPROCAL_AUTO_FIX_METHODS)


def format_reciprocal_auto_summary(
    pairs: tuple[ReciprocalPairResult, ...],
    *,
    tolerance_ms: float = DEFAULT_RECIPROCAL_TOLERANCE_MS,
    tolerance_bands: ReciprocalToleranceBands | None = None,
) -> str:
    del tolerance_ms
    band_label = format_reciprocal_tolerance_bands_label(tolerance_bands)
    if len(pairs) == 0:
        return "Reciproco: servono almeno 2 dromocrone"
    n_dromocrone = len(
        {pair.series_idx_a for pair in pairs} | {pair.series_idx_b for pair in pairs}
    )
    per_dromocrona = max(0, n_dromocrone - 1)
    failed = sum(1 for pair in pairs if not pair.result.passed)
    if failed == 0:
        return (
            f"Reciproco: {len(pairs)} rettangoli OK "
            f"({per_dromocrona} per dromocrona, soglia dinamica {band_label})"
        )
    return (
        f"Reciproco: {failed}/{len(pairs)} rettangoli fuori soglia "
        f"({per_dromocrona} per dromocrona, soglia dinamica {band_label})"
    )


def _auto_fix_series_point_index(meta: dict[str, object], trace_idx: int) -> int:
    traces = meta.get("trace_idx")
    if traces is not None:
        arr = np.asarray(traces, dtype=np.int64)
        matches = np.nonzero(arr == int(trace_idx))[0]
        return int(matches[0]) if matches.size else -1
    x = np.asarray(meta.get("x"), dtype=np.float64)
    if x.size == 0:
        return -1
    matches = np.nonzero(np.isclose(x, float(trace_idx) + 1.0, atol=0.01))[0]
    return int(matches[0]) if matches.size else -1


def _auto_fix_is_shot_point(y_ms: float, *, shot_eps_ms: float = SHOT_DROMOCRONA_EPS_MS) -> bool:
    return float(y_ms) <= float(shot_eps_ms)


def _auto_fix_shift_column(
    meta: dict[str, object],
    meta_idx: int,
    delta_ms: float,
    *,
    original_values: dict[tuple[int, int], float],
    touched: dict[tuple[int, int], float],
    shot_eps_ms: float,
) -> int:
    if bool(meta.get("auto_fix_locked")):
        return 0
    if abs(float(delta_ms)) < 1e-9:
        return 0
    y = np.asarray(meta.get("y"), dtype=np.float64, copy=True)
    trace_raw = meta.get("trace_idx")
    if trace_raw is not None:
        trace_idx = np.asarray(trace_raw, dtype=np.int64)
    else:
        trace_idx = np.arange(y.size, dtype=np.int64)
    changed = 0
    n = min(y.size, trace_idx.size)
    for pt_idx in range(n):
        if _auto_fix_is_shot_point(float(y[pt_idx]), shot_eps_ms=shot_eps_ms):
            continue
        old_val = float(y[pt_idx])
        if not math.isfinite(old_val):
            continue
        new_val = max(0.0, old_val + float(delta_ms))
        if abs(new_val - old_val) < 0.01:
            continue
        tr = int(trace_idx[pt_idx])
        key = (int(meta_idx), tr)
        if key not in original_values:
            original_values[key] = old_val
        y[pt_idx] = new_val
        touched[key] = new_val
        changed += 1
    if changed > 0:
        meta["y"] = y
    return changed


def _auto_fix_resolve_shot_trace_idx(
    meta: dict[str, object],
    *,
    shot_eps_ms: float,
) -> int | None:
    raw = meta.get("shot_trace_idx")
    if raw is not None:
        try:
            return int(raw)
        except (TypeError, ValueError):
            pass
    y = np.asarray(meta.get("y"), dtype=np.float64)
    trace_raw = meta.get("trace_idx")
    if y.size == 0:
        return None
    if trace_raw is not None:
        trace_idx = np.asarray(trace_raw, dtype=np.int64)
    else:
        trace_idx = np.arange(y.size, dtype=np.int64)
    n = min(y.size, trace_idx.size)
    for pt_idx in range(n):
        if _auto_fix_is_shot_point(float(y[pt_idx]), shot_eps_ms=shot_eps_ms):
            return int(trace_idx[pt_idx])
    return None


def _auto_fix_shift_shot_reference(
    meta: dict[str, object],
    meta_idx: int,
    delta_ms: float,
    *,
    original_values: dict[tuple[int, int], float],
    touched: dict[tuple[int, int], float],
    original_shot_abs_ref: dict[int, float],
    updated_shot_abs_ref: dict[int, float],
    shot_eps_ms: float,
) -> int:
    """Duale dello shift colonna: stessi y relativi, ma sposta solo shot_abs_ref.

    y_non_shot += Δ, shot_abs_ref -= Δ → t_abs geofoni invariati, cambia solo lo shot.
    """
    if bool(meta.get("auto_fix_locked")):
        return 0
    if abs(float(delta_ms)) < 1e-9:
        return 0
    raw_ref = meta.get("shot_abs_ref_ms")
    if raw_ref is None:
        return 0
    try:
        old_ref = float(raw_ref)
    except (TypeError, ValueError):
        return 0
    if not math.isfinite(old_ref):
        return 0

    n_changed = _auto_fix_shift_column(
        meta,
        meta_idx,
        delta_ms,
        original_values=original_values,
        touched=touched,
        shot_eps_ms=shot_eps_ms,
    )
    if n_changed <= 0:
        return 0

    new_ref = float(old_ref) - float(delta_ms)
    if not math.isfinite(new_ref):
        return n_changed
    meta_i = int(meta_idx)
    if meta_i not in original_shot_abs_ref:
        original_shot_abs_ref[meta_i] = float(old_ref)
    meta["shot_abs_ref_ms"] = float(new_ref)
    updated_shot_abs_ref[meta_i] = float(new_ref)

    shot_tr = _auto_fix_resolve_shot_trace_idx(meta, shot_eps_ms=shot_eps_ms)
    if shot_tr is not None:
        key = (meta_i, int(shot_tr))
        # Shot resta a y≈0 in relativo; il persist usa il nuovo ref.
        if key not in original_values:
            original_values[key] = 0.0
        touched[key] = 0.0
    return n_changed


def _auto_fix_nudge_point(
    meta: dict[str, object],
    meta_idx: int,
    trace_idx: int,
    delta_ms: float,
    *,
    original_values: dict[tuple[int, int], float],
    touched: dict[tuple[int, int], float],
    shot_eps_ms: float,
) -> bool:
    if bool(meta.get("auto_fix_locked")):
        return False
    if abs(float(delta_ms)) < 1e-9:
        return False
    pt_idx = _auto_fix_series_point_index(meta, int(trace_idx))
    y = np.asarray(meta.get("y"), dtype=np.float64)
    if pt_idx < 0 or pt_idx >= y.size:
        return False
    old_val = float(y[pt_idx])
    if not math.isfinite(old_val):
        return False
    if _auto_fix_is_shot_point(old_val, shot_eps_ms=shot_eps_ms):
        return False
    new_val = max(0.0, old_val + float(delta_ms))
    if abs(new_val - old_val) < 0.005:
        return False
    tr = int(trace_idx)
    key = (int(meta_idx), tr)
    if key not in original_values:
        original_values[key] = old_val
    y_new = np.array(meta.get("y"), dtype=np.float64, copy=True)
    y_new[pt_idx] = new_val
    meta["y"] = y_new
    touched[key] = new_val
    return True


def _auto_fix_morph_prior_smooth(
    metas: list[dict[str, object]],
    col_to_meta: dict[int, int],
    columns: set[int] | frozenset[int],
    *,
    original_values: dict[tuple[int, int], float],
    touched: dict[tuple[int, int], float],
    blend: float = 0.18,
    shot_eps_ms: float = SHOT_DROMOCRONA_EPS_MS,
) -> set[int]:
    """
    Prior morfologico leggero: riduce le secondee differenze lungo la dromocrona
    (blend verso media dei vicini), senza toccare i punti shot.
    """
    changed: set[int] = set()
    b = float(np.clip(float(blend), 0.0, 0.5))
    if b <= 1e-9 or not columns:
        return changed
    for col_idx in columns:
        meta_idx = col_to_meta.get(int(col_idx))
        if meta_idx is None:
            continue
        meta = metas[int(meta_idx)]
        if bool(meta.get("auto_fix_locked")):
            continue
        y = np.asarray(meta.get("y"), dtype=np.float64)
        if y.size < 3:
            continue
        trace_raw = meta.get("trace_idx")
        if trace_raw is None:
            traces = np.arange(y.size, dtype=np.int64)
        else:
            traces = np.asarray(trace_raw, dtype=np.int64)
        if traces.size != y.size:
            continue
        y_new = y.copy()
        local_changed = False
        for i in range(1, int(y.size) - 1):
            if (
                _auto_fix_is_shot_point(float(y[i]), shot_eps_ms=shot_eps_ms)
                or _auto_fix_is_shot_point(float(y[i - 1]), shot_eps_ms=shot_eps_ms)
                or _auto_fix_is_shot_point(float(y[i + 1]), shot_eps_ms=shot_eps_ms)
            ):
                continue
            if not (
                math.isfinite(float(y[i]))
                and math.isfinite(float(y[i - 1]))
                and math.isfinite(float(y[i + 1]))
            ):
                continue
            target = 0.5 * (float(y[i - 1]) + float(y[i + 1]))
            blended = (1.0 - b) * float(y[i]) + b * target
            blended = max(0.0, blended)
            if abs(blended - float(y[i])) < 0.005:
                continue
            tr = int(traces[i])
            key = (int(meta_idx), tr)
            if key not in original_values:
                original_values[key] = float(y[i])
            y_new[i] = blended
            touched[key] = blended
            local_changed = True
        if local_changed:
            meta["y"] = y_new
            changed.add(int(col_idx))
    return changed


def run_reciprocal_auto_fix(
    series_meta: list[dict[str, object]],
    shot_registry: dict[str, int],
    *,
    method: str = "hybrid",
    prefer_memory: bool = True,
    max_col_iter: int = 6,
    max_corner_iter: int = 2,
    blend_col: float = 0.5,
    blend_corner: float = 0.25,
    max_step: float = 1.0,
    max_step_corner: float = 0.35,
    min_corner_delta: float = 0.6,
    shot_eps_ms: float = SHOT_DROMOCRONA_EPS_MS,
    tolerance_bands: ReciprocalToleranceBands | None = None,
) -> dict[str, object]:
    """
    Algoritmo auto-fix reciproci (CPU-bound, senza Qt).

    Restituisce y aggiornate, coppie finali e statistiche per applicazione sulla GUI.
    """
    from dromocrona_grid_data import series_meta_index_to_column_map, sort_series_meta_by_shot_order

    if len(series_meta) < 2:
        return {"status": "noop", "fails_before": 0, "fails_after": 0}

    bands = (tolerance_bands or DEFAULT_RECIPROCAL_TOLERANCE_BANDS).normalized()

    metas: list[dict[str, object]] = []
    for meta in series_meta:
        clone = dict(meta)
        clone["y"] = np.asarray(meta.get("y"), dtype=np.float64).copy()
        trace_raw = meta.get("trace_idx")
        if trace_raw is not None:
            clone["trace_idx"] = np.asarray(trace_raw, dtype=np.int64).copy()
        metas.append(clone)

    sorted_meta = sort_series_meta_by_shot_order(
        metas, shot_registry=shot_registry
    )
    col_to_meta = {
        int(col): int(orig)
        for orig, col in series_meta_index_to_column_map(
            metas, shot_registry=shot_registry
        ).items()
    }
    locked_columns = {
        int(col)
        for col, meta_idx in col_to_meta.items()
        if bool(metas[int(meta_idx)].get("auto_fix_locked"))
    }
    n_columns = len(sorted_meta)

    method_norm = str(method or "hybrid").strip().lower()
    known_methods = reciprocal_auto_fix_method_ids()
    if method_norm not in known_methods:
        method_norm = "hybrid"

    # Parametri per-metodo (cap più stretti su smooth / seed)
    corner_blend = float(blend_corner)
    corner_step = float(max_step_corner)
    corner_iters = int(max_corner_iter)
    do_column_phase = True
    do_corner_phase = False
    corner_mode = "both"  # both | weak | seed
    smooth_radius = 0
    apply_morph_prior = False
    if method_norm == "hybrid":
        do_corner_phase = True
    elif method_norm == "hybrid_smooth":
        do_corner_phase = True
        corner_blend = min(corner_blend, 0.20)
        corner_step = min(corner_step, 0.25)
        corner_iters = max(corner_iters, 3)
        smooth_radius = 2
    elif method_norm == "morph_prior":
        do_corner_phase = True
        corner_blend = min(corner_blend, 0.22)
        corner_step = min(corner_step, 0.28)
        corner_iters = max(corner_iters, 3)
        smooth_radius = 1
        apply_morph_prior = True
    elif method_norm == "weak_side":
        do_corner_phase = True
        corner_mode = "weak"
        corner_blend = min(max(corner_blend, 0.35), 0.6)
        corner_step = max(corner_step, 0.45)
    elif method_norm == "seed_propagate":
        do_column_phase = False
        do_corner_phase = True
        corner_mode = "seed"
        corner_blend = 0.85
        corner_step = max(corner_step, 0.8)
        corner_iters = max(corner_iters, 4)
        smooth_radius = 3
    elif method_norm == "graph_global":
        do_corner_phase = True
        corner_blend = min(corner_blend, 0.18)
        corner_step = min(corner_step, 0.22)
        corner_iters = max(1, min(corner_iters, 2))
        smooth_radius = 1
    elif method_norm in {"column_shift", "shot_shift", "median_shift", "ransac_shift",
                         "robust_global", "weighted_anchor"}:
        do_corner_phase = False
    else:
        do_corner_phase = True

    pairs_map = compute_reciprocal_pairs_map(
        sorted_meta,
        shot_registry=shot_registry,
        prefer_memory=prefer_memory,
        tolerance_bands=bands,
    )
    pairs_before = reciprocal_pairs_from_map(pairs_map)
    fails_before = sum(1 for pair in pairs_before if not pair.result.passed)
    if fails_before <= 0:
        return {
            "status": "noop",
            "fails_before": 0,
            "fails_after": 0,
            "pairs": pairs_before,
        }

    touched: dict[tuple[int, int], float] = {}
    original_values: dict[tuple[int, int], float] = {}
    original_shot_abs_ref: dict[int, float] = {}
    updated_shot_abs_ref: dict[int, float] = {}
    shifted_columns: set[int] = set()
    point_touched_columns: set[int] = set()

    def _compute_shifts(failing_pairs: tuple[ReciprocalPairResult, ...]) -> np.ndarray:
        if method_norm == "robust_global":
            return compute_reciprocal_column_shifts_robust(
                failing_pairs, n_columns, locked_columns=locked_columns
            )
        if method_norm == "median_shift":
            return compute_reciprocal_column_shifts_median(
                failing_pairs, n_columns, locked_columns=locked_columns
            )
        if method_norm == "ransac_shift":
            return compute_reciprocal_column_shifts_ransac(
                failing_pairs, n_columns, locked_columns=locked_columns
            )
        if method_norm in {"weighted_anchor", "weak_side"}:
            return compute_reciprocal_column_shifts_weighted_anchor(
                failing_pairs, n_columns, locked_columns=locked_columns
            )
        if method_norm == "graph_global":
            # una passata Huber più aggressiva (grafo globale)
            return compute_reciprocal_column_shifts_robust(
                failing_pairs,
                n_columns,
                locked_columns=locked_columns,
                huber_delta_ms=2.0,
                max_irls_iter=14,
                ridge=1e-5,
            )
        return compute_reciprocal_column_shifts(
            failing_pairs, n_columns, locked_columns=locked_columns
        )

    if do_column_phase:
        col_iters = int(max_col_iter)
        if method_norm == "graph_global":
            col_iters = max(col_iters, 8)
        elif method_norm in {"median_shift", "ransac_shift", "weighted_anchor"}:
            col_iters = max(col_iters, 5)
        for _step in range(col_iters):
            current_pairs = reciprocal_pairs_from_map(pairs_map)
            failing_pairs = tuple(
                pair for pair in current_pairs if not pair.result.passed
            )
            if not failing_pairs:
                break
            shifts = _compute_shifts(failing_pairs)
            if shifts.size == 0:
                break
            changed_iter = 0
            changed_cols: set[int] = set()
            for col_idx, shift_val in enumerate(shifts):
                if col_idx >= n_columns:
                    break
                if int(col_idx) in locked_columns:
                    continue
                applied = float(
                    np.clip(float(shift_val) * float(blend_col), -max_step, max_step)
                )
                if abs(applied) < 0.02:
                    continue
                meta_idx = col_to_meta.get(int(col_idx))
                if meta_idx is None:
                    continue
                if method_norm == "shot_shift":
                    n_changed = _auto_fix_shift_shot_reference(
                        metas[int(meta_idx)],
                        int(meta_idx),
                        applied,
                        original_values=original_values,
                        touched=touched,
                        original_shot_abs_ref=original_shot_abs_ref,
                        updated_shot_abs_ref=updated_shot_abs_ref,
                        shot_eps_ms=shot_eps_ms,
                    )
                else:
                    n_changed = _auto_fix_shift_column(
                        metas[int(meta_idx)],
                        int(meta_idx),
                        applied,
                        original_values=original_values,
                        touched=touched,
                        shot_eps_ms=shot_eps_ms,
                    )
                if n_changed <= 0:
                    continue
                changed_cols.add(int(col_idx))
                shifted_columns.add(int(col_idx))
                changed_iter += n_changed
            if changed_cols:
                pairs_map = patch_reciprocal_pairs_map(
                    dict(pairs_map),
                    sorted_meta,
                    changed_cols,
                    shot_registry=shot_registry,
                    prefer_memory=prefer_memory,
                    tolerance_bands=bands,
                )
            if changed_iter == 0:
                break

    if do_corner_phase:
        for _step in range(int(corner_iters)):
            current_pairs = reciprocal_pairs_from_map(pairs_map)
            failing_pairs = tuple(
                pair for pair in current_pairs if not pair.result.passed
            )
            if not failing_pairs:
                break
            fail_counts = _column_fail_counts(failing_pairs, n_columns)
            # seed: priorità ai FAIL più grandi
            ordered = sorted(
                failing_pairs,
                key=lambda p: abs(float(p.result.corner_delta_ms)),
                reverse=True,
            )
            changed_iter = 0
            changed_cols: set[int] = set()
            seed_deltas: dict[tuple[int, int], float] = {}

            for pair in ordered:
                if abs(float(pair.result.corner_delta_ms)) < float(min_corner_delta):
                    continue
                if corner_mode == "weak":
                    deltas = reciprocal_corner_point_deltas_weak_side(
                        pair, fail_counts, locked_columns=locked_columns
                    )
                else:
                    deltas = reciprocal_corner_point_deltas(
                        pair, locked_columns=locked_columns
                    )
                for col_idx, trace_idx, delta_y in deltas:
                    applied = float(
                        np.clip(
                            float(delta_y) * float(corner_blend),
                            -corner_step,
                            corner_step,
                        )
                    )
                    if abs(applied) < 0.02:
                        continue
                    key = (int(col_idx), int(trace_idx))
                    # in seed mode accumula e applica dopo lo smooth
                    if corner_mode == "seed" or smooth_radius > 0:
                        prev = float(seed_deltas.get(key, 0.0))
                        if abs(applied) > abs(prev):
                            seed_deltas[key] = applied
                        continue
                    meta_idx = col_to_meta.get(int(col_idx))
                    if meta_idx is None:
                        continue
                    if _auto_fix_nudge_point(
                        metas[int(meta_idx)],
                        int(meta_idx),
                        int(trace_idx),
                        applied,
                        original_values=original_values,
                        touched=touched,
                        shot_eps_ms=shot_eps_ms,
                    ):
                        changed_cols.add(int(col_idx))
                        point_touched_columns.add(int(col_idx))
                        changed_iter += 1

            if seed_deltas:
                if smooth_radius > 0:
                    seed_deltas = _auto_fix_smooth_point_deltas(
                        metas,
                        col_to_meta,
                        seed_deltas,
                        radius=int(smooth_radius),
                        decay=0.55 if corner_mode != "seed" else 0.65,
                        shot_eps_ms=shot_eps_ms,
                    )
                for (col_idx, trace_idx), applied in seed_deltas.items():
                    if abs(float(applied)) < 0.02:
                        continue
                    meta_idx = col_to_meta.get(int(col_idx))
                    if meta_idx is None:
                        continue
                    if _auto_fix_nudge_point(
                        metas[int(meta_idx)],
                        int(meta_idx),
                        int(trace_idx),
                        float(applied),
                        original_values=original_values,
                        touched=touched,
                        shot_eps_ms=shot_eps_ms,
                    ):
                        changed_cols.add(int(col_idx))
                        point_touched_columns.add(int(col_idx))
                        changed_iter += 1

            if changed_cols:
                pairs_map = patch_reciprocal_pairs_map(
                    dict(pairs_map),
                    sorted_meta,
                    changed_cols,
                    shot_registry=shot_registry,
                    prefer_memory=prefer_memory,
                    tolerance_bands=bands,
                )
            if changed_iter == 0:
                break

    if apply_morph_prior and point_touched_columns:
        morph_cols = _auto_fix_morph_prior_smooth(
            metas,
            col_to_meta,
            point_touched_columns,
            original_values=original_values,
            touched=touched,
            blend=0.18,
            shot_eps_ms=shot_eps_ms,
        )
        if morph_cols:
            pairs_map = patch_reciprocal_pairs_map(
                dict(pairs_map),
                sorted_meta,
                morph_cols,
                shot_registry=shot_registry,
                prefer_memory=prefer_memory,
                tolerance_bands=bands,
            )

    pairs_after = reciprocal_pairs_from_map(pairs_map)
    fails_after = sum(1 for pair in pairs_after if not pair.result.passed)
    delta_before = _total_fail_abs_corner_delta(pairs_before)
    delta_after = _total_fail_abs_corner_delta(pairs_after)
    rollback = bool(original_values) and (
        fails_after > fails_before
        or (
            fails_after >= fails_before
            and delta_after > delta_before + 1e-6
        )
    )
    if rollback:
        meta_to_col = {int(meta_idx): int(col) for col, meta_idx in col_to_meta.items()}
        rollback_cols: set[int] = set()
        for (meta_idx, trace_idx), old_val in original_values.items():
            meta = metas[int(meta_idx)]
            pt_idx = _auto_fix_series_point_index(meta, int(trace_idx))
            if pt_idx < 0:
                continue
            y_new = np.asarray(meta.get("y"), dtype=np.float64).copy()
            if pt_idx >= y_new.size:
                continue
            y_new[pt_idx] = float(old_val)
            meta["y"] = y_new
            col_idx = meta_to_col.get(int(meta_idx))
            if col_idx is not None:
                rollback_cols.add(int(col_idx))
        for meta_idx, old_ref in original_shot_abs_ref.items():
            metas[int(meta_idx)]["shot_abs_ref_ms"] = float(old_ref)
        touched.clear()
        original_shot_abs_ref.clear()
        updated_shot_abs_ref.clear()
        if rollback_cols:
            pairs_map = patch_reciprocal_pairs_map(
                dict(pairs_map),
                sorted_meta,
                rollback_cols,
                shot_registry=shot_registry,
                prefer_memory=prefer_memory,
                tolerance_bands=bands,
            )
        pairs_after = reciprocal_pairs_from_map(pairs_map)
        fails_after = sum(1 for pair in pairs_after if not pair.result.passed)

    updated_y: dict[int, list[float]] = {}
    for meta_idx, meta in enumerate(metas):
        y_arr = np.asarray(meta.get("y"), dtype=np.float64)
        updated_y[int(meta_idx)] = [float(v) for v in y_arr.tolist()]

    return {
        "status": "done",
        "method": method_norm,
        "fails_before": int(fails_before),
        "fails_after": int(fails_after),
        "pairs": pairs_after,
        "pairs_map": pairs_map,
        "touched_keys": [list(k) for k in touched.keys()],
        "touched": {f"{a},{b}": float(v) for (a, b), v in touched.items()},
        "original_values": {
            f"{a},{b}": float(v) for (a, b), v in original_values.items()
        },
        "updated_y": {str(k): v for k, v in updated_y.items()},
        "shifted_columns": sorted(int(c) for c in shifted_columns),
        "point_touched_columns": sorted(int(c) for c in point_touched_columns),
        "locked_columns": sorted(int(c) for c in locked_columns),
        "rollback": rollback,
        "updated_shot_abs_ref": {
            str(k): float(v) for k, v in updated_shot_abs_ref.items()
        },
        "original_shot_abs_ref": {
            str(k): float(v) for k, v in original_shot_abs_ref.items()
        },
    }


def _series_full_trace_state(
    meta: dict[str, object],
    *,
    shot_eps_ms: float = SHOT_DROMOCRONA_EPS_MS,
) -> tuple[int | None, dict[int, float], set[int], dict[int, int]]:
    """Shot, tempi presenti, tracce mancanti, mappa traccia→indice in y."""
    y = np.asarray(meta.get("y"), dtype=np.float64).ravel()
    trace_raw = meta.get("trace_idx")
    if trace_raw is not None:
        traces = np.asarray(trace_raw, dtype=np.int64).ravel()
    else:
        traces = np.arange(y.size, dtype=np.int64)
    n = min(y.size, traces.size)
    if n <= 0:
        return None, {}, set(), {}
    shot_raw = meta.get("shot_trace_idx")
    if shot_raw is not None:
        shot_tr: int | None = int(shot_raw)
    else:
        shot_tr = None
        for i in range(n):
            if float(y[i]) <= float(shot_eps_ms):
                shot_tr = int(traces[i])
                break
    present: dict[int, float] = {}
    missing: set[int] = set()
    pt_of: dict[int, int] = {}
    for i in range(n):
        tr = int(traces[i])
        pt_of[tr] = int(i)
        t = float(y[i])
        if is_missing_fbp_pick(tr, t, shot_trace_idx=shot_tr, shot_eps_ms=shot_eps_ms):
            missing.add(tr)
        elif math.isfinite(t):
            present[tr] = t
    return shot_tr, present, missing, pt_of


def _interp_missing_time(
    present: dict[int, float],
    missing_tr: int,
) -> float | None:
    """Interpolazione lineare tra i pick presenti più vicini (per indice traccia)."""
    if not present:
        return None
    left = [tr for tr in present if int(tr) < int(missing_tr)]
    right = [tr for tr in present if int(tr) > int(missing_tr)]
    if left and right:
        tl = max(left)
        tr = min(right)
        span = float(tr - tl)
        if span <= 0.0:
            return None
        w = (float(missing_tr) - float(tl)) / span
        return float(present[tl]) + w * (float(present[tr]) - float(present[tl]))
    if left:
        return float(present[max(left)])
    if right:
        return float(present[min(right)])
    return None


def run_reciprocal_estimate_missing(
    series_meta: list[dict[str, object]],
    shot_registry: dict[str, int],
    *,
    prefer_memory: bool = True,
    fill_interp: bool = True,
    shot_eps_ms: float = SHOT_DROMOCRONA_EPS_MS,
    tolerance_bands: ReciprocalToleranceBands | None = None,
) -> dict[str, object]:
    """Stima i break mancanti: reciproco agli angoli shot, altrimenti interpolazione.

    Per ogni coppia di shot (A,B): se manca il pick di A sulla posizione di B,
    stima ``t_A(B) ≈ t_B(A)`` (e simmetrico). I gap non-angolo usano interp
    lineare sui pick presenti della stessa dromocrona.
    """
    from dromocrona_grid_data import series_meta_index_to_column_map, sort_series_meta_by_shot_order

    del prefer_memory  # stato già in meta["y"]; tenuto per simmetria API worker
    if len(series_meta) < 1:
        return {"status": "noop", "n_filled": 0, "fails_before": 0, "fails_after": 0}

    bands = (tolerance_bands or DEFAULT_RECIPROCAL_TOLERANCE_BANDS).normalized()
    metas: list[dict[str, object]] = []
    for meta in series_meta:
        clone = dict(meta)
        clone["y"] = np.asarray(meta.get("y"), dtype=np.float64).copy()
        trace_raw = meta.get("trace_idx")
        if trace_raw is not None:
            clone["trace_idx"] = np.asarray(trace_raw, dtype=np.int64).copy()
        metas.append(clone)

    sorted_meta = sort_series_meta_by_shot_order(
        metas, shot_registry=shot_registry
    )
    meta_to_col = series_meta_index_to_column_map(
        metas, shot_registry=shot_registry
    )
    col_to_meta = {int(col): int(orig) for orig, col in meta_to_col.items()}

    pairs_before_map = compute_reciprocal_pairs_map(
        sorted_meta,
        shot_registry=shot_registry,
        prefer_memory=True,
        tolerance_bands=bands,
    )
    pairs_before = reciprocal_pairs_from_map(pairs_before_map)
    fails_before = sum(1 for pair in pairs_before if not pair.result.passed)

    states: list[tuple[int | None, dict[int, float], set[int], dict[int, int]]] = []
    for meta in metas:
        states.append(_series_full_trace_state(meta, shot_eps_ms=shot_eps_ms))

    # candidati reciproci: (meta_idx, trace) -> lista tempi stimati
    # Una dromocrona fissata non viene riscritta, ma i suoi pick restano usabili
    # come sorgente per stimare le altre.
    recip_cands: dict[tuple[int, int], list[float]] = {}
    n_series = len(metas)
    for i in range(n_series):
        shot_i, present_i, missing_i, _pt_i = states[i]
        if shot_i is None:
            continue
        locked_i = bool(metas[i].get("auto_fix_locked"))
        for j in range(i + 1, n_series):
            shot_j, present_j, missing_j, _pt_j = states[j]
            if shot_j is None:
                continue
            locked_j = bool(metas[j].get("auto_fix_locked"))
            # manca A@shot_B → stima da B@shot_A
            if (
                not locked_i
                and int(shot_j) in missing_i
                and int(shot_i) in present_j
            ):
                recip_cands.setdefault((i, int(shot_j)), []).append(
                    float(present_j[int(shot_i)])
                )
            # manca B@shot_A → stima da A@shot_B
            if (
                not locked_j
                and int(shot_i) in missing_j
                and int(shot_j) in present_i
            ):
                recip_cands.setdefault((j, int(shot_i)), []).append(
                    float(present_i[int(shot_j)])
                )

    touched: dict[tuple[int, int], float] = {}
    original_values: dict[tuple[int, int], float] = {}
    estimates: list[dict[str, object]] = []
    point_touched_columns: set[int] = set()
    n_reciprocal = 0
    n_interp = 0

    def _apply_fill(
        meta_idx: int,
        trace_idx: int,
        new_t: float,
        *,
        source: str,
        n_sources: int,
        spread_ms: float,
    ) -> bool:
        nonlocal n_reciprocal, n_interp
        if bool(metas[meta_idx].get("auto_fix_locked")):
            return False
        shot_tr, present, missing, pt_of = states[meta_idx]
        if int(trace_idx) not in missing:
            return False
        if shot_tr is not None and int(trace_idx) == int(shot_tr):
            return False
        t_f = float(new_t)
        if not math.isfinite(t_f) or t_f <= float(shot_eps_ms):
            return False
        pt_idx = pt_of.get(int(trace_idx))
        if pt_idx is None:
            return False
        y = np.asarray(metas[meta_idx].get("y"), dtype=np.float64)
        if pt_idx < 0 or pt_idx >= y.size:
            return False
        key = (int(meta_idx), int(trace_idx))
        if key not in original_values:
            original_values[key] = float(y[pt_idx])
        y_new = y.copy()
        y_new[pt_idx] = t_f
        metas[meta_idx]["y"] = y_new
        present[int(trace_idx)] = t_f
        missing.discard(int(trace_idx))
        states[meta_idx] = (shot_tr, present, missing, pt_of)
        touched[key] = t_f
        col = meta_to_col.get(int(meta_idx))
        if col is not None:
            point_touched_columns.add(int(col))
        if source == "reciprocal":
            n_reciprocal += 1
        else:
            n_interp += 1
        estimates.append(
            {
                "meta_idx": int(meta_idx),
                "trace_idx": int(trace_idx),
                "time_ms": float(t_f),
                "source": str(source),
                "n_sources": int(n_sources),
                "spread_ms": float(spread_ms),
            }
        )
        return True

    # 1) angoli reciproci
    for (meta_idx, trace_idx), cands in sorted(recip_cands.items()):
        vals = [float(v) for v in cands if math.isfinite(float(v)) and float(v) > float(shot_eps_ms)]
        if not vals:
            continue
        est = float(np.median(np.asarray(vals, dtype=np.float64)))
        spread = float(max(vals) - min(vals)) if len(vals) > 1 else 0.0
        _apply_fill(
            int(meta_idx),
            int(trace_idx),
            est,
            source="reciprocal",
            n_sources=len(vals),
            spread_ms=spread,
        )

    # 2) gap residui: interpolazione sulla stessa dromocrona
    if fill_interp:
        for meta_idx, (_shot, present, missing, _pt) in enumerate(states):
            if bool(metas[meta_idx].get("auto_fix_locked")):
                continue
            for tr in sorted(missing):
                if (int(meta_idx), int(tr)) in touched:
                    continue
                est = _interp_missing_time(present, int(tr))
                if est is None:
                    continue
                _apply_fill(
                    int(meta_idx),
                    int(tr),
                    float(est),
                    source="interp",
                    n_sources=1,
                    spread_ms=0.0,
                )

    if not touched:
        return {
            "status": "noop",
            "n_filled": 0,
            "n_reciprocal": 0,
            "n_interp": 0,
            "fails_before": int(fails_before),
            "fails_after": int(fails_before),
            "pairs": pairs_before,
            "pairs_map": pairs_before_map,
            "touched": {},
            "original_values": {},
            "updated_y": {},
            "point_touched_columns": [],
            "estimates": [],
        }

    pairs_after_map = compute_reciprocal_pairs_map(
        sorted_meta,
        shot_registry=shot_registry,
        prefer_memory=True,
        tolerance_bands=bands,
    )
    pairs_after = reciprocal_pairs_from_map(pairs_after_map)
    fails_after = sum(1 for pair in pairs_after if not pair.result.passed)

    updated_y: dict[int, list[float]] = {}
    for meta_idx, meta in enumerate(metas):
        if any(si == int(meta_idx) for (si, _tr) in touched):
            y_arr = np.asarray(meta.get("y"), dtype=np.float64)
            updated_y[int(meta_idx)] = [float(v) for v in y_arr.tolist()]

    return {
        "status": "done",
        "n_filled": int(len(touched)),
        "n_reciprocal": int(n_reciprocal),
        "n_interp": int(n_interp),
        "fails_before": int(fails_before),
        "fails_after": int(fails_after),
        "pairs": pairs_after,
        "pairs_map": pairs_after_map,
        "touched": {f"{a},{b}": float(v) for (a, b), v in touched.items()},
        "original_values": {
            f"{a},{b}": float(v) for (a, b), v in original_values.items()
        },
        "updated_y": {str(k): v for k, v in updated_y.items()},
        "point_touched_columns": sorted(int(c) for c in point_touched_columns),
        "estimates": estimates,
        "col_to_meta": {str(k): int(v) for k, v in col_to_meta.items()},
    }

