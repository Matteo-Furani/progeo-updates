"""Dialog Qt per scaricare e applicare aggiornamenti ProgeoView."""

from __future__ import annotations

from typing import Any

from PyQt6 import QtCore, QtWidgets

from updater.apply_update import choose_update_strategy, run_update


class _UpdateWorker(QtCore.QObject):
    progress = QtCore.pyqtSignal(int, object)  # done, total|None
    status = QtCore.pyqtSignal(str)
    finished_ok = QtCore.pyqtSignal(str)
    failed = QtCore.pyqtSignal(str)

    def __init__(self, update_info: dict[str, Any]) -> None:
        super().__init__()
        self._info = update_info

    @QtCore.pyqtSlot()
    def run(self) -> None:
        try:
            strategy = run_update(
                self._info,
                progress=lambda done, total: self.progress.emit(int(done), total),
                exit_after=False,
                status=lambda msg: self.status.emit(str(msg)),
            )
            self.finished_ok.emit(strategy)
        except Exception as exc:
            self.failed.emit(str(exc))


class UpdateDialog(QtWidgets.QDialog):
    """Mostra note di rilascio e avvia download/apply in background."""

    def __init__(
        self,
        update_info: dict[str, Any],
        parent: QtWidgets.QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._info = dict(update_info)
        self._thread: QtCore.QThread | None = None
        self._worker: _UpdateWorker | None = None
        self._should_quit_app = False

        local_v = str(self._info.get("local_version") or "?")
        latest_v = str(self._info.get("latest_version") or "?")
        strategy = str(self._info.get("strategy") or "") or choose_update_strategy(
            self._info
        )
        self._info["strategy"] = strategy

        is_test = bool(self._info.get("is_test_channel"))
        self.setWindowTitle(
            "Aggiornamento TEST ProgeoView" if is_test else "Aggiornamento ProgeoView"
        )
        self.setModal(True)
        self.setMinimumWidth(420)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(10)

        if is_test:
            banner = QtWidgets.QLabel(
                "Canale <b>TEST</b> — non è la release ufficiale."
            )
            banner.setTextFormat(QtCore.Qt.TextFormat.RichText)
            banner.setStyleSheet(
                "color: #fcd34d; background: rgba(252, 211, 77, 0.12); "
                "padding: 6px 8px; border-radius: 6px;"
            )
            layout.addWidget(banner)

        title = QtWidgets.QLabel(
            f"{'Scarica aggiornamento test' if is_test else 'Disponibile la versione'} "
            f"<b>{latest_v}</b> (installata: {local_v})"
        )
        title.setTextFormat(QtCore.Qt.TextFormat.RichText)
        layout.addWidget(title)

        chain = self._info.get("patch_chain") or []
        if strategy == "patch" and isinstance(chain, list) and len(chain) > 1:
            hops = " → ".join(
                [local_v]
                + [str(step.get("to_version") or "?") for step in chain]
            )
            mode = f"catena patch ({len(chain)} passi: {hops})"
        elif strategy == "patch":
            mode = "patch (file modificati)"
        elif strategy == "installer":
            mode = "installer completo"
        else:
            mode = "nessuna (manifest incompleto)"
        mode_lbl = QtWidgets.QLabel(f"Modalità: {mode}")
        mode_lbl.setStyleSheet("color: #9aa3b2;")
        mode_lbl.setWordWrap(True)
        layout.addWidget(mode_lbl)

        notes = str(self._info.get("release_notes") or "").strip()
        if notes:
            notes_box = QtWidgets.QPlainTextEdit(notes)
            notes_box.setReadOnly(True)
            notes_box.setMaximumHeight(140)
            layout.addWidget(notes_box)

        self._status = QtWidgets.QLabel("Pronto.")
        layout.addWidget(self._status)

        self._bar = QtWidgets.QProgressBar()
        self._bar.setRange(0, 0)
        self._bar.setVisible(False)
        layout.addWidget(self._bar)

        buttons = QtWidgets.QHBoxLayout()
        buttons.addStretch(1)
        self._later_btn = QtWidgets.QPushButton("Più tardi")
        self._later_btn.clicked.connect(self.reject)
        self._update_btn = QtWidgets.QPushButton(
            "Scarica aggiornamento test" if is_test else "Aggiorna ora"
        )
        self._update_btn.setDefault(True)
        self._update_btn.clicked.connect(self._start_update)
        if not strategy:
            self._update_btn.setEnabled(False)
        buttons.addWidget(self._later_btn)
        buttons.addWidget(self._update_btn)
        layout.addLayout(buttons)

    def _start_update(self) -> None:
        self._update_btn.setEnabled(False)
        self._later_btn.setEnabled(False)
        self._bar.setVisible(True)
        self._bar.setRange(0, 0)
        self._status.setText("Avvio download…")

        self._thread = QtCore.QThread(self)
        self._worker = _UpdateWorker(self._info)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self._on_progress)
        self._worker.status.connect(self._status.setText)
        self._worker.finished_ok.connect(self._on_ok)
        self._worker.failed.connect(self._on_fail)
        self._worker.finished_ok.connect(self._thread.quit)
        self._worker.failed.connect(self._thread.quit)
        self._thread.start()

    def _on_progress(self, done: int, total: object) -> None:
        if isinstance(total, int) and total > 0:
            self._bar.setRange(0, int(total))
            self._bar.setValue(min(int(done), int(total)))
            mb_done = done / (1024 * 1024)
            mb_total = total / (1024 * 1024)
            self._status.setText(f"Download… {mb_done:.1f} / {mb_total:.1f} MB")
        else:
            self._bar.setRange(0, 0)
            self._status.setText(f"Download… {done / (1024 * 1024):.1f} MB")

    def _on_ok(self, strategy: str) -> None:
        # Niente MessageBox bloccante: ritarda la chiusura e quindi il riavvio.
        self._should_quit_app = True
        if strategy == "patch":
            self._status.setText("Chiusura in corso… riavvio automatico a breve.")
        else:
            self._status.setText("Installer avviato… riavvio automatico a breve.")
        self.accept()

    def _on_fail(self, message: str) -> None:
        self._bar.setVisible(False)
        self._update_btn.setEnabled(True)
        self._later_btn.setEnabled(True)
        self._status.setText("Errore.")
        QtWidgets.QMessageBox.critical(
            self,
            "Aggiornamento non riuscito",
            message,
        )

    @property
    def should_quit_app(self) -> bool:
        return bool(self._should_quit_app)

    def closeEvent(self, event: Any) -> None:  # type: ignore[override]
        if self._thread is not None and self._thread.isRunning():
            event.ignore()
            return
        super().closeEvent(event)


def prompt_and_apply_update(
    parent: QtWidgets.QWidget | None,
    update_info: dict[str, Any],
) -> bool:
    """
    Mostra il dialog. Ritorna True se l'app deve uscire per completare l'update.
    """
    is_test = bool(update_info.get("is_test_channel"))
    title = "Aggiornamento TEST" if is_test else "Aggiornamenti"
    if not update_info.get("update_available"):
        err = str(update_info.get("error") or "").strip()
        if err and err not in {"disabled"}:
            detail = {
                "manifest_url_missing": "URL manifest non configurato.",
                "manifest_unavailable": (
                    "Manifest TEST non raggiungibile.\n"
                    "Pubblica su progeo-updates/ProgeoView/test/latest.json "
                    "oppure verifica la rete."
                    if is_test
                    else "Impossibile contattare il server aggiornamenti."
                ),
                "invalid_manifest": "Manifest aggiornamenti non valido.",
            }.get(err, f"Controllo non riuscito ({err}).")
            QtWidgets.QMessageBox.warning(parent, title, detail)
        else:
            QtWidgets.QMessageBox.information(
                parent,
                title,
                (
                    "Nessun pacchetto TEST disponibile sul canale test."
                    if is_test
                    else "Sei già alla versione più recente."
                ),
            )
        return False
    dlg = UpdateDialog(update_info, parent=parent)
    dlg.exec()
    return dlg.should_quit_app
