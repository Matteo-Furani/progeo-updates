"""Costruzione matrice dromocrone (geofono × file .fbp) per griglia e export."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from constants import natural_sort_key
from siesview_reciprocal_analysis import (
    load_fbp_full_absolute_column,
    load_fbp_full_dromocrona_column,
)

SHOT_EPS_MS = 1e-6


@dataclass(frozen=True)
class DromocronaGridData:
    """Matrice geofono × dromocrona pronta per la tabella o l'export Excel."""

    column_labels: tuple[str, ...]
    shot_channels: tuple[int, ...]
    row_channels: tuple[int, ...]
    values: tuple[tuple[float | None, ...], ...]


def dromocrona_grid_to_payload(grid: DromocronaGridData) -> dict[str, object]:
    """Serializza la griglia per il worker / callback GUI."""
    return {
        "column_labels": list(grid.column_labels),
        "shot_channels": [int(v) for v in grid.shot_channels],
        "row_channels": [int(v) for v in grid.row_channels],
        "values": [[None if v is None else float(v) for v in row] for row in grid.values],
    }


def dromocrona_grid_from_payload(payload: dict[str, object]) -> DromocronaGridData:
    """Ricostruisce la griglia da payload worker."""
    values_raw = payload.get("values") or ()
    values: list[tuple[float | None, ...]] = []
    for row in values_raw:
        values.append(
            tuple(None if v is None else float(v) for v in row)
        )
    return DromocronaGridData(
        column_labels=tuple(str(x) for x in (payload.get("column_labels") or ())),
        shot_channels=tuple(int(x) for x in (payload.get("shot_channels") or ())),
        row_channels=tuple(int(x) for x in (payload.get("row_channels") or ())),
        values=tuple(values),
    )


def series_meta_file_sort_key(meta: dict[str, object]) -> tuple[tuple[int, object], ...]:
    """Chiave di ordinamento colonne griglia: ordine naturale del nome file .fbp."""
    source = meta.get("source_path")
    if source is not None:
        try:
            return natural_sort_key(Path(str(source)).name)
        except Exception:
            pass
    label = str(meta.get("label") or "")
    return natural_sort_key(label)


def sort_series_meta_by_file_order(
    series_meta: list[dict[str, object]],
) -> list[dict[str, object]]:
    """Copia ordinata per nome file (stesso ordine della lista file in cartella)."""
    if len(series_meta) < 2:
        return list(series_meta)
    return sorted(series_meta, key=series_meta_file_sort_key)


def series_meta_shot_sort_key(
    meta: dict[str, object],
    *,
    shot_registry: dict[str, int] | None = None,
) -> tuple[int, tuple[tuple[int, object], ...]]:
    """Chiave colonne griglia: canale shot crescente (primo 0 in alto a sinistra)."""
    shot = int(meta.get("registry_shot_channel") or 0)
    if shot <= 0:
        shot = int(meta.get("shot_channel") or 0)
    if shot <= 0 and shot_registry:
        source = meta.get("source_path")
        if source is not None:
            try:
                name = Path(str(source)).name
                stem = Path(str(source)).stem
                shot = int(
                    shot_registry.get(name)
                    or shot_registry.get(name.lower())
                    or shot_registry.get(stem)
                    or shot_registry.get(stem.lower())
                    or 0
                )
            except Exception:
                shot = 0
    primary = shot if shot > 0 else 10**9
    return (primary, series_meta_file_sort_key(meta))


def sort_series_meta_by_shot_order(
    series_meta: list[dict[str, object]],
    *,
    shot_registry: dict[str, int] | None = None,
) -> list[dict[str, object]]:
    """Ordine colonne griglia/reciproci/export: per posizione shot, non nome file."""
    if len(series_meta) < 2:
        return list(series_meta)
    return sorted(
        series_meta,
        key=lambda m: series_meta_shot_sort_key(m, shot_registry=shot_registry),
    )


def reverse_dromocrona_grid_file_order(grid: DromocronaGridData) -> DromocronaGridData:
    """Inverte l'ordine delle colonne file (ultimo → primo), utile se la linea è acquisita al contrario."""
    n = len(grid.column_labels)
    if n < 2:
        return grid
    return DromocronaGridData(
        column_labels=tuple(reversed(grid.column_labels)),
        shot_channels=tuple(reversed(grid.shot_channels)),
        row_channels=grid.row_channels,
        values=tuple(tuple(reversed(row)) for row in grid.values),
    )


def sort_dromocrona_grid_by_shot_order(grid: DromocronaGridData) -> DromocronaGridData:
    """
    Ordina le colonne per canale shot crescente.

    Così nella matrice (geofono × file) il primo 0 di shot è in alto a sinistra
    e gli shot successivi scendono in diagonale, indipendentemente dal nome file.
    I file senza shot noto (canale 0) restano in coda.
    """
    n = len(grid.column_labels)
    if n < 2:
        return grid

    def _key(i: int) -> tuple[int, int]:
        ch = int(grid.shot_channels[i]) if i < len(grid.shot_channels) else 0
        primary = ch if ch > 0 else 10**9
        return (primary, i)

    order = sorted(range(n), key=_key)
    if order == list(range(n)):
        return grid
    return DromocronaGridData(
        column_labels=tuple(grid.column_labels[i] for i in order),
        shot_channels=tuple(
            int(grid.shot_channels[i]) if i < len(grid.shot_channels) else 0
            for i in order
        ),
        row_channels=grid.row_channels,
        values=tuple(tuple(row[i] for i in order) for row in grid.values),
    )


def prepare_dromocrona_grid_for_export(
    grid: DromocronaGridData,
    *,
    reverse_file_order: bool = False,
) -> DromocronaGridData:
    """Griglia pronta per Excel/GEO: ordine per shot, opzionalmente invertito."""
    ordered = sort_dromocrona_grid_by_shot_order(grid)
    if reverse_file_order:
        return reverse_dromocrona_grid_file_order(ordered)
    return ordered


def series_meta_index_to_column_map(
    series_meta: list[dict[str, object]],
    *,
    shot_registry: dict[str, int] | None = None,
) -> dict[int, int]:
    """Mappa indice in `_series_meta` del monitor → colonna griglia (ordine shot)."""
    ordered = sorted(
        enumerate(series_meta),
        key=lambda item: series_meta_shot_sort_key(
            item[1], shot_registry=shot_registry
        ),
    )
    return {int(orig_idx): int(col_idx) for col_idx, (orig_idx, _) in enumerate(ordered)}


def remap_reciprocal_pairs_to_grid_columns(
    pairs: tuple,
    series_meta: list[dict[str, object]],
    *,
    shot_registry: dict[str, int] | None = None,
) -> tuple:
    """Valida coppie reciproche per la griglia (indici = colonna ordine shot).

    ``compute_reciprocal_pairs_map`` opera su meta ordinate per shot: ``series_idx_*``
    sono indici colonna griglia (0…n−1), non indici in ``_series_meta`` del monitor.
    """
    if not pairs:
        return ()
    n_cols = len(
        sort_series_meta_by_shot_order(series_meta, shot_registry=shot_registry)
    )
    out = []
    for pair in pairs:
        col_a = int(pair.series_idx_a)
        col_b = int(pair.series_idx_b)
        if (
            col_a < 0
            or col_b < 0
            or col_a >= n_cols
            or col_b >= n_cols
            or col_a == col_b
        ):
            continue
        out.append(pair)
    return tuple(out)


def short_column_label(label: str) -> str:
    text = str(label).strip()
    if not text:
        return "—"
    try:
        return Path(text).stem
    except Exception:
        return text


def format_dromocrona_ms_display(val: float) -> str:
    if abs(val) <= SHOT_EPS_MS:
        return "0"
    text = f"{val:.3f}".rstrip("0").rstrip(".")
    if text in ("-0", "+0"):
        return "0"
    return text or "0"


def _resolve_shot_channel(
    shot_ch: int,
    channel_map: dict[int, float],
    *,
    registry_shot_channel: int = 0,
    meta_shot_channel: int = 0,
) -> int:
    if shot_ch > 0:
        return int(shot_ch)
    if registry_shot_channel > 0:
        return int(registry_shot_channel)
    if meta_shot_channel > 0:
        return int(meta_shot_channel)
    if channel_map:
        return int(min(channel_map.keys(), key=lambda ch: float(channel_map[ch])))
    return 0


def _full_channel_map(
    channel_map: dict[int, float],
    n_traces: int,
) -> tuple[dict[int, float], int]:
    """Estende la colonna a tutte le tracce 1..n; pick mancante = 0.0."""
    n = max(int(n_traces), max(channel_map.keys()) if channel_map else 0)
    if n <= 0:
        return dict(channel_map), 0
    full = {ch: 0.0 for ch in range(1, n + 1)}
    for ch, val in channel_map.items():
        if int(ch) > 0:
            full[int(ch)] = float(val)
    return full, int(n)


def _memory_column_from_meta(
    meta: dict[str, object],
) -> tuple[dict[int, float], int, int] | None:
    """Colonna relativa dai punti già in memoria nel monitor (y / trace_idx)."""
    if "y" not in meta or "trace_idx" not in meta:
        return None
    from siesview_reciprocal_analysis import is_missing_fbp_pick

    trace_idx = np.asarray(meta.get("trace_idx"), dtype=np.int64).ravel()
    dromocrona_ms = np.asarray(meta.get("y"), dtype=np.float64).ravel()
    n = min(trace_idx.size, dromocrona_ms.size)
    partial: dict[int, float] = {}
    shot_guess = int(meta.get("shot_trace_idx") or -1)
    for i in range(n):
        tr = int(trace_idx[i])
        ch = tr + 1
        t_ms = float(dromocrona_ms[i])
        if ch <= 0:
            continue
        if is_missing_fbp_pick(
            tr,
            t_ms,
            shot_trace_idx=shot_guess if shot_guess >= 0 else None,
        ):
            partial[ch] = 0.0
        else:
            partial[ch] = t_ms
    n_traces = int(meta.get("fbp_n_traces") or 0)
    if n_traces <= 0 and trace_idx.size > 0:
        n_traces = int(trace_idx.max()) + 1
    channel_map, n_traces = _full_channel_map(partial, n_traces)
    shot_from_meta = int(meta.get("shot_channel") or 0)
    if shot_from_meta <= 0 and shot_guess >= 0:
        shot_from_meta = int(shot_guess) + 1
    shot_ch = _resolve_shot_channel(
        shot_from_meta,
        channel_map,
        registry_shot_channel=int(meta.get("registry_shot_channel") or 0),
        meta_shot_channel=int(meta.get("shot_channel") or 0),
    )
    return channel_map, shot_ch, int(n_traces)


def _series_column_from_meta(
    meta: dict[str, object],
    *,
    shot_registry: dict[str, int] | None = None,
) -> tuple[dict[int, float], int, int, str]:
    """Colonna dromocrona: t_geofono − t_min; include 0.0 per pick mancanti.

    Preferisce i break in memoria (monitor) così la griglia segue le modifiche
    anche prima del salvataggio su disco. Il .fbp è solo fallback.
    """
    label = str(meta.get("label") or "—")
    memory = _memory_column_from_meta(meta)
    if memory is not None:
        channel_map, shot_ch, n_traces = memory
        return channel_map, shot_ch, int(n_traces), label

    source = meta.get("source_path")
    if source is not None:
        path = Path(source)
        if path.is_file():
            loaded = load_fbp_full_dromocrona_column(path, registry=shot_registry)
            if loaded is not None:
                channel_map, n_traces, shot = loaded
                meta_n = int(meta.get("fbp_n_traces") or 0)
                if meta_n > n_traces:
                    channel_map, n_traces = _full_channel_map(channel_map, meta_n)
                shot_ch = _resolve_shot_channel(
                    int(shot.shot_channel) if shot.is_valid else 0,
                    channel_map,
                    registry_shot_channel=int(meta.get("registry_shot_channel") or 0),
                    meta_shot_channel=int(meta.get("shot_channel") or 0),
                )
                return channel_map, shot_ch, int(n_traces), label

    return {}, 0, 0, label


def build_dromocrona_absolute_grid_data(
    series_meta: list[dict[str, object]],
    *,
    shot_registry: dict[str, int] | None = None,
) -> "DromocronaGridData":
    """Matrice con tempi assoluti (ms) come nel .fbp, senza sottrarre il tempo shot.

    Ogni cella contiene il valore esatto scritto nel file .fbp (es. 100.000000 ms).
    Lo shot è identificato e la sua cella viene comunque inclusa con il suo tempo assoluto.
    """
    if not series_meta:
        return DromocronaGridData((), (), (), ())

    series_meta = sort_series_meta_by_shot_order(
        series_meta, shot_registry=shot_registry
    )

    column_labels: list[str] = []
    shot_channels: list[int] = []
    file_maps: list[dict[int, float]] = []
    max_traces = 0

    for meta in series_meta:
        label = str(meta.get("label") or "—")
        source = meta.get("source_path")
        channel_map: dict[int, float] = {}
        shot_ch = 0
        n_traces = 0

        if source is not None:
            path = Path(source)
            if path.is_file():
                loaded = load_fbp_full_absolute_column(path, registry=shot_registry)
                if loaded is not None:
                    channel_map, n_traces, shot_det = loaded
                    meta_n = int(meta.get("fbp_n_traces") or 0)
                    if meta_n > n_traces:
                        channel_map, n_traces = _full_channel_map(channel_map, meta_n)
                    shot_ch = _resolve_shot_channel(
                        int(shot_det.shot_channel) if shot_det.is_valid else 0,
                        channel_map,
                        registry_shot_channel=int(meta.get("registry_shot_channel") or 0),
                        meta_shot_channel=int(meta.get("shot_channel") or 0),
                    )

        if not channel_map:
            trace_idx = np.asarray(meta.get("trace_idx"), dtype=np.int64).ravel()
            dromocrona_ms = np.asarray(meta.get("y"), dtype=np.float64).ravel()
            n = min(trace_idx.size, dromocrona_ms.size)
            partial: dict[int, float] = {}
            for i in range(n):
                ch = int(trace_idx[i]) + 1
                if ch <= 0:
                    continue
                partial[ch] = float(dromocrona_ms[i])
            n_traces = int(meta.get("fbp_n_traces") or 0)
            if n_traces <= 0 and trace_idx.size > 0:
                n_traces = int(trace_idx.max()) + 1
            channel_map, n_traces = _full_channel_map(partial, n_traces)
            shot_ch = _resolve_shot_channel(
                0,
                channel_map,
                registry_shot_channel=int(meta.get("registry_shot_channel") or 0),
                meta_shot_channel=int(meta.get("shot_channel") or 0),
            )

        column_labels.append(label)
        shot_channels.append(shot_ch)
        file_maps.append(channel_map)
        max_traces = max(max_traces, int(n_traces))

    if max_traces <= 0:
        return DromocronaGridData((), (), (), ())

    row_channels = tuple(range(1, max_traces + 1))
    values: list[tuple[float | None, ...]] = []
    for ch in row_channels:
        row_vals: list[float | None] = []
        for channel_map in file_maps:
            row_vals.append(float(channel_map.get(int(ch), 0.0)))
        values.append(tuple(row_vals))

    return sort_dromocrona_grid_by_shot_order(
        DromocronaGridData(
            column_labels=tuple(column_labels),
            shot_channels=tuple(shot_channels),
            row_channels=row_channels,
            values=tuple(values),
        )
    )


def build_dromocrona_grid_data(
    series_meta: list[dict[str, object]],
    *,
    shot_registry: dict[str, int] | None = None,
) -> DromocronaGridData:
    """Costruisce la matrice dromocrone dai break in memoria, con fallback .fbp.

    Colonne ordinate per canale shot crescente: il primo 0 in alto a sinistra.
    """
    if not series_meta:
        return DromocronaGridData((), (), (), ())

    series_meta = sort_series_meta_by_shot_order(
        series_meta, shot_registry=shot_registry
    )

    column_labels: list[str] = []
    shot_channels: list[int] = []
    file_maps: list[dict[int, float]] = []
    max_traces = 0

    for meta in series_meta:
        channel_map, shot_ch, n_traces, label = _series_column_from_meta(
            meta,
            shot_registry=shot_registry,
        )
        column_labels.append(label)
        shot_channels.append(shot_ch)
        file_maps.append(channel_map)
        max_traces = max(max_traces, int(n_traces))

    if max_traces <= 0:
        return DromocronaGridData((), (), (), ())

    row_channels = tuple(range(1, max_traces + 1))
    values: list[tuple[float | None, ...]] = []
    for ch in row_channels:
        row_vals: list[float | None] = []
        for channel_map in file_maps:
            row_vals.append(float(channel_map.get(int(ch), 0.0)))
        values.append(tuple(row_vals))

    return sort_dromocrona_grid_by_shot_order(
        DromocronaGridData(
            column_labels=tuple(column_labels),
            shot_channels=tuple(shot_channels),
            row_channels=row_channels,
            values=tuple(values),
        )
    )
