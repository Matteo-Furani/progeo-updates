"""Monitor FBP / dromocrona (monolite)."""

from __future__ import annotations

import logging
import math
import traceback
import numpy as np
import pyqtgraph as pg
import time
from PyQt6 import QtCore, QtGui, QtWidgets
from constants import DROMO_GEOPHONE_SPACING_M
from dromocrona_grid_data import series_meta_file_sort_key, sort_series_meta_by_file_order
from dromocrona_grid_window import DromocronaGridWindow, ReciprocalToleranceBandsDialog
from morphology import LineMorphology, _MeterIntegerAxis, _morphology_profile_elevations_m
from pathlib import Path
from perf_report import flush_report, perf_section
from plot_items import build_dromocrona_series_palette
from siesview_reciprocal_analysis import (
    DEFAULT_RECIPROCAL_TOLERANCE_BANDS,
    RECIPROCAL_AUTO_FIX_METHODS,
    ReciprocalToleranceBands,
    _fbp_line_by_trace_from_lines,
    compute_reciprocal_pairs_map,
    fbp_disk_write_template,
    failed_trace_bands_from_pairs,
    patch_reciprocal_pairs_map,
    reciprocal_auto_fix_method_label,
    reciprocal_pairs_for_fail_spot,
    reciprocal_pairs_from_map,
    reciprocal_pairs_to_map,
    remap_reciprocal_pairs_map_columns,
    run_reciprocal_estimate_missing,
    snap_reciprocal_fail_at_spot,
)

_LOG = logging.getLogger(__name__)
from typing import Callable

# Flag per-item: dromocrona selezionata dal grafico → quadrato bianco.
_SERIES_LIST_SELECTED_ROLE = int(QtCore.Qt.ItemDataRole.UserRole) + 1


class _SeriesVisibilityListDelegate(QtWidgets.QStyledItemDelegate):
    """Riga elenco: quadrato colore + nome (niente checkbox)."""

    def __init__(self, owner: "FbpVelocityMonitorWindow", parent=None) -> None:
        super().__init__(parent)
        self._owner = owner

    def paint(
        self,
        painter: QtGui.QPainter,
        option: QtWidgets.QStyleOptionViewItem,
        index: QtCore.QModelIndex,
    ) -> None:
        opt = QtWidgets.QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        # Niente area checkbox nativa.
        opt.features &= ~QtWidgets.QStyleOptionViewItem.ViewItemFeature.HasCheckIndicator
        widget = option.widget
        style = widget.style() if widget is not None else QtWidgets.QApplication.style()

        style.drawPrimitive(
            QtWidgets.QStyle.PrimitiveElement.PE_PanelItemViewItem,
            opt,
            painter,
            widget,
        )

        left = opt.rect.left() + 4
        # Icona colore
        icon = opt.icon
        if not icon.isNull():
            icon_rect = QtCore.QRect(
                left,
                opt.rect.center().y() - 6,
                12,
                12,
            )
            icon.paint(painter, icon_rect, QtCore.Qt.AlignmentFlag.AlignCenter)
            text_left = icon_rect.right() + 6
        else:
            text_left = left

        text_rect = QtCore.QRect(
            text_left,
            opt.rect.top(),
            max(0, opt.rect.right() - text_left - 4),
            opt.rect.height(),
        )
        painter.save()
        painter.setPen(opt.palette.color(QtGui.QPalette.ColorRole.Text))
        painter.drawText(
            text_rect,
            int(QtCore.Qt.AlignmentFlag.AlignVCenter | QtCore.Qt.AlignmentFlag.AlignLeft),
            opt.text,
        )
        painter.restore()


class FbpVelocityMonitorWindow(QtWidgets.QWidget):
    _DROMOCRONA_SERIES_PALETTE = build_dromocrona_series_palette()

    _STATIC_DIM_ALPHA = 58

    _PLOT_BG = "#0b1f4a"

    _CHROME_BG = "#1a2233"

    _AXIS_COLOR = "#d8dee9"

    _TEXT_COLOR = "#e8eaed"

    _MUTED_TEXT = "#9aa3b2"

    _MONITOR_LEFT_AXIS_WIDTH_PX = 82

    _SHOT_DROMOCRONA_EPS_MS = 1e-6

    _EMPTY_X_RANGE = (1.0, 24.0)

    _GEOPHONE_X_ORIGIN = 1

    _EMPTY_Y_RANGE = (0.0, 80.0)

    _STATIC_SPOT_SIZE = 6.0

    _STATIC_SPOT_SIZE_HIGHLIGHT = 7.0

    _STATIC_SPOT_SIZE_FAIL = 9.0

    _STATIC_CURVE_WIDTH = 1.8

    _STATIC_CURVE_WIDTH_HIGHLIGHT = 2.6

    _VEL_LINE_COLOR = "#f5d90a"

    _RECIPROCAL_AUTO_FIX_BLEND = 0.5

    _RECIPROCAL_AUTO_FIX_MAX_STEP_MS = 1.0

    # Fase 2 (nudge punti): più conservativa dello shift colonna.
    _RECIPROCAL_CORNER_FIX_BLEND = 0.25

    _RECIPROCAL_CORNER_FIX_MAX_STEP_MS = 0.35

    _RECIPROCAL_CORNER_FIX_MIN_DELTA_MS = 0.6

    _RECIPROCAL_AUTO_FIX_COL_ITER = 6

    _RECIPROCAL_AUTO_FIX_CORNER_ITER = 2

    _MORPHOLOGY_PLOT_FIXED_HEIGHT_PX = 260

    @staticmethod
    def _is_shot_dromocrona_point(y_ms: float) -> bool:
        return float(y_ms) <= FbpVelocityMonitorWindow._SHOT_DROMOCRONA_EPS_MS

    @staticmethod
    def _sanitize_dromocrona_series_by_trace(
            x: np.ndarray, time_ms_rel: np.ndarray
        ) -> tuple[np.ndarray, np.ndarray]:
            """Punti validi ordinati per indice traccia (0-based); y relativo mai < 0."""
            x = np.asarray(x, dtype=np.float64).ravel()
            y = np.asarray(time_ms_rel, dtype=np.float64).ravel()
            n = min(x.size, y.size)
            if n == 0:
                return np.array([], dtype=np.int64), np.array([], dtype=np.float64)
            x = x[:n]
            y = y[:n]
            trace_idx = np.rint(x).astype(np.int64)
            mask = np.isfinite(y) & (trace_idx >= 0)
            if not np.any(mask):
                return np.array([], dtype=np.int64), np.array([], dtype=np.float64)
            trace_idx = trace_idx[mask]
            # Clamp: y sottozero sono artefatti di ref sbagliato, non tempi reali.
            y = np.maximum(0.0, y[mask])
            order = np.argsort(trace_idx, kind="stable")
            return trace_idx[order], y[order]

    def __init__(
            self,
            parent=None,
            on_point_moved=None,
            on_drag_finished: Callable[[], None] | None = None,
            on_series_activated: Callable[[Path, Path | None], None] | None = None,
            get_line_morphology: Callable[[], LineMorphology | None] | None = None,
            get_folder: Callable[[], Path | None] | None = None,
            on_shot_registry_changed: Callable[[], None] | None = None,
            on_export_dromocrona_grid: Callable[[], None] | None = None,
            get_shot_registry: Callable[[], dict[str, int]] | None = None,
        ) -> None:
            super().__init__(parent, QtCore.Qt.WindowType.Window)
            self.setWindowTitle("Dromocrone")
            # Larghezza minima fissa: la toolbar resta sempre leggibile.
            self._dromo_window_min_width = 1320
            self._dromo_window_min_height = 720
            self.resize(1400, 920)
            self.setMinimumSize(
                self._dromo_window_min_width, self._dromo_window_min_height
            )
            self.setWindowModality(QtCore.Qt.WindowModality.NonModal)
            self.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, False)
            self.setStyleSheet(f"background-color: {self._CHROME_BG};")
            self._series_meta: list[dict[str, object]] = []
            # (series_idx, trace_idx geofono) — non indice nell'array spot.
            self._active_drag: tuple[int, int, int] | None = None
            self._drag_pan_prev: tuple[bool, bool] | None = None
            self._drag_pick_radius_px = 20.0
            self._drag_start_y: float | None = None
            self._drag_moved = False
            self._on_point_moved = on_point_moved
            self._on_drag_finished = on_drag_finished
            self._on_batch_points_moved: Callable[
                [dict[Path, dict[int, float]]], tuple[int, list[Path]]
            ] | None = None
            self._on_batch_write_fbp_from_memory: Callable[
                [dict[Path, dict[str, object]]],
                tuple[int, list[Path]] | tuple[int, list[Path], list[Path]],
            ] | None = None
            self._on_batch_points_saved: Callable[..., None] | None = None
            self._on_series_activated = on_series_activated
            self._get_line_morphology = get_line_morphology
            self._get_folder = get_folder
            self._on_shot_registry_changed = on_shot_registry_changed
            self._on_export_dromocrona_grid = on_export_dromocrona_grid
            self._get_shot_registry = get_shot_registry
            self._last_auto_fix_restore_points: list[tuple[Path, int, float]] = []
            self._last_auto_fix_restore_shot_refs: list[tuple[Path, float]] = []
            self._vel_line_p0: tuple[float, float] | None = None
            self._vel_line_p1: tuple[float, float] | None = None
            self._vel_line_cursor: tuple[float, float] | None = None
            self._vel_line_placing = False
            self._vel_line_item: pg.PlotDataItem | None = None
            self._vel_line_markers: pg.ScatterPlotItem | None = None
            self._vel_pan_prev: tuple[bool, bool] | None = None
            self._vel_layer_button_group: QtWidgets.QButtonGroup | None = None
            self._drag_commit_timer = QtCore.QTimer(self)
            self._drag_commit_timer.setInterval(40)
            self._drag_commit_timer.timeout.connect(self._check_drag_release)
            self._dromocrona_view_bounds: tuple[float, float, float, float] | None = None
            self._dromocrona_view_fit_busy = False
            self._hover_series_idx: int | None = None
            self._hover_candidate_idx: int | None = None
            self._locked_series_idx: int | None = None
            self._hover_last_pick_pos: QtCore.QPointF | None = None
            self._hover_pick_min_dist_px = 10.0
            # Soft hover: dwell prima dell'highlight + isteresi anti-sfarfallio.
            self._hover_dwell_ms = 300
            self._hover_hysteresis_px = 6.0
            self._hover_dwell_timer = QtCore.QTimer(self)
            self._hover_dwell_timer.setSingleShot(True)
            self._hover_dwell_timer.timeout.connect(self._commit_hover_dwell)
            self._pick_spatial_cell_px = 36.0
            self._pick_spatial_min_points = 96
            self._morph_profile_curve: pg.PlotDataItem | None = None
            self._morph_profile_fill: pg.PlotDataItem | None = None
            self._morph_profile_markers: pg.ScatterPlotItem | None = None
            self._dromocrona_grid_window: DromocronaGridWindow | None = None
            self._grid_refresh_deferred = False
            self._morphology_visible_fraction: float = 1.0
            self._morphology_true_scale: bool = False
            self._morphology_ui_key: tuple[str, int] | None = None
            self._morph_profile_y_bounds: tuple[float, float] | None = None
            self._reciprocal_pairs_cache_key: object | None = None
            self._reciprocal_pairs_cache: tuple | None = None
            self._reciprocal_pairs_map: dict[tuple[int, int], object] | None = None
            # Mappe FAIL già calcolate sul worker (indici meta serie).
            self._reciprocal_fail_maps_meta_cache: (
                tuple[
                    dict[int, set[int]],
                    dict[int, dict[int, float]],
                    dict[int, dict[int, float]],
                ]
                | None
            ) = None
            self._reciprocal_tolerance_bands = DEFAULT_RECIPROCAL_TOLERANCE_BANDS
            self._reciprocal_cached_struct_key: object | None = None
            self._reciprocal_pairs_cache_prefer_memory = False
            self._reciprocal_pairs_compute_error: str | None = None
            self._gui_worker: object | None = None
            self._reciprocal_worker_pending = False
            self._reciprocal_reschedule_pending = False
            self._reciprocal_reschedule_prefer_memory = False
            self._series_y_revision = 0
            # meta_idx → tracce modificate (-1 = tutta la serie)
            self._reciprocal_patch_pending: dict[int, set[int]] = {}
            self._reciprocal_patch_worker_pending = False
            self._reciprocal_patch_reschedule_payload: dict[str, object] | None = None
            self._grid_build_worker_pending = False
            self._grid_build_revision = 0
            self._grid_build_pending_pairs: tuple | None = None
            self._snap_reciprocal_worker_pending = False
            self._fbp_export_worker_pending = False
            self._fbp_export_pending_ctx: dict[str, object] | None = None
            self._fbp_export_queue: list[dict[str, object]] = []
            self._auto_fix_worker_pending = False
            self._auto_fix_progress: QtWidgets.QProgressDialog | None = None
            self._reciprocal_pending_key: object | None = None
            self._reciprocal_snap_armed = False
            self._on_reciprocal_fail_changed: Callable[[], None] | None = None
            self._series_batch_depth = 0
            self._batch_perf_t0: float | None = None
            self._window_title_base = "Dromocrone"

            root = QtWidgets.QVBoxLayout(self)
            root.setContentsMargins(8, 8, 8, 8)
            root.setSpacing(6)

            # Toolbar in alto: controlli sempre visibili e raggruppati.
            self._monitor_toolbar = self._build_monitor_toolbar()
            root.addWidget(self._monitor_toolbar)

            self._graphics = pg.GraphicsLayoutWidget()
            self._graphics.setBackground(self._CHROME_BG)
            self._series_visibility_panel = self._build_series_visibility_panel()
            self._plot_splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
            self._plot_splitter.setChildrenCollapsible(False)
            self._plot_splitter.addWidget(self._series_visibility_panel)
            self._plot_splitter.addWidget(self._graphics)
            self._plot_splitter.setStretchFactor(0, 0)
            self._plot_splitter.setStretchFactor(1, 1)
            self._plot_splitter.setSizes([220, 1100])
            root.addWidget(self._plot_splitter, stretch=1)

            self._velocity_analysis_panel = self._build_velocity_analysis_panel()
            root.addWidget(self._velocity_analysis_panel)

            self._morphology_range_bar = self._build_morphology_range_bar()
            root.addWidget(self._morphology_range_bar)

            axis_pen = pg.mkPen(self._AXIS_COLOR)
            self._dromocrona_bottom_axis = _MeterIntegerAxis(orientation="bottom")
            self._dromocrona_bottom_axis.setPen(axis_pen)
            self._dromocrona_bottom_axis.setTextPen(axis_pen)
            self.dromocrona_plot = self._graphics.addPlot(
                row=0,
                col=0,
                axisItems={"bottom": self._dromocrona_bottom_axis},
            )
            self.dromocrona_plot.setMenuEnabled(False)
            self.dromocrona_plot.showGrid(x=True, y=True, alpha=0.22)
            self.dromocrona_plot.setLabel(
                "left", "Tempo relativo (ms vs shot)", color=self._AXIS_COLOR
            )
            self.dromocrona_plot.setLabel(
                "bottom", "Geofono / distanza", color=self._AXIS_COLOR
            )
            self.dromocrona_plot.setMouseEnabled(x=True, y=True)
            vb = self.dromocrona_plot.getViewBox()
            # X (tracce) e Y (ms) hanno scale diverse: niente aspect lock (evita bande vuote).
            vb.setAspectLocked(False)
            vb.setBackgroundColor(self._PLOT_BG)
            vb.setMenuEnabled(False)
            self.dromocrona_plot.enableAutoRange(x=False, y=False)
            vb.sigRangeChanged.connect(self._on_dromocrona_view_range_changed)
            for axis_name in ("left", "bottom"):
                ax = self.dromocrona_plot.getAxis(axis_name)
                ax.setPen(axis_pen)
                ax.setTextPen(axis_pen)
            shot_pen = pg.mkPen("#ff9f43", width=1.2, style=QtCore.Qt.PenStyle.DashLine)
            self._zero_line_y = pg.InfiniteLine(pos=0.0, angle=0, pen=shot_pen, movable=False)
            self._zero_line_x = pg.InfiniteLine(pos=0.0, angle=90, pen=shot_pen, movable=False)
            for zero_line in (self._zero_line_y, self._zero_line_x):
                zero_line.setAcceptHoverEvents(False)
                zero_line.setAcceptedMouseButtons(QtCore.Qt.MouseButton.NoButton)
            self.dromocrona_plot.addItem(self._zero_line_y)
            self.dromocrona_plot.addItem(self._zero_line_x)

            self._morph_bottom_axis = _MeterIntegerAxis(orientation="bottom")
            self._morph_left_axis = _MeterIntegerAxis(orientation="left")
            for axis_item in (self._morph_bottom_axis, self._morph_left_axis):
                axis_item.setPen(axis_pen)
                axis_item.setTextPen(axis_pen)
            self.morph_plot = self._graphics.addPlot(
                row=1,
                col=0,
                axisItems={
                    "bottom": self._morph_bottom_axis,
                    "left": self._morph_left_axis,
                },
            )
            self.morph_plot.setMenuEnabled(False)
            self.morph_plot.showGrid(x=True, y=True, alpha=0.18)
            self.morph_plot.setLabel("left", "Quota Z (m)", color=self._AXIS_COLOR)
            self.morph_plot.setLabel(
                "bottom", "Distanza lungo linea (m)", color=self._AXIS_COLOR
            )
            self.morph_plot.setMouseEnabled(x=False, y=False)
            morph_vb = self.morph_plot.getViewBox()
            morph_vb.setAspectLocked(False)
            morph_vb.setBackgroundColor(self._PLOT_BG)
            # Zoom/pan solo sulla dromocrona (XLink aggiorna l'asse X del profilo).
            morph_vb.setMouseEnabled(x=False, y=False)
            self.morph_plot.enableAutoRange(x=False, y=False)
            self.morph_plot.setXLink(self.dromocrona_plot)
            self._set_morphology_plot_row_visible(False)

            self._geometry_debounce_timer = QtCore.QTimer(self)
            self._geometry_debounce_timer.setSingleShot(True)
            self._geometry_debounce_timer.setInterval(60)
            self._geometry_debounce_timer.timeout.connect(self._on_monitor_geometry_changed)
            self._dromocrona_grid_refresh_timer = QtCore.QTimer(self)
            self._dromocrona_grid_refresh_timer.setSingleShot(True)
            self._dromocrona_grid_refresh_timer.setInterval(320)
            self._dromocrona_grid_refresh_timer.timeout.connect(
                self._on_dromocrona_data_refresh_timer
            )

            scene = self._graphics.scene()
            self._mouse_move_proxy = pg.SignalProxy(
                scene.sigMouseMoved, rateLimit=60, slot=self._on_scene_mouse_moved
            )
            scene.sigMouseClicked.connect(self._on_scene_mouse_clicked)
            self._fit_view_positive_quadrant()
            self._rebuild_series_visibility_list()
            self._install_velocity_toggle_shortcut()

    def _morphology_row_should_show(self) -> bool:
        morph = self._current_line_morphology()
        return morph is not None and morph.trace_count > 0

    def _set_morphology_plot_row_visible(self, visible: bool) -> None:
        """Mostra/nasconde il profilo morfologia (altezza fissa: non affidarsi allo stretch)."""
        layout = self._graphics.ci.layout
        morph_h = int(self._MORPHOLOGY_PLOT_FIXED_HEIGHT_PX)
        if visible:
            self.morph_plot.setXLink(self.dromocrona_plot)
            self.morph_plot.show()
            layout.setRowStretchFactor(0, 1)
            layout.setRowStretchFactor(1, 0)
            layout.setRowFixedHeight(1, morph_h)
        else:
            self.morph_plot.setXLink(None)
            self.morph_plot.hide()
            layout.setRowStretchFactor(0, 1)
            layout.setRowStretchFactor(1, 0)
            layout.setRowFixedHeight(1, 0)
        layout.invalidate()
        layout.activate()
        self._graphics.updateGeometry()
        self._graphics.ci.update()

    def _ensure_morphology_plot_visible(self) -> None:
        if not self._morphology_row_should_show():
            self._set_morphology_plot_row_visible(False)
            self._sync_monitor_plot_alignment()
            return
        if self._morph_profile_curve is None:
            self._refresh_morphology_profile()
        self._set_morphology_plot_row_visible(True)
        morph = self._current_line_morphology()
        if morph is None:
            self._sync_monitor_plot_alignment()
            return
        # Non resettare lo zoom dromocrona: aggiorna solo limiti/range morfologia
        # allineati alla vista corrente (XLink).
        try:
            x_range, _y_range = self._dromocrona_view_vb().viewRange()
            cur_x0 = float(min(x_range))
            cur_x1 = float(max(x_range))
        except Exception:
            cur_x0, cur_x1 = self._effective_morphology_x_bounds(morph)
        self._sync_morph_view_x_range(cur_x0, cur_x1, apply_x_range=False)
        self._sync_monitor_plot_alignment()
        self._graphics.updateGeometry()

    def _finalize_morphology_plot_refresh(self, *, fit_view: bool = False) -> None:
        """Dopo layout/ridimensionamento: rimappa X e ridisegna le curve."""
        if not self._morphology_row_should_show():
            self._set_morphology_plot_row_visible(False)
            self._sync_monitor_plot_alignment()
            return
        if self._morph_profile_curve is None:
            self._refresh_morphology_profile()
        self._ensure_morphology_plot_visible()
        morph = self._current_line_morphology()
        if morph is None or morph.trace_count <= 0:
            return
        if fit_view:
            self._update_dromocrona_view_limits_from_data(fit_view=True)
        self._remap_all_series_display_x(fit_view=False)
        if fit_view:
            self._update_dromocrona_view_limits_from_data(fit_view=True)
        self.dromocrona_plot.update()

    def _build_series_visibility_panel(self) -> QtWidgets.QWidget:
        panel = QtWidgets.QFrame()
        panel.setObjectName("seriesVisibilityPanel")
        panel.setMinimumWidth(170)
        panel.setMaximumWidth(320)
        panel.setStyleSheet(
            "QFrame#seriesVisibilityPanel {"
            "  background: #252d3d;"
            "  border: 1px solid #3d4657;"
            "  border-radius: 6px;"
            "}"
            f"QLabel {{ color: {self._TEXT_COLOR}; }}"
            f"QListWidget {{"
            f"  background: {self._CHROME_BG};"
            f"  color: {self._TEXT_COLOR};"
            "  border: 1px solid #3d4657;"
            "  border-radius: 4px;"
            "  outline: none;"
            "}"
            "QListWidget::item { padding: 3px 4px; }"
            "QListWidget::item:selected { background: transparent; }"
            "QListWidget::item:hover { background: #2a3346; }"
            f"QPushButton {{"
            f"  color: {self._TEXT_COLOR};"
            "  background: #1a2233;"
            "  border: 1px solid #3d4657;"
            "  border-radius: 4px;"
            "  padding: 5px 8px;"
            "  font-size: 11px;"
            "  text-align: center;"
            "}"
            "QPushButton:hover { background: #2f3b52; }"
        )
        lay = QtWidgets.QVBoxLayout(panel)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)

        title = QtWidgets.QLabel("Elenco curve")
        title.setStyleSheet(
            f"color: {self._TEXT_COLOR}; font-size: 12px; font-weight: 600;"
        )
        title.setToolTip(self._series_list_help_text())
        lay.addWidget(title)

        self._series_vis_list = QtWidgets.QListWidget()
        self._series_vis_list.setSelectionMode(
            QtWidgets.QAbstractItemView.SelectionMode.NoSelection
        )
        self._series_vis_list.setUniformItemSizes(True)
        self._series_vis_list.setIconSize(QtCore.QSize(12, 12))
        self._series_vis_list.setItemDelegate(
            _SeriesVisibilityListDelegate(self, self._series_vis_list)
        )
        # Solo on/off dall'elenco: la selezione si fa solo sul grafico.
        self._series_vis_list.viewport().installEventFilter(self)
        lay.addWidget(self._series_vis_list, stretch=1)

        self._series_vis_empty = QtWidgets.QLabel("Nessuna dromocrona caricata.")
        self._series_vis_empty.setWordWrap(True)
        self._series_vis_empty.setStyleSheet(
            f"color: {self._MUTED_TEXT}; font-size: 11px;"
        )
        lay.addWidget(self._series_vis_empty)

        # Empilati: con pannello stretto restano leggibili.
        btn_col = QtWidgets.QVBoxLayout()
        btn_col.setSpacing(4)
        show_all_btn = QtWidgets.QPushButton("Mostra tutte")
        show_all_btn.setToolTip("Riaccende tutte le curve sul grafico.")
        show_all_btn.clicked.connect(self._show_all_series_on_plot)
        hide_all_btn = QtWidgets.QPushButton("Nascondi tutte")
        hide_all_btn.setToolTip(
            "Nasconde tutte le curve sul grafico (i dati restano caricati)."
        )
        hide_all_btn.clicked.connect(self._hide_all_series_on_plot)
        only_btn = QtWidgets.QPushButton("Solo selezionata")
        only_btn.setToolTip(
            "Nasconde le altre: lascia solo la dromocrona selezionata "
            "(Shift+clic) o, in alternativa, quella sotto il mouse."
        )
        only_btn.clicked.connect(self._show_only_focused_series_on_plot)
        for btn in (show_all_btn, hide_all_btn, only_btn):
            btn.setSizePolicy(
                QtWidgets.QSizePolicy.Policy.Expanding,
                QtWidgets.QSizePolicy.Policy.Fixed,
            )
            btn.setMinimumHeight(26)
            btn_col.addWidget(btn)
        lay.addLayout(btn_col)
        return panel

    @staticmethod
    def _series_list_help_text() -> str:
        return (
            "Clic: accende/spegne la curva sul grafico.\n"
            "Bordo bianco sul colore = selezionata "
            "(Shift+clic sul grafico)."
        )

    def _series_is_plot_visible(self, series_idx: int) -> bool:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return False
        return bool(self._series_meta[series_idx].get("plot_visible", True))

    def _series_color_icon(
        self, color: str, *, selected: bool = False
    ) -> QtGui.QIcon:
        """Quadrato colore; bordo bianco pieno se selezionata nel grafico."""
        pix = QtGui.QPixmap(12, 12)
        pix.fill(QtCore.Qt.GlobalColor.transparent)
        painter = QtGui.QPainter(pix)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        painter.setBrush(QtGui.QColor(str(color)))
        if selected:
            painter.setPen(QtGui.QPen(QtGui.QColor("#ffffff"), 2.0))
        else:
            painter.setPen(QtGui.QPen(QtGui.QColor("#e8eaed"), 1.0))
        painter.drawRoundedRect(1, 1, 10, 10, 2, 2)
        painter.end()
        return QtGui.QIcon(pix)

    def _apply_series_visibility_item_style(
        self, item: QtWidgets.QListWidgetItem, series_idx: int
    ) -> None:
        if item is None or series_idx < 0 or series_idx >= len(self._series_meta):
            return
        meta = self._series_meta[series_idx]
        selected = self._locked_series_idx == series_idx
        visible = bool(meta.get("plot_visible", True))
        item.setIcon(
            self._series_color_icon(
                str(meta.get("color", "#e8eaed")), selected=selected
            )
        )
        item.setData(_SERIES_LIST_SELECTED_ROLE, bool(selected))
        item.setBackground(QtGui.QBrush())
        if visible:
            item.setForeground(QtGui.QBrush(QtGui.QColor(self._TEXT_COLOR)))
        else:
            item.setForeground(QtGui.QBrush(QtGui.QColor(self._MUTED_TEXT)))

    def _refresh_series_visibility_selection_styles(self) -> None:
        lst = getattr(self, "_series_vis_list", None)
        if lst is None:
            return
        lst.blockSignals(True)
        try:
            for row in range(lst.count()):
                item = lst.item(row)
                if item is None:
                    continue
                raw = item.data(QtCore.Qt.ItemDataRole.UserRole)
                try:
                    series_idx = int(raw)
                except (TypeError, ValueError):
                    continue
                self._apply_series_visibility_item_style(item, series_idx)
        finally:
            lst.blockSignals(False)
            lst.viewport().update()

    def _rebuild_series_visibility_list(self) -> None:
        lst = getattr(self, "_series_vis_list", None)
        empty = getattr(self, "_series_vis_empty", None)
        if lst is None:
            return
        lst.blockSignals(True)
        lst.clear()
        for idx, meta in enumerate(self._series_meta):
            name = self._series_display_name(idx) or str(meta.get("label") or f"Serie {idx + 1}")
            item = QtWidgets.QListWidgetItem(name)
            item.setFlags(
                (item.flags() | QtCore.Qt.ItemFlag.ItemIsEnabled)
                & ~QtCore.Qt.ItemFlag.ItemIsUserCheckable
            )
            item.setData(QtCore.Qt.ItemDataRole.UserRole, int(idx))
            self._apply_series_visibility_item_style(item, idx)
            item.setToolTip(f"{name}\n\n{self._series_list_help_text()}")
            lst.addItem(item)
        lst.blockSignals(False)
        has_series = bool(self._series_meta)
        lst.setVisible(has_series)
        if empty is not None:
            empty.setVisible(not has_series)

    def eventFilter(self, watched: QtCore.QObject, event: QtCore.QEvent) -> bool:
        """Clic sull'elenco curve: solo accendi/spegni (mai seleziona)."""
        lst = getattr(self, "_series_vis_list", None)
        if (
            lst is not None
            and watched is lst.viewport()
            and event.type() == QtCore.QEvent.Type.MouseButtonRelease
            and isinstance(event, QtGui.QMouseEvent)
            and event.button() == QtCore.Qt.MouseButton.LeftButton
        ):
            item = lst.itemAt(event.position().toPoint())
            if item is not None:
                self._toggle_series_visibility_from_list(item)
                return True
        return super().eventFilter(watched, event)

    def _toggle_series_visibility_from_list(
        self, item: QtWidgets.QListWidgetItem
    ) -> None:
        if item is None:
            return
        raw = item.data(QtCore.Qt.ItemDataRole.UserRole)
        try:
            series_idx = int(raw)
        except (TypeError, ValueError):
            return
        visible = not self._series_is_plot_visible(series_idx)
        # unlock_if_hidden=False: spegnere dall'elenco non tocca la selezione grafico
        # (evita flash/sblocchi); se spegni quella selezionata, resta selezionata
        # ma nascosta finché non la riaccendi o la deselezioni dal grafico.
        self._set_series_plot_visible(
            series_idx, visible, sync_list=True, unlock_if_hidden=False
        )

    def _set_series_plot_visible(
        self,
        series_idx: int,
        visible: bool,
        *,
        sync_list: bool = True,
        unlock_if_hidden: bool = True,
    ) -> None:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return
        meta = self._series_meta[series_idx]
        visible = bool(visible)
        if bool(meta.get("plot_visible", True)) == visible:
            if sync_list:
                self._sync_series_visibility_list_item(series_idx)
            return
        meta["plot_visible"] = visible
        if (
            unlock_if_hidden
            and not visible
            and self._locked_series_idx == series_idx
        ):
            self._unlock_series()
        elif (
            unlock_if_hidden
            and not visible
            and (
                self._hover_series_idx == series_idx
                or getattr(self, "_hover_candidate_idx", None) == series_idx
            )
        ):
            self._clear_hover_dwell_state()
            self._set_hover_series(None)
        else:
            self._apply_series_highlight_style(series_idx)
        if sync_list:
            self._sync_series_visibility_list_item(series_idx)

    def _sync_series_visibility_list_item(self, series_idx: int) -> None:
        lst = getattr(self, "_series_vis_list", None)
        if lst is None or series_idx < 0 or series_idx >= lst.count():
            return
        item = lst.item(series_idx)
        if item is None:
            return
        lst.blockSignals(True)
        self._apply_series_visibility_item_style(item, series_idx)
        lst.blockSignals(False)
        lst.viewport().update()

    def _show_all_series_on_plot(self) -> None:
        changed = False
        for idx, meta in enumerate(self._series_meta):
            if not bool(meta.get("plot_visible", True)):
                meta["plot_visible"] = True
                changed = True
        if not changed:
            return
        self._refresh_all_series_styles()
        self._rebuild_series_visibility_list()

    def _hide_all_series_on_plot(self) -> None:
        if not self._series_meta:
            return
        changed = False
        for idx, meta in enumerate(self._series_meta):
            if bool(meta.get("plot_visible", True)):
                meta["plot_visible"] = False
                changed = True
        if not changed:
            return
        if self._locked_series_idx is not None:
            self._unlock_series()
        if self._hover_series_idx is not None or getattr(
            self, "_hover_candidate_idx", None
        ) is not None:
            self._clear_hover_dwell_state()
            self._hover_series_idx = None
        self._refresh_all_series_styles()
        self._rebuild_series_visibility_list()

    def _show_only_focused_series_on_plot(self) -> None:
        keep = self._locked_series_idx
        if keep is None:
            keep = self._hover_series_idx
        if keep is None:
            keep = getattr(self, "_hover_candidate_idx", None)
        if keep is None or keep < 0 or keep >= len(self._series_meta):
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Seleziona prima una dromocrona (Shift+clic o doppio clic in lista)",
                self,
                QtCore.QRect(),
                2500,
            )
            return
        for idx, meta in enumerate(self._series_meta):
            meta["plot_visible"] = idx == int(keep)
        self._clear_hover_dwell_state()
        if self._hover_series_idx is not None and self._hover_series_idx != keep:
            self._hover_series_idx = None
        self._refresh_all_series_styles()
        self._rebuild_series_visibility_list()

    def _build_morphology_range_bar(self) -> QtWidgets.QWidget:
        bar = QtWidgets.QFrame()
        bar.setFrameShape(QtWidgets.QFrame.Shape.StyledPanel)
        bar.setStyleSheet(
            "QFrame { background: #252d3d; border: 1px solid #3d4657; "
            "border-radius: 6px; }"
        )
        row = QtWidgets.QHBoxLayout(bar)
        row.setContentsMargins(10, 6, 10, 6)
        row.setSpacing(8)

        title = QtWidgets.QLabel("Tratto morfologia visibile")
        title.setStyleSheet(
            f"color: {self._TEXT_COLOR}; font-size: 12px; font-weight: 600;"
        )
        title.setToolTip(
            "Riduce la distanza lungo linea mostrata nei grafici dromocrona e morfologia."
        )
        row.addWidget(title)

        self._morph_range_slider = QtWidgets.QSlider(
            QtCore.Qt.Orientation.Horizontal
        )
        self._morph_range_slider.setRange(5, 100)
        self._morph_range_slider.setValue(100)
        self._morph_range_slider.setToolTip(
            "Percentuale della lunghezza totale della linea da mostrare (da inizio linea)."
        )
        self._morph_range_slider.valueChanged.connect(
            self._on_morphology_visible_slider_changed
        )
        row.addWidget(self._morph_range_slider, stretch=1)

        self._morph_range_value_label = QtWidgets.QLabel("—")
        self._morph_range_value_label.setStyleSheet(
            f"color: {self._TEXT_COLOR}; font-size: 12px; min-width: 140px;"
        )
        self._morph_range_value_label.setAlignment(
            QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter
        )
        row.addWidget(self._morph_range_value_label)

        reset_btn = QtWidgets.QPushButton("Intera linea")
        reset_btn.setStyleSheet(
            f"color: {self._TEXT_COLOR}; background: #1a2233; "
            "border: 1px solid #3d4657; padding: 3px 10px; border-radius: 4px;"
        )
        reset_btn.setToolTip("Ripristina la morfologia completa lungo l'asse X.")
        reset_btn.clicked.connect(self._reset_morphology_visible_range)
        row.addWidget(reset_btn)

        self._morph_true_scale_chk = QtWidgets.QCheckBox("Scala 1:1")
        self._morph_true_scale_chk.setStyleSheet(
            f"color: {self._TEXT_COLOR}; font-size: 12px;"
        )
        self._morph_true_scale_chk.setToolTip(
            "Blocca il rapporto metri X/Y (pendenza geometrica reale). "
            "Disattivato: la quota riempie il pannello (più leggibile, angolo esagerato)."
        )
        self._morph_true_scale_chk.toggled.connect(self._on_morphology_true_scale_toggled)
        row.addWidget(self._morph_true_scale_chk)

        self._morph_slope_label = QtWidgets.QLabel("—")
        self._morph_slope_label.setStyleSheet(
            f"color: {self._MUTED_TEXT}; font-size: 11px; min-width: 220px;"
        )
        self._morph_slope_label.setToolTip(
            "Pendenza reale del profilo (da quota e distanza lungo linea), "
            "indipendente dallo zoom verticale del pannello."
        )
        row.addWidget(self._morph_slope_label)

        bar.hide()
        return bar

    def _morphology_line_length_m(self, morph: LineMorphology) -> float:
        if morph.trace_count <= 0:
            return 0.0
        return max(0.0, float(morph.geophones[-1].cumulative_m))

    def _morphology_visible_end_m(self, morph: LineMorphology) -> float:
        line_len = self._morphology_line_length_m(morph)
        if line_len <= 0.0:
            return 0.0
        frac = float(getattr(self, "_morphology_visible_fraction", 1.0))
        frac = min(1.0, max(0.05, frac))
        if frac >= 0.999:
            return line_len
        return max(line_len * 0.05, line_len * frac)

    def _effective_morphology_x_bounds(
            self, morph: LineMorphology
        ) -> tuple[float, float]:
            visible_end = self._morphology_visible_end_m(morph)
            x_pad = max(5.0, visible_end * 0.03)
            return 0.0, visible_end + x_pad

    def _update_morphology_range_bar_ui(self) -> None:
        bar = getattr(self, "_morphology_range_bar", None)
        slider = getattr(self, "_morph_range_slider", None)
        value_lbl = getattr(self, "_morph_range_value_label", None)
        morph = self._current_line_morphology()
        if bar is None or slider is None or value_lbl is None:
            return
        if morph is None or morph.trace_count <= 0:
            bar.hide()
            return
        bar.show()
        line_len = self._morphology_line_length_m(morph)
        visible_end = self._morphology_visible_end_m(morph)
        if line_len > 0.0:
            pct = int(round(100.0 * visible_end / line_len))
            slider.blockSignals(True)
            slider.setValue(max(5, min(100, pct)))
            slider.blockSignals(False)
        if visible_end >= line_len - 0.5:
            value_lbl.setText(f"0 – {int(round(line_len))} m (intera linea)")
        else:
            value_lbl.setText(
                f"0 – {int(round(visible_end))} m / {int(round(line_len))} m"
            )

    def _set_morphology_visible_fraction(
            self, fraction: float, *, fit_view: bool = True
        ) -> None:
            self._morphology_visible_fraction = min(1.0, max(0.05, float(fraction)))
            self._update_morphology_range_bar_ui()
            morph = self._current_line_morphology()
            if morph is None or morph.trace_count <= 0:
                return
            self._update_dromocrona_view_limits_from_data(fit_view=fit_view)
            self._refresh_morphology_profile()
            QtCore.QTimer.singleShot(0, self._ensure_morphology_plot_visible)

    def _on_morphology_visible_slider_changed(self, value: int) -> None:
        self._set_morphology_visible_fraction(float(value) / 100.0, fit_view=True)

    def _reset_morphology_visible_range(self) -> None:
        slider = getattr(self, "_morph_range_slider", None)
        if slider is not None:
            slider.blockSignals(True)
            slider.setValue(100)
            slider.blockSignals(False)
        self._set_morphology_visible_fraction(1.0, fit_view=True)

    def _clear_morphology_profile_graphics(self) -> None:
        if self._morph_profile_curve is not None:
            self.morph_plot.removeItem(self._morph_profile_curve)
            self._morph_profile_curve = None
        if getattr(self, "_morph_profile_fill", None) is not None:
            self.morph_plot.removeItem(self._morph_profile_fill)
            self._morph_profile_fill = None
        if self._morph_profile_markers is not None:
            self.morph_plot.removeItem(self._morph_profile_markers)
            self._morph_profile_markers = None

    @staticmethod
    def _morphology_slope_stats(
        dist_m: np.ndarray, elev_m: np.ndarray
    ) -> tuple[float, float, float, float]:
        """Restituisce (Δz_m, pendenza_media_%, pendenza_max_abs_%, angolo_medio_deg)."""
        dist = np.asarray(dist_m, dtype=np.float64).ravel()
        elev = np.asarray(elev_m, dtype=np.float64).ravel()
        n = min(dist.size, elev.size)
        if n < 2:
            return 0.0, 0.0, 0.0, 0.0
        dist = dist[:n]
        elev = elev[:n]
        dz_total = float(elev[-1] - elev[0])
        dx_total = float(dist[-1] - dist[0])
        mean_pct = (100.0 * dz_total / dx_total) if abs(dx_total) > 1e-9 else 0.0
        mean_deg = float(np.degrees(np.arctan2(dz_total, dx_total))) if abs(dx_total) > 1e-9 else 0.0
        ddx = np.diff(dist)
        ddz = np.diff(elev)
        ok = np.abs(ddx) > 1e-9
        if not np.any(ok):
            return float(elev.max() - elev.min()), mean_pct, 0.0, mean_deg
        seg_pct = 100.0 * ddz[ok] / ddx[ok]
        max_pct = float(np.max(np.abs(seg_pct)))
        return float(elev.max() - elev.min()), mean_pct, max_pct, mean_deg

    def _on_morphology_true_scale_toggled(self, checked: bool) -> None:
        self._morphology_true_scale = bool(checked)
        if self._morphology_row_should_show():
            self._refresh_morphology_profile()
            QtCore.QTimer.singleShot(0, self._ensure_morphology_plot_visible)

    def _update_morphology_slope_label(
        self, dist: np.ndarray, elev: np.ndarray
    ) -> None:
        lbl = getattr(self, "_morph_slope_label", None)
        if lbl is None:
            return
        dz, mean_pct, max_pct, mean_deg = self._morphology_slope_stats(dist, elev)
        scale_note = " · scala 1:1" if getattr(self, "_morphology_true_scale", False) else ""
        lbl.setText(
            f"Δz {dz:.2f} m · media {mean_pct:+.1f}% ({mean_deg:+.1f}°) · "
            f"|max| {max_pct:.1f}%{scale_note}"
        )

    def _refresh_morphology_profile(self) -> None:
        morph = self._current_line_morphology()
        self._clear_morphology_profile_graphics()
        if morph is None or morph.trace_count <= 0:
            self._morph_profile_y_bounds = None
            slope_lbl = getattr(self, "_morph_slope_label", None)
            if slope_lbl is not None:
                slope_lbl.setText("—")
            self._set_morphology_plot_row_visible(False)
            self._sync_monitor_plot_alignment()
            return

        self._set_morphology_plot_row_visible(True)
        dist = np.array(
            [float(g.cumulative_m) for g in morph.geophones], dtype=np.float64
        )
        elev = _morphology_profile_elevations_m(morph)
        visible_end = self._morphology_visible_end_m(morph)
        mask = dist <= visible_end + 1e-6
        if np.count_nonzero(mask) < 2:
            mask = np.ones(dist.shape, dtype=bool)
        dist = dist[mask]
        elev = elev[mask]
        self._update_morphology_slope_label(dist, elev)

        y_min = float(np.min(elev))
        y_max = float(np.max(elev))
        # Fill sotto il profilo: rende evidente il rilievo.
        fill_base = y_min - max(0.25, (y_max - y_min) * 0.05)
        fill_brush = pg.mkBrush(QtGui.QColor(80, 200, 140, 55))
        self._morph_profile_fill = self.morph_plot.plot(
            dist,
            elev,
            pen=pg.mkPen(None),
            fillLevel=float(fill_base),
            brush=fill_brush,
            connect="all",
        )
        self._morph_profile_fill.setZValue(1)
        pen = pg.mkPen("#9aefb8", width=3.0)
        self._morph_profile_curve = self.morph_plot.plot(
            dist, elev, pen=pen, connect="all"
        )
        self._morph_profile_curve.setZValue(3)
        spots = [
            {
                "pos": (float(dist[i]), float(elev[i])),
                "size": 7,
                "brush": pg.mkBrush("#5eead4"),
                "pen": pg.mkPen("#0b1f4a", width=1.0),
            }
            for i in range(dist.size)
        ]
        self._morph_profile_markers = pg.ScatterPlotItem(hoverable=False)
        self._morph_profile_markers.setData(spots=spots)
        self._morph_profile_markers.setZValue(5)
        self.morph_plot.addItem(self._morph_profile_markers)

        true_scale = bool(getattr(self, "_morphology_true_scale", False))
        morph_vb = self.morph_plot.getViewBox()
        morph_vb.setAspectLocked(bool(true_scale), ratio=1.0 if true_scale else None)

        if true_scale:
            # Y centrata sul profilo: l'aspect lock impone la pendenza geometrica.
            y_mid = 0.5 * (y_min + y_max)
            x_lo, x_hi = self._effective_morphology_x_bounds(morph)
            x_span = max(1.0, float(x_hi - x_lo))
            # Margine minimo così un profilo quasi piano resta riconoscibile.
            half = max(2.0, 0.5 * (y_max - y_min) + 1.0, 0.02 * x_span)
            y_lo = y_mid - half
            y_hi = y_mid + half
            self.morph_plot.setLabel(
                "left", "Quota Z (m) — scala 1:1", color=self._AXIS_COLOR
            )
        else:
            y_pad = max(0.35, (y_max - y_min) * 0.08)
            y_lo = min(y_min, fill_base) - y_pad * 0.25
            y_hi = y_max + y_pad
            self.morph_plot.setLabel("left", "Quota Z (m)", color=self._AXIS_COLOR)

        self._morph_profile_y_bounds = (y_lo, y_hi)
        self.morph_plot.setYRange(y_lo, y_hi, padding=0.0)
        morph = self._current_line_morphology()
        if morph is not None:
            x_lo, x_hi = self._effective_morphology_x_bounds(morph)
            self._sync_morph_view_x_range(x_lo, x_hi)
        self._sync_monitor_plot_alignment()

    def _current_line_morphology(self) -> LineMorphology | None:
        getter = getattr(self, "_get_line_morphology", None)
        if getter is None:
            return None
        try:
            morph = getter()
        except Exception:
            return None
        if morph is None or morph.trace_count <= 0:
            return None
        return morph

    def _morphology_ui_identity(
            self, morph: LineMorphology | None
        ) -> tuple[str, int] | None:
            if morph is None or morph.trace_count <= 0:
                return None
            try:
                source = str(morph.source_path.resolve())
            except Exception:
                source = str(morph.source_path)
            return source, int(morph.trace_count)

    def refresh_line_morphology_ui(self, *, fit_view: bool = False) -> None:
        morph = self._current_line_morphology()
        morph_key = self._morphology_ui_identity(morph)
        morph_changed = morph_key != getattr(self, "_morphology_ui_key", None)
        if morph_changed:
            self._morphology_ui_key = morph_key
            self._morphology_visible_fraction = 1.0
            if self._velocity_mode_active():
                self._reset_velocity_line()
            slider = getattr(self, "_morph_range_slider", None)
            if slider is not None:
                slider.blockSignals(True)
                slider.setValue(100)
                slider.blockSignals(False)
        label = getattr(self, "_morphology_label", None)
        spacing_lbl = getattr(self, "_vel_spacing_lbl", None)
        spin = getattr(self, "_vel_spacing_spin", None)
        if label is not None:
            if morph is None:
                label.setText("Morfologia: —")
                label.setToolTip(
                    "Opzionale. Importa Excel (GPS) o JSON (campagna) dal menu Break."
                )
            else:
                sheet = f", foglio {morph.sheet_name}" if morph.sheet_name else ""
                line = f", linea {morph.line_id}" if morph.line_id is not None else ""
                label.setText(
                    f"Morfologia: {morph.source_label} — "
                    f"{morph.trace_count} geofoni{line}"
                )
                label.setToolTip(
                    f"{morph.source_path.name}{sheet}\n"
                    f"Lunghezza ~{morph.geophones[-1].cumulative_m:.1f} m"
                )
        if spin is not None:
            if morph is None:
                spin.setEnabled(True)
                if spacing_lbl is not None:
                    spacing_lbl.setText("Spaz. (m):")
                    spacing_lbl.setToolTip("Spaziatura geofoni (m)")
            else:
                spin.setEnabled(False)
                spin.setValue(max(0.1, morph.typical_excel_spacing_m()))
                spin.setToolTip(
                    "Mediana «dist pianta geof» dal file Excel POST "
                    f"(ultimo tratto: {morph.tail_excel_spacing_m():.3f} m)."
                )
                if spacing_lbl is not None:
                    spacing_lbl.setText("Excel (m):")
                    spacing_lbl.setToolTip("Spaziatura Excel (m)")
        self._update_morphology_range_bar_ui()
        self._refresh_morphology_profile()
        self._update_velocity_readout()
        self._sync_monitor_plot_alignment()
        if morph is not None and morph.trace_count > 0:
            if morph_changed or fit_view:
                self._update_dromocrona_view_limits_from_data(fit_view=True)
            self._remap_all_series_display_x(fit_view=False)
        else:
            self._remap_all_series_display_x(fit_view=fit_view)
        QtCore.QTimer.singleShot(
            0,
            lambda fv=fit_view: self._finalize_morphology_plot_refresh(fit_view=fv),
        )

    def notify_line_morphology_memory_status(
            self,
            *,
            removed_from_memory: bool,
            source_name: str = "",
        ) -> None:
        """Conferma sul monitor se la morfologia è stata tolta dalla RAM."""
        self.refresh_line_morphology_ui(fit_view=True)
        label = getattr(self, "_morphology_label", None)
        if removed_from_memory:
            if label is not None:
                label.setText("Morfologia: rimossa dalla memoria")
                label.setToolTip(
                    "Nessun file morfologia è più caricato in RAM."
                )
            file_txt = f"«{source_name}»" if source_name else "della linea"
            QtWidgets.QMessageBox.information(
                self,
                "Morfologia rimossa",
                (
                    f"Il file {file_txt} è stato tolto dalla memoria.\n"
                    "Il monitor non usa più la morfologia."
                ),
            )
            return
        QtWidgets.QMessageBox.warning(
            self,
            "Morfologia non rimossa",
            "La morfologia risulta ancora presente in memoria.",
        )

    def _build_velocity_analysis_panel(self) -> QtWidgets.QWidget:
        panel = QtWidgets.QFrame()
        panel.setObjectName("velocityAnalysisPanel")
        panel.setFrameShape(QtWidgets.QFrame.Shape.StyledPanel)
        panel.setStyleSheet(
            "QFrame#velocityAnalysisPanel {"
            "  background: #252d3d;"
            "  border: 1px solid #3d4657;"
            "  border-radius: 6px;"
            "}"
            f"QLabel {{ color: {self._TEXT_COLOR}; }}"
            "QDoubleSpinBox {"
            f"  background: {self._CHROME_BG};"
            f"  color: {self._TEXT_COLOR};"
            "  border: 1px solid #3d4657;"
            "  border-radius: 3px;"
            "  padding: 0px 4px;"
            "  font-size: 11px;"
            "  selection-background-color: #3d5a80;"
            "}"
            "QRadioButton {"
            f"  color: {self._TEXT_COLOR};"
            "  font-size: 11px;"
            "  font-weight: 700;"
            "  spacing: 4px;"
            "}"
            "QRadioButton::indicator {"
            "  width: 11px; height: 11px;"
            "  border-radius: 6px;"
            "  border: 1px solid #6b7588;"
            f"  background: {self._CHROME_BG};"
            "}"
            "QRadioButton::indicator:hover { border-color: #8b95a8; }"
            "QRadioButton::indicator:checked {"
            f"  background: {self._VEL_LINE_COLOR};"
            f"  border: 2px solid {self._VEL_LINE_COLOR};"
            "}"
        )
        panel.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Preferred,
            QtWidgets.QSizePolicy.Policy.Maximum,
        )
        # Una sola riga: tre card + V grande a destra.
        outer = QtWidgets.QHBoxLayout(panel)
        outer.setContentsMargins(6, 4, 6, 4)
        outer.setSpacing(6)

        hint = QtWidgets.QLabel("Strato → retta gialla (2 clic)")
        hint.setStyleSheet(f"color: {self._MUTED_TEXT}; font-size: 10px;")
        hint.setToolTip(
            "Seleziona lo strato, disegna la retta gialla (2 clic), ripeti per II°/III°."
        )
        hint.setAlignment(
            QtCore.Qt.AlignmentFlag.AlignVCenter | QtCore.Qt.AlignmentFlag.AlignLeft
        )
        outer.addWidget(hint)

        self._vel_layer_button_group = QtWidgets.QButtonGroup(panel)
        self._vel_layer_radios: list[QtWidgets.QRadioButton] = []
        self._vel_layer_spins: list[QtWidgets.QDoubleSpinBox] = []
        self._vel_intercept_spins: list[QtWidgets.QDoubleSpinBox] = []
        self._vel_depth_spins: list[QtWidgets.QDoubleSpinBox] = []
        self._vel_layer_cards: list[QtWidgets.QFrame] = []

        label_style = f"color: {self._MUTED_TEXT}; font-size: 10px;"
        depth_style = "color: #ff8a80; font-size: 10px; font-weight: 600;"

        def _readonly_spin(suffix: str, lo: float, hi: float) -> QtWidgets.QDoubleSpinBox:
            spin = QtWidgets.QDoubleSpinBox()
            spin.setRange(lo, hi)
            spin.setDecimals(2)
            spin.setSuffix(suffix)
            spin.setReadOnly(True)
            spin.setButtonSymbols(
                QtWidgets.QAbstractSpinBox.ButtonSymbols.NoButtons
            )
            spin.setFixedWidth(96)
            spin.setFixedHeight(20)
            return spin

        def _field(
            row: QtWidgets.QHBoxLayout, text: str, style: str, spin: QtWidgets.QDoubleSpinBox
        ) -> None:
            lbl = QtWidgets.QLabel(text)
            lbl.setStyleSheet(style)
            row.addWidget(lbl)
            row.addWidget(spin)

        for idx, roman in enumerate(("I", "II", "III")):
            card = QtWidgets.QFrame()
            card.setObjectName("velocityLayerCard")
            card_l = QtWidgets.QHBoxLayout(card)
            card_l.setContentsMargins(6, 3, 6, 3)
            card_l.setSpacing(5)

            radio = QtWidgets.QRadioButton(f"{roman}°")
            radio.setToolTip(
                f"Seleziona il {roman}° strato prima di confermare la retta gialla."
            )
            self._vel_layer_button_group.addButton(radio, idx)
            self._vel_layer_radios.append(radio)
            self._vel_layer_cards.append(card)
            card_l.addWidget(radio)

            v_spin = _readonly_spin(" m/s", 0.0, 20000.0)
            v_spin.setToolTip("Velocità apparente della retta disegnata sul grafico.")
            self._vel_layer_spins.append(v_spin)
            _field(card_l, "V", label_style, v_spin)

            if idx < 2:
                i_spin = _readonly_spin(" ms", -1e6, 1e6)
                i_spin.setToolTip(
                    "Intercetta della retta: a x=0 (n° geofono) senza morfologia, "
                    "allo shot (offset 0 m) con morfologia."
                )
                self._vel_intercept_spins.append(i_spin)
                _field(card_l, "Ti", label_style, i_spin)

                z_spin = _readonly_spin(" m", 0.0, 1e6)
                z_spin.setToolTip(
                    "Profondità alla base del II° strato (cumulativa, ≥ Profondità I°)."
                    if idx == 1
                    else "Profondità alla base del I° strato."
                )
                self._vel_depth_spins.append(z_spin)
                _field(card_l, "Z", depth_style, z_spin)

            card.setSizePolicy(
                QtWidgets.QSizePolicy.Policy.Maximum,
                QtWidgets.QSizePolicy.Policy.Maximum,
            )
            outer.addWidget(card)

        outer.addStretch(1)
        self._vel_panel_value_label = QtWidgets.QLabel("V = —")
        self._vel_panel_value_label.setAlignment(
            QtCore.Qt.AlignmentFlag.AlignVCenter | QtCore.Qt.AlignmentFlag.AlignRight
        )
        self._vel_panel_value_label.setStyleSheet(
            f"color: {self._VEL_LINE_COLOR}; font-size: 20px; font-weight: 800;"
            " padding: 2px 10px; background: #1a2233; border: 1px solid #3d4657;"
            " border-radius: 4px;"
        )
        self._vel_panel_value_label.setMinimumWidth(170)
        outer.addWidget(self._vel_panel_value_label)
        self._vel_layer_button_group.idToggled.connect(
            self._refresh_velocity_layer_card_styles
        )
        self._vel_layer_radios[0].setChecked(True)
        self._refresh_velocity_layer_card_styles()
        panel.hide()
        return panel

    def _refresh_velocity_layer_card_styles(self, *_args) -> None:
        cards = getattr(self, "_vel_layer_cards", None)
        radios = getattr(self, "_vel_layer_radios", None)
        if not cards or not radios:
            return
        active_idx = self._active_velocity_layer_index()
        for idx, card in enumerate(cards):
            if idx == active_idx:
                card.setStyleSheet(
                    "QFrame#velocityLayerCard {"
                    f"  background: {self._CHROME_BG};"
                    f"  border: 1px solid {self._VEL_LINE_COLOR};"
                    "  border-radius: 4px;"
                    "}"
                )
            else:
                card.setStyleSheet(
                    "QFrame#velocityLayerCard {"
                    "  background: #1e2636;"
                    "  border: 1px solid #3d4657;"
                    "  border-radius: 4px;"
                    "}"
                )

    def _set_velocity_analysis_panel_visible(self, visible: bool) -> None:
        panel = getattr(self, "_velocity_analysis_panel", None)
        if panel is not None:
            panel.setVisible(bool(visible))

    def _active_velocity_layer_index(self) -> int:
        group = getattr(self, "_vel_layer_button_group", None)
        if group is None:
            return 0
        return int(max(0, group.checkedId()))

    def _velocity_plot_x_to_distance_m(self, x_plot: float) -> float:
        """Converte la coordinata X del grafico in distanza lungo linea (m)."""
        if self._uses_geophone_index_x_axis():
            spacing = self._velocity_geophone_spacing_m()
            return (
                float(x_plot) - float(self._GEOPHONE_X_ORIGIN)
            ) * spacing
        return float(x_plot)

    def _locked_series_shot_display_x(self) -> float | None:
        locked = self._locked_series_idx
        if locked is None or locked < 0 or locked >= len(self._series_meta):
            return None
        meta = self._series_meta[locked]
        shot_tr = meta.get("shot_trace_idx")
        if shot_tr is None:
            return None
        return float(
            self._display_x_for_traces(
                np.asarray([int(shot_tr)], dtype=np.int64)
            )[0]
        )

    def _velocity_dist_m_from_endpoints(
            self, p0: tuple[float, float], p1: tuple[float, float]
        ) -> float:
            x0_m = self._velocity_plot_x_to_distance_m(p0[0])
            x1_m = self._velocity_plot_x_to_distance_m(p1[0])
            return abs(x1_m - x0_m)

    def _velocity_slope_ms_per_m(
            self, p0: tuple[float, float], p1: tuple[float, float]
        ) -> float | None:
            x0_m = self._velocity_plot_x_to_distance_m(p0[0])
            x1_m = self._velocity_plot_x_to_distance_m(p1[0])
            dx_m = x1_m - x0_m
            if abs(dx_m) < 1e-9:
                return None
            return (float(p1[1]) - float(p0[1])) / dx_m

    def _velocity_intercept_ms_at_x0(
            self, p0: tuple[float, float], p1: tuple[float, float]
        ) -> float | None:
            x0, y0 = p0
            if self._uses_geophone_index_x_axis():
                # Legacy SeisView: intercetta al numero geofono 0 (asse X del grafico).
                dx_plot = float(p1[0]) - float(x0)
                if abs(dx_plot) < 1e-9:
                    return None
                slope_plot = (float(p1[1]) - float(y0)) / dx_plot
                return float(y0) - slope_plot * float(x0)
            slope = self._velocity_slope_ms_per_m(p0, p1)
            if slope is None:
                return None
            x0_m = self._velocity_plot_x_to_distance_m(x0)
            shot_x = self._locked_series_shot_display_x()
            if shot_x is None:
                return float(y0) - slope * x0_m
            x_shot_m = self._velocity_plot_x_to_distance_m(shot_x)
            return float(y0) - slope * (x0_m - x_shot_m)

    @staticmethod
    def _velocity_m_s(dist_m: float, time_ms: float) -> float | None:
        if time_ms <= 1e-9:
            return None
        return float(dist_m) * 1000.0 / float(time_ms)

    @staticmethod
    def _recalculate_velocity_layer_depths_from_values(
            v1: float,
            v2: float,
            v3: float,
            t1_ms: float,
            t2_ms: float,
        ) -> tuple[float | None, float | None]:
            """Formule legacy SeisView (calcola_spessori) con profondità cumulative.

            SeisView scrive s1 e s2 con segno (dipende dal segno delle intercette).
            Per la visualizzazione usiamo:
            - profondità I° = |s1|
            - profondità II° = |s1| + |s2 − s1|  (base del II° strato, sempre ≥ I°)
            """
            depth1: float | None = None
            depth2: float | None = None
            t1 = float(t1_ms)
            t2 = float(t2_ms)
            s1: float | None = None
            s2: float | None = None
            if v1 > 0.0 and v2 > v1 and abs(t1) > 1e-9:
                j5 = v1 * v2
                j7_sq = (v2 * v2) - j5
                if j7_sq > 1e-9:
                    s1 = (t1 / 2000.0) * (j5 / math.sqrt(j7_sq))
            if (
                s1 is not None
                and v3 > v2 > v1
                and abs(t2) > 1e-9
            ):
                j8 = v1 * v1
                j9 = v2 * v2
                j10 = v3 * v3
                j11 = v3 * v1
                j12 = v3 * v2
                j13_sq = j10 - j8
                j14_sq = j10 - j9
                if j11 > 1e-9 and j13_sq > 1e-9 and j14_sq > 1e-9:
                    j13 = math.sqrt(j13_sq)
                    j14 = math.sqrt(j14_sq)
                    j15 = (t2 / 1000.0) - ((2.0 * s1) * (j13 / j11))
                    j16 = j12 / (2.0 * j14)
                    s2 = s1 + (j15 * j16)
            if s1 is not None:
                depth1 = abs(s1)
            if s1 is not None and s2 is not None:
                depth2 = abs(s1) + abs(s2 - s1)
            return depth1, depth2

    def _recalculate_velocity_layer_depths(self) -> None:
        spins_v = getattr(self, "_vel_layer_spins", ())
        spins_t = getattr(self, "_vel_intercept_spins", ())
        spins_z = getattr(self, "_vel_depth_spins", ())
        if not spins_v or not spins_z:
            return
        v1 = float(spins_v[0].value()) if len(spins_v) > 0 else 0.0
        v2 = float(spins_v[1].value()) if len(spins_v) > 1 else 0.0
        v3 = float(spins_v[2].value()) if len(spins_v) > 2 else 0.0
        t1 = float(spins_t[0].value()) if len(spins_t) > 0 else 0.0
        t2 = float(spins_t[1].value()) if len(spins_t) > 1 else 0.0
        depth1, depth2 = self._recalculate_velocity_layer_depths_from_values(
            v1, v2, v3, t1, t2
        )
        spins_z[0].setValue(float(depth1) if depth1 is not None else 0.0)
        if len(spins_z) > 1:
            spins_z[1].setValue(float(depth2) if depth2 is not None else 0.0)

    def _apply_velocity_line_to_layers(
            self,
            p0: tuple[float, float],
            p1: tuple[float, float],
        ) -> None:
            dist_m = self._velocity_dist_m_from_endpoints(p0, p1)
            time_ms = abs(float(p1[1]) - float(p0[1]))
            v_m_s = self._velocity_m_s(dist_m, time_ms)
            intercept_ms = self._velocity_intercept_ms_at_x0(p0, p1)
            if v_m_s is None:
                return
            layer_idx = self._active_velocity_layer_index()
            if layer_idx < len(self._vel_layer_spins):
                self._vel_layer_spins[layer_idx].setValue(float(v_m_s))
            if intercept_ms is not None:
                if layer_idx == 0 and self._vel_intercept_spins:
                    self._vel_intercept_spins[0].setValue(float(intercept_ms))
                elif layer_idx == 1 and len(self._vel_intercept_spins) > 1:
                    self._vel_intercept_spins[1].setValue(float(intercept_ms))
            self._recalculate_velocity_layer_depths()

    def _reset_velocity_analysis_fields(self) -> None:
        if hasattr(self, "_vel_panel_value_label"):
            self._vel_panel_value_label.setText("V = —")
        for spin in getattr(self, "_vel_layer_spins", ()):
            spin.setValue(0.0)
        for spin in getattr(self, "_vel_intercept_spins", ()):
            spin.setValue(0.0)
        for spin in getattr(self, "_vel_depth_spins", ()):
            spin.setValue(0.0)

    def _cleanup_velocity_mode_on_close(self) -> None:
        """Ripristina pan e stato retta velocità se la finestra viene chiusa a metà disegno."""
        self._reset_velocity_line()
        self._reset_velocity_analysis_fields()
        self._set_velocity_analysis_panel_visible(False)
        checkbox = getattr(self, "_vel_calc_checkbox", None)
        if checkbox is not None and checkbox.isChecked():
            checkbox.blockSignals(True)
            checkbox.setChecked(False)
            checkbox.blockSignals(False)
        self._update_velocity_readout()

    def _velocity_mode_active(self) -> bool:
        checkbox = getattr(self, "_vel_calc_checkbox", None)
        return (
            checkbox is not None
            and checkbox.isChecked()
            and self._locked_series_idx is not None
        )

    def _velocity_geophone_spacing_m(self) -> float:
        spin = getattr(self, "_vel_spacing_spin", None)
        if spin is None:
            return DROMO_GEOPHONE_SPACING_M
        return max(0.1, float(spin.value()))

    def _map_scene_to_dromocrona_plot(self, scene_pos) -> tuple[float, float] | None:
        vb = self.dromocrona_plot.getViewBox()
        if vb is None or not vb.sceneBoundingRect().contains(scene_pos):
            return None
        p = vb.mapSceneToView(scene_pos)
        return float(p.x()), float(p.y())

    def _set_velocity_pan_enabled(self, enabled: bool) -> None:
        # Il pan/zoom è gestito da _sync_dromocrona_mouse_enabled (evita lock annidati).
        if enabled:
            self._vel_pan_prev = None
        else:
            self._vel_pan_prev = (False, False)  # solo flag «modo velocity attivo»
        self._sync_dromocrona_mouse_enabled()

    def _dromocrona_interaction_blocks_mouse(self) -> bool:
        return self._active_drag is not None or bool(self._vel_line_placing)

    def _sync_dromocrona_mouse_enabled(self) -> None:
        """Ripristina sempre pan/zoom salvo durante drag break o disegno retta V."""
        vb = self.dromocrona_plot.getViewBox()
        if vb is None:
            return
        if self._dromocrona_interaction_blocks_mouse():
            vb.setMouseEnabled(x=False, y=False)
        else:
            vb.setMouseEnabled(x=True, y=True)
            self._drag_pan_prev = None
            self._vel_pan_prev = None

    def _cancel_active_drag(self) -> None:
        """Annulla un drag in corso e ripristina pan/zoom (senza commit)."""
        self._active_drag = None
        self._drag_start_y = None
        self._drag_moved = False
        self._drag_pan_prev = None
        if self._drag_commit_timer.isActive():
            self._drag_commit_timer.stop()
        self._sync_dromocrona_mouse_enabled()

    def _remove_velocity_line_graphics(self) -> None:
        if self._vel_line_item is not None:
            self.dromocrona_plot.removeItem(self._vel_line_item)
            self._vel_line_item = None
        if self._vel_line_markers is not None:
            self.dromocrona_plot.removeItem(self._vel_line_markers)
            self._vel_line_markers = None

    def _reset_velocity_line(self) -> None:
        self._vel_line_p0 = None
        self._vel_line_p1 = None
        self._vel_line_cursor = None
        self._vel_line_placing = False
        self._remove_velocity_line_graphics()
        self._set_velocity_pan_enabled(True)

    def _velocity_line_endpoints(
            self,
        ) -> tuple[tuple[float, float], tuple[float, float]] | None:
            if self._vel_line_p0 is None:
                return None
            if self._vel_line_placing and self._vel_line_cursor is not None:
                return self._vel_line_p0, self._vel_line_cursor
            if self._vel_line_p1 is not None:
                return self._vel_line_p0, self._vel_line_p1
            return None

    def _sync_velocity_line_graphics(self) -> None:
        self._remove_velocity_line_graphics()
        if not self._velocity_mode_active():
            return
        endpoints = self._velocity_line_endpoints()
        if endpoints is None:
            return
        (x0, y0), (x1, y1) = endpoints
        pen = pg.mkPen(self._VEL_LINE_COLOR, width=2.8)
        self._vel_line_item = self.dromocrona_plot.plot(
            [x0, x1],
            [y0, y1],
            pen=pen,
            connect="all",
        )
        self._vel_line_item.setZValue(18)
        marker_spots = [
            {
                "pos": (x0, y0),
                "size": 11,
                "brush": pg.mkBrush(self._VEL_LINE_COLOR),
                "pen": pg.mkPen(None),
            }
        ]
        if not self._vel_line_placing or self._vel_line_cursor is not None:
            end_color = (
                self._VEL_LINE_COLOR
                if not self._vel_line_placing
                else "#7fdbff"
            )
            marker_spots.append(
                {
                    "pos": (x1, y1),
                    "size": 11 if not self._vel_line_placing else 9,
                    "brush": pg.mkBrush(end_color),
                    "pen": pg.mkPen(None),
                }
            )
        self._vel_line_markers = pg.ScatterPlotItem(hoverable=False)
        self._vel_line_markers.setData(spots=marker_spots)
        self._vel_line_markers.setZValue(20)
        self.dromocrona_plot.addItem(self._vel_line_markers)

    def _update_velocity_readout(self, *_args) -> None:
        panel_vel = getattr(self, "_vel_panel_value_label", None)

        def _clear_v() -> None:
            if panel_vel is not None:
                panel_vel.setText("V = —")

        if not self._velocity_mode_active():
            _clear_v()
            return
        endpoints = self._velocity_line_endpoints()
        if endpoints is None:
            _clear_v()
            return
        (x0, y0), (x1, y1) = endpoints
        dist_m = self._velocity_dist_m_from_endpoints((x0, y0), (x1, y1))
        time_ms = abs(float(y1) - float(y0))
        v_m_s = self._velocity_m_s(dist_m, time_ms)
        if v_m_s is None:
            _clear_v()
            return
        if panel_vel is not None:
            panel_vel.setText(f"V = {v_m_s:.2f} m/s")
        if not self._vel_line_placing and self._vel_line_p1 is not None:
            self._apply_velocity_line_to_layers((x0, y0), (x1, y1))

    def _install_velocity_toggle_shortcut(self) -> None:
        """V: accende/spegne analisi velocità quando la finestra dromocrone è attiva."""
        shortcut = QtGui.QShortcut(QtGui.QKeySequence("V"), self)
        shortcut.setContext(QtCore.Qt.ShortcutContext.WindowShortcut)
        shortcut.setObjectName("velocityToggleShortcut")
        shortcut.activated.connect(self._toggle_velocity_analysis_from_shortcut)
        self._velocity_toggle_shortcut = shortcut

    def _toggle_velocity_analysis_from_shortcut(self) -> None:
        focus = QtWidgets.QApplication.focusWidget()
        if isinstance(
            focus,
            (QtWidgets.QLineEdit, QtWidgets.QTextEdit, QtWidgets.QPlainTextEdit),
        ):
            return
        # Spinbox in editing: non rubare la digitazione.
        if isinstance(focus, QtWidgets.QAbstractSpinBox) and focus.hasFocus():
            if focus.focusWidget() is not None and isinstance(
                focus.focusWidget(), QtWidgets.QLineEdit
            ):
                line = focus.focusWidget()
                if line is not None and line.hasFocus() and not line.isReadOnly():
                    return
        checkbox = getattr(self, "_vel_calc_checkbox", None)
        if checkbox is None or not checkbox.isEnabled():
            return
        checkbox.toggle()

    def _on_velocity_mode_toggled(self, checked: bool) -> None:
        if checked and self._locked_series_idx is None:
            QtWidgets.QMessageBox.information(
                self,
                "Analisi velocità",
                "Seleziona prima una dromocrona (Shift + clic sinistro sulla curva).",
            )
            checkbox = getattr(self, "_vel_calc_checkbox", None)
            if checkbox is not None:
                checkbox.blockSignals(True)
                checkbox.setChecked(False)
                checkbox.blockSignals(False)
            return
        if not checked:
            self._reset_velocity_line()
            self._reset_velocity_analysis_fields()
            self._set_velocity_analysis_panel_visible(False)
        else:
            self._update_lock_status_label()
            self._set_velocity_analysis_panel_visible(True)
            self._recalculate_velocity_layer_depths()
        self._sync_velocity_line_graphics()
        self._update_velocity_readout()

    def _on_velocity_scene_moved(self, scene_pos) -> None:
        if not self._vel_line_placing or self._vel_line_p0 is None:
            return
        mapped = self._map_scene_to_dromocrona_plot(scene_pos)
        if mapped is None:
            return
        self._vel_line_cursor = mapped
        self._sync_velocity_line_graphics()
        self._update_velocity_readout()

    def _on_velocity_scene_clicked(self, ev) -> None:
        if ev.button() != QtCore.Qt.MouseButton.LeftButton:
            return
        mapped = self._map_scene_to_dromocrona_plot(ev.scenePos())
        if mapped is None:
            return
        if self._vel_line_p0 is None or not self._vel_line_placing:
            self._vel_line_p0 = mapped
            self._vel_line_p1 = None
            self._vel_line_cursor = mapped
            self._vel_line_placing = True
            self._set_velocity_pan_enabled(False)
        else:
            self._vel_line_p1 = mapped
            self._vel_line_cursor = None
            self._vel_line_placing = False
            self._set_velocity_pan_enabled(True)
        self._sync_velocity_line_graphics()
        self._update_velocity_readout()

    def set_gui_worker(self, worker: object | None) -> None:
        self._gui_worker = worker

    def _series_meta_for_reciprocals(self) -> list[dict[str, object]]:
        """Meta ordinate come le colonne della griglia (file_idx = series_idx)."""
        return sort_series_meta_by_file_order(self._series_meta)

    def _series_meta_index_to_column(self) -> dict[int, int]:
        from dromocrona_grid_data import series_meta_index_to_column_map

        return series_meta_index_to_column_map(self._series_meta)

    def _column_to_series_meta_index(self) -> dict[int, int]:
        return {
            int(col): int(orig)
            for orig, col in self._series_meta_index_to_column().items()
        }

    def _reciprocal_fail_maps_for_meta_indices(
            self,
            pairs: tuple,
        ) -> tuple[
            dict[int, set[int]],
            dict[int, dict[int, float]],
            dict[int, dict[int, float]],
        ]:
            fails, fail_bands_by_series, fail_deltas_by_series = (
                failed_trace_bands_from_pairs(pairs)
            )
            col_to_meta = self._column_to_series_meta_index()
            fails_meta: dict[int, set[int]] = {}
            bands_meta: dict[int, dict[int, float]] = {}
            deltas_meta: dict[int, dict[int, float]] = {}
            for col_idx, traces in fails.items():
                meta_idx = col_to_meta.get(int(col_idx))
                if meta_idx is None:
                    continue
                fails_meta[int(meta_idx)] = set(traces)
            for col_idx, bands in fail_bands_by_series.items():
                meta_idx = col_to_meta.get(int(col_idx))
                if meta_idx is None:
                    continue
                bands_meta[int(meta_idx)] = dict(bands)
            for col_idx, deltas in fail_deltas_by_series.items():
                meta_idx = col_to_meta.get(int(col_idx))
                if meta_idx is None:
                    continue
                deltas_meta[int(meta_idx)] = {
                    int(tr): float(val) for tr, val in deltas.items()
                }
            return fails_meta, bands_meta, deltas_meta

    def _fail_maps_meta_from_worker_result(
            self, result: dict[str, object]
        ) -> (
            tuple[
                dict[int, set[int]],
                dict[int, dict[int, float]],
                dict[int, dict[int, float]],
            ]
            | None
        ):
            """Converte mappe FAIL (chiavi colonna) dal worker in indici meta serie."""
            if "fail_traces" not in result:
                return None
            col_to_meta = self._column_to_series_meta_index()
            fails_meta: dict[int, set[int]] = {}
            bands_meta: dict[int, dict[int, float]] = {}
            deltas_meta: dict[int, dict[int, float]] = {}
            for col_raw, traces in dict(result.get("fail_traces") or {}).items():
                meta_idx = col_to_meta.get(int(col_raw))
                if meta_idx is None:
                    continue
                fails_meta[int(meta_idx)] = {int(t) for t in traces}
            for col_raw, bands in dict(result.get("fail_bands") or {}).items():
                meta_idx = col_to_meta.get(int(col_raw))
                if meta_idx is None:
                    continue
                bands_meta[int(meta_idx)] = {
                    int(tr): float(tol) for tr, tol in dict(bands).items()
                }
            for col_raw, deltas in dict(result.get("fail_deltas") or {}).items():
                meta_idx = col_to_meta.get(int(col_raw))
                if meta_idx is None:
                    continue
                deltas_meta[int(meta_idx)] = {
                    int(tr): float(val) for tr, val in dict(deltas).items()
                }
            return fails_meta, bands_meta, deltas_meta

    def _series_meta_worker_payload(
            self, metas: list[dict[str, object]] | None = None
        ) -> list[dict[str, object]]:
            from worker_tasks import normalize_series_meta_for_worker

            source = metas if metas is not None else self._series_meta
            return [normalize_series_meta_for_worker(dict(meta)) for meta in source]

    def _series_meta_fbp_export_payload(self) -> list[dict[str, object]]:
        """Meta serializzate con template .fbp in memoria per export su worker."""
        self._ensure_all_series_disk_templates()
        rows = self._series_meta_worker_payload()
        for row, meta in zip(rows, self._series_meta):
            for key in (
                "shot_abs_ref_ms",
                "fbp_n_traces",
                "fbp_samples",
                "fbp_disk_lines",
                "fbp_line_by_trace",
                "sgy_path",
            ):
                if key not in meta:
                    continue
                val = meta.get(key)
                if key == "fbp_disk_lines" and isinstance(val, list):
                    row[key] = list(val)
                elif key == "fbp_line_by_trace" and isinstance(val, dict):
                    row[key] = {int(k): int(v) for k, v in val.items()}
                elif key == "fbp_samples" and isinstance(val, dict):
                    row[key] = {int(k): int(v) for k, v in val.items()}
                else:
                    row[key] = val
        return rows

    def _schedule_reciprocal_patch_worker(
            self,
            *,
            affected_cols: set[int],
            traces_by_col: dict[int, set[int]] | None,
            prefer_memory: bool,
            cache_key: object,
        ) -> None:
            hub = self._gui_worker
            if hub is None:
                return
            payload: dict[str, object] = {
                "series_meta": self._series_meta_worker_payload(
                    self._series_meta_for_reciprocals()
                ),
                "shot_registry": self._shot_registry_for_monitor(),
                "prefer_memory": bool(prefer_memory),
                "tolerance_bands": self.reciprocal_tolerance_bands().to_dict(),
                "existing_pairs": self._reciprocal_pairs_cache or (),
                "affected_cols": sorted(int(c) for c in affected_cols),
                "cache_key": cache_key,
            }
            if traces_by_col:
                payload["traces_by_col"] = {
                    str(int(col)): sorted(int(t) for t in traces)
                    for col, traces in traces_by_col.items()
                }
            if self._reciprocal_patch_worker_pending:
                pending = dict(self._reciprocal_patch_reschedule_payload or {})
                old_cols = {int(c) for c in (pending.get("affected_cols") or [])}
                old_cols.update(int(c) for c in (payload.get("affected_cols") or []))
                payload["affected_cols"] = sorted(old_cols)
                old_traces = dict(pending.get("traces_by_col") or {})
                new_traces = dict(payload.get("traces_by_col") or {})
                for col_raw, traces in new_traces.items():
                    bucket = set(old_traces.get(str(col_raw), []))
                    bucket.update(traces)
                    old_traces[str(col_raw)] = sorted(bucket)
                if old_traces:
                    payload["traces_by_col"] = old_traces
                self._reciprocal_patch_reschedule_payload = payload
                return
            self._reciprocal_patch_worker_pending = True
            self._reciprocal_patch_reschedule_payload = None
            hub.submit("reciprocal_patch", payload)

    def apply_reciprocal_patch_worker_result(
            self, job: object, result: dict[str, object]
        ) -> None:
            del job
            self._reciprocal_patch_worker_pending = False
            reschedule = self._reciprocal_patch_reschedule_payload
            self._reciprocal_patch_reschedule_payload = None
            prefer_memory = bool(result.get("prefer_memory"))
            current_key = self._reciprocal_pairs_cache_fingerprint(
                prefer_memory=prefer_memory
            )
            job_key = result.get("cache_key")
            stale = job_key is not None and job_key != current_key
            # Risultato stantio: non aggiornare FAIL/pair, solo rilanciare.
            if stale and reschedule is None:
                pending = getattr(self, "_reciprocal_patch_pending", None) or {}
                if pending:
                    self._flush_reciprocal_patch_pending(prefer_memory=prefer_memory)
                elif self._reciprocals_compute_wanted():
                    self._schedule_reciprocal_worker(prefer_memory=prefer_memory)
                return
            pairs = result.get("pairs")
            if pairs is None:
                pairs_tuple: tuple = ()
                pairs_map: dict[tuple[int, int], object] = {}
            else:
                pairs_tuple = tuple(pairs)
                pairs_map = reciprocal_pairs_to_map(pairs_tuple)
            if not stale:
                pairs_tuple = self._commit_reciprocal_pairs_map(
                    pairs_map,
                    prefer_memory=prefer_memory,
                    cache_key=job_key,
                )
                fail_maps = self._fail_maps_meta_from_worker_result(result)
                if fail_maps is not None:
                    self._reciprocal_fail_maps_meta_cache = fail_maps
                    self._refresh_reciprocal_fail_highlights(fail_maps_meta=fail_maps)
                else:
                    self._reciprocal_fail_maps_meta_cache = None
                    self._refresh_reciprocal_fail_highlights(
                        reciprocal_pairs=pairs_tuple
                    )
            else:
                pairs_tuple = self._reciprocal_pairs_cache or ()
            if reschedule is not None:
                hub = self._gui_worker
                if hub is not None:
                    reschedule["existing_pairs"] = pairs_tuple
                    self._reciprocal_patch_worker_pending = True
                    hub.submit("reciprocal_patch", reschedule)
                return
            if self._dromocrona_grid_refresh_wanted():
                self._schedule_dromocrona_grid_build_worker(
                    reciprocal_pairs=pairs_tuple
                )

    def on_reciprocal_patch_worker_error(self, message: str) -> None:
            self._reciprocal_patch_worker_pending = False
            reschedule = self._reciprocal_patch_reschedule_payload
            self._reciprocal_patch_reschedule_payload = None
            _LOG.warning("Patch reciproci non riuscito: %s", message)
            if reschedule is not None and self._gui_worker is not None:
                self._reciprocal_patch_worker_pending = True
                self._gui_worker.submit("reciprocal_patch", reschedule)

    def _schedule_dromocrona_grid_build_worker(
            self, *, reciprocal_pairs: tuple | None = None
        ) -> None:
            hub = self._gui_worker
            grid = getattr(self, "_dromocrona_grid_window", None)
            if hub is None or grid is None or not grid.isVisible():
                self._refresh_dromocrona_grid_window_sync(
                    reciprocal_pairs=reciprocal_pairs
                )
                return
            self._grid_build_revision = int(getattr(self, "_grid_build_revision", 0)) + 1
            revision = int(self._grid_build_revision)
            if reciprocal_pairs is not None:
                self._grid_build_pending_pairs = reciprocal_pairs
            elif self._reciprocals_compute_wanted():
                cached = self._reciprocal_pairs_cache
                if cached is not None:
                    self._grid_build_pending_pairs = cached
            if self._grid_build_worker_pending:
                return
            self._grid_build_worker_pending = True
            self._grid_build_submitted_revision = revision
            hub.submit(
                "build_dromocrona_grid",
                {
                    "series_meta": self._series_meta_worker_payload(),
                    "shot_registry": self._shot_registry_for_monitor(),
                    "revision": revision,
                },
            )

    def apply_grid_build_worker_result(
            self, job: object, result: dict[str, object]
        ) -> None:
            del job
            self._grid_build_worker_pending = False
            grid_win = getattr(self, "_dromocrona_grid_window", None)
            if grid_win is None or not grid_win.isVisible():
                return
            revision = int(result.get("revision") or 0)
            if revision != int(getattr(self, "_grid_build_revision", 0)):
                if self._dromocrona_grid_refresh_wanted():
                    self._schedule_dromocrona_grid_build_worker(
                        reciprocal_pairs=self._grid_build_pending_pairs
                    )
                return
            from dromocrona_grid_data import dromocrona_grid_from_payload

            grid_payload = result.get("grid")
            if not isinstance(grid_payload, dict):
                return
            with perf_section("grid.apply_worker_result"):
                grid_data = dromocrona_grid_from_payload(grid_payload)
                pairs = self._grid_build_pending_pairs
                if pairs is None and self._reciprocals_compute_wanted():
                    pairs = self._reciprocal_pairs_cache
                grid_win.apply_grid_data(
                    grid_data,
                    reciprocal_pairs=pairs,
                )

    def on_grid_build_worker_error(self, message: str) -> None:
            self._grid_build_worker_pending = False
            _LOG.warning("Build griglia dromocrona non riuscito: %s", message)
            submitted = int(getattr(self, "_grid_build_submitted_revision", 0))
            current = int(getattr(self, "_grid_build_revision", 0))
            if (
                self._dromocrona_grid_refresh_wanted()
                and current != submitted
            ):
                self._schedule_dromocrona_grid_build_worker(
                    reciprocal_pairs=self._grid_build_pending_pairs
                )

    def _schedule_snap_reciprocal_fail_worker(
            self, meta_idx: int, trace_idx: int, *, col_idx: int
        ) -> None:
            hub = self._gui_worker
            if hub is None:
                return
            if self._snap_reciprocal_worker_pending:
                QtWidgets.QToolTip.showText(
                    QtGui.QCursor.pos(),
                    "Aggancio reciproco già in corso…",
                    self,
                    QtCore.QRect(),
                    2000,
                )
                return
            self._snap_reciprocal_worker_pending = True
            hub.submit(
                "snap_reciprocal_fail",
                {
                    "series_meta": self._series_meta_worker_payload(),
                    "pairs": self._reciprocal_pairs_cache or (),
                    "column_idx": int(col_idx),
                    "trace_idx": int(trace_idx),
                    "meta_idx": int(meta_idx),
                    "shot_registry": self._shot_registry_for_monitor(),
                    "prefer_memory": True,
                    "y_revision": int(getattr(self, "_series_y_revision", 0)),
                    "tolerance_bands": self.reciprocal_tolerance_bands().to_dict(),
                },
            )

    def apply_snap_reciprocal_worker_result(
            self, job: object, result: dict[str, object]
        ) -> None:
            self._snap_reciprocal_worker_pending = False
            payload = getattr(job, "payload", None) or {}
            started_rev = int(payload.get("y_revision") or 0)
            if started_rev != int(getattr(self, "_series_y_revision", 0)):
                QtWidgets.QToolTip.showText(
                    QtGui.QCursor.pos(),
                    "I break sono cambiati durante lo snap. Ripeti l'operazione.",
                    self,
                    QtCore.QRect(),
                    2500,
                )
                return
            if str(result.get("status")) != "done":
                reason = str(result.get("reason") or "")
                if reason == "no_matching_fail":
                    msg = "Nessun reciproco FAIL su questo punto."
                elif reason == "locked_or_too_small":
                    msg = (
                        "Snap non applicabile "
                        "(riferimento bloccato o spostamento troppo piccolo)."
                    )
                else:
                    msg = "Aggancio reciproco non applicabile."
                QtWidgets.QToolTip.showText(
                    QtGui.QCursor.pos(),
                    msg,
                    self,
                    QtCore.QRect(),
                    2500,
                )
                return
            self._apply_snap_reciprocal_result(result, async_persist=True)

    def on_snap_reciprocal_worker_error(self, message: str) -> None:
            self._snap_reciprocal_worker_pending = False
            QtWidgets.QMessageBox.warning(
                self,
                "Aggancio reciproco FAIL",
                f"Calcolo non riuscito:\n{message}",
            )

    def apply_build_fbp_exports_worker_result(
            self, job: object, result: dict[str, object]
        ) -> None:
            del job
            self._fbp_export_worker_pending = False
            ctx = dict(self._fbp_export_pending_ctx or {})
            self._fbp_export_pending_ctx = None
            if ctx:
                exports_raw = result.get("exports") or {}
                exports = {Path(str(k)): dict(v) for k, v in dict(exports_raw).items()}
                self._finish_persist_from_exports(exports, ctx)
            queued = list(getattr(self, "_fbp_export_queue", None) or [])
            self._fbp_export_queue = []
            if queued:
                self._replay_queued_fbp_persists(queued)

    def on_build_fbp_exports_worker_error(self, message: str) -> None:
            self._fbp_export_worker_pending = False
            ctx = dict(self._fbp_export_pending_ctx or {})
            self._fbp_export_pending_ctx = None
            progress = ctx.get("progress")
            if progress is not None:
                try:
                    progress.close()
                except Exception:
                    pass
            on_complete = ctx.get("on_complete")
            if on_complete is not None:
                try:
                    on_complete(0, [], [Path(p) for p in (ctx.get("target_paths") or [])])
                except Exception:
                    pass
            _LOG.warning("Build export FBP su worker non riuscito: %s", message)
            queued = list(getattr(self, "_fbp_export_queue", None) or [])
            self._fbp_export_queue = []
            if queued:
                self._replay_queued_fbp_persists(queued)

    def _replay_queued_fbp_persists(self, queued: list[dict[str, object]]) -> None:
            merged_updates: dict[Path, dict[int, float]] = {}
            callbacks: list[Callable] = []
            progress = None
            async_write = False
            for item in queued:
                for raw_path, traces in dict(item.get("file_updates") or {}).items():
                    path = Path(str(raw_path))
                    bucket = merged_updates.setdefault(path, {})
                    bucket.update({int(tr): float(v) for tr, v in dict(traces).items()})
                cb = item.get("on_complete")
                if cb is not None:
                    callbacks.append(cb)
                if item.get("progress") is not None:
                    progress = item.get("progress")
                async_write = async_write or bool(item.get("async_write"))

            def _chained(
                saved_points: int, saved: list[Path], failed: list[Path]
            ) -> None:
                for cb in callbacks:
                    try:
                        cb(saved_points, saved, failed)
                    except Exception:
                        _LOG.exception("Callback persistenza FBP in coda non riuscito")

            if not merged_updates:
                if callbacks:
                    _chained(0, [], [])
                return
            self._persist_fbp_point_updates_impl(
                merged_updates,
                progress=progress,  # type: ignore[arg-type]
                async_write=async_write,
                on_complete=_chained if callbacks else None,
            )

    def _finish_persist_from_exports(
            self,
            exports: dict[Path, dict[str, object]],
            ctx: dict[str, object],
        ) -> tuple[int, list[Path], list[Path]]:
            file_updates = dict(ctx.get("file_updates") or {})
            target_paths = list(ctx.get("target_paths") or [])
            async_write = bool(ctx.get("async_write"))
            on_complete = ctx.get("on_complete")
            progress = ctx.get("progress")
            memory_writer = getattr(self, "_on_batch_write_fbp_from_memory", None)
            batch_cb = getattr(self, "_on_batch_points_moved", None)
            if not exports or memory_writer is None:
                if batch_cb is not None and file_updates:
                    try:
                        saved_points, saved_paths = batch_cb(file_updates)
                        result = (
                            int(saved_points),
                            [Path(p) for p in saved_paths],
                            [],
                        )
                        if on_complete is not None:
                            on_complete(*result)
                        elif progress is not None:
                            progress.close()
                        return result
                    except Exception:
                        result = (0, [], [Path(p) for p in target_paths])
                        if on_complete is not None:
                            on_complete(*result)
                        elif progress is not None:
                            progress.close()
                        return result
                result = (0, [], [])
                if on_complete is not None:
                    on_complete(*result)
                elif progress is not None:
                    progress.close()
                return result
            try:
                with perf_section(
                    "auto_fix_reciprocal.persist.memory_write",
                    n_files=len(exports),
                ):
                    write_result = memory_writer(
                        exports,
                        async_write=async_write,
                        on_complete=(
                            None
                            if on_complete is None
                            else lambda saved, failed, pts: on_complete(
                                int(pts), saved, failed
                            )
                        ),
                    )
                if (
                    isinstance(write_result, tuple)
                    and len(write_result) >= 1
                    and int(write_result[0]) < 0
                ):
                    return (-1, [], [])
                if (
                    isinstance(write_result, tuple)
                    and len(write_result) >= 3
                ):
                    saved_points, saved_paths, failed_paths = write_result[:3]
                else:
                    saved_points, saved_paths = write_result
                    failed_paths = []
                saved_paths = [Path(p) for p in saved_paths]
                failed_paths = [Path(p) for p in failed_paths]
                if failed_paths:
                    names = ", ".join(p.name for p in failed_paths[:5])
                    if len(failed_paths) > 5:
                        names += f" (+{len(failed_paths) - 5})"
                    _LOG.warning(
                        "Salvataggio fallito su %d file .fbp: %s",
                        len(failed_paths),
                        names,
                    )
                    if on_complete is None:
                        QtWidgets.QMessageBox.warning(
                            self,
                            "Salvataggio .fbp",
                            (
                                f"Salvataggio non riuscito su {len(failed_paths)} file "
                                f".fbp (spesso accesso negato su rete/condivisione):\n"
                                f"{names}\n\n"
                                "Le modifiche restano in memoria: riprova o salva "
                                "di nuovo quando il file non è bloccato."
                            ),
                        )
                    result = (
                        int(saved_points),
                        list(dict.fromkeys(saved_paths)),
                        list(failed_paths),
                    )
                    if on_complete is not None:
                        on_complete(*result)
                    elif progress is not None:
                        progress.close()
                    return result
                missing = {
                    Path(p): file_updates[Path(p)]
                    for p in target_paths
                    if Path(p) not in {Path(ep) for ep in exports}
                }
                if missing and batch_cb is not None:
                    try:
                        extra_pts, extra_paths = batch_cb(missing)
                        saved_points = int(saved_points) + int(extra_pts)
                        saved_paths.extend(Path(p) for p in extra_paths)
                    except Exception:
                        pass
                result = (
                    int(saved_points),
                    list(dict.fromkeys(saved_paths)),
                    [],
                )
                if on_complete is not None:
                    on_complete(*result)
                elif progress is not None:
                    progress.close()
                return result
            except Exception as exc:
                if progress is not None:
                    try:
                        progress.close()
                    except Exception:
                        pass
                _LOG.exception("Persistenza export FBP non riuscita")
                if on_complete is not None:
                    on_complete(0, [], target_paths)
                    return (0, [], list(target_paths))
                QtWidgets.QMessageBox.warning(
                    self,
                    "Salvataggio .fbp",
                    f"Salvataggio non riuscito:\n{exc}",
                )
                return (0, [], list(target_paths))

    def _refresh_dromocrona_grid_window_sync(
            self, *, reciprocal_pairs: tuple | None = None
        ) -> None:
            from dromocrona_grid_data import build_dromocrona_grid_data

            grid = getattr(self, "_dromocrona_grid_window", None)
            if grid is None or not grid.isVisible():
                return
            try:
                series_meta = sort_series_meta_by_file_order(list(self._series_meta))
                shot_registry = self._shot_registry_for_monitor()
                with perf_section("grid.build_sync_gui", n_series=len(series_meta)):
                    grid_data = build_dromocrona_grid_data(
                        series_meta,
                        shot_registry=shot_registry,
                    )
                grid.apply_grid_data(
                    grid_data,
                    raw_series_meta=list(self._series_meta),
                    reciprocal_pairs=reciprocal_pairs,
                )
            except Exception as exc:
                _LOG.warning(
                    "Refresh griglia dromocrone non riuscito: %s", exc, exc_info=True
                )

    def apply_reciprocal_worker_result(
            self, job: object, result: dict[str, object]
        ) -> None:
            self._reciprocal_worker_pending = False
            pending_key = self._reciprocal_pending_key
            self._reciprocal_pending_key = None
            prefer_memory = bool(result.get("prefer_memory"))
            key = self._reciprocal_pairs_cache_fingerprint(prefer_memory=prefer_memory)
            stale = pending_key is not None and pending_key != key
            if stale or self._reciprocal_reschedule_pending:
                prefer_next = bool(
                    prefer_memory or self._reciprocal_reschedule_prefer_memory
                )
                self._reciprocal_reschedule_pending = False
                self._reciprocal_reschedule_prefer_memory = False
                if self._reciprocals_compute_wanted():
                    self._schedule_reciprocal_worker(prefer_memory=prefer_next)
                return
            pairs = result.get("pairs")
            if pairs is None:
                pairs_tuple: tuple = ()
                pairs_map: dict[tuple[int, int], object] = {}
            else:
                pairs_tuple = tuple(pairs)
                pairs_map = reciprocal_pairs_to_map(pairs_tuple)
            pairs_tuple = self._commit_reciprocal_pairs_map(
                pairs_map,
                prefer_memory=prefer_memory,
            )
            fail_maps = self._fail_maps_meta_from_worker_result(result)
            if fail_maps is not None:
                self._reciprocal_fail_maps_meta_cache = fail_maps
                self._refresh_reciprocal_fail_highlights(fail_maps_meta=fail_maps)
            else:
                self._reciprocal_fail_maps_meta_cache = None
                self._refresh_reciprocal_fail_highlights(reciprocal_pairs=pairs_tuple)
            self._schedule_dromocrona_grid_build_worker(
                reciprocal_pairs=pairs_tuple
            )

    def on_reciprocal_worker_error(self, message: str) -> None:
        self._reciprocal_worker_pending = False
        self._reciprocal_pending_key = None
        if self._reciprocal_reschedule_pending and self._reciprocals_compute_wanted():
            prefer = bool(self._reciprocal_reschedule_prefer_memory)
            self._reciprocal_reschedule_pending = False
            self._reciprocal_reschedule_prefer_memory = False
            self._schedule_reciprocal_worker(prefer_memory=prefer)

    def _bump_series_y_revision(self) -> None:
        self._series_y_revision = int(getattr(self, "_series_y_revision", 0)) + 1

    def _queue_reciprocal_patch(
            self,
            meta_idx: int,
            traces: set[int] | frozenset[int] | None = None,
        ) -> None:
            """Accoda un patch incrementale invece di invalidare tutto O(n²)."""
            if not self._reciprocals_compute_wanted():
                return
            if meta_idx < 0 or meta_idx >= len(self._series_meta):
                return
            pending = getattr(self, "_reciprocal_patch_pending", None)
            if pending is None:
                self._reciprocal_patch_pending = {}
                pending = self._reciprocal_patch_pending
            bucket = pending.setdefault(int(meta_idx), set())
            if traces is None:
                bucket.add(-1)
            else:
                if -1 in bucket:
                    return
                bucket.update(int(t) for t in traces)

    def _flush_reciprocal_patch_pending(
            self, *, prefer_memory: bool | None = None
        ) -> tuple | None:
            """Applica i patch in coda; se la cache manca, avvia worker completo."""
            pending = dict(getattr(self, "_reciprocal_patch_pending", {}) or {})
            self._reciprocal_patch_pending = {}
            if not pending:
                return self._reciprocal_pairs_cache
            return self._patch_reciprocal_pairs_cache(
                set(pending.keys()),
                prefer_memory=prefer_memory,
                affected_traces_by_meta=pending,
            )

    def _schedule_reciprocal_worker(self, *, prefer_memory: bool) -> None:
        hub = self._gui_worker
        if hub is None:
            return
        if self._reciprocal_worker_pending:
            self._reciprocal_reschedule_pending = True
            self._reciprocal_reschedule_prefer_memory = bool(
                prefer_memory or self._reciprocal_reschedule_prefer_memory
            )
            return
        key = self._reciprocal_pairs_cache_fingerprint(prefer_memory=prefer_memory)
        self._reciprocal_worker_pending = True
        self._reciprocal_pending_key = key
        self._reciprocal_reschedule_pending = False
        hub.submit(
            "reciprocals",
            {
                "series_meta": self._series_meta_worker_payload(
                    self._series_meta_for_reciprocals()
                ),
                "shot_registry": self._shot_registry_for_monitor(),
                "prefer_memory": bool(prefer_memory),
                "cache_key": key,
                "tolerance_bands": self.reciprocal_tolerance_bands().to_dict(),
            },
        )

    def _compute_reciprocal_pairs_sync(self, *, prefer_memory: bool) -> tuple:
        sorted_meta = self._series_meta_for_reciprocals()
        self._reciprocal_pairs_compute_error = None
        try:
            with perf_section(
                "reciprocal.compute_pairs_map",
                n_series=len(sorted_meta),
                prefer_memory=bool(prefer_memory),
            ):
                pairs_map = compute_reciprocal_pairs_map(
                    sorted_meta,
                    shot_registry=self._shot_registry_for_monitor(),
                    prefer_memory=prefer_memory,
                    tolerance_bands=self.reciprocal_tolerance_bands(),
                )
        except Exception as exc:
            pairs_map = {}
            self._reciprocal_pairs_compute_error = str(exc)
            _LOG.warning("Calcolo reciproci non riuscito: %s", exc, exc_info=True)
        with perf_section("reciprocal.commit_pairs_map"):
            pairs = self._commit_reciprocal_pairs_map(
                pairs_map, prefer_memory=prefer_memory
            )
        self._notify_reciprocal_compute_error()
        return pairs

    def _notify_reciprocal_compute_error(self) -> None:
        err = getattr(self, "_reciprocal_pairs_compute_error", None)
        if not err:
            return
        if self._reciprocal_fail_highlight_enabled() or self._reciprocals_compute_wanted():
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                f"Calcolo reciproci non riuscito:\n{err}",
                self,
                QtCore.QRect(),
                4000,
            )

    def _reciprocal_cache_struct_key(self, *, prefer_memory: bool) -> tuple:
        registry = self._shot_registry_for_monitor()
        paths: list[str] = []
        for meta in self._series_meta_for_reciprocals():
            source = meta.get("source_path")
            if source is not None:
                try:
                    paths.append(str(Path(source).resolve()))
                except Exception:
                    paths.append(str(source))
            else:
                paths.append("")
        reg_key = tuple(sorted((str(k), int(v)) for k, v in registry.items()))
        return (tuple(paths), reg_key, bool(prefer_memory))

    def _commit_reciprocal_pairs_map(
            self,
            pairs_map: dict[tuple[int, int], object],
            *,
            prefer_memory: bool,
            cache_key: object | None = None,
        ) -> tuple:
            pairs_tuple = reciprocal_pairs_from_map(pairs_map)  # type: ignore[arg-type]
            self._reciprocal_pairs_map = dict(pairs_map)
            self._reciprocal_pairs_cache = pairs_tuple
            self._reciprocal_cached_struct_key = self._reciprocal_cache_struct_key(
                prefer_memory=prefer_memory
            )
            if cache_key is not None:
                self._reciprocal_pairs_cache_key = cache_key
            else:
                self._reciprocal_pairs_cache_key = (
                    self._reciprocal_cached_struct_key,
                    int(getattr(self, "_series_y_revision", 0)),
                    self.reciprocal_tolerance_bands().as_cache_key(),
                )
            self._reciprocal_pairs_cache_prefer_memory = bool(prefer_memory)
            return pairs_tuple

    def _patch_reciprocal_pairs_cache(
            self,
            affected_series: int | set[int],
            *,
            prefer_memory: bool | None = None,
            affected_traces_by_meta: dict[int, set[int]] | None = None,
        ) -> tuple:
            if not self._reciprocals_compute_wanted():
                cached = self._reciprocal_pairs_cache
                return () if cached is None else cached
            if isinstance(affected_series, int):
                affected = {int(affected_series)}
            else:
                affected = {int(s) for s in affected_series}
            # Sempre i tempi in RAM: riusare prefer_memory=False (disco) dopo
            # uno spostamento break lascerebbe i FAIL calcolati sui vecchi pick.
            if prefer_memory is None:
                prefer_memory = True
            prefer_memory = bool(prefer_memory)
            idx_to_col = self._series_meta_index_to_column()
            affected_cols = {
                idx_to_col[int(s)] for s in affected if int(s) in idx_to_col
            }
            traces_by_col: dict[int, set[int]] | None = None
            if affected_traces_by_meta:
                traces_by_col = {}
                for meta_idx, traces in affected_traces_by_meta.items():
                    col = idx_to_col.get(int(meta_idx))
                    if col is None:
                        continue
                    traces_by_col[int(col)] = {int(t) for t in traces}
            sorted_meta = self._series_meta_for_reciprocals()
            struct = self._reciprocal_cache_struct_key(prefer_memory=prefer_memory)
            cached_struct = getattr(self, "_reciprocal_cached_struct_key", None)
            if self._reciprocal_pairs_map is None:
                if self._gui_worker is not None:
                    self._schedule_reciprocal_worker(prefer_memory=prefer_memory)
                    cached = self._reciprocal_pairs_cache
                    return () if cached is None else cached
                return self._compute_reciprocal_pairs_sync(prefer_memory=prefer_memory)
            if self._reciprocal_pairs_cache_prefer_memory != prefer_memory:
                if self._gui_worker is not None:
                    self._schedule_reciprocal_worker(prefer_memory=prefer_memory)
                    cached = self._reciprocal_pairs_cache
                    return () if cached is None else cached
                return self._compute_reciprocal_pairs_sync(prefer_memory=prefer_memory)
            # Struttura cambiata (ordine/elenco file): rimappa le coppie e
            # patcha solo le colonne nuove, invece di O(n²) completo.
            if cached_struct != struct:
                old_paths = ()
                old_reg = None
                if isinstance(cached_struct, tuple) and len(cached_struct) >= 2:
                    old_paths = tuple(cached_struct[0] or ())
                    old_reg = cached_struct[1]
                new_paths = tuple(struct[0] or ())
                new_reg = struct[1]
                if old_reg != new_reg:
                    # Cambio shot registry: serve ricalcolo completo.
                    if self._gui_worker is not None:
                        self._schedule_reciprocal_worker(prefer_memory=prefer_memory)
                        cached = self._reciprocal_pairs_cache
                        return () if cached is None else cached
                    return self._compute_reciprocal_pairs_sync(
                        prefer_memory=prefer_memory
                    )
                remapped, new_cols = remap_reciprocal_pairs_map_columns(
                    dict(self._reciprocal_pairs_map),  # type: ignore[arg-type]
                    old_paths,
                    new_paths,
                )
                self._reciprocal_pairs_map = remapped  # type: ignore[assignment]
                self._reciprocal_pairs_cache = reciprocal_pairs_from_map(remapped)
                self._reciprocal_cached_struct_key = struct
                self._reciprocal_fail_maps_meta_cache = None
                affected_cols.update(int(c) for c in new_cols)
                if not affected_cols and not new_cols:
                    # Solo riordino: mappa già valida.
                    return self._commit_reciprocal_pairs_map(
                        remapped, prefer_memory=prefer_memory
                    )
            if self._gui_worker is not None:
                cache_key = self._reciprocal_pairs_cache_fingerprint(
                    prefer_memory=prefer_memory
                )
                self._schedule_reciprocal_patch_worker(
                    affected_cols=affected_cols,
                    traces_by_col=traces_by_col,
                    prefer_memory=prefer_memory,
                    cache_key=cache_key,
                )
                cached = self._reciprocal_pairs_cache
                return () if cached is None else cached
            with perf_section(
                "reciprocal.patch_pairs_map",
                n_cols=len(affected_cols),
                n_trace_filters=len(traces_by_col or {}),
            ):
                pairs_map = patch_reciprocal_pairs_map(
                    dict(self._reciprocal_pairs_map),  # type: ignore[arg-type]
                    sorted_meta,
                    affected_cols,
                    affected_traces_by_series=traces_by_col,
                    shot_registry=self._shot_registry_for_monitor(),
                    prefer_memory=prefer_memory,
                    tolerance_bands=self.reciprocal_tolerance_bands(),
                )
            return self._commit_reciprocal_pairs_map(
                pairs_map, prefer_memory=prefer_memory
            )

    def schedule_dromocrona_grid_refresh(self, *, immediate: bool = False) -> None:
        """Aggiorna griglia dromocrone (se aperta) e/o reciproci solo se richiesti dall'UI."""
        if not self._dromocrona_grid_refresh_wanted() and not self._reciprocals_compute_wanted():
            return
        if not immediate and self.is_drag_active():
            self._grid_refresh_deferred = True
            return
        self._grid_refresh_deferred = False
        if immediate:
            self._dromocrona_grid_refresh_timer.stop()
            self._on_dromocrona_data_refresh_timer()
            return
        self._dromocrona_grid_refresh_timer.start()

    def _on_dromocrona_data_refresh_timer(self) -> None:
        pairs: tuple | None = None
        if self._reciprocals_compute_wanted():
            # I tempi in RAM (curva sul monitor) sono la fonte di verità FAIL.
            prefer_memory = True
            pending = getattr(self, "_reciprocal_patch_pending", None) or {}
            patch_busy = bool(getattr(self, "_reciprocal_patch_worker_pending", False))
            full_busy = bool(getattr(self, "_reciprocal_worker_pending", False))
            if pending and self._reciprocal_pairs_map is not None:
                # Modifiche locali: patch incrementale, niente O(n²).
                pairs = self._flush_reciprocal_patch_pending(prefer_memory=None)
            elif patch_busy or full_busy:
                # Worker già in volo sui tempi correnti: non lanciare un O(n²)
                # da disco che sovrascriverebbe il patch (FAIL resterebbe fermo).
                pairs = self._reciprocal_pairs_cache
            else:
                if pending:
                    self._reciprocal_patch_pending = {}
                pairs = self._get_cached_reciprocal_pairs(prefer_memory=prefer_memory)
            if pairs is None:
                # Worker in corso: tieni l'ultimo risultato invece di svuotare la UI.
                pairs = self._reciprocal_pairs_cache
        if self._dromocrona_grid_refresh_wanted():
            self._schedule_dromocrona_grid_build_worker(reciprocal_pairs=pairs)
        if self._reciprocals_compute_wanted() and not (
            bool(getattr(self, "_reciprocal_patch_worker_pending", False))
            or bool(getattr(self, "_reciprocal_worker_pending", False))
        ):
            # Preferisci mappe FAIL già calcolate sul worker (niente O(pairs) in GUI).
            cached_maps = getattr(self, "_reciprocal_fail_maps_meta_cache", None)
            if cached_maps is not None:
                self._refresh_reciprocal_fail_highlights(fail_maps_meta=cached_maps)
            else:
                self._refresh_reciprocal_fail_highlights(reciprocal_pairs=pairs)

    def _invalidate_reciprocal_pairs_cache(self) -> None:
        self._reciprocal_pairs_cache_key = None
        self._reciprocal_pairs_cache = None
        self._reciprocal_pairs_map = None
        self._reciprocal_cached_struct_key = None
        self._reciprocal_pairs_cache_prefer_memory = False
        self._reciprocal_patch_pending = {}
        self._reciprocal_fail_maps_meta_cache = None

    def _reciprocal_pairs_cache_fingerprint(self, *, prefer_memory: bool) -> object:
        return (
            self._reciprocal_cache_struct_key(prefer_memory=prefer_memory),
            int(getattr(self, "_series_y_revision", 0)),
            self.reciprocal_tolerance_bands().as_cache_key(),
        )

    def _report_reciprocal_compute_error(self, exc: BaseException) -> None:
        self._reciprocal_pairs_compute_error = str(exc)
        traceback.print_exc()
        QtWidgets.QToolTip.showText(
            QtGui.QCursor.pos(),
            f"Calcolo reciproci non riuscito: {exc}",
            self,
            QtCore.QRect(),
            4000,
        )

    def _get_cached_reciprocal_pairs(
            self, *, prefer_memory: bool = False
        ) -> tuple | None:
            if not self._reciprocals_compute_wanted():
                self._reciprocal_pairs_compute_error = None
                return ()
            if len(self._series_meta) < 2:
                self._reciprocal_pairs_compute_error = None
                return ()
            pending = getattr(self, "_reciprocal_patch_pending", None) or {}
            if pending and self._reciprocal_pairs_map is not None:
                return self._flush_reciprocal_patch_pending(prefer_memory=None)
            key = self._reciprocal_pairs_cache_fingerprint(prefer_memory=prefer_memory)
            if (
                key == self._reciprocal_pairs_cache_key
                and self._reciprocal_pairs_cache is not None
                and self._reciprocal_pairs_cache_prefer_memory == bool(prefer_memory)
            ):
                self._reciprocal_pairs_compute_error = None
                return self._reciprocal_pairs_cache
            if self._gui_worker is not None:
                self._schedule_reciprocal_worker(prefer_memory=prefer_memory)
                return None
            try:
                pairs = self._compute_reciprocal_pairs_sync(prefer_memory=prefer_memory)
            except Exception as exc:
                self._report_reciprocal_compute_error(exc)
                return ()
            self._reciprocal_pairs_compute_error = None
            return pairs

    def _shot_registry_for_monitor(self) -> dict[str, int]:
        getter = getattr(self, "_get_shot_registry", None)
        if getter is None:
            return {}
        try:
            return dict(getter())
        except Exception:
            return {}

    def _reciprocal_fail_highlight_enabled(self) -> bool:
        chk = getattr(self, "_reciprocal_fail_highlight_chk", None)
        return chk is not None and chk.isChecked()

    def _dromocrona_grid_refresh_wanted(self) -> bool:
        grid = getattr(self, "_dromocrona_grid_window", None)
        return grid is not None and grid.isVisible()

    def _reciprocals_compute_wanted(self) -> bool:
        """Reciproci O(n²) solo se l'utente li sta guardando."""
        if len(self._series_meta) < 2:
            return False
        if self._reciprocal_fail_highlight_enabled():
            return True
        # FAIL anche sul sismogramma → serve comunque il calcolo.
        if bool(getattr(self, "_seismogram_fail_overlay_wanted", False)):
            return True
        grid = getattr(self, "_dromocrona_grid_window", None)
        if grid is None or not grid.isVisible():
            return False
        chk = getattr(grid, "_reciprocal_chk", None)
        return chk is not None and chk.isChecked()

    def reciprocal_fail_deltas_for_source(
            self, source_path: Path | str | None
        ) -> dict[int, float]:
            """Δ FAIL (ms) per traccia del .fbp indicato (vuoto se non calcolati)."""
            if source_path is None or not self._reciprocals_compute_wanted():
                return {}
            series_idx = self.find_series_index(Path(source_path))
            if series_idx is None:
                return {}
            meta = self._series_meta[series_idx]
            raw = meta.get("reciprocal_fail_deltas") or {}
            out: dict[int, float] = {}
            for tr, delta in dict(raw).items():
                try:
                    out[int(tr)] = float(delta)
                except (TypeError, ValueError):
                    continue
            if out:
                return out
            return {
                int(t): 0.0 for t in (meta.get("reciprocal_fail_traces") or ())
            }

    def _on_reciprocal_fail_highlight_toggled(self, _checked: bool) -> None:
        if self._reciprocal_fail_highlight_enabled():
            # Carica FAIL in async; non forzare O(n²) sul thread GUI.
            self.schedule_dromocrona_grid_refresh(immediate=False)
            cached = self._reciprocal_pairs_cache
            if cached is not None:
                self._refresh_reciprocal_fail_highlights(reciprocal_pairs=cached)
            else:
                self._refresh_reciprocal_fail_highlights(reciprocal_pairs=())
            return
        self._refresh_reciprocal_fail_highlights(reciprocal_pairs=())

    def _series_has_reciprocal_fail_spots(self, series_idx: int) -> bool:
        if not self._reciprocal_fail_highlight_enabled():
            return False
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return False
        fail_traces = self._series_meta[series_idx].get("reciprocal_fail_traces")
        return bool(fail_traces)

    def _fail_only_spots_for_series(self, series_idx: int) -> list[dict[str, object]]:
        """Solo i punti FAIL colorati (visibili anche senza hover sulla serie)."""
        self._ensure_spots_base(series_idx)
        meta = self._series_meta[series_idx]
        fail_traces = set(meta.get("reciprocal_fail_traces") or ())
        if not fail_traces:
            return []
        base = meta.get("spots_base") or []
        out: list[dict[str, object]] = []
        for sp in base:
            data = sp.get("data")
            if not isinstance(data, tuple) or len(data) < 2:
                continue
            if int(data[1]) not in fail_traces:
                continue
            out.append(dict(sp))
        return out

    def _notify_reciprocal_fail_changed(self) -> None:
        cb = getattr(self, "_on_reciprocal_fail_changed", None)
        if cb is None:
            return
        try:
            cb()
        except Exception:
            _LOG.warning("Callback reciproci FAIL (sismogramma) non riuscita", exc_info=True)

    def _refresh_reciprocal_fail_highlights(
            self,
            affected_series: object | None = None,
            *,
            reciprocal_pairs: tuple | None = None,
            fail_maps_meta: (
                tuple[
                    dict[int, set[int]],
                    dict[int, dict[int, float]],
                    dict[int, dict[int, float]],
                ]
                | None
            ) = None,
        ) -> None:
            if affected_series is None:
                series_indices = range(len(self._series_meta))
            elif isinstance(affected_series, range):
                series_indices = affected_series
            else:
                series_indices = list(affected_series)

            fails: dict[int, set[int]] = {}
            fail_bands_by_series: dict[int, dict[int, float]] = {}
            fail_deltas_by_series: dict[int, dict[int, float]] = {}
            # Calcola FAIL se richiesti da griglia e/o checkbox.
            # Preferisci mappe già derivate sul worker (fail_maps_meta).
            if self._reciprocals_compute_wanted():
                try:
                    if fail_maps_meta is not None:
                        fails, fail_bands_by_series, fail_deltas_by_series = (
                            fail_maps_meta
                        )
                    else:
                        pairs = reciprocal_pairs
                        if pairs is None:
                            pairs = self._get_cached_reciprocal_pairs(prefer_memory=True)
                            if pairs is None:
                                pairs = (
                                    ()
                                    if self._reciprocal_pairs_cache is None
                                    else self._reciprocal_pairs_cache
                                )
                        (
                            fails,
                            fail_bands_by_series,
                            fail_deltas_by_series,
                        ) = self._reciprocal_fail_maps_for_meta_indices(pairs)
                        self._reciprocal_fail_maps_meta_cache = (
                            fails,
                            fail_bands_by_series,
                            fail_deltas_by_series,
                        )
                except Exception:
                    fails = {}
                    fail_bands_by_series = {}
                    fail_deltas_by_series = {}

            show_spots = self._reciprocal_fail_highlight_enabled()
            changed_styles: list[int] = []
            any_fail_map_changed = False
            for series_idx in series_indices:
                if series_idx < 0 or series_idx >= len(self._series_meta):
                    continue
                meta = self._series_meta[series_idx]
                fail_set = set(fails.get(series_idx, set()))
                prev_fail = set(meta.get("reciprocal_fail_traces") or ())
                prev_bands = dict(meta.get("reciprocal_fail_bands") or {})
                prev_deltas = {
                    int(k): float(v)
                    for k, v in dict(meta.get("reciprocal_fail_deltas") or {}).items()
                }
                new_bands = (
                    dict(fail_bands_by_series.get(series_idx, {}))
                    if fail_set
                    else {}
                )
                new_deltas = (
                    {
                        int(k): float(v)
                        for k, v in dict(
                            fail_deltas_by_series.get(series_idx, {})
                        ).items()
                    }
                    if fail_set
                    else {}
                )
                # Aggiorna sempre le mappe FAIL in meta (anche per il sismogramma).
                if fail_set:
                    meta["reciprocal_fail_traces"] = fail_set
                    meta["reciprocal_fail_bands"] = new_bands
                    meta["reciprocal_fail_deltas"] = new_deltas
                else:
                    meta.pop("reciprocal_fail_traces", None)
                    meta.pop("reciprocal_fail_bands", None)
                    meta.pop("reciprocal_fail_deltas", None)
                fail_changed = (
                    fail_set != prev_fail
                    or new_bands != prev_bands
                    or new_deltas != prev_deltas
                )
                if fail_changed:
                    any_fail_map_changed = True
                if meta.get("scatter") is None or meta.get("curve") is None:
                    continue
                if not fail_changed and affected_series is None:
                    continue
                # Spot colorati sul monitor solo con checkbox FAIL attiva.
                if show_spots or self._series_shows_spots(series_idx) or prev_fail:
                    trace_idx = np.asarray(meta.get("trace_idx"), dtype=np.int64)
                    x_arr = np.asarray(meta.get("x"), dtype=np.float64)
                    y_arr = np.asarray(meta.get("y"), dtype=np.float64)
                    if show_spots or self._series_shows_spots(series_idx):
                        self._rebuild_dromocrona_spot_cache(
                            series_idx, x_arr, y_arr, trace_idx
                        )
                    else:
                        self._mark_spots_stale(series_idx)
                    changed_styles.append(int(series_idx))
            if changed_styles:
                for idx in changed_styles:
                    self._apply_series_highlight_style(idx)
            elif affected_series is not None:
                for idx in series_indices:
                    if 0 <= int(idx) < len(self._series_meta):
                        self._apply_series_highlight_style(int(idx))
            if any_fail_map_changed or affected_series is None:
                self._notify_reciprocal_fail_changed()

    def _rewire_dromocrona_grid_callbacks(self) -> None:
        grid = getattr(self, "_dromocrona_grid_window", None)
        if grid is None:
            return
        grid._get_folder = self._get_folder
        grid._get_shot_registry = self._get_shot_registry
        grid._schedule_reciprocal_refresh = self._on_grid_reciprocal_ui_changed
        grid._on_tolerance_bands_changed = (
            lambda bands: self.set_reciprocal_tolerance_bands(bands, refresh=True)
        )
        if hasattr(grid, "sync_tolerance_bands_from_monitor"):
            grid.sync_tolerance_bands_from_monitor(self.reciprocal_tolerance_bands())

    def _on_grid_reciprocal_ui_changed(self) -> None:
        """Toggle reciproci in griglia: aggiorna griglia + mappa FAIL (anche sismogramma)."""
        self.schedule_dromocrona_grid_refresh(immediate=False)
        if not self._reciprocals_compute_wanted():
            self._refresh_reciprocal_fail_highlights(reciprocal_pairs=())

    def _open_dromocrona_grid_window(self) -> None:
        if self._dromocrona_grid_window is None:
            self._dromocrona_grid_window = DromocronaGridWindow(
                parent=None,
                get_series_meta=lambda: self._series_meta,
                get_folder=self._get_folder,
                get_shot_registry=self._get_shot_registry,
            )
            self._rewire_dromocrona_grid_callbacks()
        self._dromocrona_grid_window.show()
        self._dromocrona_grid_window.raise_()
        self._dromocrona_grid_window.activateWindow()
        # Build griglia + reciproci sul worker (non bloccare apertura finestra).
        self.schedule_dromocrona_grid_refresh(immediate=False)

    def _meta_is_auto_fix_locked(self, meta_idx: int) -> bool:
        if meta_idx < 0 or meta_idx >= len(self._series_meta):
            return False
        return bool(self._series_meta[meta_idx].get("auto_fix_locked"))

    def _set_auto_fix_locked(self, meta_idx: int, locked: bool) -> None:
        if meta_idx < 0 or meta_idx >= len(self._series_meta):
            return
        self._series_meta[meta_idx]["auto_fix_locked"] = bool(locked)
        self._apply_series_highlight_style(meta_idx)
        self._sync_auto_fix_ref_lock_btn()

    def _toggle_auto_fix_locked(self, meta_idx: int) -> None:
        self._set_auto_fix_locked(
            meta_idx, not self._meta_is_auto_fix_locked(meta_idx)
        )

    def _sync_auto_fix_ref_lock_btn(self) -> None:
        btn = getattr(self, "_auto_fix_ref_lock_btn", None)
        if btn is None:
            return
        idx = self._locked_series_idx
        blocked = btn.blockSignals(True)
        try:
            if idx is None:
                btn.setChecked(False)
                btn.setEnabled(False)
                btn.setText("Blocca rif.")
            else:
                btn.setEnabled(True)
                locked = self._meta_is_auto_fix_locked(int(idx))
                btn.setChecked(locked)
                btn.setText("Sblocca rif." if locked else "Blocca rif.")
        finally:
            btn.blockSignals(blocked)

    def _on_auto_fix_ref_lock_toggled(self, checked: bool) -> None:
        idx = self._locked_series_idx
        if idx is None:
            self._sync_auto_fix_ref_lock_btn()
            return
        self._set_auto_fix_locked(int(idx), bool(checked))
        self._update_lock_status_label()
        name = self._series_display_name(int(idx))
        state = "fissata" if checked else "sbloccata"
        QtWidgets.QToolTip.showText(
            QtGui.QCursor.pos(),
            f"Dromocrona {name}: {state} come riferimento auto-fix.",
            self,
            QtCore.QRect(),
            2200,
        )

    def _group_series_point_updates(
            self,
            point_map: dict[tuple[int, int], float],
        ) -> dict[Path, dict[int, float]]:
            file_updates: dict[Path, dict[int, float]] = {}
            for (series_idx, trace_idx), target in point_map.items():
                if series_idx < 0 or series_idx >= len(self._series_meta):
                    continue
                meta = self._series_meta[series_idx]
                source = meta.get("source_path")
                if source is None:
                    continue
                fbp_path = Path(source)
                file_updates.setdefault(fbp_path, {})[int(trace_idx)] = float(target)
            return file_updates

    def _apply_file_point_updates_in_memory(
            self,
            file_updates: dict[Path, dict[int, float]],
            *,
            refresh_visual: bool = True,
            reciprocal_prefer_memory: bool = True,
        ) -> set[int]:
            """Aggiorna i break nel monitor senza rileggere i file .fbp."""
            if not file_updates:
                return set()
            path_to_series: dict[Path, list[int]] = {}
            for idx, meta in enumerate(self._series_meta):
                source = meta.get("source_path")
                if source is not None:
                    path_to_series.setdefault(Path(source), []).append(int(idx))
            affected_series: set[int] = set()
            for fbp_path, trace_times in file_updates.items():
                for series_idx in path_to_series.get(Path(fbp_path), []):
                    meta = self._series_meta[series_idx]
                    y = np.array(meta.get("y"), dtype=np.float64, copy=True)
                    changed = False
                    for trace_idx, new_y in trace_times.items():
                        pt_idx = self._series_point_index(meta, int(trace_idx))
                        if 0 <= pt_idx < y.size:
                            y[pt_idx] = max(0.0, float(new_y))
                            changed = True
                    if changed:
                        meta["y"] = y
                        affected_series.add(int(series_idx))
            if refresh_visual:
                for series_idx in affected_series:
                    self._refresh_series_visual(
                        series_idx, fit_range=False, sanitize=False
                    )
            if reciprocal_prefer_memory and affected_series:
                self._patch_reciprocal_pairs_cache(
                    affected_series, prefer_memory=True
                )
            return affected_series

    def _notify_batch_points_saved(
            self,
            saved_paths: list[Path],
            *,
            reload_from_disk: bool,
            refresh_ui: bool = True,
        ) -> None:
            batch_cb = getattr(self, "_on_batch_points_saved", None)
            if batch_cb is None or not saved_paths:
                return
            unique_paths = list(dict.fromkeys(Path(p) for p in saved_paths))
            try:
                batch_cb(
                    unique_paths,
                    reload_from_disk=reload_from_disk,
                    refresh_ui=refresh_ui,
                )
            except TypeError:
                try:
                    batch_cb(unique_paths, reload_from_disk=reload_from_disk)
                except TypeError:
                    batch_cb(unique_paths)

    def _existing_shot_abs_ref_ms(self, meta: dict[str, object]) -> float | None:
        raw_ref = meta.get("shot_abs_ref_ms")
        try:
            ref = float(raw_ref) if raw_ref is not None else float("nan")
        except (TypeError, ValueError):
            return None
        if not math.isfinite(ref):
            return None
        return float(ref)

    @staticmethod
    def _qt_wrapper_alive(obj: object) -> bool:
        if obj is None:
            return False
        try:
            from PyQt6 import sip
            return not sip.isdeleted(obj)
        except Exception:
            try:
                obj.parentItem()
                return True
            except RuntimeError:
                return False
            except Exception:
                return True

    def _store_fbp_disk_meta(
            self,
            meta: dict[str, object],
            *,
            shot_abs_ref_ms: float | None = None,
            fbp_n_traces: int | None = None,
            fbp_samples: dict[int, int] | None = None,
            fbp_disk_lines: list[str] | None = None,
            fbp_line_by_trace: dict[int, int] | None = None,
        ) -> None:
            if shot_abs_ref_ms is not None and math.isfinite(float(shot_abs_ref_ms)):
                meta["shot_abs_ref_ms"] = float(shot_abs_ref_ms)
            if fbp_n_traces is not None and int(fbp_n_traces) > 0:
                meta["fbp_n_traces"] = int(fbp_n_traces)
            if fbp_samples:
                meta["fbp_samples"] = {int(k): int(v) for k, v in fbp_samples.items()}
            if fbp_disk_lines:
                meta["fbp_disk_lines"] = list(fbp_disk_lines)
            if fbp_line_by_trace:
                meta["fbp_line_by_trace"] = {
                    int(k): int(v) for k, v in fbp_line_by_trace.items()
                }

    def _ensure_fbp_disk_template(self, meta: dict[str, object], fbp_path: Path) -> bool:
            from fbp_io import (
                build_fbp_lines_from_break_map,
                fbp_lines_have_corruption,
                normalize_fbp_disk_lines,
            )

            lines = meta.get("fbp_disk_lines")
            if isinstance(lines, list) and lines:
                if fbp_lines_have_corruption(lines):
                    n_target = int(meta.get("fbp_n_traces") or 0) or len(lines)
                    lines = normalize_fbp_disk_lines(lines, n_traces=n_target)
                    rebuilt = {i: i for i in range(len(lines))}
                    self._store_fbp_disk_meta(
                        meta,
                        fbp_disk_lines=lines,
                        fbp_line_by_trace=rebuilt,
                        fbp_n_traces=len(lines),
                    )
                else:
                    rebuilt = _fbp_line_by_trace_from_lines(lines)
                    if rebuilt:
                        self._store_fbp_disk_meta(meta, fbp_line_by_trace=rebuilt)
                return True
            # Durante import batch evita letture disco per ogni serie (lazy al primo edit).
            if self._series_batch_depth > 0:
                return False
            template = fbp_disk_write_template(fbp_path)
            if template is not None:
                ref, n_lines, samples, disk_lines, disk_line_by_trace = template
                if fbp_lines_have_corruption(disk_lines):
                    disk_lines = normalize_fbp_disk_lines(disk_lines, n_traces=n_lines)
                    disk_line_by_trace = {i: i for i in range(len(disk_lines))}
                    n_lines = len(disk_lines)
                keep_ref = self._existing_shot_abs_ref_ms(meta)
                self._store_fbp_disk_meta(
                    meta,
                    shot_abs_ref_ms=(keep_ref if keep_ref is not None else ref),
                    fbp_n_traces=n_lines,
                    fbp_samples=samples,
                    fbp_disk_lines=disk_lines,
                    fbp_line_by_trace=disk_line_by_trace,
                )
                return True
            # File assente: costruisci template dai tempi relativi già in memoria.
            trace_arr = np.asarray(meta.get("trace_idx"), dtype=np.int64)
            y = np.asarray(meta.get("y"), dtype=np.float64)
            n_pts = min(int(trace_arr.size), int(y.size))
            raw_ref = meta.get("shot_abs_ref_ms")
            try:
                ref = float(raw_ref) if raw_ref is not None else 0.0
            except (TypeError, ValueError):
                ref = 0.0
            if not math.isfinite(ref):
                ref = 0.0
            break_map: dict[int, float] = {}
            for i in range(n_pts):
                tr = int(trace_arr[i])
                if tr < 0:
                    continue
                y_val = float(y[i])
                if not math.isfinite(y_val):
                    continue
                break_map[tr] = max(0.0, float(ref) + max(0.0, y_val))
            n_lines = int(meta.get("fbp_n_traces") or 0)
            if n_lines <= 0 and break_map:
                n_lines = max(break_map.keys()) + 1
            if n_lines <= 0 and trace_arr.size:
                n_lines = int(trace_arr.max()) + 1
            if n_lines > 0:
                samples_raw = meta.get("fbp_samples")
                samples = (
                    {int(k): int(v) for k, v in samples_raw.items()}
                    if isinstance(samples_raw, dict)
                    else {}
                )
                disk_lines = build_fbp_lines_from_break_map(
                    n_lines, break_map, samples=samples
                )
                if disk_lines:
                    disk_line_by_trace = {i: i for i in range(len(disk_lines))}
                    self._store_fbp_disk_meta(
                        meta,
                        shot_abs_ref_ms=ref,
                        fbp_n_traces=len(disk_lines),
                        fbp_samples=samples,
                        fbp_disk_lines=disk_lines,
                        fbp_line_by_trace=disk_line_by_trace,
                    )
                    return True
            try:
                disk_lines = fbp_path.read_text(
                    encoding="utf-8", errors="replace"
                ).splitlines()
            except Exception:
                return False
            if not disk_lines:
                return False
            if fbp_lines_have_corruption(disk_lines):
                disk_lines = normalize_fbp_disk_lines(disk_lines)
            disk_line_by_trace = _fbp_line_by_trace_from_lines(disk_lines)
            keep_ref = self._existing_shot_abs_ref_ms(meta)
            self._store_fbp_disk_meta(
                meta,
                shot_abs_ref_ms=(keep_ref if keep_ref is not None else 0.0),
                fbp_n_traces=max(len(disk_lines), len(disk_line_by_trace)),
                fbp_disk_lines=disk_lines,
                fbp_line_by_trace=disk_line_by_trace,
            )
            return True

    @staticmethod
    def _normalize_fbp_path(path: Path) -> Path:
        try:
            return path.resolve()
        except Exception:
            return Path(path)

    def _lookup_path_updates(
            self,
            updates_by_path: dict[Path, dict[int, float]],
            fbp_path: Path,
        ) -> dict[int, float] | None:
        key = self._normalize_fbp_path(fbp_path)
        direct = updates_by_path.get(key)
        if direct:
            return direct
        for raw_path, trace_times in updates_by_path.items():
            if self._normalize_fbp_path(Path(raw_path)) == key:
                return trace_times
        return None

    def _shot_abs_ref_for_series_meta(
            self, meta: dict[str, object], fbp_path: Path
    ) -> float | None:
        raw_ref = meta.get("shot_abs_ref_ms")
        if raw_ref is not None and math.isfinite(float(raw_ref)):
            return float(raw_ref)
        if self._ensure_fbp_disk_template(meta, fbp_path):
            raw_ref = meta.get("shot_abs_ref_ms")
            if raw_ref is not None and math.isfinite(float(raw_ref)):
                return float(raw_ref)
        return None

    def _ensure_all_series_disk_templates(self) -> None:
        for meta in self._series_meta:
            source = meta.get("source_path")
            if source is None:
                continue
            try:
                self._ensure_fbp_disk_template(meta, Path(source))
            except Exception:
                continue

    def build_fbp_disk_exports(
            self,
            fbp_paths: list[Path],
            file_updates: dict[Path, dict[int, float]] | None = None,
        ) -> dict[Path, dict[str, object]]:
            """Esporta dromocrone in memoria pronte per scrittura .fbp senza rilettura."""
            updates_by_path: dict[Path, dict[int, float]] = {}
            if file_updates:
                for raw_path, trace_times in file_updates.items():
                    if not trace_times:
                        continue
                    updates_by_path[self._normalize_fbp_path(Path(raw_path))] = {
                        int(tr): float(val) for tr, val in trace_times.items()
                    }
            path_list: list[Path] = [
                self._normalize_fbp_path(Path(p)) for p in fbp_paths
            ]
            seen_paths = set(path_list)
            if file_updates:
                for raw_path in file_updates:
                    norm = self._normalize_fbp_path(Path(raw_path))
                    if norm not in seen_paths:
                        path_list.append(norm)
                        seen_paths.add(norm)
            exports: dict[Path, dict[str, object]] = {}
            for raw_path in path_list:
                fbp_path = Path(raw_path)
                changed_traces = self._lookup_path_updates(updates_by_path, fbp_path)
                if file_updates is not None and not changed_traces:
                    continue
                series_idx = self.find_series_index(fbp_path)
                if series_idx is None:
                    continue
                meta = self._series_meta[series_idx]
                if not self._ensure_fbp_disk_template(meta, fbp_path):
                    continue
                ref = self._shot_abs_ref_for_series_meta(meta, fbp_path)
                n_traces = int(meta.get("fbp_n_traces") or 0)
                samples = meta.get("fbp_samples")
                if ref is None or n_traces <= 0:
                    continue
                if not isinstance(samples, dict):
                    samples = {}
                if changed_traces is None:
                    trace_idx = np.asarray(meta.get("trace_idx"), dtype=np.int64)
                    y_rel = np.asarray(meta.get("y"), dtype=np.float64)
                    if trace_idx.size == 0 or y_rel.size == 0:
                        continue
                    changed_traces = {
                        int(tr): float(y)
                        for tr, y in zip(trace_idx, y_rel)
                        if math.isfinite(float(y))
                    }
                if not changed_traces:
                    continue
                if n_traces <= 0:
                    n_traces = max(changed_traces.keys()) + 1
                exports[fbp_path] = {
                    "changed_traces": dict(changed_traces),
                    "shot_abs_ref_ms": float(ref),
                    "n_traces": n_traces,
                    "samples_by_trace": dict(samples),
                    "fbp_disk_lines": meta.get("fbp_disk_lines"),
                    "fbp_line_by_trace": meta.get("fbp_line_by_trace"),
                    "linked_sgy": meta.get("sgy_path"),
                }
            return exports

    def _persist_fbp_point_updates(
            self,
            file_updates: dict[Path, dict[int, float]],
            *,
            progress: QtWidgets.QProgressDialog | None = None,
            progress_value: int | None = None,
            async_write: bool = False,
            on_complete: Callable[[int, list[Path], list[Path]], None] | None = None,
        ) -> tuple[int, list[Path]]:
            if not file_updates:
                return 0, []
            with perf_section(
                "auto_fix_reciprocal.persist.total",
                n_files=len(file_updates),
                n_points=sum(len(v) for v in file_updates.values()),
            ):
                return self._persist_fbp_point_updates_impl(
                    file_updates,
                    progress=progress,
                    progress_value=progress_value,
                    async_write=async_write,
                    on_complete=on_complete,
                )

    def _persist_fbp_point_updates_impl(
            self,
            file_updates: dict[Path, dict[int, float]],
            *,
            progress: QtWidgets.QProgressDialog | None = None,
            progress_value: int | None = None,
            async_write: bool = False,
            on_complete: Callable[[int, list[Path], list[Path]], None] | None = None,
        ) -> tuple[int, list[Path]]:
            if not file_updates:
                return 0, []
            if progress is not None:
                n_files = len(file_updates)
                n_points = sum(len(values) for values in file_updates.values())
                progress.setLabelText(
                    "Salvataggio break aggiornati…\n"
                    f"{n_points} punti su {n_files} file"
                )
                if progress_value is not None:
                    progress.setValue(int(progress_value))
                QtWidgets.QApplication.processEvents()
            target_paths = list(dict.fromkeys(Path(p) for p in file_updates))
            n_points = sum(len(values) for values in file_updates.values())
            memory_writer = getattr(self, "_on_batch_write_fbp_from_memory", None)
            batch_cb = getattr(self, "_on_batch_points_moved", None)
            hub = self._gui_worker
            if hub is not None and memory_writer is not None and file_updates:
                ctx: dict[str, object] = {
                    "file_updates": file_updates,
                    "target_paths": target_paths,
                    "n_points": n_points,
                    "async_write": bool(async_write),
                    "on_complete": on_complete,
                    "progress": progress,
                }
                if self._fbp_export_worker_pending:
                    queue = getattr(self, "_fbp_export_queue", None)
                    if queue is None:
                        queue = []
                        self._fbp_export_queue = queue
                    queue.append(ctx)
                    return -1, []
                self._fbp_export_worker_pending = True
                self._fbp_export_pending_ctx = ctx
                hub.submit(
                    "build_fbp_disk_exports",
                    {
                        "series_meta": self._series_meta_fbp_export_payload(),
                        "file_updates": {
                            str(p): {int(tr): float(v) for tr, v in vals.items()}
                            for p, vals in file_updates.items()
                        },
                    },
                )
                return -1, []
            self._ensure_all_series_disk_templates()
            if memory_writer is not None and file_updates:
                with perf_section("auto_fix_reciprocal.persist.build_exports"):
                    exports = self.build_fbp_disk_exports(
                        target_paths, file_updates=file_updates
                    )
                if exports:
                    sync_ctx: dict[str, object] = {
                        "file_updates": file_updates,
                        "target_paths": target_paths,
                        "n_points": n_points,
                        "async_write": bool(async_write),
                        "on_complete": on_complete,
                        "progress": progress,
                    }
                    saved_points, saved_paths, failed_paths = (
                        self._finish_persist_from_exports(exports, sync_ctx)
                    )
                    if int(saved_points) < 0:
                        return -1, []
                    if failed_paths:
                        names = ", ".join(p.name for p in failed_paths[:3])
                        raise RuntimeError(
                            f"Salvataggio fallito su {len(failed_paths)} file .fbp: {names}"
                        )
                    return int(saved_points), list(saved_paths)
            if batch_cb is not None:
                try:
                    with perf_section(
                        "auto_fix_reciprocal.persist.batch_callback",
                        n_files=len(file_updates),
                    ):
                        saved_points, saved_paths = batch_cb(file_updates)
                    return int(saved_points), [Path(p) for p in saved_paths]
                except TypeError:
                    saved_paths = batch_cb(file_updates)
                    return n_points, [Path(p) for p in saved_paths]
                except Exception:
                    pass
            if n_points > 4:
                raise RuntimeError(
                    "Salvataggio batch .fbp non disponibile: ricollega il monitor "
                    "dromocrone e riprova."
                )
            saved_points = 0
            saved_paths: list[Path] = []
            with perf_section(
                "auto_fix_reciprocal.persist.per_point_invoke",
                n_points=sum(len(v) for v in file_updates.values()),
            ):
                for fbp_path, trace_times in file_updates.items():
                    for trace_idx, target in trace_times.items():
                        try:
                            save_ok = self._invoke_point_moved(
                                Path(fbp_path),
                                int(trace_idx),
                                float(target),
                                refresh_monitor=False,
                            )
                        except Exception:
                            continue
                        if not save_ok:
                            continue
                        saved_paths.append(Path(fbp_path))
                        saved_points += 1
                        if saved_points % 25 == 0 and progress is not None:
                            QtWidgets.QApplication.processEvents()
            return saved_points, list(dict.fromkeys(saved_paths))

    def _series_meta_auto_fix_payload(self) -> list[dict[str, object]]:
        rows: list[dict[str, object]] = []
        for meta in self._series_meta:
            row: dict[str, object] = {
                "label": meta.get("label"),
                "source_path": meta.get("source_path"),
                "path": meta.get("path"),
                "shot_trace_idx": meta.get("shot_trace_idx"),
                "auto_fix_locked": bool(meta.get("auto_fix_locked")),
                "y": np.asarray(meta.get("y"), dtype=np.float64).copy(),
            }
            raw_ref = meta.get("shot_abs_ref_ms")
            if raw_ref is not None:
                try:
                    ref_f = float(raw_ref)
                except (TypeError, ValueError):
                    ref_f = float("nan")
                if math.isfinite(ref_f):
                    row["shot_abs_ref_ms"] = float(ref_f)
            trace_raw = meta.get("trace_idx")
            if trace_raw is not None:
                row["trace_idx"] = np.asarray(trace_raw, dtype=np.int64).copy()
            x_raw = meta.get("x")
            if x_raw is not None:
                row["x"] = np.asarray(x_raw, dtype=np.float64).copy()
            rows.append(row)
        return rows

    def _close_auto_fix_progress(self) -> None:
        progress = getattr(self, "_auto_fix_progress", None)
        self._auto_fix_progress = None
        if progress is not None:
            try:
                progress.close()
            except Exception:
                pass

    def on_auto_fix_worker_error(self, message: str) -> None:
        self._auto_fix_worker_pending = False
        self._close_auto_fix_progress()
        QtWidgets.QMessageBox.critical(
            self,
            "Metti in ordine i reciproci",
            f"Calcolo non riuscito:\n{message}",
        )

    def apply_auto_fix_worker_result(
            self, job: object, result: dict[str, object]
        ) -> None:
            self._auto_fix_worker_pending = False
            self._close_auto_fix_progress()
            payload = getattr(job, "payload", None) or {}
            started_rev = int(payload.get("y_revision") or 0)
            if started_rev != int(getattr(self, "_series_y_revision", 0)):
                QtWidgets.QMessageBox.information(
                    self,
                    "Metti in ordine i reciproci",
                    "I break sono cambiati durante il calcolo.\n"
                    "Rilancia auto-correggi per usare i dati aggiornati.",
                )
                flush_report(note="auto_fix_reciprocal_stale")
                return
            status = str(result.get("status") or "done")
            if status == "noop":
                QtWidgets.QToolTip.showText(
                    QtGui.QCursor.pos(),
                    "Reciproci già entro soglia: niente da correggere.",
                    self,
                    QtCore.QRect(),
                    2500,
                )
                flush_report(note="auto_fix_reciprocal_noop")
                return
            try:
                with perf_section("auto_fix_reciprocal.apply_gui"):
                    self._apply_auto_fix_worker_result_impl(result)
            except Exception as exc:
                QtWidgets.QMessageBox.critical(
                    self,
                    "Metti in ordine i reciproci",
                    f"Applicazione risultati non riuscita:\n{exc}",
                )
                flush_report(note="auto_fix_reciprocal_apply_failed")
                return
            # flush_report al termine del salvataggio (sync o async) in finish_auto_fix

    def _apply_auto_fix_worker_result_impl(self, result: dict[str, object]) -> None:
        method = str(result.get("method") or "hybrid")
        method_label = reciprocal_auto_fix_method_label(method)
        elapsed_ms = float(result.get("worker_elapsed_ms") or 0.0)
        elapsed_note = ""
        if elapsed_ms > 0.0:
            elapsed_note = f"\nTempo calcolo worker: {elapsed_ms:.1f} ms"
        fails_before = int(result.get("fails_before") or 0)
        fails_after = int(result.get("fails_after") or 0)
        updated_y = dict(result.get("updated_y") or {})
        for meta_idx_raw, y_vals in updated_y.items():
            meta_idx = int(meta_idx_raw)
            if meta_idx < 0 or meta_idx >= len(self._series_meta):
                continue
            self._series_meta[meta_idx]["y"] = np.asarray(
                y_vals, dtype=np.float64
            )
        updated_refs = dict(result.get("updated_shot_abs_ref") or {})
        restore_shot_refs: list[tuple[Path, float]] = []
        original_refs = dict(result.get("original_shot_abs_ref") or {})
        for meta_idx_raw, new_ref in updated_refs.items():
            meta_idx = int(meta_idx_raw)
            if meta_idx < 0 or meta_idx >= len(self._series_meta):
                continue
            meta = self._series_meta[meta_idx]
            try:
                ref_f = float(new_ref)
            except (TypeError, ValueError):
                continue
            if not math.isfinite(ref_f):
                continue
            source = meta.get("source_path")
            old_ref_raw = original_refs.get(str(meta_idx), original_refs.get(meta_idx))
            if source is not None and old_ref_raw is not None:
                try:
                    old_ref_f = float(old_ref_raw)
                except (TypeError, ValueError):
                    old_ref_f = float("nan")
                if math.isfinite(old_ref_f):
                    restore_shot_refs.append((Path(source), float(old_ref_f)))
            meta["shot_abs_ref_ms"] = float(ref_f)
        if updated_y:
            self._bump_series_y_revision()
        pairs_map = result.get("pairs_map")
        pairs_tuple: tuple = ()
        if isinstance(pairs_map, dict):
            pairs_tuple = self._commit_reciprocal_pairs_map(
                pairs_map, prefer_memory=True  # type: ignore[arg-type]
            )
        else:
            pairs_tuple = tuple(result.get("pairs") or ()) or (
                self._reciprocal_pairs_cache or ()
            )
        col_to_meta = self._column_to_series_meta_index()
        refresh_cols = set(int(c) for c in (result.get("shifted_columns") or ()))
        refresh_cols.update(int(c) for c in (result.get("point_touched_columns") or ()))
        with perf_section(
            "auto_fix_reciprocal.refresh_visuals",
            n_cols=len(refresh_cols),
        ):
            for col_idx in refresh_cols:
                meta_idx = col_to_meta.get(int(col_idx))
                if meta_idx is not None:
                    self._refresh_series_visual(
                        int(meta_idx), fit_range=False, sanitize=False
                    )
        # I pair sono nuovi: invalida mappe FAIL stale e ridisegna i colori
        # (senza questo restano quelli pre-auto-fix finché non si riaccende Evidenzia FAIL).
        self._reciprocal_fail_maps_meta_cache = None
        fail_maps = self._fail_maps_meta_from_worker_result(result)
        if fail_maps is not None:
            self._reciprocal_fail_maps_meta_cache = fail_maps
            self._refresh_reciprocal_fail_highlights(fail_maps_meta=fail_maps)
        else:
            self._refresh_reciprocal_fail_highlights(reciprocal_pairs=pairs_tuple)
        touched: dict[tuple[int, int], float] = {}
        for key, val in dict(result.get("touched") or {}).items():
            parts = str(key).split(",", 1)
            if len(parts) != 2:
                continue
            touched[(int(parts[0]), int(parts[1]))] = float(val)
        original_values: dict[tuple[int, int], float] = {}
        for key, val in dict(result.get("original_values") or {}).items():
            parts = str(key).split(",", 1)
            if len(parts) != 2:
                continue
            original_values[(int(parts[0]), int(parts[1]))] = float(val)
        restore_points: list[tuple[Path, int, float]] = []
        for (series_idx, trace_idx), _target in touched.items():
            if series_idx < 0 or series_idx >= len(self._series_meta):
                continue
            meta = self._series_meta[series_idx]
            source = meta.get("source_path")
            if source is None:
                continue
            old_val = original_values.get((series_idx, trace_idx))
            if old_val is not None:
                restore_points.append(
                    (Path(source), int(trace_idx), float(old_val))
                )
        file_updates = self._group_series_point_updates(touched)
        progress = QtWidgets.QProgressDialog(
            "Salvataggio break aggiornati…",
            "",
            0,
            1,
            self,
        )
        progress.setWindowTitle("Metti in ordine i reciproci")
        progress.setWindowModality(QtCore.Qt.WindowModality.NonModal)
        progress.setMinimumDuration(0)
        progress.show()

        def finish_auto_fix(saved_points: int, saved_paths: list[Path]) -> None:
            progress.close()
            if saved_points > 0:
                self._notify_batch_points_saved(
                    saved_paths,
                    reload_from_disk=False,
                    refresh_ui=False,
                )
            elif self._on_drag_finished is not None:
                try:
                    self._on_drag_finished()
                except Exception:
                    pass
            if saved_points > 0:
                self._last_auto_fix_restore_points = restore_points
                self._last_auto_fix_restore_shot_refs = restore_shot_refs
                self.schedule_dromocrona_grid_refresh(immediate=False)
            lock_note = ""
            locked_columns = result.get("locked_columns") or ()
            if locked_columns:
                lock_note = f"\nDromocrone fisse (riferimento): {len(locked_columns)}"
            perf_report_path = flush_report(note="auto_fix_reciprocal_done")
            report_hint = ""
            if perf_report_path is not None:
                report_hint = f"\n\nReport tempi: {perf_report_path}"
            if method == "shot_shift":
                shift_note = (
                    f"Dromocrone con shot spostato: {len(result.get('shifted_columns') or ())}\n"
                    "Break geofono invariati in assoluto (solo tempo di shot)"
                )
            else:
                shift_note = (
                    f"Dromocrone spostate (shift colonna): {len(result.get('shifted_columns') or ())}\n"
                    f"Colonne con punti corretti: {len(result.get('point_touched_columns') or ())}"
                )
            rollback_note = ""
            if bool(result.get("rollback")):
                rollback_note = (
                    "\n\nAnnullato automaticamente: dopo la prova il numero/entità "
                    "dei FAIL non migliorava, quindi le modifiche sono state "
                    "ripristinate (sembra “non aver fatto nulla”).\n"
                    "Prova un altro metodo (es. Ibrido / Solo lato debole / "
                    "Propagazione da seed) o sblocca eventuali dromocrone fisse."
                )
            elif fails_before > 0 and fails_after >= fails_before and len(touched) == 0:
                rollback_note = (
                    "\n\nNessun punto modificato: spesso i metodi “solo shift” "
                    "non correggono pick locali sparsi (servono metodi con "
                    "correzione punti), oppure gli shift calcolati erano sotto "
                    "la soglia minima."
                )
            QtWidgets.QMessageBox.information(
                self,
                "Metti in ordine i reciproci",
                (
                    f"Metodo: {method_label}\n"
                    f"Rettangoli reciproci fuori soglia: {fails_before} → {fails_after}\n"
                    f"{shift_note}\n"
                    f"Punti aggiornati: {len(touched)}\n"
                    f"Punti salvati su file: {saved_points}"
                    f"{elapsed_note}"
                    f"{lock_note}"
                    f"{rollback_note}"
                    f"{report_hint}"
                ),
            )

        def _rollback_auto_fix_memory() -> None:
            undo_updates: dict[Path, dict[int, float]] = {}
            for path, trace_idx, old_time in restore_points:
                undo_updates.setdefault(Path(path), {})[int(trace_idx)] = float(
                    old_time
                )
            if undo_updates:
                self._apply_file_point_updates_in_memory(
                    undo_updates,
                    refresh_visual=True,
                    reciprocal_prefer_memory=True,
                )
            for path, old_ref in restore_shot_refs:
                series_idx = self.find_series_index(Path(path))
                if series_idx is None:
                    continue
                self._series_meta[series_idx]["shot_abs_ref_ms"] = float(old_ref)
                self._refresh_series_visual(
                    int(series_idx), fit_range=False, sanitize=False
                )
            self._reciprocal_fail_maps_meta_cache = None
            self._refresh_reciprocal_fail_highlights()

        persist_done = {"ok": False}

        def on_persist_complete(
            saved_points: int, saved_paths: list[Path], failed_paths: list[Path]
        ) -> None:
            if persist_done["ok"]:
                return
            persist_done["ok"] = True
            if failed_paths:
                _rollback_auto_fix_memory()
                QtWidgets.QMessageBox.critical(
                    self,
                    "Metti in ordine i reciproci",
                    "Salvataggio batch non riuscito su "
                    f"{len(failed_paths)} file .fbp.\n"
                    "Le modifiche in memoria sono state annullate.",
                )
                progress.close()
                return
            finish_auto_fix(int(saved_points), list(saved_paths))

        try:
            saved_points, saved_paths = self._persist_fbp_point_updates(
                file_updates,
                progress=progress,
                progress_value=0,
                async_write=True,
                on_complete=on_persist_complete,
            )
        except RuntimeError as exc:
            _rollback_auto_fix_memory()
            progress.close()
            QtWidgets.QMessageBox.critical(
                self,
                "Metti in ordine i reciproci",
                f"Salvataggio batch non riuscito:\n{exc}",
            )
            return
        # -1 = worker async (callback già accodato); >=0 = sync (callback o fallback).
        if int(saved_points) >= 0:
            on_persist_complete(int(saved_points), saved_paths, [])

    def _auto_adjust_reciprocal_breaks(self) -> None:
        if self._on_point_moved is None:
            QtWidgets.QMessageBox.warning(
                self,
                "Metti in ordine i reciproci",
                "Salvataggio break non disponibile in questa sessione.",
            )
            return
        hub = getattr(self, "_gui_worker", None)
        if hub is None:
            QtWidgets.QMessageBox.warning(
                self,
                "Metti in ordine i reciproci",
                "Worker background non disponibile.",
            )
            return
        if getattr(self, "_auto_fix_worker_pending", False):
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Auto-correzione già in corso…",
                self,
                QtCore.QRect(),
                2000,
            )
            return
        if getattr(self, "_estimate_missing_worker_pending", False):
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Stima gap già in corso…",
                self,
                QtCore.QRect(),
                2000,
            )
            return
        method_combo = getattr(self, "_reciprocal_auto_fix_method_combo", None)
        method = "hybrid"
        method_label = "Ibrido"
        if method_combo is not None:
            method = str(method_combo.currentData() or "hybrid")
            method_label = str(method_combo.currentText() or "Ibrido")
        self._auto_fix_worker_pending = True
        progress = QtWidgets.QProgressDialog(
            f"Auto-correzione reciproci ({method_label}) sul worker…\n"
            "Puoi continuare a usare il sismogramma.",
            "",
            0,
            0,
            self,
        )
        progress.setWindowTitle("Metti in ordine i reciproci")
        progress.setWindowModality(QtCore.Qt.WindowModality.NonModal)
        progress.setCancelButton(None)
        progress.setMinimumDuration(0)
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        progress.show()
        self._auto_fix_progress = progress
        hub.submit(
            "auto_fix_reciprocals",
            {
                "series_meta": self._series_meta_auto_fix_payload(),
                "shot_registry": self._shot_registry_for_monitor(),
                "prefer_memory": True,
                "y_revision": int(getattr(self, "_series_y_revision", 0)),
                "params": {
                    "method": method,
                    "max_col_iter": int(self._RECIPROCAL_AUTO_FIX_COL_ITER),
                    "max_corner_iter": int(self._RECIPROCAL_AUTO_FIX_CORNER_ITER),
                    "blend_col": float(self._RECIPROCAL_AUTO_FIX_BLEND),
                    "blend_corner": float(self._RECIPROCAL_CORNER_FIX_BLEND),
                    "max_step": float(self._RECIPROCAL_AUTO_FIX_MAX_STEP_MS),
                    "max_step_corner": float(self._RECIPROCAL_CORNER_FIX_MAX_STEP_MS),
                    "min_corner_delta": float(self._RECIPROCAL_CORNER_FIX_MIN_DELTA_MS),
                    "tolerance_bands": self.reciprocal_tolerance_bands().to_dict(),
                },
            },
        )

    def _close_estimate_missing_progress(self) -> None:
        progress = getattr(self, "_estimate_missing_progress", None)
        self._estimate_missing_progress = None
        if progress is not None:
            try:
                progress.close()
            except Exception:
                pass

    def _estimate_missing_reciprocal_breaks(self) -> None:
        if self._on_point_moved is None:
            QtWidgets.QMessageBox.warning(
                self,
                "Stima gap",
                "Salvataggio break non disponibile in questa sessione.",
            )
            return
        if getattr(self, "_auto_fix_worker_pending", False) or getattr(
            self, "_estimate_missing_worker_pending", False
        ):
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Operazione reciproci già in corso…",
                self,
                QtCore.QRect(),
                2000,
            )
            return
        hub = getattr(self, "_gui_worker", None)
        payload = {
            "series_meta": self._series_meta_auto_fix_payload(),
            "shot_registry": self._shot_registry_for_monitor(),
            "prefer_memory": True,
            "y_revision": int(getattr(self, "_series_y_revision", 0)),
            "params": {
                "fill_interp": True,
                "tolerance_bands": self.reciprocal_tolerance_bands().to_dict(),
            },
        }
        if hub is None:
            # Fallback sync (es. test senza worker).
            result = run_reciprocal_estimate_missing(
                list(payload["series_meta"]),  # type: ignore[arg-type]
                dict(payload["shot_registry"]),  # type: ignore[arg-type]
                prefer_memory=True,
                fill_interp=True,
                tolerance_bands=self.reciprocal_tolerance_bands(),
            )
            self.apply_estimate_missing_worker_result(
                type("Job", (), {"payload": payload})(),
                result,
            )
            return
        self._estimate_missing_worker_pending = True
        progress = QtWidgets.QProgressDialog(
            "Stima break mancanti sul worker…\n"
            "Puoi continuare a usare il sismogramma.",
            "",
            0,
            0,
            self,
        )
        progress.setWindowTitle("Stima gap")
        progress.setWindowModality(QtCore.Qt.WindowModality.NonModal)
        progress.setCancelButton(None)
        progress.setMinimumDuration(0)
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        progress.show()
        self._estimate_missing_progress = progress
        hub.submit("estimate_missing_reciprocals", payload)

    def on_estimate_missing_worker_error(self, message: str) -> None:
        self._estimate_missing_worker_pending = False
        self._close_estimate_missing_progress()
        QtWidgets.QMessageBox.critical(
            self,
            "Stima gap",
            f"Calcolo non riuscito:\n{message}",
        )

    def apply_estimate_missing_worker_result(
            self, job: object, result: dict[str, object]
        ) -> None:
            self._estimate_missing_worker_pending = False
            self._close_estimate_missing_progress()
            payload = getattr(job, "payload", None) or {}
            started_rev = int(payload.get("y_revision") or 0)
            if started_rev != int(getattr(self, "_series_y_revision", 0)):
                QtWidgets.QMessageBox.information(
                    self,
                    "Stima gap",
                    "I break sono cambiati durante il calcolo.\n"
                    "Rilancia «Stima gap» per usare i dati aggiornati.",
                )
                return
            status = str(result.get("status") or "done")
            if status == "noop":
                QtWidgets.QToolTip.showText(
                    QtGui.QCursor.pos(),
                    "Nessun break mancante da stimare.",
                    self,
                    QtCore.QRect(),
                    2500,
                )
                return
            try:
                self._apply_estimate_missing_worker_result_impl(result)
            except Exception as exc:
                QtWidgets.QMessageBox.critical(
                    self,
                    "Stima gap",
                    f"Applicazione risultati non riuscita:\n{exc}",
                )

    def _apply_estimate_missing_worker_result_impl(
            self, result: dict[str, object]
        ) -> None:
            updated_y = dict(result.get("updated_y") or {})
            for meta_idx_raw, y_vals in updated_y.items():
                meta_idx = int(meta_idx_raw)
                if 0 <= meta_idx < len(self._series_meta):
                    self._series_meta[meta_idx]["y"] = np.asarray(
                        y_vals, dtype=np.float64
                    )
            if updated_y:
                self._bump_series_y_revision()
            pairs_map = result.get("pairs_map")
            if isinstance(pairs_map, dict):
                self._commit_reciprocal_pairs_map(
                    pairs_map, prefer_memory=True  # type: ignore[arg-type]
                )
            col_to_meta = self._column_to_series_meta_index()
            refresh_cols = set(int(c) for c in (result.get("point_touched_columns") or ()))
            for col_idx in refresh_cols:
                meta_idx = col_to_meta.get(int(col_idx))
                if meta_idx is not None:
                    self._refresh_series_visual(
                        int(meta_idx), fit_range=False, sanitize=False
                    )
            touched: dict[tuple[int, int], float] = {}
            for key, val in dict(result.get("touched") or {}).items():
                parts = str(key).split(",", 1)
                if len(parts) == 2:
                    touched[(int(parts[0]), int(parts[1]))] = float(val)
            original_values: dict[tuple[int, int], float] = {}
            for key, val in dict(result.get("original_values") or {}).items():
                parts = str(key).split(",", 1)
                if len(parts) == 2:
                    original_values[(int(parts[0]), int(parts[1]))] = float(val)
            restore_points: list[tuple[Path, int, float]] = []
            for (series_idx, trace_idx), _target in touched.items():
                if series_idx < 0 or series_idx >= len(self._series_meta):
                    continue
                meta = self._series_meta[series_idx]
                source = meta.get("source_path")
                if source is None:
                    continue
                old_val = original_values.get((series_idx, trace_idx))
                if old_val is not None:
                    restore_points.append(
                        (Path(source), int(trace_idx), float(old_val))
                    )
            file_updates = self._group_series_point_updates(touched)
            n_filled = int(result.get("n_filled") or len(touched))
            n_recip = int(result.get("n_reciprocal") or 0)
            n_interp = int(result.get("n_interp") or 0)
            fails_before = int(result.get("fails_before") or 0)
            fails_after = int(result.get("fails_after") or 0)

            def _rollback_estimate_memory() -> None:
                undo_updates: dict[Path, dict[int, float]] = {}
                for path, trace_idx, old_time in restore_points:
                    undo_updates.setdefault(Path(path), {})[int(trace_idx)] = float(
                        old_time
                    )
                if undo_updates:
                    self._apply_file_point_updates_in_memory(
                        undo_updates,
                        refresh_visual=True,
                        reciprocal_prefer_memory=True,
                    )
                self._reciprocal_fail_maps_meta_cache = None
                self._refresh_reciprocal_fail_highlights()

            persist_done = {"ok": False}

            def after_persist(
                saved_points: int, saved: list[Path], failed: list[Path]
            ) -> None:
                if persist_done["ok"]:
                    return
                persist_done["ok"] = True
                if failed:
                    _rollback_estimate_memory()
                    names = ", ".join(p.name for p in failed[:5])
                    QtWidgets.QMessageBox.warning(
                        self,
                        "Stima gap",
                        (
                            f"Salvataggio non riuscito su {len(failed)} file .fbp"
                            f"{f': {names}' if names else ''}.\n"
                            "Le modifiche in memoria sono state annullate."
                        ),
                    )
                    return
                if saved_points > 0 and saved:
                    self._notify_batch_points_saved(
                        saved,
                        reload_from_disk=False,
                        refresh_ui=False,
                    )
                elif saved_points > 0 and self._on_drag_finished is not None:
                    try:
                        self._on_drag_finished()
                    except Exception:
                        pass
                self._last_auto_fix_restore_points = restore_points
                self._last_auto_fix_restore_shot_refs = []
                self._reciprocal_fail_maps_meta_cache = None
                fail_maps = self._fail_maps_meta_from_worker_result(result)
                if fail_maps is not None:
                    self._reciprocal_fail_maps_meta_cache = fail_maps
                    self._refresh_reciprocal_fail_highlights(fail_maps_meta=fail_maps)
                else:
                    self._refresh_reciprocal_fail_highlights()
                self.schedule_dromocrona_grid_refresh(immediate=False)
                QtWidgets.QToolTip.showText(
                    QtGui.QCursor.pos(),
                    (
                        f"Stima gap: {n_filled} break "
                        f"(reciproci {n_recip}, interp {n_interp}) · "
                        f"FAIL {fails_before}→{fails_after} · salvati {saved_points}"
                    ),
                    self,
                    QtCore.QRect(),
                    4000,
                )

            saved_points, saved_paths = self._persist_fbp_point_updates(
                file_updates,
                async_write=True,
                on_complete=after_persist,
            )
            if int(saved_points) >= 0:
                after_persist(int(saved_points), saved_paths, [])

    def _arm_reciprocal_snap_fail_pick(self) -> None:
        if self._locked_series_idx is None:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Blocca prima una dromocrona (Shift+clic), poi seleziona il punto FAIL.",
                self,
                QtCore.QRect(),
                3000,
            )
            return
        self._reciprocal_snap_armed = True
        QtWidgets.QToolTip.showText(
            QtGui.QCursor.pos(),
            "Clic sul break FAIL evidenziato (o tasto destro sul punto).",
            self,
            QtCore.QRect(),
            3500,
        )

    def _series_has_reciprocal_fail_at(self, meta_idx: int, trace_idx: int) -> bool:
        if meta_idx < 0 or meta_idx >= len(self._series_meta):
            return False
        fail_traces = set(self._series_meta[meta_idx].get("reciprocal_fail_traces") or ())
        return int(trace_idx) in fail_traces

    def _snap_reciprocal_fail_at_spot(self, meta_idx: int, trace_idx: int) -> None:
        if self._on_point_moved is None:
            QtWidgets.QMessageBox.warning(
                self,
                "Aggancio reciproco FAIL",
                "Salvataggio break non disponibile in questa sessione.",
            )
            return
        idx_to_col = self._series_meta_index_to_column()
        col_idx = idx_to_col.get(int(meta_idx))
        if col_idx is None:
            return
        pairs = self._reciprocal_pairs_cache
        if not pairs:
            # Evita O(n²) sulla GUI: richiedi worker e avvisa.
            self._schedule_reciprocal_worker(prefer_memory=True)
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Calcolo reciproci in corso… riprova lo snap tra un momento.",
                self,
                QtCore.QRect(),
                2500,
            )
            return
        matching = reciprocal_pairs_for_fail_spot(pairs, int(col_idx), int(trace_idx))
        if not matching:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Nessun reciproco FAIL su questo punto.",
                self,
                QtCore.QRect(),
                2500,
            )
            return
        hub = self._gui_worker
        if hub is not None:
            self._schedule_snap_reciprocal_fail_worker(
                int(meta_idx), int(trace_idx), col_idx=int(col_idx)
            )
            return
        result = snap_reciprocal_fail_at_spot(
            self._series_meta,
            pairs,
            column_idx=int(col_idx),
            trace_idx=int(trace_idx),
            shot_registry=self._shot_registry_for_monitor(),
            prefer_memory=True,
            tolerance_bands=self.reciprocal_tolerance_bands(),
        )
        if str(result.get("status")) != "done":
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Snap non applicabile (riferimento bloccato o spostamento troppo piccolo).",
                self,
                QtCore.QRect(),
                2500,
            )
            return
        self._apply_snap_reciprocal_result(result)

    def _apply_snap_reciprocal_result(
            self, result: dict[str, object], *, async_persist: bool = False
        ) -> None:
        updated_y = dict(result.get("updated_y") or {})
        for meta_idx_raw, y_vals in updated_y.items():
            meta_idx = int(meta_idx_raw)
            if 0 <= meta_idx < len(self._series_meta):
                self._series_meta[meta_idx]["y"] = np.asarray(
                    y_vals, dtype=np.float64
                )
        if updated_y:
            self._bump_series_y_revision()
        pairs_map = result.get("pairs_map")
        if isinstance(pairs_map, dict):
            self._commit_reciprocal_pairs_map(
                pairs_map, prefer_memory=True  # type: ignore[arg-type]
            )
        col_to_meta = self._column_to_series_meta_index()
        refresh_cols = set(int(c) for c in (result.get("point_touched_columns") or ()))
        for col_idx in refresh_cols:
            meta_idx = col_to_meta.get(int(col_idx))
            if meta_idx is not None:
                self._refresh_series_visual(
                    int(meta_idx), fit_range=False, sanitize=False
                )
        touched: dict[tuple[int, int], float] = {}
        for key, val in dict(result.get("touched") or {}).items():
            parts = str(key).split(",", 1)
            if len(parts) == 2:
                touched[(int(parts[0]), int(parts[1]))] = float(val)
        original_values: dict[tuple[int, int], float] = {}
        for key, val in dict(result.get("original_values") or {}).items():
            parts = str(key).split(",", 1)
            if len(parts) == 2:
                original_values[(int(parts[0]), int(parts[1]))] = float(val)
        restore_points: list[tuple[Path, int, float]] = []
        for (series_idx, trace_idx), _target in touched.items():
            if series_idx < 0 or series_idx >= len(self._series_meta):
                continue
            meta = self._series_meta[series_idx]
            source = meta.get("source_path")
            if source is None:
                continue
            old_val = original_values.get((series_idx, trace_idx))
            if old_val is not None:
                restore_points.append((Path(source), int(trace_idx), float(old_val)))
        file_updates: dict[Path, dict[int, float]] = {}
        for (series_idx, trace_idx), new_val in touched.items():
            if series_idx < 0 or series_idx >= len(self._series_meta):
                continue
            meta = self._series_meta[series_idx]
            source = meta.get("source_path")
            if source is None:
                continue
            fbp_path = Path(source)
            file_updates.setdefault(fbp_path, {})[int(trace_idx)] = float(new_val)
        fails_before = int(result.get("fails_before") or 0)
        fails_after = int(result.get("fails_after") or 0)

        def _rollback_snap_memory() -> None:
            undo_updates: dict[Path, dict[int, float]] = {}
            for path, trace_idx, old_time in restore_points:
                undo_updates.setdefault(Path(path), {})[int(trace_idx)] = float(
                    old_time
                )
            if undo_updates:
                self._apply_file_point_updates_in_memory(
                    undo_updates,
                    refresh_visual=True,
                    reciprocal_prefer_memory=True,
                )
            self._reciprocal_fail_maps_meta_cache = None
            self._refresh_reciprocal_fail_highlights()

        snap_persist_done = {"ok": False}

        def after_persist(
            saved_points: int, _saved: list[Path], failed: list[Path]
        ) -> None:
            if snap_persist_done["ok"]:
                return
            snap_persist_done["ok"] = True
            if failed:
                _rollback_snap_memory()
                names = ", ".join(p.name for p in failed[:5])
                QtWidgets.QMessageBox.warning(
                    self,
                    "Aggancio reciproco",
                    (
                        f"Salvataggio non riuscito su {len(failed)} file .fbp"
                        f"{f': {names}' if names else ''}.\n"
                        "Le modifiche in memoria sono state annullate."
                    ),
                )
                return
            self._last_auto_fix_restore_points = restore_points
            self._last_auto_fix_restore_shot_refs = []
            self._refresh_reciprocal_fail_highlights()
            self._schedule_dromocrona_grid_build_worker(
                reciprocal_pairs=self._reciprocal_pairs_cache
            )
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                f"Aggancio reciproco: FAIL {fails_before} → {fails_after} · "
                f"salvati {saved_points} punti",
                self,
                QtCore.QRect(),
                3500,
            )

        if async_persist:
            saved_points, _saved_paths = self._persist_fbp_point_updates(
                file_updates,
                async_write=True,
                on_complete=after_persist,
            )
            # -1 = worker async (callback già accodato); >=0 = sync senza callback.
            if int(saved_points) >= 0:
                after_persist(int(saved_points), _saved_paths, [])
            return

        saved_points, saved_paths = self._persist_fbp_point_updates(file_updates)
        self._last_auto_fix_restore_points = restore_points
        self._last_auto_fix_restore_shot_refs = []
        if not isinstance(pairs_map, dict):
            affected: dict[int, set[int]] = {}
            for (series_idx, trace_idx), _ in touched.items():
                affected.setdefault(int(series_idx), set()).add(int(trace_idx))
            if affected:
                self._patch_reciprocal_pairs_cache(
                    set(affected.keys()),
                    prefer_memory=None,
                    affected_traces_by_meta=affected,
                )
        self._refresh_reciprocal_fail_highlights()
        self._schedule_dromocrona_grid_build_worker(
            reciprocal_pairs=self._reciprocal_pairs_cache
        )
        QtWidgets.QToolTip.showText(
            QtGui.QCursor.pos(),
            f"Aggancio reciproco: FAIL {fails_before} → {fails_after} · salvati {saved_points} punti",
            self,
            QtCore.QRect(),
            3500,
        )

    def _undo_last_auto_adjust_reciprocal_breaks(self) -> None:
        restore_points = list(getattr(self, "_last_auto_fix_restore_points", []))
        restore_refs = list(getattr(self, "_last_auto_fix_restore_shot_refs", []) or [])
        if not restore_points and not restore_refs:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Nessun auto-fix recente da annullare.",
                self,
                QtCore.QRect(),
                2500,
            )
            return
        if self._on_point_moved is None:
            return

        total = max(1, len(restore_points))
        progress = QtWidgets.QProgressDialog(
            "Ripristino break in corso…",
            "",
            0,
            total,
            self,
        )
        progress.setWindowTitle("Annulla ultima correzione")
        progress.setWindowModality(QtCore.Qt.WindowModality.WindowModal)
        progress.setCancelButton(None)
        progress.setMinimumDuration(0)
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        progress.setValue(0)
        progress.show()
        QtWidgets.QApplication.processEvents()

        restored = 0
        restored_paths: list[Path] = []
        try:
            # Prima i ref shot: abs = ref + y deve usare il riferimento originale.
            for path, old_ref in restore_refs:
                series_idx = self.find_series_index(Path(path))
                if series_idx is None:
                    continue
                self._series_meta[series_idx]["shot_abs_ref_ms"] = float(old_ref)
            undo_updates: dict[Path, dict[int, float]] = {}
            for path, trace_idx, old_time in restore_points:
                undo_updates.setdefault(Path(path), {})[int(trace_idx)] = float(old_time)
            if undo_updates:
                self._apply_file_point_updates_in_memory(
                    undo_updates,
                    refresh_visual=True,
                    reciprocal_prefer_memory=True,
                )
                restored, restored_paths = self._persist_fbp_point_updates(
                    undo_updates,
                    progress=progress,
                )
            progress.setValue(total)
            if restored > 0:
                self._notify_batch_points_saved(
                    restored_paths,
                    reload_from_disk=False,
                    refresh_ui=False,
                )
            elif self._on_drag_finished is not None:
                try:
                    self._on_drag_finished()
                except Exception:
                    pass

            self._last_auto_fix_restore_points = []
            self._last_auto_fix_restore_shot_refs = []
            if restored > 0 or restore_refs:
                self.schedule_dromocrona_grid_refresh(immediate=False)
            QtWidgets.QMessageBox.information(
                self,
                "Annulla ultima correzione",
                f"Ripristinati {restored} punti dell'ultimo auto-aggiustamento.",
            )
        finally:
            progress.close()

    def reciprocal_tolerance_bands(self) -> ReciprocalToleranceBands:
        bands = getattr(self, "_reciprocal_tolerance_bands", None)
        if isinstance(bands, ReciprocalToleranceBands):
            return bands.normalized()
        return DEFAULT_RECIPROCAL_TOLERANCE_BANDS

    def set_reciprocal_tolerance_bands(
        self,
        bands: ReciprocalToleranceBands | dict | None,
        *,
        refresh: bool = True,
    ) -> None:
        if isinstance(bands, ReciprocalToleranceBands):
            new_bands = bands.normalized()
        else:
            new_bands = ReciprocalToleranceBands.from_dict(bands)
        old = self.reciprocal_tolerance_bands()
        if old.as_cache_key() == new_bands.as_cache_key():
            return
        self._reciprocal_tolerance_bands = new_bands
        self._invalidate_reciprocal_pairs_cache()
        grid = getattr(self, "_dromocrona_grid_window", None)
        if grid is not None and hasattr(grid, "sync_tolerance_bands_from_monitor"):
            grid.sync_tolerance_bands_from_monitor(new_bands)
        if refresh:
            self.schedule_dromocrona_grid_refresh(immediate=True)

    def _edit_reciprocal_tolerance_bands(self) -> None:
        current = self.reciprocal_tolerance_bands()
        dlg = ReciprocalToleranceBandsDialog(self, bands=current)
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        new_bands = dlg.bands()
        if new_bands is None:
            return
        self.set_reciprocal_tolerance_bands(new_bands, refresh=True)

    def _edit_reciprocal_fail_colors_from_monitor(self) -> None:
        """Apre il dialog colori FAIL (delega alla main window se collegata)."""
        cb = getattr(self, "_edit_reciprocal_fail_colors_request", None)
        if callable(cb):
            cb()
            return
        from reciprocal_fail_display_prefs import (
            ReciprocalFailDisplayColorsDialog,
            load_reciprocal_fail_display_prefs,
            save_reciprocal_fail_display_prefs,
        )

        current = load_reciprocal_fail_display_prefs()
        dlg = ReciprocalFailDisplayColorsDialog(self, settings=current)
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        result = dlg.settings()
        if result:
            save_reciprocal_fail_display_prefs(result)
        self.refresh_reciprocal_fail_display_colors()

    def refresh_reciprocal_fail_display_colors(self) -> None:
        """Ridisegna i punti FAIL con i colori per fascia di tolleranza correnti."""
        changed = False
        for series_idx, meta in enumerate(self._series_meta):
            if not meta.get("reciprocal_fail_traces"):
                continue
            x = np.asarray(meta.get("x"), dtype=np.float64)
            y = np.asarray(meta.get("y"), dtype=np.float64)
            trace_arr = meta.get("trace_idx")
            if x.size == 0 or y.size == 0:
                continue
            self._rebuild_dromocrona_spot_cache(
                series_idx,
                x,
                y,
                np.asarray(trace_arr, dtype=np.int64) if trace_arr is not None else None,
            )
            if meta.get("scatter") is not None:
                self._apply_series_highlight_style(series_idx)
            changed = True
        if changed:
            self._notify_reciprocal_fail_changed()

    def _reciprocal_fail_spot_style_for_delta(
            self, delta_ms: float, band_tol_ms: float | None = None
        ) -> tuple[object, object]:
        """Brush e pen per FAIL in base alla fascia di tolleranza (near/mid/far)."""
        return self._reciprocal_fail_spot_style_for_band(band_tol_ms)

    def _reciprocal_fail_spot_style_for_band(
            self, band_tol_ms: float | None
        ) -> tuple[object, object]:
        """Rosso = fascia vicina, giallo = media, blu = lontana."""
        bands = self.reciprocal_tolerance_bands().normalized()
        tol = float(band_tol_ms) if band_tol_ms is not None else bands.tol_far_ms
        if tol <= bands.tol_near_ms + 1e-6:
            color = "#e74c3c"   # rosso — fascia vicina
        elif tol <= bands.tol_mid_ms + 1e-6:
            color = "#f1c40f"   # giallo — fascia media
        else:
            color = "#3498db"   # blu — fascia lontana
        qc = QtGui.QColor(color)
        pen_qc = QtGui.QColor(qc)
        return pg.mkBrush(qc), pg.mkPen(pen_qc.darker(140), width=1.6)

    def _dromocrona_view_vb(self) -> pg.ViewBox:
        return self.dromocrona_plot.getViewBox()

    def _dromocrona_view_programmatic_begin(self) -> None:
        self._dromocrona_view_fit_busy = True
        self._dromocrona_view_vb().blockSignals(True)

    def _dromocrona_view_programmatic_end(self) -> None:
        self._dromocrona_view_vb().blockSignals(False)
        self._dromocrona_view_fit_busy = False

    def _dromocrona_view_set_range(
            self,
            x_lo: float,
            x_hi: float,
            y_lo: float,
            y_hi: float,
        ) -> None:
            self._dromocrona_view_vb().setRange(
                xRange=(x_lo, x_hi),
                yRange=(y_lo, y_hi),
                padding=0.0,
            )
            self._sync_linked_x_range(x_lo, x_hi)

    def _sync_linked_x_range(self, x_lo: float, x_hi: float) -> None:
        self._sync_morph_view_x_range(x_lo, x_hi)

    def _compute_dromocrona_data_bounds(self) -> tuple[float, float, float, float] | None:
        """Estensione (con margine) di tutte le curve dromocrona caricate."""
        x_min = math.inf
        x_max = -math.inf
        y_min = math.inf
        y_max = -math.inf
        found = False
        for meta in self._series_meta:
            x = np.asarray(meta.get("x"), dtype=np.float64)
            y = np.asarray(meta.get("y"), dtype=np.float64)
            mask = np.isfinite(x) & np.isfinite(y)
            if not np.any(mask):
                continue
            xf = x[mask]
            yf = y[mask]
            found = True
            x_min = min(x_min, float(np.min(xf)))
            x_max = max(x_max, float(np.max(xf)))
            y_min = min(y_min, float(np.min(yf)))
            y_max = max(y_max, float(np.max(yf)))
        if not found:
            return None
        x_span = max(1.0, x_max - x_min)
        y_span = max(1.0, y_max - y_min)
        x_pad = max(1.0, x_span * 0.06)
        y_pad = max(0.5, y_span * 0.10)
        x_floor = (
            float(self._GEOPHONE_X_ORIGIN)
            if self._uses_geophone_index_x_axis()
            else 0.0
        )
        x_lo = max(x_floor, x_min - x_pad * 0.25)
        if y_min >= -1e-6:
            # Dati tutti ≥ 0: non aprire il riquadro sottozero (evita drag/view negativi).
            y_lo = -max(0.5, y_span * 0.02)
        else:
            y_lo = y_min - y_pad * 0.25
        x_hi = max(x_lo + 1.0, x_max + x_pad)
        y_hi = max(y_lo + 1.0, y_max + y_pad)
        return (x_lo, x_hi, y_lo, y_hi)

    def _default_dromocrona_view_bounds(self) -> tuple[float, float, float, float]:
        x0, x1 = self._EMPTY_X_RANGE
        y0, y1 = self._EMPTY_Y_RANGE
        return (float(x0), float(x1), float(y0), float(y1))

    def _sync_monitor_plot_alignment(self) -> None:
        """Allinea orizzontalmente dromocrona e morfologia."""
        has_morph = self._morphology_row_should_show()
        dromo_left = self.dromocrona_plot.getAxis("left")
        morph_left = self.morph_plot.getAxis("left")
        target_w = max(
            self._MONITOR_LEFT_AXIS_WIDTH_PX,
            int(dromo_left.width() or 0),
            int(morph_left.width() or 0),
        )
        dromo_left.setWidth(target_w)
        morph_left.setWidth(target_w)

        self.dromocrona_plot.hideAxis("bottom")
        self.morph_plot.hideAxis("bottom")

        if has_morph:
            self.morph_plot.showAxis("bottom")
            self.morph_plot.setLabel(
                "bottom", "Distanza lungo linea (m)", color=self._AXIS_COLOR
            )
            self.morph_plot.setMouseEnabled(x=False, y=False)
        else:
            self.dromocrona_plot.showAxis("bottom")
            self.dromocrona_plot.setLabel(
                "bottom", "N° geofono", color=self._AXIS_COLOR
            )
            self.morph_plot.setMouseEnabled(x=False, y=False)

    def _sync_morph_view_x_range(
            self,
            x_lo: float,
            x_hi: float,
            *,
            apply_x_range: bool = True,
        ) -> None:
        morph = self._current_line_morphology()
        if morph is None or morph.trace_count <= 0:
            return
        morph_vb = self.morph_plot.getViewBox()
        data_x_lo, data_x_hi = self._effective_morphology_x_bounds(morph)
        x_span = max(1e-6, float(data_x_hi - data_x_lo))
        y_bounds = getattr(self, "_morph_profile_y_bounds", None)
        if y_bounds is not None:
            y_lo, y_hi = float(y_bounds[0]), float(y_bounds[1])
        else:
            try:
                _x_range, y_range = morph_vb.viewRange()
                y_lo = float(min(y_range))
                y_hi = float(max(y_range))
            except Exception:
                y_lo, y_hi = 0.0, 1.0
        if y_hi <= y_lo:
            y_hi = y_lo + 1.0
        morph_vb.setLimits(
            xMin=data_x_lo,
            xMax=data_x_hi,
            yMin=y_lo,
            yMax=y_hi,
            minXRange=min(1.0, x_span * 0.05),
            maxXRange=x_span * 1.05,
        )
        if apply_x_range:
            morph_vb.setRange(
                xRange=(x_lo, x_hi),
                yRange=(y_lo, y_hi),
                padding=0.0,
            )
        else:
            # Solo Y: l'asse X resta agganciato al dromo (XLink) senza resettare lo zoom.
            morph_vb.setRange(yRange=(y_lo, y_hi), padding=0.0)

    def _resolve_dromocrona_view_bounds(self) -> tuple[float, float, float, float]:
        morph = self._current_line_morphology()
        data_bounds = self._compute_dromocrona_data_bounds()
        if morph is not None and morph.trace_count > 0:
            x_lo, x_hi = self._effective_morphology_x_bounds(morph)
            if data_bounds is not None:
                _dx_lo, _dx_hi, y_lo, y_hi = data_bounds
            else:
                _x0, _x1, y_lo, y_hi = self._default_dromocrona_view_bounds()
            return (x_lo, x_hi, y_lo, y_hi)
        if data_bounds is None:
            return self._default_dromocrona_view_bounds()
        return data_bounds

    def _apply_dromocrona_view_limits(
            self,
            bounds: tuple[float, float, float, float],
            *,
            fit_view: bool = False,
        ) -> None:
            x_lo, x_hi, y_lo, y_hi = bounds
            x_span = max(1e-6, float(x_hi - x_lo))
            y_span = max(1e-6, float(y_hi - y_lo))
            self._dromocrona_view_bounds = bounds
            vb = self._dromocrona_view_vb()
            self._dromocrona_view_programmatic_begin()
            try:
                if not fit_view:
                    try:
                        x_range, y_range = vb.viewRange()
                        vx0, vx1 = float(min(x_range)), float(max(x_range))
                        vy0, vy1 = float(min(y_range)), float(max(y_range))
                        wx = max(0.0, vx1 - vx0)
                        wy = max(0.0, vy1 - vy0)
                        if wx > x_span + 1e-6 or wy > y_span + 1e-6:
                            self._dromocrona_view_set_range(x_lo, x_hi, y_lo, y_hi)
                    except Exception:
                        pass
                vb.setLimits(
                    xMin=x_lo,
                    xMax=x_hi,
                    yMin=y_lo,
                    yMax=y_hi,
                    minXRange=min(1.0, x_span * 0.05),
                    minYRange=min(0.5, y_span * 0.05),
                    maxXRange=x_span * 1.05,
                    maxYRange=y_span * 1.05,
                )
                if fit_view:
                    self._dromocrona_view_set_range(x_lo, x_hi, y_lo, y_hi)
                else:
                    self._clamp_dromocrona_view_to_bounds(inside_programmatic=True)
                    # Aggiorna limiti morfologia senza forzare X = estensione dati
                    # (altrimenti XLink riporta lo zoom dromo a piena linea).
                    try:
                        x_range, _y_range = vb.viewRange()
                        self._sync_morph_view_x_range(
                            float(min(x_range)),
                            float(max(x_range)),
                            apply_x_range=False,
                        )
                    except Exception:
                        self._sync_morph_view_x_range(
                            x_lo, x_hi, apply_x_range=False
                        )
            except Exception:
                pass
            finally:
                self._dromocrona_view_programmatic_end()
                self._sync_monitor_plot_alignment()

    def _update_dromocrona_view_limits_from_data(self, *, fit_view: bool = False) -> None:
        self._apply_dromocrona_view_limits(
            self._resolve_dromocrona_view_bounds(),
            fit_view=fit_view,
        )

    def _clamp_dromocrona_view_to_bounds(self, *, inside_programmatic: bool = False) -> None:
        bounds = getattr(self, "_dromocrona_view_bounds", None)
        if bounds is None:
            return
        x_lo, x_hi, y_lo, y_hi = bounds
        x_span = float(x_hi - x_lo)
        y_span = float(y_hi - y_lo)
        vb = self._dromocrona_view_vb()
        try:
            x_range, y_range = vb.viewRange()
        except Exception:
            return
        vx0, vx1 = float(min(x_range)), float(max(x_range))
        vy0, vy1 = float(min(y_range)), float(max(y_range))
        wx = max(1e-9, vx1 - vx0)
        wy = max(1e-9, vy1 - vy0)
        if wx >= x_span:
            nx0, nx1 = x_lo, x_hi
        else:
            nx0 = max(x_lo, min(vx0, x_hi - wx))
            nx1 = min(x_hi, nx0 + wx)
            nx0 = max(x_lo, nx1 - wx)
        if wy >= y_span:
            ny0, ny1 = y_lo, y_hi
        else:
            ny0 = max(y_lo, min(vy0, y_hi - wy))
            ny1 = min(y_hi, ny0 + wy)
            ny0 = max(y_lo, ny1 - wy)
        if (
            abs(nx0 - vx0) < 1e-6
            and abs(nx1 - vx1) < 1e-6
            and abs(ny0 - vy0) < 1e-6
            and abs(ny1 - vy1) < 1e-6
        ):
            return
        if inside_programmatic:
            self._dromocrona_view_set_range(nx0, nx1, ny0, ny1)
            return
        self._dromocrona_view_programmatic_begin()
        try:
            self._dromocrona_view_set_range(nx0, nx1, ny0, ny1)
        except Exception:
            pass
        finally:
            self._dromocrona_view_programmatic_end()

    def _on_dromocrona_view_range_changed(self, *_args) -> None:
        if getattr(self, "_dromocrona_view_fit_busy", False):
            return
        self._invalidate_all_scene_pick_caches()
        self._clamp_dromocrona_view_to_bounds()

    def _fit_view_positive_quadrant(self) -> None:
        """Inquadra le dromocrone e limita pan/zoom all'estensione dei dati."""
        self._update_dromocrona_view_limits_from_data(fit_view=True)

    def _uses_geophone_index_x_axis(self) -> bool:
        """True se l'asse X è il numero geofono (1…N), non la distanza in metri."""
        morph = self._current_line_morphology()
        return morph is None or morph.trace_count <= 0

    @staticmethod
    def _trace_idx_from_x(x_val: float) -> int:
        """Da coordinata X display (geofono 1-based) a indice traccia 0-based."""
        return max(0, int(round(float(x_val))) - FbpVelocityMonitorWindow._GEOPHONE_X_ORIGIN)

    def _trace_idx_array_from_display_x(self, x: np.ndarray) -> np.ndarray:
        x_arr = np.asarray(x, dtype=np.float64).ravel()
        if x_arr.size == 0:
            return np.array([], dtype=np.int64)
        if self._uses_geophone_index_x_axis():
            return np.maximum(
                np.rint(x_arr).astype(np.int64) - int(self._GEOPHONE_X_ORIGIN),
                0,
            )
        return np.array(
            [self._trace_idx_from_display_x(float(v)) for v in x_arr],
            dtype=np.int64,
        )

    def _display_x_for_traces(self, trace_idx: np.ndarray) -> np.ndarray:
        morph = self._current_line_morphology()
        traces = np.asarray(trace_idx, dtype=np.int64).ravel()
        if morph is None or morph.trace_count <= 0:
            return traces.astype(np.float64) + float(self._GEOPHONE_X_ORIGIN)
        return np.asarray(
            [morph.cumulative_m_for_trace(int(ti)) for ti in traces],
            dtype=np.float64,
        )

    def _trace_idx_from_display_x(self, x_val: float) -> int:
        morph = self._current_line_morphology()
        if morph is None or morph.trace_count <= 0:
            return self._trace_idx_from_x(x_val)
        target_x = float(x_val)
        ordered = sorted(morph.geophones, key=lambda g: int(g.trace_idx))
        if not ordered:
            return self._trace_idx_from_x(x_val)
        if target_x <= float(ordered[0].cumulative_m):
            return int(ordered[0].trace_idx)
        last = ordered[-1]
        if target_x >= float(last.cumulative_m):
            step = max(1e-6, morph.tail_excel_spacing_m())
            return int(
                round(int(last.trace_idx) + (target_x - float(last.cumulative_m)) / step)
            )
        prev = ordered[0]
        for geophone in ordered[1:]:
            x0 = float(prev.cumulative_m)
            x1 = float(geophone.cumulative_m)
            if x0 <= target_x <= x1:
                t0 = int(prev.trace_idx)
                t1 = int(geophone.trace_idx)
                if abs(x1 - x0) < 1e-9:
                    return t1
                frac = (target_x - x0) / (x1 - x0)
                return int(round(t0 + frac * (t1 - t0)))
            prev = geophone
        return int(last.trace_idx)

    def _remap_all_series_display_x(self, *, fit_view: bool = False) -> None:
        for series_idx, meta in enumerate(self._series_meta):
            trace_raw = meta.get("trace_idx")
            if trace_raw is None:
                trace_idx = self._trace_idx_array_from_display_x(
                    np.asarray(meta.get("x"), dtype=np.float64)
                )
                meta["trace_idx"] = trace_idx
            else:
                trace_idx = np.asarray(trace_raw, dtype=np.int64)
            meta["x"] = self._display_x_for_traces(trace_idx)
            self._refresh_series_visual(series_idx, fit_range=False, sanitize=False)
        self._force_dromocrona_curves_redraw()
        if fit_view:
            self._fit_view_positive_quadrant()
        else:
            self._update_dromocrona_view_limits_from_data(fit_view=False)

    def _force_dromocrona_curves_redraw(self) -> None:
        """Ridisegna tutte le curve (evita artefatti dopo batch/remap)."""
        for meta in self._series_meta:
            curve = meta.get("curve")
            if curve is None or not self._qt_wrapper_alive(curve):
                continue
            x = np.asarray(meta.get("x"), dtype=np.float64)
            y = np.asarray(meta.get("y"), dtype=np.float64)
            if x.size == 0 or y.size == 0 or x.size != y.size:
                continue
            try:
                self._configure_dromocrona_curve(curve)
                curve.setData(x, y, connect="all")
                curve.prepareGeometryChange()
                curve.updateItems()
            except RuntimeError:
                meta["curve"] = None

    def series_count(self) -> int:
        return len(self._series_meta)

    def _restore_origin_axes(self) -> None:
        self.dromocrona_plot.addItem(self._zero_line_y)
        self.dromocrona_plot.addItem(self._zero_line_x)

    def begin_series_batch(self) -> None:
        if self._series_batch_depth == 0:
            self._batch_perf_t0 = time.perf_counter()
        self._series_batch_depth += 1

    def sort_series_by_file_order(self) -> None:
        """Allinea l'ordine delle serie al nome file (come colonne griglia / cartella)."""
        n = len(self._series_meta)
        if n < 2:
            return
        order = sorted(range(n), key=lambda i: series_meta_file_sort_key(self._series_meta[i]))
        if order == list(range(n)):
            return
        old_to_new = {old_i: new_i for new_i, old_i in enumerate(order)}
        self._series_meta = [self._series_meta[i] for i in order]
        if self._locked_series_idx is not None:
            self._locked_series_idx = old_to_new.get(
                int(self._locked_series_idx), self._locked_series_idx
            )
        if self._hover_series_idx is not None:
            self._hover_series_idx = old_to_new.get(
                int(self._hover_series_idx), self._hover_series_idx
            )
        cand = getattr(self, "_hover_candidate_idx", None)
        if cand is not None:
            self._hover_candidate_idx = old_to_new.get(int(cand), cand)
        if self._active_drag is not None:
            si, ti, pi = self._active_drag
            self._active_drag = (
                old_to_new.get(int(si), int(si)),
                int(ti),
                int(pi),
            )
        # Non invalidare i reciproci: al prossimo patch la mappa viene rimappata
        # per path (O(n) sulle colonne toccate, non O(n²)).

    def end_series_batch(
        self, *, fit_view: bool = True, schedule_grid_refresh: bool = True
    ) -> dict[str, float]:
        self._series_batch_depth = max(0, self._series_batch_depth - 1)
        stats: dict[str, float] = {}
        if self._series_batch_depth > 0:
            return stats
        self.sort_series_by_file_order()
        t0 = time.perf_counter()
        batch_ms = (
            (t0 - self._batch_perf_t0) * 1000.0
            if self._batch_perf_t0 is not None
            else 0.0
        )
        self._batch_perf_t0 = None
        series_count = len(self._series_meta)
        for idx in range(series_count):
            meta = self._series_meta[idx]
            curve = meta.get("curve")
            if curve is not None:
                self._configure_dromocrona_curve(curve)
        self._force_dromocrona_curves_redraw()
        self._refresh_all_series_styles()
        finalize_ms = (time.perf_counter() - t0) * 1000.0
        self._invalidate_reciprocal_pairs_cache()
        if fit_view and series_count > 0:
            self._fit_view_positive_quadrant()
        if schedule_grid_refresh:
            self.schedule_dromocrona_grid_refresh()
        stats = {
            "series_count": float(series_count),
            "batch_ms": batch_ms,
            "finalize_ms": finalize_ms,
        }
        self._flash_perf_hint(stats)
        self._rebuild_series_visibility_list()
        return stats

    def _flash_perf_hint(self, stats: dict[str, float]) -> None:
        count = int(stats.get("series_count", 0))
        if count < 2:
            return
        batch_ms = stats.get("batch_ms", 0.0)
        finalize_ms = stats.get("finalize_ms", 0.0)
        base = getattr(self, "_window_title_base", "Dromocrone")
        self.setWindowTitle(
            f"{base} — caricamento {count} serie: "
            f"{batch_ms:.0f} ms + finalize {finalize_ms:.0f} ms"
        )
        QtCore.QTimer.singleShot(8000, lambda: self.setWindowTitle(base))

    @staticmethod
    def _configure_dromocrona_curve(curve: pg.PlotDataItem) -> None:
        # Pochi punti per serie: clip+peak downsample creano tagli e V spurii.
        curve.setClipToView(False)
        curve.setDownsampling(auto=False)

    def _series_shows_spots(self, series_idx: int) -> bool:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return False
        drag = self._active_drag
        if drag is not None and int(drag[0]) == int(series_idx):
            return True
        if self._locked_series_idx is not None:
            return self._locked_series_idx == series_idx
        if self._hover_series_idx is not None:
            return self._hover_series_idx == series_idx
        return False

    def _invalidate_spot_style_caches(self, meta: dict[str, object]) -> None:
        meta.pop("spots_highlight", None)
        meta.pop("spots_dim", None)

    def _mark_spots_stale(self, series_idx: int) -> None:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return
        meta = self._series_meta[series_idx]
        meta["spots_base_stale"] = True
        self._invalidate_spot_style_caches(meta)

    def clear_series(self, *, defer_ui: bool = False) -> None:
        self._series_batch_depth = 0
        self._batch_perf_t0 = None
        self._cancel_active_drag()
        self._reset_velocity_line()
        self._invalidate_reciprocal_pairs_cache()
        self._invalidate_all_scene_pick_caches()
        self.dromocrona_plot.clear()
        self._restore_origin_axes()
        self._series_meta.clear()
        self._clear_hover_dwell_state()
        self._hover_series_idx = None
        self._locked_series_idx = None
        if defer_ui:
            # Reload cartella: morph/griglia/lista una sola volta in end_series_batch.
            self._clear_morphology_profile_graphics()
            self._set_morphology_plot_row_visible(False)
            self._sync_dromocrona_mouse_enabled()
            return
        self.schedule_dromocrona_grid_refresh()
        if self._morphology_row_should_show():
            self._refresh_morphology_profile()
        else:
            self._clear_morphology_profile_graphics()
            self._set_morphology_plot_row_visible(False)
        self._fit_view_positive_quadrant()
        self._sync_dromocrona_mouse_enabled()
        self._rebuild_series_visibility_list()

    def _locked_series_source_path(self) -> Path | None:
        locked = self._locked_series_idx
        if locked is None or locked < 0 or locked >= len(self._series_meta):
            return None
        source = self._series_meta[locked].get("source_path")
        return Path(source) if source is not None else None

    def _restore_lock_for_source(self, source_path: Path | None) -> None:
        if source_path is None:
            return
        series_idx = self.find_series_index(source_path)
        if series_idx is None:
            return
        self._locked_series_idx = series_idx
        self._clear_hover_dwell_state()
        self._hover_series_idx = None
        self._refresh_all_series_styles()
        self._update_lock_status_label()

    def is_drag_active(self) -> bool:
        return self._active_drag is not None

    def find_series_index(self, source_path: Path) -> int | None:
        target = self._resolved_source_path_key(source_path)
        if not target:
            return None
        target_l = target.lower()
        for series_idx, meta in enumerate(self._series_meta):
            key = self._series_source_path_key(meta)
            if key == target or key.lower() == target_l:
                return series_idx
        return None

    @staticmethod
    def _resolved_source_path_key(path: object) -> str:
        if path is None:
            return ""
        try:
            return str(Path(path).resolve())
        except Exception:
            return str(path)

    def _series_source_path_key(self, meta: dict[str, object]) -> str:
        cached = meta.get("source_path_key")
        if cached:
            return str(cached)
        key = self._resolved_source_path_key(meta.get("source_path"))
        if key:
            meta["source_path_key"] = key
        return key

    def remove_series_traces(
            self, source_path: Path, trace_indices: set[int] | frozenset[int]
        ) -> bool:
            """Rimuove punti dalla dromocrona in memoria (es. break cancellato)."""
            if not trace_indices:
                return False
            series_idx = self.find_series_index(source_path)
            if series_idx is None:
                return False
            remove = {int(t) for t in trace_indices}
            meta = self._series_meta[series_idx]
            trace_arr = np.asarray(meta.get("trace_idx"), dtype=np.int64)
            y = np.asarray(meta.get("y"), dtype=np.float64)
            if trace_arr.size == 0 or y.size == 0:
                return False
            keep = ~np.isin(trace_arr, np.fromiter(remove, dtype=np.int64, count=len(remove)))
            if np.all(keep):
                return False
            trace_arr = trace_arr[keep]
            y = y[keep]
            if trace_arr.size == 0:
                meta["trace_idx"] = np.array([], dtype=np.int64)
                meta["x"] = np.array([], dtype=np.float64)
                meta["y"] = np.array([], dtype=np.float64)
            else:
                meta["trace_idx"] = trace_arr
                meta["x"] = self._display_x_for_traces(trace_arr)
                meta["y"] = y
            self._bump_series_y_revision()
            self._queue_reciprocal_patch(series_idx, remove)
            self._refresh_series_visual(
                series_idx, fit_range=False, sanitize=False, update_view_limits=False
            )
            self.schedule_dromocrona_grid_refresh(immediate=False)
            return True

    def clear_series_breaks(self, source_path: Path) -> bool:
            """Svuota i pick in memoria per una dromocrona (dopo cancellazione break)."""
            series_idx = self.find_series_index(source_path)
            if series_idx is None:
                return False
            meta = self._series_meta[series_idx]
            meta["trace_idx"] = np.array([], dtype=np.int64)
            meta["x"] = np.array([], dtype=np.float64)
            meta["y"] = np.array([], dtype=np.float64)
            self._bump_series_y_revision()
            # Solo questa serie: niente drop cache O(n²).
            self._queue_reciprocal_patch(series_idx, None)
            self._refresh_series_visual(series_idx, fit_range=False, sanitize=False)
            self.schedule_dromocrona_grid_refresh(immediate=False)
            return True

    def set_series_profile(
            self,
            source_path: Path,
            x: np.ndarray,
            time_ms_rel: np.ndarray,
            *,
            fit_range: bool = False,
            shot_trace_idx: int | None = None,
            shot_channel: int | None = None,
            registry_shot_channel: int | None = None,
            shot_abs_ref_ms: float | None = None,
            fbp_n_traces: int | None = None,
            fbp_samples: dict[int, int] | None = None,
            schedule_grid_refresh: bool = True,
            invalidate_reciprocals: bool = False,
        ) -> bool:
            series_idx = self.find_series_index(source_path)
            if series_idx is None:
                return False
            if self._active_drag is not None and self._active_drag[0] == series_idx:
                return False
            meta = self._series_meta[series_idx]
            trace_idx, y_s = self._sanitize_dromocrona_series_by_trace(x, time_ms_rel)
            if trace_idx.size == 0:
                return False
            meta["trace_idx"] = trace_idx
            meta["x"] = self._display_x_for_traces(trace_idx)
            meta["y"] = y_s
            self._bump_series_y_revision()
            if shot_trace_idx is not None:
                meta["shot_trace_idx"] = int(shot_trace_idx)
                meta["shot_channel"] = int(
                    shot_channel if shot_channel is not None else int(shot_trace_idx) + 1
                )
            if registry_shot_channel is not None and int(registry_shot_channel) > 0:
                meta["registry_shot_channel"] = int(registry_shot_channel)
            self._store_fbp_disk_meta(
                meta,
                shot_abs_ref_ms=shot_abs_ref_ms,
                fbp_n_traces=fbp_n_traces,
                fbp_samples=fbp_samples,
            )
            if source_path is not None:
                self._ensure_fbp_disk_template(meta, Path(source_path))
            if invalidate_reciprocals:
                self._invalidate_reciprocal_pairs_cache()
            else:
                # Profilo aggiornato senza drop cache: patch solo questa serie.
                self._queue_reciprocal_patch(series_idx, None)
            self._refresh_series_visual(series_idx, fit_range=fit_range, sanitize=False)
            if schedule_grid_refresh:
                self.schedule_dromocrona_grid_refresh()
            return True

    def append_series(
            self,
            x: np.ndarray,
            time_ms_rel: np.ndarray,
            source_path: Path | None,
            shot_label: str,
            *,
            sgy_path: Path | None = None,
            fit_view: bool = True,
            shot_trace_idx: int | None = None,
            shot_channel: int | None = None,
            registry_shot_channel: int | None = None,
            shot_abs_ref_ms: float | None = None,
            fbp_n_traces: int | None = None,
            fbp_samples: dict[int, int] | None = None,
        ) -> None:
            trace_idx, y_plot = self._sanitize_dromocrona_series_by_trace(x, time_ms_rel)
            if trace_idx.size == 0:
                return
            x_plot = self._display_x_for_traces(trace_idx)
            series_idx = len(self._series_meta)
            color = self._color_for_series(source_path, series_idx)
            curve_pen, _spot_brush = self._series_curve_pen_and_spot_brush(color, series_idx)
            if shot_trace_idx is None:
                zero_mask = y_plot <= self._SHOT_DROMOCRONA_EPS_MS
                if np.any(zero_mask):
                    shot_trace_idx = int(trace_idx[int(np.argmax(zero_mask))])
                else:
                    shot_trace_idx = int(trace_idx[int(np.argmin(y_plot))])
            shot_channel = int(
                shot_channel if shot_channel is not None else int(shot_trace_idx) + 1
            )
            curve_time = self.dromocrona_plot.plot(
                x_plot,
                y_plot,
                pen=curve_pen,
                connect="all",
            )
            self._configure_dromocrona_curve(curve_time)
            curve_time.setZValue(4)
            scatter = pg.ScatterPlotItem(hoverable=False)
            scatter.setZValue(12)
            scatter.setData(spots=[])
            batch = self._series_batch_depth > 0
            self._series_meta.append(
                {
                    "trace_idx": np.asarray(trace_idx, dtype=np.int64),
                    "x": np.asarray(x_plot, dtype=np.float64),
                    "y": np.asarray(y_plot, dtype=np.float64),
                    "curve": curve_time,
                    "scatter": scatter,
                    "color": color,
                    "source_path": source_path,
                    "source_path_key": self._resolved_source_path_key(source_path),
                    "sgy_path": sgy_path,
                    "label": shot_label,
                    "shot_trace_idx": int(shot_trace_idx),
                    "shot_channel": int(shot_channel),
                    "registry_shot_channel": (
                        int(registry_shot_channel)
                        if registry_shot_channel is not None and int(registry_shot_channel) > 0
                        else 0
                    ),
                    "auto_fix_locked": False,
                    "plot_visible": True,
                    "spots_base_stale": batch,
                }
            )
            self._store_fbp_disk_meta(
                self._series_meta[series_idx],
                shot_abs_ref_ms=shot_abs_ref_ms,
                fbp_n_traces=fbp_n_traces,
                fbp_samples=fbp_samples,
            )
            if source_path is not None:
                self._ensure_fbp_disk_template(
                    self._series_meta[series_idx], Path(source_path)
                )
            meta = self._series_meta[series_idx]
            meta["pen_normal"] = self._curve_pen_for_style(
                color, highlighted=False, dimmed=False
            )
            meta["pen_highlight"] = self._curve_pen_for_style(
                color, highlighted=True, dimmed=False
            )
            meta["pen_dim"] = self._curve_pen_for_style(
                color, highlighted=False, dimmed=True
            )
            if not batch:
                self._rebuild_dromocrona_spot_cache(series_idx, x_plot, y_plot, trace_idx)
                self._apply_series_highlight_style(series_idx)
            scatter.sigClicked.connect(self._on_scatter_clicked)
            self.dromocrona_plot.addItem(scatter)
            self._invalidate_series_scene_pick_cache(series_idx)
            if not batch and (
                self._locked_series_idx is not None or self._hover_series_idx is not None
            ):
                self._refresh_all_series_styles()
            if fit_view and not batch:
                self._fit_view_positive_quadrant()
            if not batch:
                # Nuovo FBP: patch solo le coppie che lo coinvolgono (O(n), non O(n²)).
                self._queue_reciprocal_patch(series_idx, None)
                self.schedule_dromocrona_grid_refresh()
                self._rebuild_series_visibility_list()

    def _series_reference_hint(self, series_idx: int) -> str:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return ""
        meta = self._series_meta[series_idx]
        zero_ch = int(meta.get("shot_channel") or 0)
        reg_ch = int(meta.get("registry_shot_channel") or 0)
        if zero_ch <= 0:
            return ""
        if reg_ch > 0 and reg_ch != zero_ch:
            return (
                f" Zero grafico: can.{zero_ch} (minimo nel .fbp). "
                f"Shot reciproco: can.{reg_ch} (sessione) — "
                "non vincola i pick sul sismogramma."
            )
        return f" Zero grafico: can.{zero_ch} (minimo nel .fbp)."

    def _invoke_point_moved(
            self,
            path: Path,
            trace_idx: int,
            time_ms: float,
            *,
            refresh_monitor: bool = True,
        ) -> bool:
            if self._on_point_moved is None:
                return False
            try:
                result = self._on_point_moved(
                    Path(path),
                    int(trace_idx),
                    float(time_ms),
                    refresh_monitor=refresh_monitor,
                )
                if result is None:
                    return True
                return bool(result)
            except TypeError:
                try:
                    result = self._on_point_moved(
                        Path(path), int(trace_idx), float(time_ms)
                    )
                    if result is None:
                        return True
                    return bool(result)
                except Exception:
                    _LOG.exception(
                        "Salvataggio break dal monitor non riuscito (%s traccia %s)",
                        path,
                        trace_idx,
                    )
                    return False
            except Exception:
                _LOG.exception(
                    "Salvataggio break dal monitor non riuscito (%s traccia %s)",
                    path,
                    trace_idx,
                )
                return False

    @classmethod
    def _color_for_series(
            cls, _source_path: Path | None, series_idx: int
        ) -> str:
            # Colore stabile dall'ordine nel monitor (non dal nome file).
            palette = cls._DROMOCRONA_SERIES_PALETTE
            if not palette:
                return "#0072B2"
            return palette[int(series_idx) % len(palette)]

    def _focus_series_idx(self) -> int | None:
        if self._locked_series_idx is not None:
            return self._locked_series_idx
        return self._hover_series_idx

    def _series_is_highlighted(self, series_idx: int) -> bool:
        focus = self._focus_series_idx()
        return focus is not None and series_idx == focus

    def _series_alpha(self, series_idx: int) -> int:
        focus = self._focus_series_idx()
        if focus is None or series_idx == focus:
            return 255
        return int(self._STATIC_DIM_ALPHA)

    def _series_curve_pen_and_spot_brush(
            self, color: str, series_idx: int
        ) -> tuple[QtGui.QPen, QtGui.QBrush]:
            highlighted = self._series_is_highlighted(series_idx)
            qc = QtGui.QColor(str(color))
            qc.setAlpha(self._series_alpha(series_idx))
            width = (
                self._STATIC_CURVE_WIDTH_HIGHLIGHT
                if highlighted
                else self._STATIC_CURVE_WIDTH
            )
            return pg.mkPen(qc, width=width), pg.mkBrush(qc)

    def _curve_pen_for_style(
            self, color: str, *, highlighted: bool, dimmed: bool
        ) -> QtGui.QPen:
            qc = QtGui.QColor(str(color))
            if dimmed:
                qc.setAlpha(self._STATIC_DIM_ALPHA)
            width = (
                self._STATIC_CURVE_WIDTH_HIGHLIGHT
                if highlighted
                else self._STATIC_CURVE_WIDTH
            )
            return pg.mkPen(qc, width=width)

    def _make_dromocrona_spots_with_style(
            self,
            series_idx: int,
            x: np.ndarray,
            y: np.ndarray,
            trace_idx: np.ndarray | None = None,
            *,
            highlighted: bool,
            dimmed: bool,
        ) -> list[dict[str, object]]:
            spots: list[dict[str, object]] = []
            spot_size = (
                self._STATIC_SPOT_SIZE_HIGHLIGHT
                if highlighted
                else self._STATIC_SPOT_SIZE
            )
            meta = (
                self._series_meta[series_idx]
                if 0 <= series_idx < len(self._series_meta)
                else None
            )
            color = str(meta.get("color", "#0072B2")) if meta else "#0072B2"
            qc = QtGui.QColor(color)
            if dimmed:
                qc.setAlpha(self._STATIC_DIM_ALPHA)
            brush = pg.mkBrush(qc)
            fail_traces = set()
            fail_band_by_trace: dict[int, float] = {}
            if meta:
                fail_traces = set(meta.get("reciprocal_fail_traces") or ())
                fail_band_by_trace = {
                    int(k): float(v)
                    for k, v in dict(meta.get("reciprocal_fail_bands") or {}).items()
                }
            n = min(np.asarray(x).size, np.asarray(y).size)
            traces = (
                np.asarray(trace_idx, dtype=np.int64)
                if trace_idx is not None
                else self._trace_idx_array_from_display_x(np.asarray(x, dtype=np.float64))
            )
            for i in range(n):
                y_val = float(y[i])
                if self._is_shot_dromocrona_point(y_val):
                    continue
                ti = int(traces[i]) if i < traces.size else self._trace_idx_from_display_x(
                    float(x[i])
                )
                if ti in fail_traces:
                    band_tol = fail_band_by_trace.get(ti)
                    spot_brush, spot_pen = self._reciprocal_fail_spot_style_for_band(
                        band_tol
                    )
                    spot_size_use = max(spot_size, self._STATIC_SPOT_SIZE_FAIL)
                else:
                    spot_brush = brush
                    spot_pen = pg.mkPen(None)
                    spot_size_use = spot_size
                spots.append(
                    {
                        "pos": (float(x[i]), y_val),
                        "data": (series_idx, ti),
                        "size": spot_size_use,
                        "brush": spot_brush,
                        "pen": spot_pen,
                    }
                )
            return spots

    def _rebuild_dromocrona_spot_cache(
            self,
            series_idx: int,
            x: np.ndarray,
            y: np.ndarray,
            trace_idx: np.ndarray | None = None,
        ) -> None:
            if series_idx < 0 or series_idx >= len(self._series_meta):
                return
            meta = self._series_meta[series_idx]
            if trace_idx is None:
                trace_idx = np.asarray(meta.get("trace_idx"), dtype=np.int64)
            color = str(meta.get("color", "#0072B2"))
            meta["spots_base"] = self._make_dromocrona_spots_with_style(
                series_idx,
                x,
                y,
                trace_idx,
                highlighted=False,
                dimmed=False,
            )
            meta["spots_base_stale"] = False
            meta.pop("spots_normal", None)
            self._invalidate_spot_style_caches(meta)
            meta["pen_normal"] = self._curve_pen_for_style(
                color, highlighted=False, dimmed=False
            )
            meta["pen_highlight"] = self._curve_pen_for_style(
                color, highlighted=True, dimmed=False
            )
            meta["pen_dim"] = self._curve_pen_for_style(
                color, highlighted=False, dimmed=True
            )

    def _ensure_spots_base(self, series_idx: int) -> None:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return
        meta = self._series_meta[series_idx]
        if meta.get("spots_base") is not None and not meta.get("spots_base_stale", False):
            return
        x = np.asarray(meta.get("x"), dtype=np.float64)
        y = np.asarray(meta.get("y"), dtype=np.float64)
        trace_idx = np.asarray(meta.get("trace_idx"), dtype=np.int64)
        self._rebuild_dromocrona_spot_cache(series_idx, x, y, trace_idx)

    def _styled_spots_from_base(
            self,
            series_idx: int,
            *,
            highlighted: bool,
            dimmed: bool,
        ) -> list[dict[str, object]]:
            if series_idx < 0 or series_idx >= len(self._series_meta):
                return []
            meta = self._series_meta[series_idx]
            base = meta.get("spots_base")
            if not base:
                return []
            if not highlighted and not dimmed:
                return list(base)
            cache_key = "spots_highlight" if highlighted else "spots_dim"
            cached = meta.get(cache_key)
            if cached is not None:
                return list(cached)
            color = str(meta.get("color", "#0072B2"))
            qc = QtGui.QColor(color)
            if dimmed:
                qc.setAlpha(self._STATIC_DIM_ALPHA)
            brush = pg.mkBrush(qc)
            spot_size = (
                self._STATIC_SPOT_SIZE_HIGHLIGHT
                if highlighted
                else self._STATIC_SPOT_SIZE
            )
            fail_traces = set(meta.get("reciprocal_fail_traces") or ())
            styled: list[dict[str, object]] = []
            for sp in base:
                new_sp = dict(sp)
                data = sp.get("data")
                is_fail = (
                    isinstance(data, tuple)
                    and len(data) >= 2
                    and int(data[1]) in fail_traces
                )
                if is_fail:
                    if highlighted:
                        new_sp["size"] = max(
                            float(new_sp.get("size", spot_size)),
                            self._STATIC_SPOT_SIZE_HIGHLIGHT,
                        )
                    styled.append(new_sp)
                    continue
                new_sp["brush"] = brush
                new_sp["pen"] = pg.mkPen(None)
                new_sp["size"] = spot_size
                styled.append(new_sp)
            meta[cache_key] = styled
            return styled

    def _display_spots_for_series(self, series_idx: int) -> list[dict[str, object]]:
        self._ensure_spots_base(series_idx)
        meta = self._series_meta[series_idx]
        highlighted = self._series_is_highlighted(series_idx)
        if highlighted:
            return self._styled_spots_from_base(
                series_idx, highlighted=True, dimmed=False
            )
        # Soft hover: niente dim spots sulle altre; solo lock seleziona/opacizza.
        if self._locked_series_idx is not None:
            return self._styled_spots_from_base(
                series_idx, highlighted=False, dimmed=True
            )
        base = meta.get("spots_base")
        return list(base) if base else []

    def _invalidate_series_scene_pick_cache(self, series_idx: int) -> None:
        if 0 <= series_idx < len(self._series_meta):
            meta = self._series_meta[series_idx]
            for key in (
                "_scene_pick_xy",
                "_scene_pick_xy_key",
                "_scene_pick_bounds",
                "_scene_pick_pick_pt_idx",
                "_scene_pick_pick_trace_idx",
                "_scene_pick_pick_sx",
                "_scene_pick_pick_sy",
                "_scene_pick_grid",
            ):
                meta.pop(key, None)

    def _invalidate_all_scene_pick_caches(self) -> None:
        for idx in range(len(self._series_meta)):
            self._invalidate_series_scene_pick_cache(idx)
        self._hover_last_pick_pos = None

    @staticmethod
    def _build_pick_spatial_grid(
            px: np.ndarray, py: np.ndarray, cell_size: float
        ) -> tuple[dict[tuple[int, int], list[int]], float]:
            grid: dict[tuple[int, int], list[int]] = {}
            cell = max(8.0, float(cell_size))
            for i in range(int(px.size)):
                key = (int(float(px[i]) // cell), int(float(py[i]) // cell))
                grid.setdefault(key, []).append(int(i))
            return grid, cell

    @staticmethod
    def _nearest_pickable_point_scene(
            sx: float,
            sy: float,
            pick_sx: np.ndarray,
            pick_sy: np.ndarray,
            pick_pt_idx: np.ndarray,
            pick_trace_idx: np.ndarray,
            max_d2: float,
            grid: tuple[dict[tuple[int, int], list[int]], float] | None = None,
        ) -> tuple[int, int, float] | None:
            if pick_sx.size == 0:
                return None
            if grid is not None:
                grid_map, cell = grid
                cx = int(sx // cell)
                cy = int(sy // cell)
                candidates: list[int] = []
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        candidates.extend(grid_map.get((cx + dx, cy + dy), ()))
                if candidates:
                    idxs = np.asarray(candidates, dtype=np.int64)
                    d2_arr = (pick_sx[idxs] - sx) * (pick_sx[idxs] - sx) + (
                        pick_sy[idxs] - sy
                    ) * (pick_sy[idxs] - sy)
                    local_idx = int(np.argmin(d2_arr))
                    local = int(idxs[local_idx])
                    best_d2 = float(d2_arr[local_idx])
                    if best_d2 <= max_d2:
                        return (
                            int(pick_pt_idx[local]),
                            int(pick_trace_idx[local]),
                            best_d2,
                        )
            d2_all = (pick_sx - sx) * (pick_sx - sx) + (pick_sy - sy) * (pick_sy - sy)
            local = int(np.argmin(d2_all))
            best_d2 = float(d2_all[local])
            if best_d2 > max_d2:
                return None
            return int(pick_pt_idx[local]), int(pick_trace_idx[local]), best_d2

    def _series_scene_bounds_overlap(
            self,
            series_idx: int,
            sx: float,
            sy: float,
            margin_px: float,
        ) -> bool:
            meta = self._series_meta[series_idx]
            bounds = meta.get("_scene_pick_bounds")
            if bounds is None:
                if self._series_scene_pick_xy(series_idx) is None:
                    return False
                bounds = meta.get("_scene_pick_bounds")
            if bounds is None:
                return True
            sx_min, sx_max, sy_min, sy_max = bounds
            margin = float(margin_px)
            return not (
                sx < float(sx_min) - margin
                or sx > float(sx_max) + margin
                or sy < float(sy_min) - margin
                or sy > float(sy_max) + margin
            )

    def _scene_pick_cache_key(self) -> tuple:
        vb = self._dromocrona_view_vb()
        if vb is None:
            return ()
        try:
            geom = vb.sceneBoundingRect()
            x_range, y_range = vb.viewRange()
            left_axis = self.dromocrona_plot.getAxis("left")
            left_w = int(left_axis.width() if left_axis is not None else 0)
            return (
                left_w,
                int(round(geom.width())),
                int(round(geom.height())),
                float(x_range[0]),
                float(x_range[1]),
                float(y_range[0]),
                float(y_range[1]),
            )
        except Exception:
            return ()

    def _series_scene_pick_xy(
            self, series_idx: int
        ) -> tuple[np.ndarray, np.ndarray] | None:
            if series_idx < 0 or series_idx >= len(self._series_meta):
                return None
            meta = self._series_meta[series_idx]
            cache_key = self._scene_pick_cache_key()
            cached = meta.get("_scene_pick_xy")
            if cached is not None and meta.get("_scene_pick_xy_key") == cache_key:
                return cached
            x = np.asarray(meta.get("x"), dtype=np.float64)
            y = np.asarray(meta.get("y"), dtype=np.float64)
            n = min(x.size, y.size)
            if n == 0:
                return None
            vb = self.dromocrona_plot.getViewBox()
            if vb is None:
                return None
            x_n = x[:n]
            y_n = y[:n]
            sx, sy = self._map_view_xy_to_scene_arrays(vb, x_n, y_n)
            if sx is None or sy is None:
                return None
            meta["_scene_pick_xy"] = (sx, sy)
            meta["_scene_pick_xy_key"] = cache_key
            meta["_scene_pick_bounds"] = (
                float(np.min(sx)),
                float(np.max(sx)),
                float(np.min(sy)),
                float(np.max(sy)),
            )
            pick_mask = (
                np.isfinite(x_n)
                & np.isfinite(y_n)
                & (y_n > float(self._SHOT_DROMOCRONA_EPS_MS))
            )
            pick_pt_idx = np.nonzero(pick_mask)[0].astype(np.int64, copy=False)
            traces = np.asarray(meta.get("trace_idx"), dtype=np.int64)
            if traces.size >= n:
                pick_trace_idx = traces[pick_pt_idx]
            else:
                pick_trace_idx = self._trace_idx_array_from_display_x(
                    x_n[pick_pt_idx]
                )
            pick_sx = sx[pick_pt_idx]
            pick_sy = sy[pick_pt_idx]
            meta["_scene_pick_pick_pt_idx"] = pick_pt_idx
            meta["_scene_pick_pick_trace_idx"] = pick_trace_idx
            meta["_scene_pick_pick_sx"] = pick_sx
            meta["_scene_pick_pick_sy"] = pick_sy
            min_pts = int(getattr(self, "_pick_spatial_min_points", 96))
            if pick_pt_idx.size >= min_pts:
                meta["_scene_pick_grid"] = self._build_pick_spatial_grid(
                    pick_sx,
                    pick_sy,
                    float(getattr(self, "_pick_spatial_cell_px", 36.0)),
                )
            else:
                meta.pop("_scene_pick_grid", None)
            return sx, sy

    def _map_view_xy_to_scene_arrays(
            self,
            vb,
            x: np.ndarray,
            y: np.ndarray,
        ) -> tuple[np.ndarray | None, np.ndarray | None]:
            """View → scene vettoriale (evita mapViewToScene punto-per-punto)."""
            n = int(min(x.size, y.size))
            if n <= 0:
                return None, None
            try:
                # childGroup.transform() mappa coordinate view → scene in pyqtgraph.
                tr = vb.childGroup.transform()
                m11 = float(tr.m11())
                m12 = float(tr.m12())
                m21 = float(tr.m21())
                m22 = float(tr.m22())
                dx = float(tr.dx())
                dy = float(tr.dy())
                xv = np.asarray(x[:n], dtype=np.float64)
                yv = np.asarray(y[:n], dtype=np.float64)
                sx = m11 * xv + m21 * yv + dx
                sy = m12 * xv + m22 * yv + dy
                # Sanity check su un punto (view invertita / transform diversa).
                if n > 0 and np.isfinite(xv[0]) and np.isfinite(yv[0]):
                    probe = vb.mapViewToScene(
                        QtCore.QPointF(float(xv[0]), float(yv[0]))
                    )
                    if (
                        abs(float(probe.x()) - float(sx[0])) > 1.5
                        or abs(float(probe.y()) - float(sy[0])) > 1.5
                    ):
                        raise RuntimeError("view→scene transform mismatch")
                return sx, sy
            except Exception:
                sx = np.empty(n, dtype=np.float64)
                sy = np.empty(n, dtype=np.float64)
                for i in range(n):
                    sp = vb.mapViewToScene(
                        QtCore.QPointF(float(x[i]), float(y[i]))
                    )
                    sx[i] = float(sp.x())
                    sy[i] = float(sp.y())
                return sx, sy
            return sx, sy

    @staticmethod
    def _min_segment_dist_sq_scene(
            px: float, py: float, xs: np.ndarray, ys: np.ndarray
        ) -> float:
            if xs.size < 2:
                return float("inf")
            x0 = xs[:-1]
            y0 = ys[:-1]
            x1 = xs[1:]
            y1 = ys[1:]
            dx = x1 - x0
            dy = y1 - y0
            len_sq = dx * dx + dy * dy
            t = np.clip(
                ((px - x0) * dx + (py - y0) * dy) / np.maximum(len_sq, 1e-12),
                0.0,
                1.0,
            )
            qx = x0 + t * dx
            qy = y0 + t * dy
            ddx = px - qx
            ddy = py - qy
            return float(np.min(ddx * ddx + ddy * ddy))

    def _apply_series_highlight_style(self, series_idx: int) -> None:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return
        meta = self._series_meta[series_idx]
        plot_visible = bool(meta.get("plot_visible", True))
        highlighted = self._series_is_highlighted(series_idx)
        curve = meta.get("curve")
        scatter = meta.get("scatter")
        if curve is not None and not self._qt_wrapper_alive(curve):
            meta["curve"] = None
            curve = None
        if scatter is not None and not self._qt_wrapper_alive(scatter):
            meta["scatter"] = None
            scatter = None
        focus = self._focus_series_idx()
        if highlighted:
            pen = meta.get("pen_highlight")
        elif focus is not None:
            pen = meta.get("pen_dim")
        else:
            pen = meta.get("pen_normal")
        if curve is not None and pen is not None:
            if meta.get("auto_fix_locked"):
                qc = QtGui.QColor(str(meta.get("color", "#e8eaed")))
                qc.setAlpha(self._series_alpha(series_idx))
                pen = pg.mkPen(
                    qc,
                    width=max(2.0, float(pen.widthF()) if hasattr(pen, "widthF") else 2.0),
                    style=QtCore.Qt.PenStyle.DashLine,
                )
            curve.setPen(pen)
            if highlighted:
                z_curve = 8
            elif focus is not None:
                z_curve = 2
            else:
                z_curve = 4
            curve.setZValue(z_curve)
            curve.setVisible(plot_visible)
        if scatter is not None:
            try:
                scatter.setVisible(plot_visible)
                if not plot_visible:
                    scatter.setData(spots=[])
                elif self._series_shows_spots(series_idx):
                    scatter.setData(spots=self._display_spots_for_series(series_idx))
                    scatter.setZValue(14 if highlighted else 10)
                elif self._series_has_reciprocal_fail_spots(series_idx):
                    scatter.setData(spots=self._fail_only_spots_for_series(series_idx))
                    scatter.setZValue(16)
                else:
                    scatter.setData(spots=[])
            except RuntimeError:
                meta["scatter"] = None

    def _refresh_all_series_styles(self) -> None:
        for idx in range(len(self._series_meta)):
            self._apply_series_highlight_style(idx)

    def _refresh_focus_styles(
        self, old_idx: int | None, new_idx: int | None
    ) -> None:
        if old_idx == new_idx:
            return
        # Entrata/uscita focus: tutte le serie cambiano (normal ↔ dim).
        # Switch A→B: basta aggiornare le due coinvolte.
        if old_idx is None or new_idx is None:
            self._refresh_all_series_styles()
            return
        for idx in (old_idx, new_idx):
            if 0 <= idx < len(self._series_meta):
                self._apply_series_highlight_style(idx)

    def _clear_hover_dwell_state(self) -> None:
        timer = getattr(self, "_hover_dwell_timer", None)
        if timer is not None:
            timer.stop()
        self._hover_candidate_idx = None

    def _commit_hover_dwell(self) -> None:
        if self._locked_series_idx is not None:
            return
        self._set_hover_series(getattr(self, "_hover_candidate_idx", None))

    def _schedule_hover_dwell(self, series_idx: int | None) -> None:
        """Aggiorna l'highlight solo dopo dwell; None cancella subito."""
        if self._locked_series_idx is not None:
            return
        if series_idx is not None and (
            series_idx < 0
            or series_idx >= len(self._series_meta)
            or not self._series_is_plot_visible(series_idx)
        ):
            series_idx = None
        if series_idx is None:
            self._clear_hover_dwell_state()
            self._set_hover_series(None)
            return
        if series_idx == self._hover_series_idx:
            self._hover_candidate_idx = series_idx
            timer = getattr(self, "_hover_dwell_timer", None)
            if timer is not None:
                timer.stop()
            return
        if series_idx == getattr(self, "_hover_candidate_idx", None):
            return
        self._hover_candidate_idx = series_idx
        timer = getattr(self, "_hover_dwell_timer", None)
        if timer is None:
            self._set_hover_series(series_idx)
            return
        timer.stop()
        timer.start(int(getattr(self, "_hover_dwell_ms", 300)))

    def _set_hover_series(self, series_idx: int | None) -> None:
        if self._locked_series_idx is not None:
            return
        if series_idx is not None and (
            series_idx < 0
            or series_idx >= len(self._series_meta)
            or not self._series_is_plot_visible(series_idx)
        ):
            series_idx = None
        if self._hover_series_idx == series_idx:
            return
        old_idx = self._hover_series_idx
        self._hover_series_idx = series_idx
        self._refresh_focus_styles(old_idx, series_idx)

    def _lock_series(self, series_idx: int, *, activate_viewer: bool = True) -> None:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return
        if not self._series_is_plot_visible(series_idx):
            self._set_series_plot_visible(
                series_idx, True, sync_list=True, unlock_if_hidden=False
            )
        if self._locked_series_idx == series_idx:
            if activate_viewer:
                self._activate_series(series_idx)
            return
        if self._locked_series_idx != series_idx:
            self._reset_velocity_line()
        self._locked_series_idx = series_idx
        self._clear_hover_dwell_state()
        self._hover_series_idx = None
        self._ensure_spots_base(series_idx)
        self._refresh_all_series_styles()
        self._refresh_series_visibility_selection_styles()
        self._update_lock_status_label()
        self._sync_auto_fix_ref_lock_btn()
        if activate_viewer:
            self._activate_series(series_idx)

    def _unlock_series(self) -> None:
        if self._locked_series_idx is None:
            return
        self._cancel_active_drag()
        self._locked_series_idx = None
        self._clear_hover_dwell_state()
        self._reset_velocity_line()
        self._refresh_all_series_styles()
        self._refresh_series_visibility_selection_styles()
        self._update_velocity_readout()
        self._sync_auto_fix_ref_lock_btn()
        self._sync_dromocrona_mouse_enabled()

    def _update_lock_status_label(self) -> None:
        # Stato selezione: solo grafico / elenco (niente riga testo in alto).
        return

    def _series_allowed_for_edit(self, series_idx: int) -> bool:
        if self._locked_series_idx is None:
            return False
        return series_idx == self._locked_series_idx

    @staticmethod
    def _shift_held_for_event(ev: object | None = None) -> bool:
        if ev is not None:
            try:
                modifiers = ev.modifiers()
                if modifiers is not None:
                    return bool(
                        modifiers & QtCore.Qt.KeyboardModifier.ShiftModifier
                    )
            except Exception:
                pass
        return bool(
            QtWidgets.QApplication.keyboardModifiers()
            & QtCore.Qt.KeyboardModifier.ShiftModifier
        )

    def _series_point_index(self, meta: dict[str, object], trace_idx: int) -> int:
        traces = meta.get("trace_idx")
        if traces is not None:
            arr = np.asarray(traces, dtype=np.int64)
            matches = np.nonzero(arr == int(trace_idx))[0]
            return int(matches[0]) if matches.size else -1
        x = np.asarray(meta.get("x"), dtype=np.float64)
        if x.size == 0:
            return -1
        expected = float(
            self._display_x_for_traces(np.array([int(trace_idx)], dtype=np.int64))[0]
        )
        matches = np.nonzero(np.isclose(x, expected, atol=0.01))[0]
        return int(matches[0]) if matches.size else -1

    def _refresh_series_visual(
            self,
            series_idx: int,
            *,
            fit_range: bool = False,
            sanitize: bool = True,
            update_view_limits: bool = True,
        ) -> None:
            if series_idx < 0 or series_idx >= len(self._series_meta):
                return
            meta = self._series_meta[series_idx]
            y_raw = np.asarray(meta["y"], dtype=np.float64)
            if sanitize:
                trace_src = meta.get("trace_idx")
                if trace_src is None:
                    trace_src = self._trace_idx_array_from_display_x(
                        np.asarray(meta.get("x"), dtype=np.float64)
                    )
                else:
                    trace_src = np.asarray(trace_src, dtype=np.int64)
                trace_idx, y = self._sanitize_dromocrona_series_by_trace(trace_src, y_raw)
                meta["trace_idx"] = trace_idx
                meta["y"] = y
                meta["x"] = self._display_x_for_traces(trace_idx)
            else:
                trace_idx = np.asarray(meta.get("trace_idx"), dtype=np.int64)
                if trace_idx.size == 0:
                    trace_idx = self._trace_idx_array_from_display_x(
                        np.asarray(meta.get("x"), dtype=np.float64)
                    )
                    meta["trace_idx"] = trace_idx
                # Anche senza sanitize completo: mai disegnare y sottozero.
                if y_raw.size and np.any(y_raw < 0.0):
                    y = np.maximum(0.0, y_raw)
                    meta["y"] = y
                else:
                    y = y_raw
            curve = meta.get("curve")
            scatter = meta.get("scatter")
            if curve is not None and not self._qt_wrapper_alive(curve):
                meta["curve"] = None
                curve = None
            if scatter is not None and not self._qt_wrapper_alive(scatter):
                meta["scatter"] = None
                scatter = None
            if curve is not None:
                try:
                    self._configure_dromocrona_curve(curve)
                    curve.setData(np.asarray(meta["x"]), y, connect="all")
                    curve.prepareGeometryChange()
                except RuntimeError:
                    meta["curve"] = None
            if scatter is not None:
                self._mark_spots_stale(series_idx)
                if self._series_shows_spots(series_idx):
                    self._rebuild_dromocrona_spot_cache(
                        series_idx,
                        np.asarray(meta["x"]),
                        y,
                        np.asarray(meta.get("trace_idx"), dtype=np.int64),
                    )
                self._apply_series_highlight_style(series_idx)
                self._invalidate_series_scene_pick_cache(series_idx)
            if fit_range:
                self._fit_view_positive_quadrant()
            elif update_view_limits and self._active_drag is None:
                self._update_dromocrona_view_limits_from_data(fit_view=False)

    def _series_display_name(self, series_idx: int) -> str:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return ""
        meta = self._series_meta[series_idx]
        source = meta.get("source_path")
        if source is not None:
            return Path(source).name
        return str(meta.get("label", ""))

    def _update_hover_info(self, scene_pos) -> None:
        if self._active_drag is not None:
            return
        if self._locked_series_idx is not None:
            return
        last = self._hover_last_pick_pos
        min_dist = float(getattr(self, "_hover_pick_min_dist_px", 5.0))
        if last is not None:
            dx = float(scene_pos.x()) - float(last.x())
            dy = float(scene_pos.y()) - float(last.y())
            if (dx * dx + dy * dy) < (min_dist * min_dist):
                return
        self._hover_last_pick_pos = QtCore.QPointF(scene_pos)
        prefer = self._hover_series_idx
        if prefer is None:
            prefer = getattr(self, "_hover_candidate_idx", None)
        series_idx = self._pick_series_near_scene(
            scene_pos,
            prefer_idx=prefer,
            hysteresis_px=float(getattr(self, "_hover_hysteresis_px", 6.0)),
        )
        self._schedule_hover_dwell(series_idx)

    def _begin_drag(self, series_idx: int, trace_idx: int) -> None:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return
        # Durante il disegno della retta V non avviare drag (lock pan annidati).
        if self._vel_line_placing:
            return
        if not self._series_allowed_for_edit(series_idx):
            return
        meta = self._series_meta[series_idx]
        pt_idx = self._series_point_index(meta, trace_idx)
        if pt_idx < 0:
            return
        y_arr = np.asarray(meta["y"], dtype=np.float64)
        self._drag_start_y = float(y_arr[pt_idx])
        self._drag_moved = False
        self._active_drag = (int(series_idx), int(trace_idx), int(pt_idx))
        self._ensure_spots_base(series_idx)
        self._lock_plot_pan_for_drag(True)
        if not self._drag_commit_timer.isActive():
            self._drag_commit_timer.start()

    def _set_series_point_y(
            self,
            series_idx: int,
            trace_idx: int,
            new_y: float,
            *,
            pt_idx: int | None = None,
            reciprocal_prefer_memory: bool = False,
            defer_reciprocal_patch: bool = False,
        ) -> None:
            if series_idx < 0 or series_idx >= len(self._series_meta):
                return
            meta = self._series_meta[series_idx]
            if pt_idx is None:
                idx = self._series_point_index(meta, trace_idx)
            else:
                idx = int(pt_idx)
            if idx < 0 or idx >= np.asarray(meta.get("y")).size:
                return
            y = np.array(meta["y"], dtype=np.float64, copy=True)
            y[idx] = max(0.0, float(new_y))
            meta["y"] = y
            self._bump_series_y_revision()
            if not defer_reciprocal_patch:
                self._patch_reciprocal_pairs_cache(
                    series_idx,
                    prefer_memory=None,
                    affected_traces_by_meta={int(series_idx): {int(trace_idx)}},
                )
            else:
                self._queue_reciprocal_patch(series_idx, {int(trace_idx)})
            self._refresh_series_visual(
                series_idx, fit_range=False, sanitize=False, update_view_limits=False
            )

    def apply_trace_y_updates(
            self,
            source_path: Path,
            updates: dict[int, float],
            *,
            defer_reciprocal_patch: bool = True,
        ) -> bool:
            """Aggiorna solo i punti modificati (sync leggera da sismogramma)."""
            if not updates:
                return False
            series_idx = self.find_series_index(source_path)
            if series_idx is None:
                return False
            meta = self._series_meta[series_idx]
            y = np.asarray(meta.get("y"), dtype=np.float64)
            if y.size == 0:
                return False
            trace_arr = np.asarray(meta.get("trace_idx"), dtype=np.int64)
            x = np.asarray(meta.get("x"), dtype=np.float64)
            y = np.array(y, dtype=np.float64, copy=True)
            changed_traces: set[int] = set()
            new_trace_ids: list[int] = []
            new_y_vals: list[float] = []
            for trace_idx, new_y in updates.items():
                pt_idx = self._series_point_index(meta, int(trace_idx))
                new_val = max(0.0, float(new_y))
                if pt_idx < 0 or pt_idx >= y.size:
                    # Traccia nuova: da aggiungere alla serie
                    new_trace_ids.append(int(trace_idx))
                    new_y_vals.append(new_val)
                    changed_traces.add(int(trace_idx))
                    continue
                if abs(float(y[pt_idx]) - new_val) < 1e-9:
                    continue
                y[pt_idx] = new_val
                changed_traces.add(int(trace_idx))
            if new_trace_ids:
                new_tr_arr = np.array(new_trace_ids, dtype=np.int64)
                new_x_arr = self._display_x_for_traces(new_tr_arr)
                new_y_arr = np.array(new_y_vals, dtype=np.float64)
                trace_arr = np.concatenate([trace_arr, new_tr_arr])
                x = np.concatenate([x, new_x_arr])
                y = np.concatenate([y, new_y_arr])
                order = np.argsort(trace_arr, kind="stable")
                trace_arr = trace_arr[order]
                x = x[order]
                y = y[order]
                meta["trace_idx"] = trace_arr
                meta["x"] = x
            if not changed_traces:
                return False
            meta["y"] = y
            self._bump_series_y_revision()
            if not defer_reciprocal_patch:
                self._patch_reciprocal_pairs_cache(
                    series_idx,
                    prefer_memory=None,
                    affected_traces_by_meta={int(series_idx): changed_traces},
                )
            else:
                # Non invalidare tutto: in coda solo le tracce toccate.
                self._queue_reciprocal_patch(series_idx, changed_traces)
            self._refresh_series_visual(
                series_idx, fit_range=False, sanitize=False, update_view_limits=False
            )
            return True

    def _update_series_point_y_during_drag(
            self,
            series_idx: int,
            pt_idx: int,
            new_y: float,
            trace_idx: int,
        ) -> None:
            """Solo curva + spot trascinato; rebuild completo al rilascio."""
            if series_idx < 0 or series_idx >= len(self._series_meta):
                return
            meta = self._series_meta[series_idx]
            y = np.array(meta["y"], dtype=np.float64, copy=True)
            if pt_idx < 0 or pt_idx >= y.size:
                return
            y[pt_idx] = max(0.0, float(new_y))
            meta["y"] = y
            self._bump_series_y_revision()
            self._invalidate_series_scene_pick_cache(series_idx)
            x = np.asarray(meta["x"], dtype=np.float64)
            curve = meta.get("curve")
            if curve is not None:
                curve.setData(x, y, connect="all")
            if pt_idx < x.size:
                self._patch_dromocrona_spot_position(
                    series_idx, float(x[pt_idx]), float(new_y), int(trace_idx)
                )

    def _patch_dromocrona_spot_position(
            self,
            series_idx: int,
            x_val: float,
            y_val: float,
            trace_idx: int,
        ) -> None:
            if self._is_shot_dromocrona_point(y_val):
                return
            meta = self._series_meta[series_idx]
            pos = (float(x_val), float(y_val))
            base = meta.get("spots_base")
            if base:
                for sp in base:
                    data = sp.get("data")
                    if (
                        isinstance(data, tuple)
                        and len(data) >= 2
                        and int(data[1]) == int(trace_idx)
                    ):
                        sp["pos"] = pos
                        break
            self._invalidate_spot_style_caches(meta)
            scatter = meta.get("scatter")
            if scatter is None or not self._series_shows_spots(series_idx):
                return
            scatter.setData(spots=self._display_spots_for_series(series_idx))

    def _finalize_drag_visual(
            self, series_idx: int, dragged_trace_idx: int | None = None
        ) -> None:
            if series_idx < 0 or series_idx >= len(self._series_meta):
                return
            meta = self._series_meta[series_idx]
            traces: set[int] | None = (
                {int(dragged_trace_idx)} if dragged_trace_idx is not None else None
            )
            self._bump_series_y_revision()
            if traces is not None:
                self._patch_reciprocal_pairs_cache(
                    series_idx,
                    prefer_memory=None,
                    affected_traces_by_meta={int(series_idx): traces},
                )
            else:
                self._patch_reciprocal_pairs_cache(series_idx, prefer_memory=None)
            x = np.asarray(meta["x"], dtype=np.float64)
            y = np.asarray(meta["y"], dtype=np.float64)
            trace_arr = np.asarray(meta.get("trace_idx"), dtype=np.int64)
            if meta.get("scatter") is not None:
                self._rebuild_dromocrona_spot_cache(series_idx, x, y, trace_arr)
                self._apply_series_highlight_style(series_idx)
            self._invalidate_series_scene_pick_cache(series_idx)
            # Aggiorna FAIL subito (patch worker già lanciato; niente reload disco).
            self.schedule_dromocrona_grid_refresh(immediate=True)

    def _parse_drag_payload(self, data: object) -> tuple[int, int] | None:
        if (
            not isinstance(data, tuple)
            or len(data) != 2
            or not isinstance(data[0], int)
            or not isinstance(data[1], int)
        ):
            return None
        return int(data[0]), int(data[1])

    def _on_scatter_clicked(self, item, points, ev) -> None:
        del item
        if ev is None:
            return
        if self._vel_line_placing:
            return
        if points is None or int(np.size(points)) == 0:
            return
        if ev.button() != QtCore.Qt.MouseButton.LeftButton:
            return
        if self._locked_series_idx is None:
            return
        first = points[0]
        spot_data = first.data() if hasattr(first, "data") else first
        payload = self._parse_drag_payload(spot_data)
        if payload is None:
            return
        self._begin_drag(payload[0], payload[1])

    def _on_scene_mouse_clicked(self, ev) -> None:
        if ev.button() == QtCore.Qt.MouseButton.RightButton:
            if self._locked_series_idx is not None:
                picked = self._pick_point_near_scene(ev.scenePos(), max_px=18.0)
                if picked is not None:
                    series_idx, trace_idx, _pt_idx = picked
                    if self._series_has_reciprocal_fail_at(series_idx, trace_idx):
                        self._reciprocal_snap_armed = False
                        self._snap_reciprocal_fail_at_spot(series_idx, trace_idx)
                        return
            if self._velocity_mode_active() and (
                self._vel_line_placing or self._vel_line_p0 is not None
            ):
                self._reset_velocity_line()
                self._update_velocity_readout()
                return
            if self._locked_series_idx is not None:
                self._unlock_series()
            return
        if self._velocity_mode_active():
            self._on_velocity_scene_clicked(ev)
            return
        if ev.button() != QtCore.Qt.MouseButton.LeftButton:
            return
        if self._active_drag is not None:
            return
        if self._locked_series_idx is not None:
            if getattr(self, "_reciprocal_snap_armed", False):
                picked = self._pick_point_near_scene(ev.scenePos(), max_px=18.0)
                if picked is not None:
                    series_idx, trace_idx, _pt_idx = picked
                    if self._series_has_reciprocal_fail_at(series_idx, trace_idx):
                        self._reciprocal_snap_armed = False
                        self._snap_reciprocal_fail_at_spot(series_idx, trace_idx)
                        return
                self._reciprocal_snap_armed = False
            if self._shift_held_for_event(ev):
                series_idx = self._pick_series_near_scene(ev.scenePos())
                if series_idx == self._locked_series_idx:
                    self._toggle_auto_fix_locked(series_idx)
                    self._update_lock_status_label()
                    return
            picked = self._pick_point_near_scene(ev.scenePos())
            if picked is not None:
                self._begin_drag(picked[0], picked[1])
            return
        if not self._shift_held_for_event(ev):
            return
        series_idx = self._pick_series_near_scene(ev.scenePos())
        if series_idx is not None:
            self._lock_series(series_idx, activate_viewer=True)

    def _activate_series(self, series_idx: int) -> None:
        if series_idx < 0 or series_idx >= len(self._series_meta):
            return
        if self._active_drag is not None:
            return
        meta = self._series_meta[series_idx]
        source = meta.get("source_path")
        if source is None or self._on_series_activated is None:
            return
        fbp_path = Path(source)
        sgy_raw = meta.get("sgy_path")
        sgy_path = Path(sgy_raw) if sgy_raw is not None else None
        self._on_series_activated(fbp_path, sgy_path)

    def _series_dist_sq_near_scene(
            self, series_idx: int, sx: float, sy: float
        ) -> float | None:
            """Distanza² minima (punti/segmenti) in scene coords; None se non pickabile."""
            if not self._series_is_plot_visible(series_idx):
                return None
            scene_xy = self._series_scene_pick_xy(series_idx)
            if scene_xy is None:
                return None
            sc_x, sc_y = scene_xy
            d2_pts = (sc_x - sx) * (sc_x - sx) + (sc_y - sy) * (sc_y - sy)
            min_pt = float(np.min(d2_pts))
            d2_seg = self._min_segment_dist_sq_scene(sx, sy, sc_x, sc_y)
            return min(min_pt, d2_seg)

    def _pick_series_near_scene(
            self,
            scene_pos,
            max_px: float = 14.0,
            *,
            prefer_idx: int | None = None,
            hysteresis_px: float = 0.0,
        ) -> int | None:
            vb = self.dromocrona_plot.getViewBox()
            if vb is None or not vb.sceneBoundingRect().contains(scene_pos):
                return None
            best_series: int | None = None
            max_d2 = float(max_px * max_px)
            best_d2 = max_d2
            sx = float(scene_pos.x())
            sy = float(scene_pos.y())
            for series_idx, _meta in enumerate(self._series_meta):
                if not self._series_is_plot_visible(series_idx):
                    continue
                if not self._series_scene_bounds_overlap(series_idx, sx, sy, max_px):
                    continue
                scene_xy = self._series_scene_pick_xy(series_idx)
                if scene_xy is None:
                    continue
                sc_x, sc_y = scene_xy
                d2_pts = (sc_x - sx) * (sc_x - sx) + (sc_y - sy) * (sc_y - sy)
                min_pt = float(np.min(d2_pts))
                if min_pt < best_d2:
                    best_d2 = min_pt
                    best_series = series_idx
                    if best_d2 <= 1.0:
                        break
                d2_seg = self._min_segment_dist_sq_scene(sx, sy, sc_x, sc_y)
                if d2_seg < best_d2:
                    best_d2 = d2_seg
                    best_series = series_idx
            if best_series is None:
                return None
            # Isteresi: resta sulla preferita finché la nuova non è chiaramente più vicina.
            if (
                prefer_idx is not None
                and prefer_idx != best_series
                and 0 <= int(prefer_idx) < len(self._series_meta)
                and float(hysteresis_px) > 0.0
            ):
                prefer_d2 = self._series_dist_sq_near_scene(
                    int(prefer_idx), sx, sy
                )
                if prefer_d2 is not None and prefer_d2 <= max_d2:
                    hyst_d2 = float(hysteresis_px) * float(hysteresis_px)
                    if best_d2 >= float(prefer_d2) - hyst_d2:
                        return int(prefer_idx)
            return best_series

    def _on_scene_mouse_moved(self, event) -> None:
        scene_pos = event[0] if isinstance(event, tuple) else event
        buttons = QtWidgets.QApplication.mouseButtons()
        if buttons & (
            QtCore.Qt.MouseButton.RightButton | QtCore.Qt.MouseButton.MiddleButton
        ):
            return
        if self._velocity_mode_active() and self._vel_line_placing:
            self._on_velocity_scene_moved(scene_pos)
            return
        left_pressed = bool(
            QtWidgets.QApplication.mouseButtons() & QtCore.Qt.MouseButton.LeftButton
        )
        if not left_pressed:
            self._update_hover_info(scene_pos)
            return
        if self._velocity_mode_active():
            return
        if self._locked_series_idx is None:
            return
        if self._active_drag is None:
            picked = self._pick_point_near_scene(
                scene_pos,
                max_px=float(getattr(self, "_drag_pick_radius_px", 26.0)),
            )
            if picked is None:
                return
            self._begin_drag(picked[0], picked[1])
            if self._active_drag is None:
                return
        series_idx, trace_idx, pt_idx = self._active_drag
        mapped = self._map_scene_to_dromocrona_plot(scene_pos)
        if mapped is None:
            return
        new_y = float(mapped[1])
        # Asse «ms vs minimo»: lo shot sta a 0, non si trascina sotto zero.
        new_y = max(0.0, new_y)
        bounds = getattr(self, "_dromocrona_view_bounds", None)
        if bounds is not None:
            _x_lo, _x_hi, _y_lo, y_hi = bounds
            new_y = min(float(y_hi), new_y)
        start_y = getattr(self, "_drag_start_y", None)
        if (
            not self._drag_moved
            and start_y is not None
            and abs(new_y - float(start_y)) > 0.05
        ):
            self._drag_moved = True
        self._update_series_point_y_during_drag(
            series_idx, pt_idx, new_y, trace_idx
        )

    def _lock_plot_pan_for_drag(self, active: bool) -> None:
        if active:
            self._drag_pan_prev = (False, False)  # solo flag «drag attivo»
        else:
            self._drag_pan_prev = None
        self._sync_dromocrona_mouse_enabled()

    def _pick_point_near_scene(
            self,
            scene_pos,
            max_px: float | None = None,
        ) -> tuple[int, int, int] | None:
            vb = self.dromocrona_plot.getViewBox()
            if vb is None or not vb.sceneBoundingRect().contains(scene_pos):
                return None
            series_idx = self._locked_series_idx
            if series_idx is None:
                return None
            if series_idx < 0 or series_idx >= len(self._series_meta):
                return None
            if max_px is None:
                max_px = float(getattr(self, "_drag_pick_radius_px", 26.0))
            sx = float(scene_pos.x())
            sy = float(scene_pos.y())
            if not self._series_scene_bounds_overlap(series_idx, sx, sy, max_px):
                return None
            self._series_scene_pick_xy(series_idx)
            meta = self._series_meta[series_idx]
            pick_sx = meta.get("_scene_pick_pick_sx")
            pick_sy = meta.get("_scene_pick_pick_sy")
            pick_pt_idx = meta.get("_scene_pick_pick_pt_idx")
            pick_trace_idx = meta.get("_scene_pick_pick_trace_idx")
            if (
                pick_sx is None
                or pick_sy is None
                or pick_pt_idx is None
                or pick_trace_idx is None
            ):
                return None
            nearest = self._nearest_pickable_point_scene(
                sx,
                sy,
                np.asarray(pick_sx, dtype=np.float64),
                np.asarray(pick_sy, dtype=np.float64),
                np.asarray(pick_pt_idx, dtype=np.int64),
                np.asarray(pick_trace_idx, dtype=np.int64),
                float(max_px * max_px),
                meta.get("_scene_pick_grid"),
            )
            if nearest is None:
                return None
            pt_idx, trace_idx, _d2 = nearest
            return int(series_idx), int(trace_idx), int(pt_idx)

    def keyPressEvent(self, event: QtGui.QKeyEvent) -> None:
        if event.key() == QtCore.Qt.Key.Key_Escape:
            if self._active_drag is not None:
                self._cancel_active_drag()
                event.accept()
                return
            if self._vel_line_placing or self._vel_line_p0 is not None:
                self._reset_velocity_line()
                self._update_velocity_readout()
                event.accept()
                return
            if self._locked_series_idx is not None:
                self._unlock_series()
                event.accept()
                return
        super().keyPressEvent(event)

    def _check_drag_release(self) -> None:
        if self._active_drag is None:
            self._drag_commit_timer.stop()
            # Heal: drag annullato altrove senza unlock pan/zoom.
            if self._drag_pan_prev is not None or not self._dromocrona_interaction_blocks_mouse():
                self._sync_dromocrona_mouse_enabled()
            return
        if QtWidgets.QApplication.mouseButtons() & QtCore.Qt.MouseButton.LeftButton:
            return
        series_idx, trace_idx, pt_idx = self._active_drag
        moved = bool(getattr(self, "_drag_moved", False))
        start_y = self._drag_start_y
        self._active_drag = None
        self._drag_start_y = None
        self._drag_moved = False
        self._lock_plot_pan_for_drag(False)
        self._drag_commit_timer.stop()
        if moved:
            save_ok = False
            if 0 <= series_idx < len(self._series_meta):
                meta = self._series_meta[series_idx]
                source = meta.get("source_path")
                if source is not None and self._on_point_moved is not None:
                    y = np.asarray(meta["y"], dtype=np.float64)
                    if 0 <= pt_idx < y.size:
                        new_time = float(y[int(pt_idx)])
                        trace_arr = meta.get("trace_idx")
                        if trace_arr is not None and int(pt_idx) < np.asarray(trace_arr).size:
                            save_trace = int(np.asarray(trace_arr)[int(pt_idx)])
                        else:
                            save_trace = int(trace_idx)
                        save_ok = self._invoke_point_moved(
                            Path(source),
                            save_trace,
                            new_time,
                            refresh_monitor=False,
                        )
            if save_ok:
                self._finalize_drag_visual(series_idx, dragged_trace_idx=int(trace_idx))
                if self._on_drag_finished is not None:
                    try:
                        self._on_drag_finished()
                    except Exception:
                        pass
            elif start_y is not None:
                self._set_series_point_y(
                    series_idx,
                    trace_idx,
                    float(start_y),
                    pt_idx=pt_idx,
                )
                QtWidgets.QToolTip.showText(
                    QtGui.QCursor.pos(),
                    "Salvataggio break non riuscito — posizione ripristinata",
                    self,
                    QtCore.QRect(),
                    3000,
                )
                self.schedule_dromocrona_grid_refresh()
        if self._grid_refresh_deferred:
            self.schedule_dromocrona_grid_refresh(immediate=True)

    def _build_monitor_toolbar(self) -> QtWidgets.QWidget:
        bar = QtWidgets.QFrame()
        bar.setObjectName("dromoToolbar")
        bar.setFrameShape(QtWidgets.QFrame.Shape.StyledPanel)
        bar.setStyleSheet(
            "QFrame#dromoToolbar {"
            "  background: #252d3d; border: 1px solid #3d4657; border-radius: 6px;"
            "}"
            "QGroupBox {"
            "  color: #c5cad3; font-size: 11px; font-weight: 600;"
            "  border: 1px solid #3d4657; border-radius: 5px;"
            "  margin-top: 8px; padding: 8px 6px 6px 6px;"
            "}"
            "QGroupBox::title {"
            "  subcontrol-origin: margin; left: 8px; padding: 0 4px;"
            "}"
            # Checkbox: pieno bianco se attivo (niente spunta).
            "QCheckBox {"
            f"  color: {self._TEXT_COLOR};"
            "  font-size: 12px;"
            "  spacing: 6px;"
            "}"
            "QCheckBox::indicator {"
            "  width: 14px; height: 14px;"
            "  border-radius: 3px;"
            "  border: 1px solid #6b7588;"
            f"  background: {self._CHROME_BG};"
            "}"
            "QCheckBox::indicator:hover { border-color: #9aa3b2; }"
            "QCheckBox::indicator:checked {"
            "  background: #ffffff;"
            "  border: 1px solid #ffffff;"
            "  image: none;"
            "}"
            "QCheckBox::indicator:disabled {"
            "  background: #2a3346;"
            "  border: 1px solid #3d4657;"
            "}"
        )
        bar.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Maximum,
        )
        outer = QtWidgets.QHBoxLayout(bar)
        outer.setContentsMargins(8, 6, 8, 6)
        outer.setSpacing(10)
        outer.setAlignment(QtCore.Qt.AlignmentFlag.AlignVCenter)

        btn_style = (
            f"color: {self._TEXT_COLOR}; background: #1a2233; "
            "border: 1px solid #3d4657; padding: 5px 10px; border-radius: 4px;"
        )
        spin_style = (
            "background: #1a2233; color: #e8eaed; border: 1px solid #3d4657;"
            "padding: 2px 6px; border-radius: 3px;"
        )
        lbl_style = f"color: {self._TEXT_COLOR}; font-size: 12px;"

        def _tool_btn(
            text: str,
            tooltip: str,
            on_click=None,
            *,
            checkable: bool = False,
            expanding: bool = True,
        ) -> QtWidgets.QPushButton:
            btn = QtWidgets.QPushButton(text)
            btn.setStyleSheet(btn_style)
            btn.setToolTip(tooltip)
            btn.setCheckable(checkable)
            btn.setMinimumHeight(28)
            btn.setSizePolicy(
                QtWidgets.QSizePolicy.Policy.Expanding
                if expanding
                else QtWidgets.QSizePolicy.Policy.Minimum,
                QtWidgets.QSizePolicy.Policy.Fixed,
            )
            if on_click is not None:
                btn.clicked.connect(on_click)
            return btn

        def _group(
            title: str, *, expanding: bool = True
        ) -> tuple[QtWidgets.QGroupBox, QtWidgets.QHBoxLayout]:
            box = QtWidgets.QGroupBox(title)
            box.setSizePolicy(
                QtWidgets.QSizePolicy.Policy.Expanding
                if expanding
                else QtWidgets.QSizePolicy.Policy.Preferred,
                QtWidgets.QSizePolicy.Policy.Preferred,
            )
            lay = QtWidgets.QHBoxLayout(box)
            lay.setContentsMargins(8, 8, 8, 8)
            lay.setSpacing(8)
            return box, lay

        # --- Vista (compatta) ---
        view_box, view_row = _group("Vista", expanding=False)
        view_row.addWidget(
            _tool_btn(
                "Griglia…",
                "Apre la tabella dromocrone (righe = geofoni, colonne = file .fbp).",
                self._open_dromocrona_grid_window,
                expanding=False,
            )
        )
        outer.addWidget(view_box, stretch=0)

        # --- FAIL ---
        fail_box, fail_row = _group("FAIL")
        self._reciprocal_fail_highlight_chk = QtWidgets.QCheckBox("Evidenzia")
        self._reciprocal_fail_highlight_chk.setToolTip(
            "Colora i break con reciproci fuori soglia "
            "(stessa logica della griglia)."
        )
        self._reciprocal_fail_highlight_chk.toggled.connect(
            self._on_reciprocal_fail_highlight_toggled
        )
        fail_row.addWidget(self._reciprocal_fail_highlight_chk)
        fail_row.addWidget(
            _tool_btn(
                "Soglie…",
                "Fasce di distanza e soglie tempo (ms) per i reciproci FAIL.",
                self._edit_reciprocal_tolerance_bands,
            ),
            stretch=1,
        )
        fail_row.addWidget(
            _tool_btn(
                "Colori…",
                "Colori FAIL sul sismogramma (Δ+ / Δ−).\n"
                "Sul grafico dromocrone i colori restano per fascia.",
                self._edit_reciprocal_fail_colors_from_monitor,
            ),
            stretch=1,
        )
        outer.addWidget(fail_box, stretch=2)

        # --- Correzione reciproci (prende più spazio) ---
        recip_box = QtWidgets.QGroupBox("Correzione reciproci")
        recip_box.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Preferred,
        )
        recip_outer = QtWidgets.QVBoxLayout(recip_box)
        recip_outer.setContentsMargins(8, 8, 8, 8)
        recip_outer.setSpacing(6)
        method_row = QtWidgets.QHBoxLayout()
        method_row.setSpacing(8)
        actions_row = QtWidgets.QHBoxLayout()
        actions_row.setSpacing(8)
        recip_outer.addLayout(method_row)
        recip_outer.addLayout(actions_row)

        method_lbl = QtWidgets.QLabel("Metodo:")
        method_lbl.setStyleSheet(lbl_style)
        method_row.addWidget(method_lbl)
        self._reciprocal_auto_fix_method_combo = QtWidgets.QComboBox()
        for method_id, method_label in RECIPROCAL_AUTO_FIX_METHODS:
            self._reciprocal_auto_fix_method_combo.addItem(method_label, method_id)
        self._reciprocal_auto_fix_method_combo.setCurrentIndex(0)
        self._reciprocal_auto_fix_method_combo.setMinimumHeight(28)
        self._reciprocal_auto_fix_method_combo.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Fixed,
        )
        self._reciprocal_auto_fix_method_combo.setToolTip(
            "Algoritmo usato da «Allinea FAIL».\n"
            "Ibrido / smooth / morfologico: shift colonne + correzione punti.\n"
            "Mediana / RANSAC / Huber / Grafo / Ancore: solo shift colonna.\n"
            "Lato debole / propagazione seed: varianti mirate.\n"
            "Solo shift colonna / shot: offset globale senza nudge puntuale."
        )
        self._reciprocal_auto_fix_method_combo.setStyleSheet(spin_style)
        method_row.addWidget(self._reciprocal_auto_fix_method_combo, stretch=1)

        self._reciprocal_estimate_missing_btn = _tool_btn(
            "Riempi gap",
            "Riempie i break mancanti (0.000):\n"
            "• agli angoli shot → tempo reciproco dell’altra dromocrona\n"
            "• negli altri gap → interpolazione lineare\n"
            "Le curve bloccate come riferimento non si modificano.\n"
            "Annullabile con «Annulla».",
            self._estimate_missing_reciprocal_breaks,
        )
        self._reciprocal_auto_fix_btn = _tool_btn(
            "Allinea FAIL",
            "Allinea i reciproci FAIL con il metodo scelto sopra.\n"
            "Le curve bloccate come riferimento non si spostano.",
            self._auto_adjust_reciprocal_breaks,
        )
        self._reciprocal_snap_fail_btn = _tool_btn(
            "Aggancia FAIL",
            "Con dromocrona selezionata: clic sul pulsante, poi sul punto FAIL,\n"
            "oppure tasto destro sul punto FAIL.",
            self._arm_reciprocal_snap_fail_pick,
        )
        self._auto_fix_ref_lock_btn = _tool_btn(
            "Blocca rif.",
            "Con una dromocrona selezionata (Shift+clic):\n"
            "bloccala così «Allinea FAIL» non la sposta.\n"
            "Le curve bloccate appaiono tratteggiate.",
            checkable=True,
        )
        self._auto_fix_ref_lock_btn.setMinimumWidth(
            self._auto_fix_ref_lock_btn.fontMetrics().horizontalAdvance("Sblocca rif.")
            + 24
        )
        self._auto_fix_ref_lock_btn.setEnabled(False)
        self._auto_fix_ref_lock_btn.toggled.connect(self._on_auto_fix_ref_lock_toggled)
        self._reciprocal_auto_fix_undo_btn = _tool_btn(
            "Annulla",
            "Ripristina i break dell’ultima correzione automatica "
            "(Allinea FAIL / Riempi gap).",
            self._undo_last_auto_adjust_reciprocal_breaks,
        )
        for btn in (
            self._reciprocal_estimate_missing_btn,
            self._reciprocal_auto_fix_btn,
            self._reciprocal_snap_fail_btn,
            self._auto_fix_ref_lock_btn,
            self._reciprocal_auto_fix_undo_btn,
        ):
            actions_row.addWidget(btn, stretch=1)
        outer.addWidget(recip_box, stretch=5)

        # --- Velocità ---
        vel_box, vel_row = _group("Velocità")
        self._vel_calc_checkbox = QtWidgets.QCheckBox("Attiva (V)")
        self._vel_calc_checkbox.setToolTip(
            "Disegna la retta gialla sulla dromocrona selezionata:\n"
            "1° clic = inizio, 2° clic = conferma.\n"
            "Scorciatoia: V"
        )
        self._vel_calc_checkbox.toggled.connect(self._on_velocity_mode_toggled)
        vel_row.addWidget(self._vel_calc_checkbox)

        spacing_lbl = QtWidgets.QLabel("Spaz. (m):")
        spacing_lbl.setStyleSheet(lbl_style)
        spacing_lbl.setToolTip("Spaziatura geofoni (m)")
        self._vel_spacing_lbl = spacing_lbl
        vel_row.addWidget(spacing_lbl)
        self._vel_spacing_spin = QtWidgets.QDoubleSpinBox()
        self._vel_spacing_spin.setRange(0.1, 200.0)
        self._vel_spacing_spin.setDecimals(3)
        self._vel_spacing_spin.setSingleStep(0.1)
        self._vel_spacing_spin.setValue(DROMO_GEOPHONE_SPACING_M)
        self._vel_spacing_spin.setMinimumWidth(88)
        self._vel_spacing_spin.setFixedHeight(28)
        self._vel_spacing_spin.setToolTip(
            "Senza morfologia: distanza = |Δ traccia| × spaziatura."
        )
        self._vel_spacing_spin.setStyleSheet(spin_style)
        self._vel_spacing_spin.valueChanged.connect(self._update_velocity_readout)
        vel_row.addWidget(self._vel_spacing_spin)

        self._morphology_label = QtWidgets.QLabel("Morfologia: —")
        self._morphology_label.setStyleSheet(
            f"color: {self._MUTED_TEXT}; font-size: 12px;"
        )
        self._morphology_label.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Preferred,
        )
        self._morphology_label.setMinimumWidth(90)
        vel_row.addWidget(self._morphology_label, stretch=1)
        outer.addWidget(vel_box, stretch=3)
        return bar

    def _apply_dromo_window_min_size(self) -> None:
        """Imposta larghezza minima così la toolbar non viene mai compressa."""
        tb = getattr(self, "_monitor_toolbar", None)
        pad = 40  # margini layout finestra
        list_w = 200  # elenco curve tipico
        tb_w = int(tb.sizeHint().width()) if tb is not None else 1100
        min_w = max(
            int(getattr(self, "_dromo_window_min_width", 1320)),
            tb_w + list_w + pad,
        )
        min_h = int(getattr(self, "_dromo_window_min_height", 720))
        self._dromo_window_min_width = min_w
        self.setMinimumSize(min_w, min_h)
        if self.width() < min_w or self.height() < min_h:
            self.resize(max(self.width(), min_w), max(self.height(), min_h))

    def showEvent(self, event: QtGui.QShowEvent) -> None:
        self.refresh_line_morphology_ui()
        QtCore.QTimer.singleShot(0, self._on_monitor_geometry_changed)
        QtCore.QTimer.singleShot(0, self._apply_dromo_window_min_size)
        super().showEvent(event)

    def resizeEvent(self, event: QtGui.QResizeEvent) -> None:
        super().resizeEvent(event)
        self._schedule_monitor_geometry_sync()

    def _schedule_monitor_geometry_sync(self, *_args) -> None:
        if getattr(self, "_dromocrona_view_fit_busy", False):
            return
        self._geometry_debounce_timer.start()

    def _on_monitor_geometry_changed(self) -> None:
        self._invalidate_all_scene_pick_caches()
        if self._morphology_row_should_show():
            self._set_morphology_plot_row_visible(True)
        self._sync_monitor_plot_alignment()

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        self._cancel_active_drag()
        self._cleanup_velocity_mode_on_close()
        self._sync_dromocrona_mouse_enabled()
        super().closeEvent(event)
