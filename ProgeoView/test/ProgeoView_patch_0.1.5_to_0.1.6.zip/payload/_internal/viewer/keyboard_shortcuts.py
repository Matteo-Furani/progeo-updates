"""Scorciatoie da tastiera personalizzabili (persistenza JSON)."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Iterable

from PyQt6 import QtGui

from bootstrap import config_dir

PREFS_PATH = config_dir() / "keyboard_shortcuts.json"


@dataclass(frozen=True)
class ShortcutAction:
    action_id: str
    label: str
    default: str
    category: str


SHORTCUT_CATALOG: tuple[ShortcutAction, ...] = (
    ShortcutAction("snap_positive", "Aggancia break al positivo", "X", "Break"),
    ShortcutAction("undo_snap", "Annulla ultimo aggancio", "Z", "Break"),
    ShortcutAction("smooth_breaks", "Smusso break (interpolazione vicini)", "S", "Break"),
    ShortcutAction("copy_break_times", "Copia tempi break (relativi)", "Ctrl+C", "Break"),
    ShortcutAction(
        "copy_break_absolute_times",
        "Copia tempi break assoluti",
        "C",
        "Break",
    ),
    ShortcutAction(
        "break_ruler_confirm",
        "Righello break: conferma",
        "Return",
        "Break",
    ),
    ShortcutAction(
        "break_ruler_cancel",
        "Righello break: annulla",
        "Escape",
        "Break",
    ),
    ShortcutAction("gain_up", "Aumenta guadagno", "+,=", "Visualizzazione"),
    ShortcutAction("gain_down", "Diminuisci guadagno", "-", "Visualizzazione"),
    ShortcutAction(
        "spacing_decrease",
        "Riduci spaziatura tracce",
        "A",
        "Visualizzazione",
    ),
    ShortcutAction(
        "spacing_increase",
        "Aumenta spaziatura tracce",
        "D",
        "Visualizzazione",
    ),
    ShortcutAction(
        "rotate_view_90",
        "Ruota sismogramma 90°",
        "R",
        "Visualizzazione",
    ),
    ShortcutAction(
        "nudge_hover_break_ms_decrease",
        "Break evidenziato verso l'alto a schermo",
        "Up",
        "Break",
    ),
    ShortcutAction(
        "nudge_hover_break_ms_increase",
        "Break evidenziato verso il basso a schermo",
        "Down",
        "Break",
    ),
    ShortcutAction(
        "nudge_hover_break_traces_decrease",
        "Break evidenziato verso sinistra a schermo",
        "Left",
        "Break",
    ),
    ShortcutAction(
        "nudge_hover_break_traces_increase",
        "Break evidenziato verso destra a schermo",
        "Right",
        "Break",
    ),
    ShortcutAction(
        "shift_breaks_ms_decrease",
        "Tutti i break verso l'alto a schermo",
        "Shift+Up",
        "Break",
    ),
    ShortcutAction(
        "shift_breaks_ms_increase",
        "Tutti i break verso il basso a schermo",
        "Shift+Down",
        "Break",
    ),
    ShortcutAction(
        "shift_breaks_traces_decrease",
        "Tutti i break verso sinistra a schermo",
        "Shift+Left",
        "Break",
    ),
    ShortcutAction(
        "shift_breaks_traces_increase",
        "Tutti i break verso destra a schermo",
        "Shift+Right",
        "Break",
    ),
)

_CATALOG_BY_ID = {item.action_id: item for item in SHORTCUT_CATALOG}


def default_shortcuts() -> dict[str, str]:
    return {item.action_id: item.default for item in SHORTCUT_CATALOG}


def shortcut_label(action_id: str) -> str:
    item = _CATALOG_BY_ID.get(action_id)
    return item.label if item is not None else action_id


def _parse_sequence_parts(spec: str) -> list[str]:
    text = str(spec or "").strip()
    if not text:
        return []
    return [part.strip() for part in text.split(",") if part.strip()]


def normalize_shortcuts(raw: dict[str, object] | None) -> dict[str, str]:
    defaults = default_shortcuts()
    out = dict(defaults)
    if not isinstance(raw, dict):
        return out
    for action_id in defaults:
        value = raw.get(action_id)
        if isinstance(value, str) and value.strip():
            out[action_id] = value.strip()
    # Migrazione: C ora copia tempi assoluti; undo_snap di default era C → Z.
    if (
        "copy_break_absolute_times" not in raw
        and str(out.get("undo_snap", "")).strip().upper() == "C"
    ):
        out["undo_snap"] = defaults.get("undo_snap", "Z")
    return out


def load_keyboard_shortcuts() -> dict[str, str]:
    try:
        if PREFS_PATH.is_file():
            data = json.loads(PREFS_PATH.read_text(encoding="utf-8"))
            return normalize_shortcuts(data)
    except Exception:
        pass
    return default_shortcuts()


def save_keyboard_shortcuts(shortcuts: dict[str, str]) -> None:
    normalized = normalize_shortcuts(shortcuts)
    PREFS_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = PREFS_PATH.with_suffix(".json.tmp")
    tmp.write_text(
        json.dumps(normalized, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    tmp.replace(PREFS_PATH)


def format_shortcut(spec: str) -> str:
    parts = _parse_sequence_parts(spec)
    if not parts:
        return "—"
    labels = [
        QtGui.QKeySequence(part).toString(QtGui.QKeySequence.SequenceFormat.NativeText)
        for part in parts
    ]
    return " / ".join(label for label in labels if label) or spec


def sequence_parts(spec: str) -> tuple[QtGui.QKeySequence, ...]:
    out: list[QtGui.QKeySequence] = []
    for part in _parse_sequence_parts(spec):
        seq = QtGui.QKeySequence(part)
        if not seq.isEmpty():
            out.append(seq)
    return tuple(out)


def find_shortcut_conflicts(
    shortcuts: dict[str, str],
) -> list[tuple[str, str, str]]:
    """Restituisce conflitti (azione_a, azione_b, sequenza)."""
    seen: dict[str, str] = {}
    conflicts: list[tuple[str, str, str]] = []
    for action_id, spec in shortcuts.items():
        for part in _parse_sequence_parts(spec):
            key = part.lower()
            prev = seen.get(key)
            if prev is not None and prev != action_id:
                conflicts.append((prev, action_id, part))
            else:
                seen[key] = action_id
    return conflicts


def _event_combination(event: QtGui.QKeyEvent) -> QtGui.QKeyCombination:
    getter = getattr(event, "keyCombination", None)
    if callable(getter):
        return getter()
    return QtGui.QKeyCombination.fromCombined(
        int(event.key()) | int(event.modifiers())
    )


def event_matches_shortcut_spec(
    event: QtGui.QKeyEvent,
    spec: str,
    *,
    allow_text_fallback: bool = False,
) -> bool:
    pressed = _event_combination(event)
    for seq in sequence_parts(spec):
        for index in range(seq.count()):
            if seq[index].toCombined() == pressed.toCombined():
                return True
    if not allow_text_fallback:
        return False
    text = event.text()
    if not text:
        return False
    for part in _parse_sequence_parts(spec):
        lowered = part.lower()
        if lowered in ("+", "=") and text in ("+", "＋", "="):
            return True
        if lowered == "-" and text in ("-", "−", "—"):
            return True
    return False


# Azione legata al tasto a vista 0° (Su = tempo −, Destra = tracce +).
# Con invertY e la mappa di rotazione, il verso a schermo cambia.
_ARROW_BREAK_PREFIXES = ("nudge_hover_break_", "shift_breaks_")
_ARROW_BREAK_KINDS = (
    "ms_decrease",
    "ms_increase",
    "traces_decrease",
    "traces_increase",
)
# kind fisico (significato a 0°) → kind che sposta il break nel verso della freccia.
_ARROW_KIND_FOR_ROTATION: dict[int, dict[str, str]] = {
    0: {
        "ms_decrease": "ms_decrease",
        "ms_increase": "ms_increase",
        "traces_decrease": "traces_decrease",
        "traces_increase": "traces_increase",
    },
    # x = tempo, y = −tracce. Su (Y minore) aumenta le tracce; Destra aumenta il tempo.
    90: {
        "ms_decrease": "traces_increase",
        "ms_increase": "traces_decrease",
        "traces_decrease": "ms_decrease",
        "traces_increase": "ms_increase",
    },
    # Entrambi gli assi negati: le frecce restano sugli stessi assi, verso invertito.
    180: {
        "ms_decrease": "ms_increase",
        "ms_increase": "ms_decrease",
        "traces_decrease": "traces_increase",
        "traces_increase": "traces_decrease",
    },
    # x = −tempo, y = tracce. Su diminuisce le tracce; Destra diminuisce il tempo.
    270: {
        "ms_decrease": "traces_decrease",
        "ms_increase": "traces_increase",
        "traces_decrease": "ms_increase",
        "traces_increase": "ms_decrease",
    },
}


def arrow_break_action_for_rotation(action_id: str, rotation_deg: int) -> str:
    """Riallinea l'azione freccia al verso visivo dopo la rotazione del sismogramma."""
    prefix = ""
    kind = ""
    for candidate in _ARROW_BREAK_PREFIXES:
        if action_id.startswith(candidate):
            prefix = candidate
            kind = action_id[len(candidate) :]
            break
    if not prefix or kind not in _ARROW_BREAK_KINDS:
        return action_id
    rot = int(rotation_deg) % 360
    table = _ARROW_KIND_FOR_ROTATION.get(rot, _ARROW_KIND_FOR_ROTATION[0])
    return prefix + table.get(kind, kind)


def event_matches_action(
    event: QtGui.QKeyEvent,
    action_id: str,
    shortcuts: dict[str, str],
) -> bool:
    spec = shortcuts.get(action_id) or default_shortcuts().get(action_id, "")
    allow_text_fallback = action_id in {"gain_up", "gain_down"}
    return event_matches_shortcut_spec(
        event,
        spec,
        allow_text_fallback=allow_text_fallback,
    )


def catalog_by_category() -> list[tuple[str, tuple[ShortcutAction, ...]]]:
    order: list[str] = []
    grouped: dict[str, list[ShortcutAction]] = {}
    for item in SHORTCUT_CATALOG:
        if item.category not in grouped:
            grouped[item.category] = []
            order.append(item.category)
        grouped[item.category].append(item)
    return [(category, tuple(grouped[category])) for category in order]


def apply_shortcuts_to_windows(windows: Iterable[object], shortcuts: dict[str, str]) -> None:
    mapping = dict(normalize_shortcuts(shortcuts))
    for window in windows:
        setattr(window, "_keyboard_shortcuts", dict(mapping))
