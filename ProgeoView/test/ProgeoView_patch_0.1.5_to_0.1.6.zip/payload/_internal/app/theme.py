"""Tema scuro fisso dell'applicazione (indipendente dal tema Windows)."""

from __future__ import annotations

from PyQt6 import QtCore, QtGui, QtWidgets

# Palette allineata al monitor dromocrona
COLOR_BG = "#1a2233"
COLOR_PANEL = "#232d42"
COLOR_PANEL_ELEVATED = "#2a3548"
COLOR_BORDER = "#3d4657"
COLOR_TEXT = "#e8eaed"
COLOR_MUTED = "#9aa3b2"
COLOR_ACCENT = "#3b82f6"
COLOR_ACCENT_HOVER = "#2563eb"
COLOR_ACCENT_PRESSED = "#1d4ed8"
COLOR_SUCCESS = "#86efac"
COLOR_WARNING = "#fcd34d"
COLOR_DISABLED = "#6b7280"
COLOR_SHADOW = "#0b1220"

APP_BASE_STYLESHEET = f"""
QWidget {{
    color: {COLOR_TEXT};
}}

QDialog, QMessageBox {{
    background-color: {COLOR_BG};
    color: {COLOR_TEXT};
}}

QGroupBox {{
    background-color: {COLOR_PANEL};
    color: {COLOR_TEXT};
    border: 1px solid {COLOR_BORDER};
    border-radius: 6px;
    margin-top: 10px;
    padding-top: 8px;
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
    color: {COLOR_TEXT};
}}

QTabWidget::pane {{
    background-color: {COLOR_PANEL};
    border: 1px solid {COLOR_BORDER};
    border-radius: 4px;
}}

QTabBar::tab {{
    background-color: {COLOR_PANEL_ELEVATED};
    color: {COLOR_MUTED};
    border: 1px solid {COLOR_BORDER};
    border-bottom: none;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    padding: 6px 12px;
    margin-right: 2px;
}}

QTabBar::tab:selected {{
    background-color: {COLOR_PANEL};
    color: {COLOR_TEXT};
}}

QTabBar::tab:hover:!selected {{
    color: {COLOR_TEXT};
}}

QLineEdit, QTextEdit, QPlainTextEdit, QKeySequenceEdit {{
    background-color: {COLOR_PANEL_ELEVATED};
    color: {COLOR_TEXT};
    border: 1px solid {COLOR_BORDER};
    border-radius: 5px;
    padding: 4px 6px;
    selection-background-color: {COLOR_ACCENT};
    selection-color: #ffffff;
}}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {{
    border-color: {COLOR_ACCENT};
}}

QRadioButton {{
    color: {COLOR_TEXT};
    spacing: 6px;
}}

QHeaderView::section {{
    background-color: {COLOR_PANEL};
    color: {COLOR_TEXT};
    border: 1px solid {COLOR_BORDER};
    padding: 4px 8px;
}}

QTableView, QTreeView, QTreeWidget, QListView {{
    background-color: {COLOR_PANEL_ELEVATED};
    color: {COLOR_TEXT};
    border: 1px solid {COLOR_BORDER};
    gridline-color: {COLOR_BORDER};
    outline: none;
    alternate-background-color: {COLOR_PANEL};
}}

QTableView::item:selected, QTreeView::item:selected, QListView::item:selected {{
    background-color: {COLOR_ACCENT};
    color: #ffffff;
}}

QScrollBar:vertical {{
    background: {COLOR_PANEL};
    width: 12px;
    margin: 0;
}}

QScrollBar::handle:vertical {{
    background: {COLOR_BORDER};
    border-radius: 4px;
    min-height: 24px;
}}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}

QScrollBar:horizontal {{
    background: {COLOR_PANEL};
    height: 12px;
    margin: 0;
}}

QScrollBar::handle:horizontal {{
    background: {COLOR_BORDER};
    border-radius: 4px;
    min-width: 24px;
}}

QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0;
}}

QToolTip {{
    background-color: {COLOR_PANEL};
    color: {COLOR_TEXT};
    border: 1px solid {COLOR_BORDER};
    padding: 4px 6px;
}}

QProgressBar {{
    background-color: {COLOR_PANEL_ELEVATED};
    color: {COLOR_TEXT};
    border: 1px solid {COLOR_BORDER};
    border-radius: 4px;
    text-align: center;
}}

QProgressBar::chunk {{
    background-color: {COLOR_ACCENT};
    border-radius: 3px;
}}

QSlider::groove:horizontal {{
    background: {COLOR_BORDER};
    height: 6px;
    border-radius: 3px;
}}

QSlider::handle:horizontal {{
    background: {COLOR_ACCENT};
    width: 14px;
    margin: -5px 0;
    border-radius: 7px;
}}

QStatusBar {{
    background-color: {COLOR_PANEL};
    color: {COLOR_MUTED};
}}
"""


def build_dark_palette() -> QtGui.QPalette:
    """QPalette scura fissa (non segue il tema chiaro/scuro di Windows)."""
    p = QtGui.QPalette()
    bg = QtGui.QColor(COLOR_BG)
    panel = QtGui.QColor(COLOR_PANEL)
    elevated = QtGui.QColor(COLOR_PANEL_ELEVATED)
    text = QtGui.QColor(COLOR_TEXT)
    muted = QtGui.QColor(COLOR_MUTED)
    accent = QtGui.QColor(COLOR_ACCENT)
    border = QtGui.QColor(COLOR_BORDER)
    disabled = QtGui.QColor(COLOR_DISABLED)
    white = QtGui.QColor("#ffffff")

    roles = {
        QtGui.QPalette.ColorRole.Window: bg,
        QtGui.QPalette.ColorRole.WindowText: text,
        QtGui.QPalette.ColorRole.Base: elevated,
        QtGui.QPalette.ColorRole.AlternateBase: panel,
        QtGui.QPalette.ColorRole.Text: text,
        QtGui.QPalette.ColorRole.Button: panel,
        QtGui.QPalette.ColorRole.ButtonText: text,
        QtGui.QPalette.ColorRole.BrightText: white,
        QtGui.QPalette.ColorRole.ToolTipBase: panel,
        QtGui.QPalette.ColorRole.ToolTipText: text,
        QtGui.QPalette.ColorRole.PlaceholderText: muted,
        QtGui.QPalette.ColorRole.Highlight: accent,
        QtGui.QPalette.ColorRole.HighlightedText: white,
        QtGui.QPalette.ColorRole.Link: accent,
        QtGui.QPalette.ColorRole.LinkVisited: QtGui.QColor(COLOR_ACCENT_HOVER),
        QtGui.QPalette.ColorRole.Light: elevated,
        QtGui.QPalette.ColorRole.Midlight: panel,
        QtGui.QPalette.ColorRole.Mid: border,
        QtGui.QPalette.ColorRole.Dark: bg,
        QtGui.QPalette.ColorRole.Shadow: QtGui.QColor(COLOR_SHADOW),
    }
    for role, color in roles.items():
        p.setColor(role, color)

    disabled_roles = (
        QtGui.QPalette.ColorRole.WindowText,
        QtGui.QPalette.ColorRole.Text,
        QtGui.QPalette.ColorRole.ButtonText,
        QtGui.QPalette.ColorRole.ToolTipText,
        QtGui.QPalette.ColorRole.HighlightedText,
    )
    for role in disabled_roles:
        p.setColor(QtGui.QPalette.ColorGroup.Disabled, role, disabled)
    p.setColor(
        QtGui.QPalette.ColorGroup.Disabled,
        QtGui.QPalette.ColorRole.Base,
        panel,
    )
    p.setColor(
        QtGui.QPalette.ColorGroup.Disabled,
        QtGui.QPalette.ColorRole.Button,
        panel,
    )
    p.setColor(
        QtGui.QPalette.ColorGroup.Disabled,
        QtGui.QPalette.ColorRole.Highlight,
        border,
    )
    return p


def install_italian_qt_translations(app: QtWidgets.QApplication) -> None:
    """Bottoni standard Qt (Salva, Annulla, Sì, …) in italiano."""
    QtCore.QLocale.setDefault(QtCore.QLocale(QtCore.QLocale.Language.Italian))
    path = QtCore.QLibraryInfo.path(QtCore.QLibraryInfo.LibraryPath.TranslationsPath)
    locale = QtCore.QLocale(QtCore.QLocale.Language.Italian)
    kept: list[QtCore.QTranslator] = []
    for name in ("qtbase", "qt"):
        translator = QtCore.QTranslator(app)
        if translator.load(locale, name, "_", path):
            app.installTranslator(translator)
            kept.append(translator)
    # Evita GC: i translator devono restare vivi per tutta la vita dell'app.
    app.setProperty("_progeo_qt_translators", kept)


def apply_application_theme(app: QtWidgets.QApplication) -> None:
    """
    Blocca l'aspetto sul tema scuro ProgeoView, indipendentemente da Windows.

    Fusion + ColorScheme.Dark + palette + stylesheet base evitano testo
    illeggibile quando l'utente ha il tema chiaro di sistema.
    """
    install_italian_qt_translations(app)
    app.setStyle("Fusion")
    try:
        app.styleHints().setColorScheme(QtCore.Qt.ColorScheme.Dark)
    except Exception:
        pass
    app.setPalette(build_dark_palette())
    existing = (app.styleSheet() or "").strip()
    if "ProgeoView-app-theme" not in existing:
        marker = "/* ProgeoView-app-theme */\n"
        app.setStyleSheet(
            marker + APP_BASE_STYLESHEET + (("\n" + existing) if existing else "")
        )
