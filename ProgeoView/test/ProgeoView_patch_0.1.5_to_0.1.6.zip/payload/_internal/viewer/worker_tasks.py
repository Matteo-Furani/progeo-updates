"""
Operazioni pesanti in background per Siesview (thread worker).

Qui vivono caricamento file, costruzione cache plot, filtri, cartelle FBP
e calcoli reciproci. La GUI (`main_window.py`) invia job tramite `GuiWorkerHub`;
ogni handler `task_*` restituisce un dizionario consumato dai callback registrati.
"""

from __future__ import annotations

import copy
import logging
import math
import os
import time

_LOG = logging.getLogger(__name__)
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from constants import (
    BREAK_NEAR_GAIN_DEFAULT,
    BREAK_NEAR_WINDOW_MS_DEFAULT,
    default_fbp_path_for_seismogram,
    natural_sort_key,
)
from io_obspy import (
    ObspyStream,
    _direct_read_seg2,
    _direct_read_segy,
    coerce_to_stream,
    obspy_read,
    preferred_seismic_formats,
)
from fbp_io import (
    interpolated_positive_onset_near_ref_ms,
    parse_fbp_markers_from_path,
    registry_shot_channel_for_fbp,
    trace_dt_ms,
)
from plot_cache import apply_break_zone_gain_to_plot_cache, siesview_trace_cache_worker
from perf_report import perf_section
from siesview_reciprocal_analysis import (
    build_shot_registry_for_folder,
    compute_all_reciprocal_pairs,
    fbp_disk_export_meta,
    load_fbp_relative_profile,
    run_reciprocal_auto_fix,
    run_reciprocal_estimate_missing,
)

@dataclass
class WorkerJob:
    """Singolo job in coda: tipo, revisione (per ignorare risultati obsoleti), payload."""

    kind: str
    revision: int
    payload: dict[str, Any]
    follow_up: str = "none"
    extra: dict[str, Any] | None = None


def load_stream_from_path(path: Path) -> tuple[ObspyStream | None, str | None]:
    """Apre SEG-Y / SEG-2 / .dat / .MRG; (stream, errore)."""
    if obspy_read is None:
        return None, "ObsPy non disponibile."

    errors: list[str] = []
    formats = preferred_seismic_formats(path)

    def _try_direct(label: str, reader: object, **kwargs: object) -> ObspyStream | None:
        try:
            obj = reader(str(path), **kwargs)  # type: ignore[operator]
            stream = coerce_to_stream(obj)
            if stream:
                return stream
        except Exception as exc:
            errors.append(f"{label}: {exc}")
        return None

    def _try_obspy(label: str, **kwargs: object) -> ObspyStream | None:
        try:
            stream = obspy_read(str(path), **kwargs)
            if stream:
                return stream
        except Exception as exc:
            errors.append(f"{label}: {exc}")
        return None

    def _try_mrg(label: str = "MRG") -> ObspyStream | None:
        try:
            from core.mrg_io import read_mrg_stream

            stream = read_mrg_stream(path)
            if stream:
                return stream
        except Exception as exc:
            errors.append(f"{label}: {exc}")
        return None

    for fmt in formats:
        if fmt == "MRG":
            stream = _try_mrg()
            if stream is not None:
                return stream, None
            continue
        if fmt == "SEGY" and _direct_read_segy is not None:
            stream = _try_direct(
                "SEGY-direct",
                _direct_read_segy,
                unpack_headers=False,
                headonly=False,
            )
            if stream is not None:
                return stream, None
        if fmt == "SEG2" and _direct_read_seg2 is not None:
            stream = _try_direct("SEG2-direct", _direct_read_seg2)
            if stream is not None:
                return stream, None
        stream = _try_obspy(fmt, format=fmt)
        if stream is not None:
            return stream, None

    # Ultimo tentativo: se l'estensione non era .mrg ma il contenuto sembra MRG.
    if path.suffix.lower() != ".mrg":
        stream = _try_mrg("MRG-fallback")
        if stream is not None:
            return stream, None

    stream = _try_obspy("auto")
    if stream is not None:
        return stream, None

    return None, "Impossibile aprire il file.\n" + "\n".join(errors)


def build_plot_cache(
    stream: ObspyStream,
    *,
    points_budget: int,
    max_display_ms: float | None,
    use_auto_gain: bool,
    display_scale_percentile: float,
    break_zone_gain_active: bool,
    arrival_markers: dict[int, float],
    break_near_window_ms: float,
    break_near_gain: float,
    agc_enabled: bool = False,
    agc_window_ms: float = 100.0,
) -> dict[str, Any]:
    """
    Normalizza e decima tutte le tracce per il disegno wiggle.

    Restituisce cache per traccia (`norm`, `times`), bounds temporali e budget punti.
    Con auto-gain disattivato applica scala globale (percentile sui picchi).
    """
    n_traces = len(stream)
    with perf_section("cache.build_plot_cache", n_traces=n_traces):
        max_points = int(max(280, min(5000, int(points_budget))))
        packs = [
            (tr, max_points, max_display_ms, use_auto_gain, agc_enabled, agc_window_ms)
            for tr in stream
        ]
        _parallel_min = 12
        _max_workers = min(8, max(2, os.cpu_count() or 4), n_traces)
        if n_traces >= _parallel_min and _max_workers >= 2:
            with perf_section(
                "cache.trace_parallel_map",
                n_traces=n_traces,
                workers=_max_workers,
            ):
                with ThreadPoolExecutor(max_workers=_max_workers) as ex:
                    chunks = list(ex.map(siesview_trace_cache_worker, packs))
        else:
            with perf_section("cache.trace_sequential", n_traces=n_traces):
                chunks = [siesview_trace_cache_worker(p) for p in packs]

        cache: list[dict[str, np.ndarray]] = []
        time_min_ms = math.inf
        time_max_ms = -math.inf
        global_peak = 0.0
        trace_peaks: list[float] = []
        for entry, peak_g, t0, t1 in chunks:
            if entry is None:
                entry = {
                    "norm": np.zeros(1, dtype=np.float32),
                    "times": np.zeros(1, dtype=np.float32),
                }
            if peak_g > global_peak:
                global_peak = peak_g
            if peak_g > 0.0 and math.isfinite(peak_g):
                trace_peaks.append(float(peak_g))
            cache.append(entry)
            if math.isfinite(t0) and math.isfinite(t1):
                time_min_ms = min(time_min_ms, t0)
                time_max_ms = max(time_max_ms, t1)
        if not cache:
            return {"cache": [], "time_bounds": (0.0, 1.0), "points_budget": max_points}

        scale = 1.0
        with perf_section("cache.post_normalize", n_traces=len(cache)):
            if not use_auto_gain:
                ref_peak = global_peak
                if trace_peaks:
                    pct = float(np.clip(display_scale_percentile, 50.0, 100.0))
                    ref_peak = float(np.percentile(trace_peaks, pct))
                    ref_peak = max(ref_peak, float(np.min(trace_peaks)))
                if not math.isfinite(ref_peak) or ref_peak <= 0.0:
                    ref_peak = global_peak if global_peak > 0.0 else 1.0
                scale = 1.0 / ref_peak
            for entry in cache:
                entry["norm"] = entry["norm"] * scale

            if break_zone_gain_active and arrival_markers and break_near_gain > 1.0:
                apply_break_zone_gain_to_plot_cache(
                    cache,
                    arrival_markers,
                    float(break_near_window_ms),
                    float(break_near_gain),
                )

        if math.isfinite(time_min_ms) and math.isfinite(time_max_ms):
            time_bounds = (time_min_ms, time_max_ms)
        else:
            time_bounds = (0.0, 1.0)
        return {
            "cache": cache,
            "time_bounds": time_bounds,
            "points_budget": max_points,
        }


def _trace_sampling_rate_hz(trace: object) -> float:
    sr = float(getattr(getattr(trace, "stats", None), "sampling_rate", 0.0) or 0.0)
    if sr > 0.0:
        return sr
    dt = float(getattr(getattr(trace, "stats", None), "delta", 0.0) or 0.0)
    if dt > 0.0:
        return 1.0 / dt
    return 1000.0


def copy_stream(stream: ObspyStream) -> ObspyStream:
    """Copia profonda dello stream (dati raw preservati per rifiltrare / ricaricare)."""
    return copy.deepcopy(stream)


def _bandpass_filter_orders(params: dict[str, Any]) -> tuple[int, int]:
    """Ordini passa-alto / passa-basso dal dialog (n_lo, n_hi) o corners simmetrico."""
    n_lo = params.get("n_lo")
    n_hi = params.get("n_hi")
    if n_lo is not None and n_hi is not None:
        return (
            int(np.clip(int(n_lo), 1, 20)),
            int(np.clip(int(n_hi), 1, 20)),
        )
    corners = int(np.clip(int(params.get("corners", 4)), 1, 20))
    return corners, corners


def apply_filter_to_stream(stream: ObspyStream, params: dict[str, Any]) -> None:
    """
    Applica il filtro IIR scelto in-place su ogni traccia dello stream.

    Bandpass: cascata passa-alto (freqmin) + passa-basso (freqmax) con ordini
    separati dalle pendenze UI. Usa `core.filter` con zero-phase (sosfiltfilt).
    """
    import importlib
    from core import filter as filter_mod

    importlib.reload(filter_mod)
    n_traces = len(stream)
    with perf_section("filter.apply_to_stream", n_traces=n_traces):
        ftype = params.get("ftype", "butter")
        corners = params.get("corners", 4)
        zerophase = params.get("zerophase", True)
        filter_type = params.get("filter_type", "bandpass")
        for tr in stream:
            df = _trace_sampling_rate_hz(tr)
            data = np.asarray(tr.data, dtype=np.float64)
            if filter_type == "bandpass":
                n_lo, n_hi = _bandpass_filter_orders(params)
                out = filter_mod.highpass(
                    data,
                    params["freqmin"],
                    df,
                    corners=n_lo,
                    zerophase=zerophase,
                    ftype=ftype,
                )
                out = filter_mod.lowpass(
                    out,
                    params["freqmax"],
                    df,
                    corners=n_hi,
                    zerophase=zerophase,
                    ftype=ftype,
                )
            elif filter_type == "bandstop":
                out = filter_mod.bandstop(
                    data,
                    params["freqmin"],
                    params["freqmax"],
                    df,
                    corners=corners,
                    zerophase=zerophase,
                    ftype=ftype,
                )
            elif filter_type == "lowpass":
                out = filter_mod.lowpass(
                    data,
                    params["freq"],
                    df,
                    corners=corners,
                    zerophase=zerophase,
                    ftype=ftype,
                )
            elif filter_type == "highpass":
                out = filter_mod.highpass(
                    data,
                    params["freq"],
                    df,
                    corners=corners,
                    zerophase=zerophase,
                    ftype=ftype,
                )
            else:
                continue
            tr.data = out


def snap_breaks_to_positive(
    stream: ObspyStream,
    marker_keys: list[int],
    markers: dict[int, float],
    *,
    time_lo: float,
    time_hi: float,
) -> dict[int, float]:
    """Sposta i break indicati sul primo onset positivo della traccia (tasto X)."""
    updated: dict[int, float] = {}
    for idx in marker_keys:
        if idx < 0 or idx >= len(stream):
            continue
        ref = markers.get(idx)
        tr = stream[idx]
        data = np.asarray(tr.data, dtype=np.float64).ravel()
        t = interpolated_positive_onset_near_ref_ms(
            data,
            trace_dt_ms(tr),
            float(ref) if ref is not None else None,
        )
        if t is None:
            continue
        updated[idx] = float(max(time_lo, min(time_hi, t)))
    return updated


@dataclass
class FbpFolderSeriesRow:
    path: str
    x: np.ndarray
    y_rel: np.ndarray
    shot_trace_idx: int
    shot_channel: int
    registry_shot_channel: int
    label: str
    shot_abs_ref_ms: float | None = None
    fbp_n_traces: int = 0
    fbp_samples: dict[int, int] = field(default_factory=dict)


@dataclass
class FbpFolderLoadResult:
    shot_registry: dict[str, int]
    series_rows: list[FbpFolderSeriesRow] = field(default_factory=list)


def load_fbp_folder_profiles(
    folder: Path,
    fbp_paths: list[Path],
    *,
    extra_active: Path | None = None,
) -> FbpFolderLoadResult:
    """Carica profili dromocrona relativi da una cartella .fbp (per monitor)."""
    shot_registry = build_shot_registry_for_folder(
        folder,
        list(fbp_paths),
    )
    rows: list[FbpFolderSeriesRow] = []
    paths_to_load = list(fbp_paths)
    if extra_active is not None and extra_active.exists():
        if not any(extra_active.resolve() == p.resolve() for p in paths_to_load):
            paths_to_load.append(extra_active)
    paths_to_load = sorted(
        paths_to_load,
        key=lambda p: natural_sort_key(p.name),
    )

    for fbp_path in paths_to_load:
        loaded = load_fbp_relative_profile(fbp_path, registry=shot_registry)
        if loaded is None:
            continue
        x, y_rel, shot = loaded
        shot_ref, n_traces, samples = fbp_disk_export_meta(fbp_path)
        rows.append(
            FbpFolderSeriesRow(
                path=str(fbp_path),
                x=np.asarray(x, dtype=np.float64),
                y_rel=np.asarray(y_rel, dtype=np.float64),
                shot_trace_idx=int(shot.shot_trace_idx),
                shot_channel=int(shot.shot_channel),
                registry_shot_channel=registry_shot_channel_for_fbp(
                    fbp_path, shot_registry
                ),
                label=fbp_path.stem,
                shot_abs_ref_ms=shot_ref,
                fbp_n_traces=int(n_traces),
                fbp_samples=dict(samples),
            )
        )
    return FbpFolderLoadResult(shot_registry=shot_registry, series_rows=rows)


def compute_reciprocal_pairs_task(
    series_meta: list[dict[str, object]],
    *,
    shot_registry: dict[str, int],
    prefer_memory: bool,
    tolerance_bands: object | None = None,
) -> tuple[Any, ...]:
    from siesview_reciprocal_analysis import ReciprocalToleranceBands

    bands = ReciprocalToleranceBands.from_dict(tolerance_bands)
    return compute_all_reciprocal_pairs(
        series_meta,
        shot_registry=shot_registry,
        prefer_memory=prefer_memory,
        tolerance_bands=bands,
    )


def reciprocal_fail_maps_from_pairs(pairs: object) -> dict[str, object]:
    """
    Deriva mappe FAIL (trace/bands/deltas) dalle coppie — da eseguire sul worker,
    non sul thread GUI.
    Chiavi = indici colonna griglia (come in failed_trace_bands_from_pairs).
    """
    from siesview_reciprocal_analysis import failed_trace_bands_from_pairs

    pairs_tuple = tuple(pairs or ())
    fails, bands, deltas = failed_trace_bands_from_pairs(pairs_tuple)
    return {
        "fail_traces": {
            int(col): sorted(int(t) for t in traces) for col, traces in fails.items()
        },
        "fail_bands": {
            int(col): {int(tr): float(tol) for tr, tol in band_map.items()}
            for col, band_map in bands.items()
        },
        "fail_deltas": {
            int(col): {int(tr): float(dv) for tr, dv in delta_map.items()}
            for col, delta_map in deltas.items()
        },
    }


def normalize_series_meta_for_worker(meta: dict[str, object]) -> dict[str, object]:
    """Copia leggera di meta dromocrona per payload worker (liste al posto di numpy)."""
    row: dict[str, object] = {}
    for key in (
        "label",
        "source_path",
        "path",
        "shot_trace_idx",
        "shot_channel",
        "registry_shot_channel",
        "fbp_n_traces",
        "shot_abs_ref_ms",
        "auto_fix_locked",
    ):
        if key in meta:
            row[key] = meta[key]
    y_raw = meta.get("y")
    if y_raw is not None:
        row["y"] = np.asarray(y_raw, dtype=np.float64).tolist()
    trace_raw = meta.get("trace_idx")
    if trace_raw is not None:
        row["trace_idx"] = np.asarray(trace_raw, dtype=np.int64).tolist()
    x_raw = meta.get("x")
    if x_raw is not None:
        row["x"] = np.asarray(x_raw, dtype=np.float64).tolist()
    samples = meta.get("fbp_samples")
    if isinstance(samples, dict):
        row["fbp_samples"] = {int(k): int(v) for k, v in samples.items()}
    return row


def denormalize_series_meta_from_worker(row: dict[str, object]) -> dict[str, object]:
    """Ripristina numpy arrays da payload worker."""
    meta = dict(row)
    if "y" in meta:
        meta["y"] = np.asarray(meta["y"], dtype=np.float64)
    if "trace_idx" in meta:
        meta["trace_idx"] = np.asarray(meta["trace_idx"], dtype=np.int64)
    if "x" in meta:
        meta["x"] = np.asarray(meta["x"], dtype=np.float64)
    return meta


def task_build_dromocrona_grid(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: costruisce matrice griglia dromocrona (I/O .fbp + numpy)."""
    from dromocrona_grid_data import (
        build_dromocrona_grid_data,
        dromocrona_grid_to_payload,
    )

    rows = [
        denormalize_series_meta_from_worker(dict(r))
        for r in (payload.get("series_meta") or [])
    ]
    shot_registry = {str(k): int(v) for k, v in dict(payload.get("shot_registry") or {}).items()}
    with perf_section("worker.build_dromocrona_grid", n_series=len(rows)):
        grid = build_dromocrona_grid_data(rows, shot_registry=shot_registry)
    return {
        "grid": dromocrona_grid_to_payload(grid),
        "revision": payload.get("revision"),
    }


def task_reciprocal_patch(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: patch incrementale mappa reciproci (niente Qt)."""
    from dromocrona_grid_data import sort_series_meta_by_shot_order
    from siesview_reciprocal_analysis import (
        ReciprocalToleranceBands,
        patch_reciprocal_pairs_map,
        reciprocal_pairs_from_map,
        reciprocal_pairs_to_map,
    )

    rows = [
        denormalize_series_meta_from_worker(dict(r))
        for r in (payload.get("series_meta") or [])
    ]
    shot_registry = {
        str(k): int(v) for k, v in dict(payload.get("shot_registry") or {}).items()
    }
    sorted_meta = sort_series_meta_by_shot_order(rows, shot_registry=shot_registry)
    existing = tuple(payload.get("existing_pairs") or ())
    pairs_map = reciprocal_pairs_to_map(existing)  # type: ignore[arg-type]
    affected_cols = {int(c) for c in (payload.get("affected_cols") or [])}
    traces_raw = payload.get("traces_by_col") or {}
    traces_by_col: dict[int, set[int]] | None = None
    if traces_raw:
        traces_by_col = {}
        for col_raw, traces in dict(traces_raw).items():
            traces_by_col[int(col_raw)] = {int(t) for t in traces}
    bands = ReciprocalToleranceBands.from_dict(payload.get("tolerance_bands"))
    prefer_memory = bool(payload.get("prefer_memory"))
    with perf_section(
        "worker.reciprocal_patch",
        n_cols=len(affected_cols),
        n_series=len(sorted_meta),
    ):
        updated = patch_reciprocal_pairs_map(
            dict(pairs_map),
            sorted_meta,
            affected_cols,
            affected_traces_by_series=traces_by_col,
            shot_registry=shot_registry,
            prefer_memory=prefer_memory,
            tolerance_bands=bands,
        )
    pairs = reciprocal_pairs_from_map(updated)
    fail_maps = reciprocal_fail_maps_from_pairs(pairs)
    return {
        "pairs": pairs,
        "prefer_memory": prefer_memory,
        "cache_key": payload.get("cache_key"),
        "affected_cols": sorted(int(c) for c in affected_cols),
        **fail_maps,
    }


def build_fbp_disk_exports_from_payload(
    series_meta: list[dict[str, object]],
    *,
    file_updates: dict[str, dict[int, float]] | None = None,
) -> dict[str, dict[str, object]]:
    """Costruisce payload export .fbp da meta (worker, senza Qt)."""
    from siesview_reciprocal_analysis import fbp_disk_write_template

    def _path_key(raw: object) -> str:
        try:
            return str(Path(str(raw)).resolve())
        except Exception:
            return str(raw)

    updates_by_path: dict[str, dict[int, float]] = {}
    if file_updates:
        for raw_path, trace_times in file_updates.items():
            if not trace_times:
                continue
            updates_by_path[_path_key(raw_path)] = {
                int(tr): float(val) for tr, val in trace_times.items()
            }

    path_to_meta: dict[str, dict[str, object]] = {}
    for row in series_meta:
        meta = denormalize_series_meta_from_worker(dict(row))
        source = meta.get("source_path") or meta.get("path")
        if source is None:
            continue
        path_to_meta[_path_key(source)] = meta

    path_list = list(path_to_meta.keys())
    if file_updates:
        for raw_path in file_updates:
            key = _path_key(raw_path)
            if key not in path_to_meta:
                path_list.append(key)

    exports: dict[str, dict[str, object]] = {}
    for path_key in path_list:
        meta = path_to_meta.get(path_key)
        fbp_path = Path(path_key)
        changed_traces = updates_by_path.get(path_key)
        if file_updates is not None and not changed_traces:
            continue
        if meta is None:
            continue

        lines = meta.get("fbp_disk_lines")
        line_by_trace = meta.get("fbp_line_by_trace")
        samples: dict[int, int]
        if isinstance(lines, list) and lines and isinstance(line_by_trace, dict):
            samples_raw = meta.get("fbp_samples") or {}
            samples = (
                {int(k): int(v) for k, v in samples_raw.items()}
                if isinstance(samples_raw, dict)
                else {}
            )
            line_by_trace_i = {int(k): int(v) for k, v in line_by_trace.items()}
            shot_abs_ref = meta.get("shot_abs_ref_ms")
        else:
            template = fbp_disk_write_template(fbp_path)
            if template is not None:
                ref, n_lines, samples_map, disk_lines, disk_line_by_trace = template
                lines = list(disk_lines)
                line_by_trace_i = {int(k): int(v) for k, v in disk_line_by_trace.items()}
                samples = {int(k): int(v) for k, v in samples_map.items()}
                shot_abs_ref = ref if ref is not None else meta.get("shot_abs_ref_ms")
                if int(n_lines) > 0 and not meta.get("fbp_n_traces"):
                    meta = dict(meta)
                    meta["fbp_n_traces"] = int(n_lines)
            else:
                # File assente: sintetizza da tempi relativi in memoria.
                from fbp_io import build_fbp_lines_from_break_map

                trace_arr = np.asarray(meta.get("trace_idx"), dtype=np.int64)
                y_rel = np.asarray(meta.get("y"), dtype=np.float64)
                n_pts = min(int(trace_arr.size), int(y_rel.size))
                raw_ref = meta.get("shot_abs_ref_ms")
                try:
                    ref_f0 = float(raw_ref) if raw_ref is not None else 0.0
                except (TypeError, ValueError):
                    ref_f0 = 0.0
                if not math.isfinite(ref_f0):
                    ref_f0 = 0.0
                break_map: dict[int, float] = {}
                for i in range(n_pts):
                    tr = int(trace_arr[i])
                    if tr < 0:
                        continue
                    y_val = float(y_rel[i])
                    if not math.isfinite(y_val):
                        continue
                    break_map[tr] = max(0.0, float(ref_f0) + max(0.0, y_val))
                n_lines = int(meta.get("fbp_n_traces") or 0)
                if n_lines <= 0 and break_map:
                    n_lines = max(break_map.keys()) + 1
                if n_lines <= 0 and trace_arr.size:
                    n_lines = int(trace_arr.max()) + 1
                if n_lines <= 0:
                    continue
                samples_raw = meta.get("fbp_samples") or {}
                samples = (
                    {int(k): int(v) for k, v in samples_raw.items()}
                    if isinstance(samples_raw, dict)
                    else {}
                )
                lines = build_fbp_lines_from_break_map(
                    n_lines, break_map, samples=samples
                )
                if not lines:
                    continue
                line_by_trace_i = {i: i for i in range(len(lines))}
                shot_abs_ref = ref_f0
                meta = dict(meta)
                meta["fbp_n_traces"] = len(lines)

        try:
            ref_f = float(shot_abs_ref)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            continue
        if not math.isfinite(ref_f):
            continue

        n_traces = int(meta.get("fbp_n_traces") or 0)
        if changed_traces is None:
            trace_idx = np.asarray(meta.get("trace_idx"), dtype=np.int64)
            y_rel = np.asarray(meta.get("y"), dtype=np.float64)
            if trace_idx.size == 0 or y_rel.size == 0:
                continue
            changed_traces = {
                int(tr): float(y)
                for tr, y in zip(trace_idx, y_rel)
                if math.isfinite(float(y))
            }
        if not changed_traces:
            continue
        if n_traces <= 0:
            n_traces = max(changed_traces.keys()) + 1

        exports[path_key] = {
            "changed_traces": {int(k): float(v) for k, v in changed_traces.items()},
            "shot_abs_ref_ms": float(ref_f),
            "n_traces": int(n_traces),
            "samples_by_trace": dict(samples),
            "fbp_disk_lines": list(lines),
            "fbp_line_by_trace": dict(line_by_trace_i),
            "linked_sgy": meta.get("sgy_path"),
        }
    return exports


def task_build_fbp_disk_exports(payload: dict[str, Any]) -> dict[str, Any]:
    rows = [dict(r) for r in (payload.get("series_meta") or [])]
    file_updates_raw = payload.get("file_updates")
    updates: dict[str, dict[int, float]] | None = None
    if isinstance(file_updates_raw, dict):
        updates = {
            str(k): {int(tr): float(v) for tr, v in dict(vals).items()}
            for k, vals in file_updates_raw.items()
        }
    with perf_section(
        "worker.build_fbp_disk_exports",
        n_series=len(rows),
        n_files=len(updates or {}),
    ):
        exports = build_fbp_disk_exports_from_payload(rows, file_updates=updates)
    return {"exports": exports}


def task_snap_reciprocal_fail(payload: dict[str, Any]) -> dict[str, Any]:
    from siesview_reciprocal_analysis import (
        ReciprocalToleranceBands,
        snap_reciprocal_fail_at_spot,
    )

    rows = [
        denormalize_series_meta_from_worker(dict(r))
        for r in (payload.get("series_meta") or [])
    ]
    pairs = tuple(payload.get("pairs") or ())
    with perf_section("worker.snap_reciprocal_fail"):
        return snap_reciprocal_fail_at_spot(
            rows,
            pairs,  # type: ignore[arg-type]
            column_idx=int(payload.get("column_idx") or 0),
            trace_idx=int(payload.get("trace_idx") or 0),
            shot_registry=dict(payload.get("shot_registry") or {}),
            prefer_memory=bool(payload.get("prefer_memory", True)),
            tolerance_bands=ReciprocalToleranceBands.from_dict(
                payload.get("tolerance_bands")
            ),
        )


def task_load_file(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: legge sismogramma + .fbp omonimo e prepara cache plot."""
    path = Path(payload["path"])
    with perf_section("load_file.read_stream", path=path.name):
        stream, err = load_stream_from_path(path)
    if stream is None:
        raise RuntimeError(err or "Lettura file fallita.")
    if len(stream) == 0:
        raise RuntimeError("Il file non contiene tracce valide.")

    fbp_path = Path(
        payload.get("fbp_path") or default_fbp_path_for_seismogram(path)
    )
    markers: dict[int, float] = {}
    base_times: dict[int, float] = {}
    fbp_applied = False
    if fbp_path.exists():
        with perf_section("load_file.parse_fbp", path=fbp_path.name):
            markers, base_times = parse_fbp_markers_from_path(
                fbp_path, stream, trace_shift=0
            )
        fbp_applied = bool(markers)

    break_zone_gain_active = bool(
        fbp_applied
        and markers
        and payload.get("break_zone_gain_user_enabled")
    )
    n_traces = len(stream)
    max_plot = int(payload.get("max_plot_points", 2800))
    max_total = int(payload.get("max_total_plot_points", 500_000))
    points_budget = int(payload.get("points_budget") or 0)
    if points_budget <= 280:
        points_budget = max(280, min(max_plot, max(280, max_total // max(1, n_traces))))

    with perf_section("load_file.build_plot_cache", n_traces=n_traces):
        cache_result = build_plot_cache(
            stream,
            points_budget=points_budget,
            max_display_ms=payload.get("max_display_ms"),
            use_auto_gain=bool(payload.get("use_auto_gain")),
            display_scale_percentile=float(payload.get("display_scale_percentile", 98.0)),
            break_zone_gain_active=break_zone_gain_active,
            arrival_markers=dict(markers) if break_zone_gain_active else {},
            break_near_window_ms=float(
                payload.get("break_near_window_ms", BREAK_NEAR_WINDOW_MS_DEFAULT)
            ),
            break_near_gain=float(payload.get("break_near_gain", BREAK_NEAR_GAIN_DEFAULT)),
            agc_enabled=bool(payload.get("agc_enabled")),
            agc_window_ms=float(payload.get("agc_window_ms", 100.0)),
        )

    with perf_section("load_file.copy_raw_stream", n_traces=n_traces):
        raw_stream = copy_stream(stream)

    return {
        "stream": stream,
        "raw_stream": raw_stream,
        "path": str(path),
        "fbp_path": str(fbp_path),
        "fbp_applied": fbp_applied,
        "markers": markers,
        "base_times": base_times,
        "break_zone_gain_active": break_zone_gain_active,
        "cache": cache_result.get("cache"),
        "time_bounds": cache_result.get("time_bounds"),
        "points_budget": cache_result.get("points_budget"),
    }


def task_build_cache(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: costruisce la cache plot per lo stream corrente."""
    stream: ObspyStream = payload["stream"]
    return build_plot_cache(
        stream,
        points_budget=int(payload["points_budget"]),
        max_display_ms=payload.get("max_display_ms"),
        use_auto_gain=bool(payload.get("use_auto_gain")),
        display_scale_percentile=float(payload.get("display_scale_percentile", 98.0)),
        break_zone_gain_active=bool(payload.get("break_zone_gain_active")),
        arrival_markers=dict(payload.get("arrival_markers") or {}),
        break_near_window_ms=float(
            payload.get("break_near_window_ms", BREAK_NEAR_WINDOW_MS_DEFAULT)
        ),
        break_near_gain=float(payload.get("break_near_gain", BREAK_NEAR_GAIN_DEFAULT)),
        agc_enabled=bool(payload.get("agc_enabled")),
        agc_window_ms=float(payload.get("agc_window_ms", 100.0)),
    )


def task_apply_filter(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: filtra copia dello stream raw (non modifica l'originale salvato)."""
    params = dict(payload["filter_params"])
    source = payload.get("raw_stream") or payload.get("stream")
    if source is None:
        raise RuntimeError("Nessuno stream da filtrare.")
    stream = copy_stream(source)
    apply_filter_to_stream(stream, params)
    return {"stream": stream, "filter_params": params}


def task_load_fbp_folder(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: profili dromocrona + registry shot per il monitor."""
    folder = Path(payload["folder"])
    fbp_paths = [Path(p) for p in payload.get("fbp_paths") or []]
    fbp_paths = sorted(fbp_paths, key=lambda p: natural_sort_key(p.name))
    extra = payload.get("extra_active")
    result = load_fbp_folder_profiles(
        folder,
        fbp_paths,
        extra_active=Path(extra) if extra else None,
    )
    return {
        "shot_registry": dict(result.shot_registry),
        "series_rows": [
            {
                "path": row.path,
                "x": row.x,
                "y_rel": row.y_rel,
                "shot_trace_idx": row.shot_trace_idx,
                "shot_channel": row.shot_channel,
                "registry_shot_channel": row.registry_shot_channel,
                "label": row.label,
                "shot_abs_ref_ms": row.shot_abs_ref_ms,
                "fbp_n_traces": row.fbp_n_traces,
                "fbp_samples": dict(row.fbp_samples),
            }
            for row in result.series_rows
        ],
    }


def task_reciprocals(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: calcola coppie reciproche FAIL per evidenziazione monitor/griglia."""
    rows = [
        denormalize_series_meta_from_worker(dict(r))
        for r in (payload.get("series_meta") or [])
    ]
    with perf_section("worker.reciprocals", n_series=len(rows)):
        pairs = compute_reciprocal_pairs_task(
            rows,
            shot_registry=dict(payload.get("shot_registry") or {}),
            prefer_memory=bool(payload.get("prefer_memory")),
            tolerance_bands=payload.get("tolerance_bands"),
        )
    fail_maps = reciprocal_fail_maps_from_pairs(pairs)
    return {
        "pairs": pairs,
        "cache_key": payload.get("cache_key"),
        "prefer_memory": bool(payload.get("prefer_memory")),
        **fail_maps,
    }


def task_auto_fix_reciprocals(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: auto-correzione break reciproci FAIL (solo calcolo, no Qt/disco)."""
    from siesview_reciprocal_analysis import ReciprocalToleranceBands

    params = dict(payload.get("params") or {})
    t0 = time.perf_counter()
    bands = ReciprocalToleranceBands.from_dict(
        params.get("tolerance_bands") or payload.get("tolerance_bands")
    )
    result = run_reciprocal_auto_fix(
        list(payload.get("series_meta") or []),
        dict(payload.get("shot_registry") or {}),
        method=str(params.get("method", "hybrid")),
        prefer_memory=bool(payload.get("prefer_memory", True)),
        max_col_iter=int(params.get("max_col_iter", 6)),
        max_corner_iter=int(params.get("max_corner_iter", 2)),
        blend_col=float(params.get("blend_col", 0.5)),
        blend_corner=float(params.get("blend_corner", 0.25)),
        max_step=float(params.get("max_step", 1.0)),
        max_step_corner=float(params.get("max_step_corner", 0.35)),
        min_corner_delta=float(params.get("min_corner_delta", 0.6)),
        tolerance_bands=bands,
    )
    result["worker_elapsed_ms"] = float((time.perf_counter() - t0) * 1000.0)
    return result


def task_estimate_missing_reciprocals(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: stima break mancanti da reciproci + interpolazione."""
    from siesview_reciprocal_analysis import ReciprocalToleranceBands

    params = dict(payload.get("params") or {})
    t0 = time.perf_counter()
    bands = ReciprocalToleranceBands.from_dict(
        params.get("tolerance_bands") or payload.get("tolerance_bands")
    )
    result = run_reciprocal_estimate_missing(
        list(payload.get("series_meta") or []),
        dict(payload.get("shot_registry") or {}),
        prefer_memory=bool(payload.get("prefer_memory", True)),
        fill_interp=bool(params.get("fill_interp", True)),
        tolerance_bands=bands,
    )
    pairs = result.get("pairs") or ()
    fail_maps = reciprocal_fail_maps_from_pairs(pairs)
    result.update(fail_maps)
    result["worker_elapsed_ms"] = float((time.perf_counter() - t0) * 1000.0)
    return result


def task_snap_breaks(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: snap break al primo positivo per le tracce richieste."""
    stream: ObspyStream = payload["stream"]
    keys = [int(k) for k in payload.get("marker_keys") or []]
    markers = {int(k): float(v) for k, v in (payload.get("markers") or {}).items()}
    lo, hi = payload.get("time_limits") or (0.0, 1e9)
    updated = snap_breaks_to_positive(
        stream,
        keys,
        markers,
        time_lo=float(lo),
        time_hi=float(hi),
    )
    return {"updated_markers": updated}


def task_write_fbp_batch(payload: dict[str, Any]) -> dict[str, Any]:
    """Worker: scrittura batch di file .fbp già preparati in memoria."""
    from fbp_io import normalize_fbp_disk_lines, write_fbp_text_atomic

    saved_paths: list[str] = []
    failed_paths: list[str] = []
    for item in payload.get("files") or []:
        path = Path(str(item.get("path") or ""))
        content = item.get("content")
        if not path or not isinstance(content, str):
            if path:
                failed_paths.append(str(path))
            continue
        try:
            lines = content.splitlines()
            normalized = normalize_fbp_disk_lines(lines)
            if normalized:
                content = "\n".join(normalized) + "\n"
            if not write_fbp_text_atomic(path, content):
                failed_paths.append(str(path))
                continue
        except Exception as exc:
            _LOG.warning("Scrittura .fbp batch fallita (%s): %s", path, exc)
            failed_paths.append(str(path))
            continue
        saved_paths.append(str(path))
    return {"saved_paths": saved_paths, "failed_paths": failed_paths}


_TASKS = {
    "load_file": task_load_file,
    "build_cache": task_build_cache,
    "apply_filter": task_apply_filter,
    "load_fbp_folder": task_load_fbp_folder,
    "build_dromocrona_grid": task_build_dromocrona_grid,
    "reciprocals": task_reciprocals,
    "reciprocal_patch": task_reciprocal_patch,
    "build_fbp_disk_exports": task_build_fbp_disk_exports,
    "snap_reciprocal_fail": task_snap_reciprocal_fail,
    "auto_fix_reciprocals": task_auto_fix_reciprocals,
    "estimate_missing_reciprocals": task_estimate_missing_reciprocals,
    "snap_breaks": task_snap_breaks,
    "write_fbp_batch": task_write_fbp_batch,
}


def dispatch_worker_job(job: WorkerJob) -> dict[str, Any]:
    """Instrada un WorkerJob al handler `task_*` corrispondente."""
    handler = _TASKS.get(job.kind)
    if handler is None:
        raise ValueError(f"Job worker sconosciuto: {job.kind}")
    return handler(job.payload)
