"""Export griglia dromocrone nel formato foglio P Excel (FBP)."""

from __future__ import annotations

from pathlib import Path

from PyQt6 import QtWidgets

from dromocrona_grid_data import (
    SHOT_EPS_MS,
    DromocronaGridData,
    prepare_dromocrona_grid_for_export,
)

_DROMOCRONA_EXPORT_DECIMALS = 2
_DROMOCRONA_SHOT_EXCEL_FILL = None  # lazy PatternFill (giallo)
_DROMOCRONA_MISSING_EXCEL_FILL = None  # lazy PatternFill (arancio)


def _suggested_line_title(folder: Path | None) -> str:
    if folder is None:
        return ""
    stem = folder.name.strip()
    if not stem:
        return ""
    return f"{stem}-" if not stem.endswith("-") else stem


def suggested_export_filename(line_title: str) -> str:
    base = str(line_title).rstrip("-").strip()
    return f"{base} - FBP.xlsx" if base else "dromocrone.xlsx"


def prompt_export_line_title(
    parent: QtWidgets.QWidget | None,
    folder: Path | None,
) -> str | None:
    default = _suggested_line_title(folder)
    text, ok = QtWidgets.QInputDialog.getText(
        parent,
        "Titolo foglio P",
        "Testo per la cella A1 (es. 2508-):",
        QtWidgets.QLineEdit.EchoMode.Normal,
        default,
    )
    if not ok:
        return None
    title = str(text).strip()
    if not title:
        QtWidgets.QMessageBox.information(
            parent,
            "Esporta griglia dromocrone",
            "Inserisci un titolo per la cella A1.",
        )
        return None
    return title


def _dromocrona_shot_fill() -> object:
    """Giallo: zero dromocrona sul canale shot (riferimento)."""
    global _DROMOCRONA_SHOT_EXCEL_FILL
    if _DROMOCRONA_SHOT_EXCEL_FILL is None:
        from openpyxl.styles import PatternFill

        _DROMOCRONA_SHOT_EXCEL_FILL = PatternFill(
            fill_type="solid",
            fgColor="FFFF00",
        )
    return _DROMOCRONA_SHOT_EXCEL_FILL


def _dromocrona_missing_fill() -> object:
    """Arancio: pick mancante (placeholder 0 nel .fbp)."""
    global _DROMOCRONA_MISSING_EXCEL_FILL
    if _DROMOCRONA_MISSING_EXCEL_FILL is None:
        from openpyxl.styles import PatternFill

        _DROMOCRONA_MISSING_EXCEL_FILL = PatternFill(
            fill_type="solid",
            fgColor="FFA500",
        )
    return _DROMOCRONA_MISSING_EXCEL_FILL


def _shot_channel_for_column(grid: DromocronaGridData, file_idx: int) -> int:
    if file_idx < len(grid.shot_channels):
        return int(grid.shot_channels[file_idx])
    return 0


def _fill_for_relative_zero(
    grid: DromocronaGridData,
    channel_1based: int,
    file_idx: int,
) -> object:
    """Zero relativo: giallo se canale shot, arancio se pick mancante."""
    if _shot_channel_for_column(grid, file_idx) == int(channel_1based):
        return _dromocrona_shot_fill()
    return _dromocrona_missing_fill()


def _round_dromocrona_export_value(val: float) -> float:
    return round(float(val), _DROMOCRONA_EXPORT_DECIMALS)


def _is_dromocrona_zero(val: float) -> bool:
    return abs(float(val)) <= SHOT_EPS_MS


def _p_sheet_row_b_for_channel(channel_1based: int) -> int:
    """Indice colonna B foglio P = numero geofono (1-based)."""
    return max(1, int(channel_1based))


def _grid_rows_for_p_sheet(
    grid: DromocronaGridData,
) -> tuple[int, int, dict[int, tuple[float | None, ...]]]:
    """Indicizza i valori per riga del foglio P (colonna B = n° geofono)."""
    n_files = len(grid.column_labels)
    placed: dict[int, list[float | None]] = {}
    for row_idx, ch in enumerate(grid.row_channels):
        row_b = _p_sheet_row_b_for_channel(int(ch))
        row_vals = grid.values[row_idx] if row_idx < len(grid.values) else ()
        bucket = placed.setdefault(row_b, [None] * n_files)
        for file_idx in range(n_files):
            val = row_vals[file_idx] if file_idx < len(row_vals) else None
            if val is not None:
                bucket[file_idx] = float(val)
    min_m = 1
    max_m = max(placed.keys()) if placed else 1
    normalized: dict[int, tuple[float | None, ...]] = {}
    for row_b, vals in placed.items():
        normalized[int(row_b)] = tuple(vals)
    return min_m, max_m, normalized


def export_dromocrona_grid_excel(
    output_path: Path,
    *,
    line_title: str,
    grid: DromocronaGridData,
) -> None:
    """
    Esporta dromocrone nel formato «foglio P» (riferimento 2508 - FBP.xlsx).

    - A1: titolo scelto dall'utente
    - Riga 3: numero/nome file per ogni colonna dromocrona (non il canale shot)
    - Colonna B: n° geofono (1, 2, 3…)
    - Colonne C+: tempi dromocrona (ms), max 2 decimali;
      0 sullo shot in giallo, 0 per pick mancante in arancio
    """
    try:
        from openpyxl import Workbook
    except ImportError as exc:
        raise RuntimeError(
            "Serve openpyxl per l'export Excel.\nEsegui: pip install openpyxl"
        ) from exc

    if not grid.column_labels:
        raise ValueError("Nessuna dromocrona da esportare.")

    title = str(line_title).strip()
    if not title:
        raise ValueError("Titolo foglio P mancante.")

    # Colonne per canale shot crescente: primo 0 in alto a sinistra.
    grid = prepare_dromocrona_grid_for_export(grid)

    wb = Workbook()
    ws = wb.active
    ws.title = "P"
    ws.cell(row=1, column=1, value=title)

    n_files = len(grid.column_labels)
    for file_idx, label in enumerate(grid.column_labels):
        col = 3 + file_idx
        # Intestazione colonna = numero/nome file (stem), non canale shot.
        ws.cell(row=3, column=col, value=_file_number_header(label))

    min_m, max_m, placed = _grid_rows_for_p_sheet(grid)
    excel_row = 4
    for meter in range(min_m, max_m + 1):
        ws.cell(row=excel_row, column=2, value=float(meter))
        row_vals = placed.get(meter, (None,) * n_files)
        for file_idx in range(n_files):
            val = row_vals[file_idx] if file_idx < len(row_vals) else None
            cell = ws.cell(row=excel_row, column=3 + file_idx)
            if val is None:
                cell.value = 0
                cell.fill = _fill_for_relative_zero(grid, meter, file_idx)
                continue
            rounded = _round_dromocrona_export_value(float(val))
            if _is_dromocrona_zero(rounded):
                cell.value = 0
                cell.fill = _fill_for_relative_zero(grid, meter, file_idx)
            else:
                cell.value = rounded
        excel_row += 1

    wb.save(output_path)


def _file_number_header(label: object) -> str:
    """Numero/nome file dall'etichetta colonna (stem .fbp, es. 0083)."""
    text = str(label or "").strip()
    return text


def suggested_absolute_export_filename(line_title: str) -> str:
    base = str(line_title).rstrip("-").strip()
    return f"{base} - FBP Tempi Assoluti.xlsx" if base else "tempi_assoluti.xlsx"


def export_fbp_absolute_times_excel(
    output_path: Path,
    *,
    line_title: str,
    grid: DromocronaGridData,
) -> None:
    """Esporta tempi assoluti (ms) dal .fbp, uno per colonna/shot.

    Stessa struttura del foglio P, ma i valori sono i tempi assoluti scritti
    nel file .fbp (es. 100.000 ms), non relativi allo shot.
    Lo shot è evidenziato in giallo, pick mancanti (0 assoluto) in arancio.
    """
    try:
        from openpyxl import Workbook
    except ImportError as exc:
        raise RuntimeError(
            "Serve openpyxl per l'export Excel.\nEsegui: pip install openpyxl"
        ) from exc

    if not grid.column_labels:
        raise ValueError("Nessuna dromocrona da esportare.")

    title = str(line_title).strip()
    if not title:
        raise ValueError("Titolo mancante.")

    # Colonne per canale shot crescente: primo 0 in alto a sinistra.
    grid = prepare_dromocrona_grid_for_export(grid)

    shot_fill = _dromocrona_shot_fill()

    wb = Workbook()
    ws = wb.active
    ws.title = "Tempi Assoluti"
    ws.cell(row=1, column=1, value=title)
    ws.cell(row=2, column=1, value="Tempi assoluti (ms) - valori diretti dal file .fbp")

    n_files = len(grid.column_labels)
    for file_idx, label in enumerate(grid.column_labels):
        col = 3 + file_idx
        ws.cell(row=3, column=col, value=str(label))

    min_m, max_m, placed = _grid_rows_for_p_sheet(grid)

    # minimo positivo per colonna (shot = tempo assoluto più basso con pick valido)
    col_min: list[float | None] = [None] * n_files
    for meter in range(min_m, max_m + 1):
        row_vals = placed.get(meter, (None,) * n_files)
        for file_idx in range(n_files):
            val = row_vals[file_idx] if file_idx < len(row_vals) else None
            if val is None or _is_dromocrona_zero(float(val)):
                continue
            v = float(val)
            if col_min[file_idx] is None or v < col_min[file_idx]:  # type: ignore[operator]
                col_min[file_idx] = v

    excel_row = 4
    for meter in range(min_m, max_m + 1):
        ws.cell(row=excel_row, column=2, value=float(meter))
        row_vals = placed.get(meter, (None,) * n_files)
        for file_idx in range(n_files):
            val = row_vals[file_idx] if file_idx < len(row_vals) else None
            cell = ws.cell(row=excel_row, column=3 + file_idx)
            if val is None or _is_dromocrona_zero(float(val)):
                cell.value = 0
                cell.fill = _fill_for_relative_zero(grid, meter, file_idx)
                continue
            rounded = _round_dromocrona_export_value(float(val))
            cell.value = rounded
            if col_min[file_idx] is not None and abs(float(val) - col_min[file_idx]) < 1e-6:  # type: ignore[operator]
                cell.fill = shot_fill
        excel_row += 1

    wb.save(output_path)


def run_absolute_times_export_dialog(
    parent: "QtWidgets.QWidget | None",
    grid: DromocronaGridData,
    *,
    folder: "Path | None",
) -> bool:
    """Chiede titolo e percorso, poi esporta i tempi assoluti."""
    line_title = prompt_export_line_title(parent, folder)
    if line_title is None:
        return False
    default_name = suggested_absolute_export_filename(line_title)
    initial = str(folder.parent / default_name) if folder is not None else default_name
    path_str, _ = QtWidgets.QFileDialog.getSaveFileName(
        parent,
        "Esporta tempi assoluti FBP",
        initial,
        "Excel (*.xlsx);;Tutti i file (*.*)",
    )
    if not path_str:
        return False
    output_path = Path(path_str)
    if output_path.suffix.lower() != ".xlsx":
        output_path = output_path.with_suffix(".xlsx")
    try:
        export_fbp_absolute_times_excel(
            output_path,
            line_title=line_title,
            grid=grid,
        )
    except Exception as exc:
        QtWidgets.QMessageBox.critical(
            parent,
            "Esporta tempi assoluti FBP",
            str(exc),
        )
        return False
    QtWidgets.QMessageBox.information(
        parent,
        "Esporta tempi assoluti FBP",
        f"File salvato:\n{output_path}",
    )
    return True


def run_dromocrona_grid_export_dialog(
    parent: QtWidgets.QWidget | None,
    grid: DromocronaGridData,
    *,
    folder: Path | None,
) -> bool:
    """Chiede titolo e percorso, poi esporta il foglio P."""
    line_title = prompt_export_line_title(parent, folder)
    if line_title is None:
        return False
    default_name = suggested_export_filename(line_title)
    initial = str(folder.parent / default_name) if folder is not None else default_name
    path_str, _ = QtWidgets.QFileDialog.getSaveFileName(
        parent,
        "Esporta griglia dromocrone",
        initial,
        "Excel (*.xlsx);;Tutti i file (*.*)",
    )
    if not path_str:
        return False
    output_path = Path(path_str)
    if output_path.suffix.lower() != ".xlsx":
        output_path = output_path.with_suffix(".xlsx")
    try:
        export_dromocrona_grid_excel(
            output_path,
            line_title=line_title,
            grid=grid,
        )
    except Exception as exc:
        QtWidgets.QMessageBox.critical(
            parent,
            "Esporta griglia dromocrone",
            str(exc),
        )
        return False
    QtWidgets.QMessageBox.information(
        parent,
        "Esporta griglia dromocrone",
        f"File salvato:\n{output_path}",
    )
    return True
