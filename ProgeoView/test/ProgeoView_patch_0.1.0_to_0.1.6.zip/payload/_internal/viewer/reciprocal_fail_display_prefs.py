"""Preferenze colori break FAIL reciproci sul sismogramma."""

from __future__ import annotations

import json
from typing import Any

from bootstrap import config_dir

PREFS_PATH = config_dir() / "reciprocal_fail_display.json"

# Default: verde se Δ>0, nero se Δ<0 (evita confusione con fill tracce rosse).
DEFAULT_RECIPROCAL_FAIL_DISPLAY: dict[str, Any] = {
    "positive_color": "#22c55e",
    "negative_color": "#111827",
}


def _normalize_color(val: object, fallback: str) -> str:
    if not isinstance(val, str):
        return fallback
    text = val.strip()
    if not text:
        return fallback
    color = text if text.startswith("#") else f"#{text}"
    if len(color) not in (4, 7, 9):
        return fallback
    try:
        int(color[1:], 16)
    except ValueError:
        return fallback
    return color.lower()


def _normalize_prefs(raw: dict[str, Any] | None) -> dict[str, Any]:
    out = dict(DEFAULT_RECIPROCAL_FAIL_DISPLAY)
    if not isinstance(raw, dict):
        return out
    out["positive_color"] = _normalize_color(
        raw.get("positive_color"), out["positive_color"]
    )
    out["negative_color"] = _normalize_color(
        raw.get("negative_color"), out["negative_color"]
    )
    return out


def load_reciprocal_fail_display_prefs() -> dict[str, Any]:
    try:
        if PREFS_PATH.is_file():
            data = json.loads(PREFS_PATH.read_text(encoding="utf-8"))
            return _normalize_prefs(data)
    except Exception:
        pass
    return dict(DEFAULT_RECIPROCAL_FAIL_DISPLAY)


def save_reciprocal_fail_display_prefs(settings: dict[str, Any]) -> None:
    normalized = _normalize_prefs(settings)
    PREFS_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = PREFS_PATH.with_suffix(".json.tmp")
    tmp.write_text(
        json.dumps(normalized, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    tmp.replace(PREFS_PATH)


def pick_color_hex(
    parent,
    *,
    title: str,
    current: str,
) -> str | None:
    from PyQt6 import QtGui, QtWidgets

    initial = QtGui.QColor(current)
    if not initial.isValid():
        initial = QtGui.QColor("#22c55e")
    color = QtWidgets.QColorDialog.getColor(initial, parent, title)
    if not color.isValid():
        return None
    return color.name(QtGui.QColor.NameFormat.HexRgb)


class ReciprocalFailDisplayColorsDialog:
    """Dialog colori break FAIL sul sismogramma (Δ>0 / Δ<0)."""

    def __init__(self, parent=None, *, settings: dict[str, Any] | None = None) -> None:
        from PyQt6 import QtGui, QtWidgets

        self._QtWidgets = QtWidgets
        self._QtGui = QtGui
        self._dialog = QtWidgets.QDialog(parent)
        self._dialog.setWindowTitle("Colori FAIL")
        self._dialog.setMinimumWidth(280)
        self._result: dict[str, str] | None = None
        current = _normalize_prefs(settings)

        self._pos_color = str(current["positive_color"])
        self._neg_color = str(current["negative_color"])

        form = QtWidgets.QFormLayout()
        form.setSpacing(10)
        self._pos_btn = QtWidgets.QPushButton()
        self._neg_btn = QtWidgets.QPushButton()
        self._pos_btn.clicked.connect(self._pick_positive)
        self._neg_btn.clicked.connect(self._pick_negative)
        self._refresh_buttons()
        form.addRow("Positivo", self._pos_btn)
        form.addRow("Negativo", self._neg_btn)

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButton.Ok
            | QtWidgets.QDialogButtonBox.StandardButton.Cancel
            | QtWidgets.QDialogButtonBox.StandardButton.RestoreDefaults
        )
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self._dialog.reject)
        buttons.button(
            QtWidgets.QDialogButtonBox.StandardButton.RestoreDefaults
        ).clicked.connect(self._restore_defaults)

        layout = QtWidgets.QVBoxLayout(self._dialog)
        layout.setContentsMargins(14, 14, 14, 12)
        layout.setSpacing(12)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def exec(self) -> object:
        return self._dialog.exec()

    def settings(self) -> dict[str, str] | None:
        return self._result

    def _refresh_buttons(self) -> None:
        QtGui = self._QtGui
        for btn, color in (
            (self._pos_btn, self._pos_color),
            (self._neg_btn, self._neg_color),
        ):
            q = QtGui.QColor(color)
            text_color = "#ffffff" if q.lightness() < 140 else "#111111"
            btn.setText(color)
            btn.setStyleSheet(
                f"background:{color}; color:{text_color}; "
                "padding:6px 12px; border:1px solid #666; border-radius:4px;"
            )

    def _pick_positive(self) -> None:
        picked = pick_color_hex(
            self._dialog,
            title="Colore positivo",
            current=self._pos_color,
        )
        if picked:
            self._pos_color = picked
            self._refresh_buttons()

    def _pick_negative(self) -> None:
        picked = pick_color_hex(
            self._dialog,
            title="Colore negativo",
            current=self._neg_color,
        )
        if picked:
            self._neg_color = picked
            self._refresh_buttons()

    def _restore_defaults(self) -> None:
        self._pos_color = str(DEFAULT_RECIPROCAL_FAIL_DISPLAY["positive_color"])
        self._neg_color = str(DEFAULT_RECIPROCAL_FAIL_DISPLAY["negative_color"])
        self._refresh_buttons()

    def _on_accept(self) -> None:
        self._result = {
            "positive_color": self._pos_color,
            "negative_color": self._neg_color,
        }
        self._dialog.accept()
