"""Finestra principale Siesview: sismogramma, break, filtri, export.

Monolite che orchestra UI Qt, cache plot (`plot_cache`), job background
(`GuiWorkerHub` + `worker_tasks`) e sessione multi-finestra (`viewer_session`).
"""

from __future__ import annotations

import logging
import math
import numpy as np
import pyqtgraph as pg
import time
from PyQt6 import QtCore, QtGui, QtWidgets
from app_theme import apply_viewer_theme
from constants import BREAK_NEAR_GAIN_DEFAULT, BREAK_NEAR_WINDOW_MS_DEFAULT, DEFAULT_AGC_WINDOW_MS, DEFAULT_GAIN, DEFAULT_MAX_PLOT_POINTS, DEFAULT_MAX_TOTAL_PLOT_POINTS, DEFAULT_TIME_WINDOW_S, DEFAULT_TRACE_SPACING, DEFAULT_FBP_EXTENSION, MAX_DISPLAY_GAIN_LINEAR, MIN_DISPLAY_GAIN_LINEAR, SEISMIC_DATA_EXTENSIONS, SIDEBAR_DEFAULT_WIDTH, SIDEBAR_MAX_WIDTH, SIDEBAR_MIN_WIDTH, default_fbp_path_for_seismogram, find_fbp_for_seismogram, fbp_matches_seismogram, is_fbp_file, natural_sort_key
from dialogs import SeismogramLoadWaitDialog
from dromocrona_grid_data import build_dromocrona_absolute_grid_data
from dromocrona_grid_window import build_dromocrona_grid_data, run_dromocrona_grid_export_dialog
from export.dromocrona_fbp_export import run_absolute_times_export_dialog
from export.velocity_morphology_export import export_velocity_morphology_file, morphology_has_velocity_export, suggested_velocity_export_filename
from fbp_p_to_s import (
    GenerateSFromPDialog,
    generate_s_fbp_files,
    guess_p_folder_for_s_seismogram,
    guess_s_folder_for_seismogram,
    list_seismograms_in_folder,
    pair_p_to_s_seismograms,
    select_p_fbp_files,
    select_s_seismogram_files,
)
from fbp_monitor import FbpVelocityMonitorWindow
from keyboard_shortcuts import (
    apply_shortcuts_to_windows,
    arrow_break_action_for_rotation,
    event_matches_action,
    load_keyboard_shortcuts,
    save_keyboard_shortcuts,
)
from keyboard_shortcuts_dialog import run_keyboard_shortcuts_dialog
from filter_dialog import FilterDialog
from filter_loader import filter_module
from gui_worker import GuiWorkerHub
from io_obspy import obspy_read
from morphology import LineMorphology, LineMorphologyMapWindow, WEBENGINE_AVAILABLE, geophone_channel_number, load_line_morphology_excel, load_line_morphology_json, morphology_geophones_wgs84, pick_line_morphology_excel_sheet
from pathlib import Path
from perf_report import flush_report, perf_section, record
from shot_registry_dialog import ShotRegistryRow, run_shot_registry_editor_dialog
from fbp_io import (
    build_fbp_lines_from_break_map,
    fbp_lines_have_corruption,
    format_fbp_time_ms,
    normalize_fbp_disk_lines,
    parse_fbp_row,
    registry_shot_channel_for_fbp,
    repair_corrupted_fbp_files_in_folder,
    time_from_samples_ms,
    write_fbp_text_atomic,
)
from plot_items import ArrivalBreakOverlayItem, SiesviewViewBox
from siesview_reciprocal_analysis import (
    _fbp_line_by_trace_from_lines,
    _fbp_registry_key,
    build_relative_profile,
    build_shot_registry_for_folder,
    detect_shot_from_fbp_path,
    fbp_disk_export_meta,
    fbp_missing_pick_line,
    fbp_relative_to_absolute_ms,
    invalidate_fbp_parse_cache,
    load_fbp_relative_profile,
    parse_fbp_line,
)
from reciprocal_fail_display_prefs import ReciprocalFailDisplayColorsDialog
from trace_display_dialog import TraceDisplayDialog
from trace_display_prefs import save_trace_display_prefs
from viewer_session import SiesviewViewerSession
from worker_tasks import copy_stream
from typing import Callable

_LOG = logging.getLogger(__name__)

class SiesviewWindow(QtWidgets.QMainWindow):
    """
    Viewer sismogramma singola finestra.

    Gestisce caricamento file, disegno wiggle, editing break/FBP, dialog filtro
    e collegamento al monitor dromocrona (finestra primaria della sessione).
    """

    def __init__(
            self,
            *,
            viewer_session: SiesviewViewerSession | None = None,
            session_primary: bool = True,
        ) -> None:
            super().__init__()
            self._viewer_session: SiesviewViewerSession | None = None
            self._is_session_primary = bool(session_primary)
            self.setWindowTitle("ProgeoView – Visualizzatore sismogrammi")
            self.resize(1300, 820)
            try:
                from app.app_icon import apply_app_icon

                apply_app_icon(None, self)
            except Exception:
                pass

            self._load_wait_dialog: SeismogramLoadWaitDialog | None = None
            self.stream = None
            self._raw_stream = None
            self._stream_epoch = 0
            self.loaded_path: Path | None = None
            self._plot_cache = None
            self._plot_time_bounds = (0.0, 1.0)
            # Punti per traccia (display): valori più bassi = gain/zoom più reattivi.
            self.max_plot_points = DEFAULT_MAX_PLOT_POINTS
            self.max_total_plot_points = DEFAULT_MAX_TOTAL_PLOT_POINTS
            self._current_baseline = None
            self._empty_text_item = None
            self._reset_view_on_plot = True
            self._time_range_full = (0.0, 1.0)
            self._cache_points_budget = None
            self._global_scale = 1.0
            self._hover_track_idx: int | None = None
            self._trace_items: list[dict[str, object] | None] = []
            self._initial_zoom_ratio_x = 1.0
            self._initial_zoom_ratio_y = 1.0
            self._trace_spacing_factor = DEFAULT_TRACE_SPACING
            self._max_display_time_ms = None
            self._time_window_override_ms = float(DEFAULT_TIME_WINDOW_S) * 1000.0
            self._amplitude_squeeze = 1.0
            self._min_pixel_trace_gap = 3.0
            # Contorno traccia tenue: il riempimento (più saturo/sopra) deve dominare visivamente.
            self._trace_color = "#4a4a4a"
            self._plot_background_color = "#f5f5f5"
            self._trace_fill_color = "#ff1744"
            self._trace_fill_negative_color = "#2979ff"
            self._trace_fill_alpha = 245
            # Percentile per scala display (solo cache): attenua picchi isolati senza filtrare i dati.
            self._display_scale_percentile = 98.0
            self._display_clip_factor = 2.0
            self._wiggle_fill_on = True
            self._fill_positive_on = True
            self._fill_negative_on = False
            # Più punti = contorno fill più fedele; ~200/lobo resta leggero con molte tracce.
            self._fill_max_points_per_blob = 200
            # Fase 2A: riusa QGraphicsPathItem per traccia (setPath invece di remove/add).
            self._fill_path_reuse_enabled = True
            self._trace_baseline_offset = 0.5
            self._default_trace_pen = pg.mkPen(
                color=self._trace_color, width=0.9, cosmetic=True
            )
            self._hover_trace_pen = pg.mkPen(color="#16a34a", width=2.8)
            self._last_track_label_idx: int | None = None
            self._last_track_tick_labels: list[tuple[float, str]] | None = None
            self._x_axis_negative_margin = 0.1
            self._time_axis_headroom_ms = 0.0
            self._folder_extensions = SEISMIC_DATA_EXTENSIONS
            self._current_folder: Path | None = None
            self._app_gain_event_filter_installed = False
            # Break (pick): una quota tempo (ms) per indice traccia; disegno overlay come v5.
            self._arrival_markers: dict[int, float] = {}
            self._arrival_base_times: dict[int, float] = {}
            self._arrival_overlay_item: ArrivalBreakOverlayItem | None = None
            self._last_right_track: int | None = None
            self._last_right_y: float | None = None
            self._break_undo_pushed_this_gesture = False
            self._arrival_marker_color = "#0066ff"
            self._arrival_marker_width = 3.0
            self._arrival_marker_half_span = 0.5
            self._arrival_pen = pg.mkPen(
                QtGui.QColor(self._arrival_marker_color),
                width=float(self._arrival_marker_width),
            )
            from reciprocal_fail_display_prefs import (
                DEFAULT_RECIPROCAL_FAIL_DISPLAY,
                load_reciprocal_fail_display_prefs,
            )

            fail_prefs = load_reciprocal_fail_display_prefs()
            self._arrival_fail_positive_color = str(
                fail_prefs.get(
                    "positive_color",
                    DEFAULT_RECIPROCAL_FAIL_DISPLAY["positive_color"],
                )
            )
            self._arrival_fail_negative_color = str(
                fail_prefs.get(
                    "negative_color",
                    DEFAULT_RECIPROCAL_FAIL_DISPLAY["negative_color"],
                )
            )
            fail_w = float(self._arrival_marker_width) + 1.0
            self._arrival_fail_pen_positive = pg.mkPen(
                QtGui.QColor(self._arrival_fail_positive_color),
                width=fail_w,
            )
            self._arrival_fail_pen_negative = pg.mkPen(
                QtGui.QColor(self._arrival_fail_negative_color),
                width=fail_w,
            )
            # Opzionale: colori FAIL Δ+/Δ− anche sul sismogramma (menu Dromocrone).
            self._seismogram_fail_colors_enabled = False
            # Limite repaint overlay break (~72 Hz): evita coda GUI con mouse molto veloce.
            self._break_overlay_min_interval_s = 1.0 / 72.0
            self._break_overlay_last_paint_t = 0.0
            self._break_ov_deferred = False
            self._break_ov_throttle_timer = QtCore.QTimer(self)
            self._break_ov_throttle_timer.setSingleShot(True)
            self._break_ov_throttle_timer.timeout.connect(self._break_overlay_throttled_flush)
            self._break_right_gesture_active = False
            self._swap_break_mouse_buttons = False
            self._hover_break_nudge_active = False
            self._shift_breaks_gesture_active = False
            self._break_trace_cache_on = False
            # Undo dopo tasto X (snap al positivo): snapshot completi di markers/base_times.
            self._break_undo_stack: list[tuple[dict[int, float], dict[int, float]]] = []
            self._break_undo_max = 128
            # Avviso salvataggio solo se pochi pick mancanti (probabilmente dimenticanza).
            self._missing_break_warn_max = 5
            self._break_ruler_enabled = False
            self._ruler_vertex_a: tuple[float, float] | None = None
            self._ruler_vertex_b: tuple[float, float] | None = None
            self._ruler_preview_item: pg.PlotCurveItem | None = None
            self._ruler_vertex_scatter: pg.ScatterPlotItem | None = None
            # Gain locale intorno ai break: solo se l'utente attiva il toggle nel menu Break.
            self._break_zone_gain_active = False
            self._break_near_gain = BREAK_NEAR_GAIN_DEFAULT
            self._break_near_window_ms = BREAK_NEAR_WINDOW_MS_DEFAULT
            self._fbp_velocity_window: FbpVelocityMonitorWindow | None = None
            self._line_morphology: LineMorphology | None = None
            self._line_morphology_map_window: LineMorphologyMapWindow | None = None
            self._active_fbp_path: Path | None = None
            # Destinazione .fbp esplicita (es. break S) quando diversa dal .fbp accoppiato al sgy.
            self._fbp_save_target_override: Path | None = None
            self._last_monitor_edit_path: Path | None = None
            self._shot_registry: dict[str, int] = {}
            self._shot_registry_overrides: dict[str, int] = {}
            self._filter_params_active: dict[str, object] | None = None
            self._keyboard_shortcuts = load_keyboard_shortcuts()
            self._fbp_autosync_enabled = True
            self._fbp_autosave_dirty_traces: set[int] = set()
            self._fbp_monitor_dirty_traces: set[int] = set()
            self._deferred_grid_refresh_timer = QtCore.QTimer(self)
            self._deferred_grid_refresh_timer.setSingleShot(True)
            # Debounce più lungo: evita raffiche griglia/FAIL durante pick rapidi.
            self._deferred_grid_refresh_timer.setInterval(1100)
            self._deferred_grid_refresh_timer.timeout.connect(
                self._flush_deferred_monitor_grid_refresh
            )
            self._deferred_monitor_sync_timer = QtCore.QTimer(self)
            self._deferred_monitor_sync_timer.setSingleShot(True)
            self._deferred_monitor_sync_timer.setInterval(400)
            self._deferred_monitor_sync_timer.timeout.connect(
                self._flush_deferred_monitor_sync
            )
            # Scrittura .fbp differita: durante pick usiamo solo la RAM per la dromo.
            self._deferred_fbp_disk_timer = QtCore.QTimer(self)
            self._deferred_fbp_disk_timer.setSingleShot(True)
            self._deferred_fbp_disk_timer.setInterval(2800)
            self._deferred_fbp_disk_timer.timeout.connect(self._flush_deferred_fbp_disk)
            self._fbp_async_disk_flush_busy = False
            self._fbp_folder_import_busy = False
            self._view_rotation_deg = 0
            self._x_range_debounce_ms = 45
            self._x_range_debounce_timer = QtCore.QTimer(self)
            self._x_range_debounce_timer.setSingleShot(True)
            self._x_range_debounce_timer.timeout.connect(self._on_x_range_debounced)
            self._list_load_guard_path: Path | None = None
            self._list_load_guard_until = 0.0
            self._dromocrona_loading_min_files = 4
            self._fbp_monitor_loaded_folder: Path | None = None
            self._fbp_monitor_preload_timer = QtCore.QTimer(self)
            self._fbp_monitor_preload_timer.setSingleShot(True)
            self._fbp_monitor_preload_timer.setInterval(0)
            self._fbp_monitor_preload_timer.timeout.connect(
                self._preload_fbp_dromocrona_monitor
            )
            self._fbp_import_chunk_timer = QtCore.QTimer(self)
            self._fbp_import_chunk_timer.timeout.connect(self._process_fbp_import_chunk)
            self._fbp_import_chunk_state: dict[str, object] | None = None
            self._fbp_import_chunk_size = 16
            self._plot_chunk_timer = QtCore.QTimer(self)
            self._plot_chunk_timer.setSingleShot(True)
            self._plot_chunk_timer.timeout.connect(self._process_plot_chunk)
            self._plot_chunk_state: dict[str, object] | None = None
            self._plot_chunk_size = 48
            self._cache_build_in_flight = False
            self._filter_dialog: FilterDialog | None = None
            self._trace_display_dialog: TraceDisplayDialog | None = None
            self._trace_display_applying = False

            self._build_ui()
            apply_viewer_theme(self)
            self._set_fbp_sync_status(
                "break in memoria — salvataggio al cambio file o prima lettura .fbp",
                tone="ok",
            )
            self._init_gui_worker()
            if viewer_session is None:
                self._init_viewer_session(SiesviewViewerSession(), primary=True)
            else:
                self._init_viewer_session(viewer_session, primary=session_primary)

    def _init_gui_worker(self) -> None:
        self._gui_worker = GuiWorkerHub(self)
        self._gui_worker.register(
            "load_file",
            self._on_worker_load_file_done,
            self._on_worker_load_file_error,
        )
        self._gui_worker.register(
            "apply_filter",
            self._on_worker_apply_filter_done,
            self._on_worker_apply_filter_error,
        )
        self._gui_worker.register(
            "load_fbp_folder",
            self._on_worker_load_fbp_folder_done,
            self._on_worker_load_fbp_folder_error,
        )
        self._gui_worker.register(
            "snap_breaks",
            self._on_worker_snap_breaks_done,
            self._on_worker_snap_breaks_error,
        )
        self._gui_worker.register(
            "reciprocals",
            self._on_worker_reciprocals_done,
            self._on_worker_reciprocals_error,
        )
        self._gui_worker.register(
            "reciprocal_patch",
            self._on_worker_reciprocal_patch_done,
            self._on_worker_reciprocal_patch_error,
        )
        self._gui_worker.register(
            "build_dromocrona_grid",
            self._on_worker_build_dromocrona_grid_done,
            self._on_worker_build_dromocrona_grid_error,
        )
        self._gui_worker.register(
            "build_fbp_disk_exports",
            self._on_worker_build_fbp_disk_exports_done,
            self._on_worker_build_fbp_disk_exports_error,
        )
        self._gui_worker.register(
            "snap_reciprocal_fail",
            self._on_worker_snap_reciprocal_fail_done,
            self._on_worker_snap_reciprocal_fail_error,
        )
        self._gui_worker.register(
            "write_fbp_batch",
            self._on_worker_write_fbp_batch_done,
            self._on_worker_write_fbp_batch_error,
        )
        self._gui_worker.register(
            "auto_fix_reciprocals",
            self._on_worker_auto_fix_reciprocals_done,
            self._on_worker_auto_fix_reciprocals_error,
        )
        self._gui_worker.register(
            "estimate_missing_reciprocals",
            self._on_worker_estimate_missing_reciprocals_done,
            self._on_worker_estimate_missing_reciprocals_error,
        )
        self._gui_worker.register(
            "build_cache",
            self._on_worker_build_cache_done,
            self._on_worker_build_cache_error,
        )
        self._pending_fbp_folder_ctx: dict[str, object] | None = None
        self._pending_load_followup: dict[str, object] | None = None
        self._fbp_batch_write_waiter: QtCore.QEventLoop | None = None
        self._fbp_batch_write_result: list[Path] = []
        self._fbp_batch_write_failed: list[Path] = []
        self._fbp_batch_write_pending: list[Path] = []
        self._fbp_batch_write_callbacks: list[Callable[[list[Path], list[Path]], None]] = []
        self._fbp_batch_write_queue: list[
            tuple[list[dict[str, str]], Callable[[list[Path], list[Path]], None] | None]
        ] = []
        self._fbp_hold_batch_queue = False
        self._close_flush_active = False

    def _cache_worker_payload(
            self, points_budget: int | None = None
        ) -> dict[str, object]:
            n_traces = len(self.stream) if self.stream is not None else 1
            if points_budget is None:
                points_budget = self._trace_point_budget(n_traces)
            return {
                "stream": self.stream,
                "points_budget": int(points_budget),
                "max_display_ms": self._effective_time_window_ms(),
                "use_auto_gain": self._per_trace_auto_gain_enabled(),
                "display_scale_percentile": float(
                    getattr(self, "_display_scale_percentile", 98.0) or 98.0
                ),
                "break_zone_gain_active": bool(
                    getattr(self, "_break_zone_gain_active", False)
                ),
                "arrival_markers": dict(self._arrival_markers),
                "break_near_window_ms": float(
                    getattr(self, "_break_near_window_ms", BREAK_NEAR_WINDOW_MS_DEFAULT)
                ),
                "break_near_gain": float(
                    getattr(self, "_break_near_gain", BREAK_NEAR_GAIN_DEFAULT)
                ),
                "agc_enabled": self._agc_enabled(),
                "agc_window_ms": self._agc_window_ms(),
            }

    def _apply_cache_worker_result(self, result: dict[str, object]) -> None:
        cache = result.get("cache")
        if cache is not None:
            self._plot_cache = cache
            bounds = result.get("time_bounds")
            if bounds is not None:
                self._plot_time_bounds = tuple(bounds)  # type: ignore[assignment]
            budget = result.get("points_budget")
            if budget is not None:
                self._cache_points_budget = int(budget)

    def _run_cache_follow_up(self, follow_up: str) -> None:
        if follow_up in ("", "none"):
            return
        if follow_up == "plot_stream":
            self._plot_stream()
        elif follow_up == "fast_redraw":
            if self.stream and self._seismogram_graphics_ready(len(self.stream)):
                if self._plot_cache is not None:
                    self._sync_trace_entries_from_cache(self._plot_cache)
                self._fast_visual_redraw()
            else:
                self._plot_stream()
        elif follow_up == "replot_if_possible":
            if not self.stream:
                return
            self._reset_view_on_plot = False
            if self._plot_cache is None:
                self._plot_stream()
            elif self._seismogram_graphics_ready(len(self.stream)):
                self._sync_trace_entries_from_cache(self._plot_cache)
                self._fast_visual_redraw()
            else:
                self._plot_stream()
        elif follow_up == "break_gain":
            self._reset_view_on_plot = False
            self._plot_stream()
            self._rebuild_arrival_overlay()

    def _on_worker_load_file_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            self._hide_seismogram_loading()
            try:
                stream = result.get("stream")
                if stream is None:
                    return
                self.stream = stream
                raw = result.get("raw_stream")
                self._raw_stream = raw if raw is not None else copy_stream(stream)
                self._filter_params_active = None
                self._update_filter_restore_action_state()
                self._clear_break_markers()
                markers = dict(result.get("markers") or {})
                base_times = dict(result.get("base_times") or {})
                self._arrival_markers.update(markers)
                self._arrival_base_times.update(base_times)
                self._break_zone_gain_active = bool(result.get("break_zone_gain_active"))
                path = Path(str(result.get("path") or ""))
                fbp_path = Path(
                    str(
                        result.get("fbp_path")
                        or default_fbp_path_for_seismogram(path)
                    )
                )
                fbp_applied = bool(result.get("fbp_applied"))
                self._active_fbp_path = fbp_path
                if not self.stream:
                    QtWidgets.QMessageBox.warning(
                        self,
                        "File vuoto",
                        "Il file selezionato non contiene tracce valide.",
                    )
                    return
                self.loaded_path = path
                self.path_label.setText(str(path))
                self._reset_view_on_plot = True
                self._apply_suggested_agc_window_from_stream(rebuild_cache=False)
                extra = getattr(job, "extra", None) or {}
                paired = extra.get("paired_fbp")
                paired_path = Path(paired) if paired else fbp_path
                followup = self._pending_load_followup
                self._pending_load_followup = None
                if result.get("cache"):
                    self._invalidate_build_cache_jobs()
                    self._apply_cache_worker_result(result)
                    self._show_seismogram_loading(path, "Disegno sismogramma…")
                    self._plot_stream()
                    self._sync_plot_with_fbp_after_display(
                        paired_fbp=paired_path if fbp_applied else None,
                        plot_already_done=True,
                    )
                    self._sync_filter_dialog_from_stream()
                    if followup:
                        sgy = followup.get("highlight_sgy")
                        fbp = followup.get("highlight_fbp")
                        if sgy is not None:
                            self._highlight_folder_item(Path(str(sgy)))
                        if fbp is not None and Path(str(fbp)).exists():
                            self._highlight_break_item(Path(str(fbp)))
                            self._set_fbp_sync_status("caricato da disco")
                    self._hide_seismogram_loading()
                    flush_report(note="load_file_plot_done")
                else:
                    self._show_seismogram_loading(path, "Preparazione tracce…")
                    self._build_plot_cache(
                        follow_up="plot_stream",
                        load_sync_extra={
                            "paired_fbp": paired_path if fbp_applied else None,
                            "pending_load_followup": followup,
                        },
                    )
            except Exception:
                self._hide_seismogram_loading()
                raise
            flush_report(note="load_file_done")

    def _on_worker_load_file_error(self, job: object, message: str) -> None:
        self._hide_seismogram_loading()
        QtWidgets.QMessageBox.critical(
            self,
            "Errore di lettura",
            message,
        )

    def _on_worker_apply_filter_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            extra = getattr(job, "extra", None) or {}
            if int(extra.get("stream_epoch", -1)) != int(
                getattr(self, "_stream_epoch", 0)
            ):
                return
            stream = result.get("stream")
            if stream is not None:
                self.stream = stream
            params = extra.get("filter_params") or result.get("filter_params") or {}
            self._filter_params_active = dict(params) if params else {}
            self._update_filter_restore_action_state()
            dialog = extra.get("dialog")
            if dialog is not None:
                dialog.set_apply_status("Filtro applicato.", error=False)
                dialog._on_refresh_clicked()
            # Ricostruzione grafica completa: il fast-redraw lascia fill obsoleti
            # (soprattutto sulle ultime tracce) dopo un cambio dati grosso come il filtro.
            self._invalidate_plot_cache(reset_graphics=True, reset_view=False)
            self._build_plot_cache(follow_up="plot_stream")
            flush_report(note="apply_filter_done")

    def _on_worker_apply_filter_error(self, job: object, message: str) -> None:
        extra = getattr(job, "extra", None) or {}
        if int(extra.get("stream_epoch", -1)) != int(
            getattr(self, "_stream_epoch", 0)
        ):
            return
        dialog = extra.get("dialog")
        msg = f"Applicazione filtro fallita:\n{message}"
        if dialog is not None:
            dialog.set_apply_status(msg, error=True)
        QtWidgets.QMessageBox.critical(
            dialog if dialog is not None else self,
            "Errore filtro",
            msg,
        )

    def _on_worker_load_fbp_folder_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            ctx = self._pending_fbp_folder_ctx or {}
            self._pending_fbp_folder_ctx = None
            self._fbp_import_chunk_timer.stop()
            self._fbp_import_chunk_state = None
            try:
                win = ctx.get("win")
                if win is None:
                    if bool(ctx.get("show_loading")):
                        self._hide_dromocrona_loading()
                    return
                shot_registry = dict(result.get("shot_registry") or {})
                self._shot_registry = shot_registry
                session = getattr(self, "_viewer_session", None)
                if session is not None:
                    session.set_shared_shot_registry(shot_registry)
                locked_source = win._locked_series_source_path()
                win.clear_series(defer_ui=True)
                rows = list(result.get("series_rows") or [])
                prepared: list[dict[str, object]] = []
                for row in rows:
                    fbp_path = Path(str(row["path"]))
                    prepared.append(
                        {
                            "x": np.asarray(row["x"]),
                            "y_rel": np.asarray(row["y_rel"]),
                            "fbp_path": fbp_path,
                            "label": str(row.get("label") or fbp_path.stem),
                            "sgy_path": self._find_seismogram_for_fbp(fbp_path),
                            "shot_trace_idx": int(row["shot_trace_idx"]),
                            "shot_channel": int(row["shot_channel"]),
                            "registry_shot_channel": int(row["registry_shot_channel"]),
                            "shot_abs_ref_ms": row.get("shot_abs_ref_ms"),
                            "fbp_n_traces": int(row.get("fbp_n_traces") or 0),
                            "fbp_samples": dict(row.get("fbp_samples") or {}),
                        }
                    )
                if not prepared:
                    win.refresh_line_morphology_ui(fit_view=False)
                    if bool(ctx.get("show_loading")):
                        self._hide_dromocrona_loading()
                    if bool(ctx.get("show_window")):
                        self._bring_fbp_monitor_to_front(win)
                    return
                active = getattr(self, "_active_fbp_path", None)
                synced_active = False
                if (
                    active is not None
                    and self._arrival_markers
                    and self._fbp_is_linked_to_open_sgy(active)
                ):
                    synced_active = self._sync_monitor_series_from_markers(active)
                    if synced_active:
                        prepared = [
                            row
                            for row in prepared
                            if not self._same_path(row["fbp_path"], active)
                        ]
                elif active is not None:
                    prepared.sort(
                        key=lambda row: (
                            0 if self._same_path(row["fbp_path"], active) else 1
                        )
                    )
                if not prepared:
                    if synced_active:
                        win.refresh_line_morphology_ui(fit_view=False)
                        ctx_folder = ctx.get("folder")
                        if ctx_folder is not None:
                            owner = self._session_owner_window()
                            owner._fbp_monitor_loaded_folder = Path(ctx_folder)
                        if bool(ctx.get("show_window")):
                            self._bring_fbp_monitor_to_front(win)
                        win.schedule_dromocrona_grid_refresh(immediate=False)
                        self._refresh_morphology_map_shot_highlights()
                    if bool(ctx.get("show_loading")):
                        self._hide_dromocrona_loading()
                    return
                if bool(ctx.get("show_loading")):
                    self._show_dromocrona_loading(
                        "Disegno grafico dromocrone…",
                        detail=f"0 / {len(prepared)}",
                    )
                self._fbp_folder_import_busy = True
                self._fbp_import_chunk_state = {
                    "win": win,
                    "ctx": ctx,
                    "rows": prepared,
                    "index": 0,
                    "locked_source": locked_source,
                    "synced_active": synced_active,
                }
                win.begin_series_batch()
                self._fbp_import_chunk_timer.start(0)
            except Exception:
                self._fbp_folder_import_busy = False
                if bool(ctx.get("show_loading")):
                    self._hide_dromocrona_loading()
                raise

    def _process_fbp_import_chunk(self) -> None:
        state = self._fbp_import_chunk_state
        if state is None:
            self._fbp_import_chunk_timer.stop()
            return
        win = state["win"]
        ctx = state["ctx"]
        rows = state["rows"]
        idx = int(state["index"])
        total = len(rows)
        chunk_end = min(idx + int(self._fbp_import_chunk_size), total)
        win.setUpdatesEnabled(False)
        try:
            for i in range(idx, chunk_end):
                row = rows[i]
                win.append_series(
                    row["x"],
                    row["y_rel"],
                    row["fbp_path"],
                    str(row["label"]),
                    sgy_path=row.get("sgy_path"),
                    fit_view=False,
                    shot_trace_idx=int(row["shot_trace_idx"]),
                    shot_channel=int(row["shot_channel"]),
                    registry_shot_channel=int(row["registry_shot_channel"]),
                    shot_abs_ref_ms=row.get("shot_abs_ref_ms"),
                    fbp_n_traces=int(row.get("fbp_n_traces") or 0) or None,
                    fbp_samples=dict(row.get("fbp_samples") or {}),
                )
        finally:
            win.setUpdatesEnabled(True)
        state["index"] = chunk_end
        if bool(ctx.get("show_loading")):
            self._show_dromocrona_loading(
                "Disegno grafico dromocrone…",
                detail=f"{chunk_end} / {total}",
            )
        if chunk_end >= total:
            self._fbp_import_chunk_timer.stop()
            self._finish_fbp_import_chunk(state)

    def _finish_fbp_import_chunk(self, state: dict[str, object]) -> None:
        self._fbp_import_chunk_state = None
        win = state["win"]
        ctx = state["ctx"]
        locked_source = state.get("locked_source")
        try:
            # Un solo finalize UI: morph + fit + griglia/FAIL (no doppio schedule).
            win.end_series_batch(fit_view=False, schedule_grid_refresh=False)
            win.refresh_line_morphology_ui(fit_view=False)
            rows = state.get("rows") or []
            if len(rows) > 0 or bool(ctx.get("show_window")):
                win._fit_view_positive_quadrant()
            win._restore_lock_for_source(locked_source)
            ctx_folder = ctx.get("folder")
            if ctx_folder is not None:
                owner = self._session_owner_window()
                owner._fbp_monitor_loaded_folder = Path(ctx_folder)
            if bool(ctx.get("show_window")):
                self._bring_fbp_monitor_to_front(win)
            active = getattr(self, "_active_fbp_path", None)
            if (
                active is not None
                and win.isVisible()
                and not bool(state.get("synced_active"))
            ):
                self._sync_fbp_monitor_series(active)
            win.schedule_dromocrona_grid_refresh(immediate=False)
            self._refresh_morphology_map_shot_highlights()
        finally:
            self._fbp_folder_import_busy = False
            if bool(ctx.get("show_loading")):
                self._hide_dromocrona_loading()

    def _on_worker_load_fbp_folder_error(self, job: object, message: str) -> None:
        self._pending_fbp_folder_ctx = None
        self._fbp_import_chunk_timer.stop()
        self._fbp_import_chunk_state = None
        self._fbp_folder_import_busy = False
        self._hide_dromocrona_loading()
        QtWidgets.QMessageBox.warning(
            self,
            "Monitor dromocrone",
            f"Errore caricamento cartella:\n{message}",
        )

    def _on_worker_snap_breaks_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            extra = getattr(job, "extra", None) or {}
            if int(extra.get("stream_epoch", -1)) != int(
                getattr(self, "_stream_epoch", 0)
            ):
                if self._break_undo_stack:
                    self._break_undo_stack.pop()
                return
            updated = dict(result.get("updated_markers") or {})
            if not updated:
                if self._break_undo_stack:
                    self._break_undo_stack.pop()
                QtWidgets.QToolTip.showText(
                    QtGui.QCursor.pos(),
                    "Nessun campione positivo sulle tracce con break",
                    self,
                    QtCore.QRect(),
                    2500,
                )
                return
            for idx, t_val in updated.items():
                self._arrival_markers[int(idx)] = float(t_val)
                self._arrival_base_times[int(idx)] = max(0.0, float(t_val))
            self._mark_fbp_traces_dirty(updated.keys())
            self._clear_break_zone_gain_display()
            self._rebuild_arrival_overlay()
            self._on_seismogram_markers_changed(immediate_sync=True)

    def _on_worker_snap_breaks_error(self, job: object, message: str) -> None:
        extra = getattr(job, "extra", None) or {}
        if int(extra.get("stream_epoch", -1)) != int(
            getattr(self, "_stream_epoch", 0)
        ):
            if self._break_undo_stack:
                self._break_undo_stack.pop()
            return
        if self._break_undo_stack:
            self._break_undo_stack.pop()
        QtWidgets.QMessageBox.warning(
            self,
            "Aggancio break",
            f"Operazione non riuscita:\n{message}",
        )

    def _on_worker_reciprocals_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.apply_reciprocal_worker_result(job, result)

    def _on_worker_reciprocals_error(self, job: object, message: str) -> None:
        win = self._fbp_velocity_window_ref()
        if win is not None:
            win.on_reciprocal_worker_error(message)

    def _on_worker_reciprocal_patch_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.apply_reciprocal_patch_worker_result(job, result)

    def _on_worker_reciprocal_patch_error(self, job: object, message: str) -> None:
            del job
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.on_reciprocal_patch_worker_error(message)

    def _on_worker_build_dromocrona_grid_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.apply_grid_build_worker_result(job, result)

    def _on_worker_build_dromocrona_grid_error(self, job: object, message: str) -> None:
            del job
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.on_grid_build_worker_error(message)

    def _on_worker_build_fbp_disk_exports_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.apply_build_fbp_exports_worker_result(job, result)

    def _on_worker_build_fbp_disk_exports_error(self, job: object, message: str) -> None:
            del job
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.on_build_fbp_exports_worker_error(message)

    def _on_worker_snap_reciprocal_fail_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.apply_snap_reciprocal_worker_result(job, result)

    def _on_worker_snap_reciprocal_fail_error(self, job: object, message: str) -> None:
            del job
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.on_snap_reciprocal_worker_error(message)

    def _on_worker_auto_fix_reciprocals_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.apply_auto_fix_worker_result(job, result)

    def _on_worker_auto_fix_reciprocals_error(self, job: object, message: str) -> None:
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.on_auto_fix_worker_error(message)

    def _on_worker_estimate_missing_reciprocals_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.apply_estimate_missing_worker_result(job, result)

    def _on_worker_estimate_missing_reciprocals_error(
            self, job: object, message: str
        ) -> None:
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.on_estimate_missing_worker_error(message)

    def _on_worker_write_fbp_batch_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            saved = [Path(p) for p in (result.get("saved_paths") or [])]
            failed = [Path(p) for p in (result.get("failed_paths") or [])]
            self._finish_fbp_batch_write(saved, failed)

    def _on_worker_write_fbp_batch_error(self, job: object, message: str) -> None:
            del job
            pending = list(getattr(self, "_fbp_batch_write_pending", None) or [])
            if pending:
                self._set_fbp_sync_status(
                    f"errore salvataggio batch: {message}",
                    tone="error",
                    path=pending[-1],
                )
            self._finish_fbp_batch_write([], pending)

    def _finish_fbp_batch_write(
            self, saved: list[Path], failed: list[Path]
        ) -> None:
            self._fbp_batch_write_result = list(saved)
            self._fbp_batch_write_failed = list(failed)
            self._fbp_batch_write_pending = []
            win = self._fbp_velocity_window_ref()
            for fbp_path in saved:
                invalidate_fbp_parse_cache(fbp_path)
                if win is not None:
                    series_idx = win.find_series_index(fbp_path)
                    if series_idx is not None:
                        m = win._series_meta[series_idx]
                        m.pop("fbp_disk_lines", None)
                        m.pop("fbp_line_by_trace", None)
            callbacks = list(getattr(self, "_fbp_batch_write_callbacks", []) or [])
            self._fbp_batch_write_callbacks = []
            for cb in callbacks:
                try:
                    cb(saved, failed)
                except Exception:
                    _LOG.exception("Callback scrittura batch FBP non riuscito")
            waiter = getattr(self, "_fbp_batch_write_waiter", None)
            if waiter is not None:
                waiter.quit()
            if getattr(self, "_fbp_hold_batch_queue", False):
                return
            queued = getattr(self, "_fbp_batch_write_queue", None) or []
            if queued:
                next_files, next_cb = queued.pop(0)
                self._fbp_batch_write_queue = queued
                self._write_fbp_batch_async(next_files, on_complete=next_cb)

    def _write_fbp_batch_async(
            self,
            files: list[dict[str, str]],
            *,
            on_complete: Callable[[list[Path], list[Path]], None] | None = None,
        ) -> bool:
            """Accoda scrittura batch su worker; non blocca la GUI."""
            if not files:
                if on_complete is not None:
                    on_complete([], [])
                return False
            hub = getattr(self, "_gui_worker", None)
            if hub is None:
                saved, failed = self._write_fbp_batch_blocking(files)
                if on_complete is not None:
                    on_complete(saved, failed)
                return False
            pending = getattr(self, "_fbp_batch_write_pending", None) or []
            if pending:
                queue = getattr(self, "_fbp_batch_write_queue", None)
                if queue is None:
                    queue = []
                    self._fbp_batch_write_queue = queue
                queue.append((list(files), on_complete))
                return True
            callbacks: list[Callable[[list[Path], list[Path]], None]] = []
            if on_complete is not None:
                callbacks.append(on_complete)
            self._fbp_batch_write_callbacks = callbacks
            self._fbp_batch_write_pending = [
                Path(item["path"]) for item in files
            ]
            hub.submit("write_fbp_batch", {"files": files})
            return True

    def _write_fbp_files_sync(
            self, files: list[dict[str, str]]
        ) -> tuple[list[Path], list[Path]]:
            saved: list[Path] = []
            failed: list[Path] = []
            for item in files:
                path = Path(item["path"])
                content = str(item.get("content") or "")
                lines = content.splitlines()
                if self._write_fbp_text(path, lines):
                    saved.append(path)
                    invalidate_fbp_parse_cache(path)
                else:
                    failed.append(path)
            return saved, failed

    def _write_fbp_batch_blocking(
            self, files: list[dict[str, str]]
        ) -> tuple[list[Path], list[Path]]:
            if not files:
                return [], []
            hub = getattr(self, "_gui_worker", None)
            waiter_busy = getattr(self, "_fbp_batch_write_waiter", None) is not None
            pending_busy = bool(getattr(self, "_fbp_batch_write_pending", None))
            # Un secondo QEventLoop sovrascrive il waiter e può freezeare la GUI.
            if hub is None or waiter_busy or pending_busy:
                return self._write_fbp_files_sync(files)
            self._fbp_batch_write_result = []
            self._fbp_batch_write_failed = []
            self._fbp_batch_write_pending = [
                Path(item["path"]) for item in files
            ]
            loop = QtCore.QEventLoop()
            self._fbp_batch_write_waiter = loop
            hub.submit("write_fbp_batch", {"files": files})
            loop.exec()
            self._fbp_batch_write_waiter = None
            return (
                list(self._fbp_batch_write_result),
                list(getattr(self, "_fbp_batch_write_failed", []) or []),
            )

    def _invalidate_build_cache_jobs(self) -> None:
            hub = getattr(self, "_gui_worker", None)
            if hub is not None:
                hub.invalidate("build_cache")
            self._cache_build_in_flight = False

    def _on_worker_build_cache_done(
            self, job: object, result: dict[str, object]
        ) -> None:
            extra = getattr(job, "extra", None) or {}
            self._cache_build_in_flight = False
            if int(extra.get("stream_epoch", -1)) != int(
                getattr(self, "_stream_epoch", 0)
            ):
                if self.stream is not None and self._plot_cache is None:
                    self._ensure_plot_cache()
                return
            if not result.get("cache"):
                self._invalidate_plot_cache()
                self._hide_seismogram_loading()
                return
            self._apply_cache_worker_result(result)
            follow_up = str(getattr(job, "follow_up", "none") or "none")
            if follow_up == "plot_stream":
                path = self.loaded_path
                if path is not None:
                    self._show_seismogram_loading(path, "Disegno sismogramma…")
            self._run_cache_follow_up(follow_up)
            if follow_up == "plot_stream":
                paired_extra = extra.get("load_sync_extra")
                if isinstance(paired_extra, dict):
                    self._sync_plot_with_fbp_after_display(
                        paired_fbp=paired_extra.get("paired_fbp"),
                        plot_already_done=True,
                    )
                    self._sync_filter_dialog_from_stream()
                    followup = paired_extra.get("pending_load_followup")
                    if followup:
                        sgy = followup.get("highlight_sgy")
                        fbp = followup.get("highlight_fbp")
                        if sgy is not None:
                            self._highlight_folder_item(Path(str(sgy)))
                        if fbp is not None and Path(str(fbp)).exists():
                            self._highlight_break_item(Path(str(fbp)))
                            self._set_fbp_sync_status("caricato da disco")
                self._hide_seismogram_loading()
                flush_report(note="load_file_plot_done")

    def _on_worker_build_cache_error(self, job: object, message: str) -> None:
            del job
            self._cache_build_in_flight = False
            self._hide_seismogram_loading()
            QtWidgets.QMessageBox.warning(
                self,
                "Cache grafico",
                f"Preparazione tracce non riuscita:\n{message}",
            )

    def _init_viewer_session(
            self,
            session: SiesviewViewerSession,
            *,
            primary: bool,
        ) -> None:
            self._viewer_session = session
            self._is_session_primary = bool(primary)
            if primary:
                def _child_window_factory() -> SiesviewWindow:
                    return SiesviewWindow(
                        viewer_session=session,
                        session_primary=False,
                    )

                session.set_window_factory(_child_window_factory)
            session.register(self, primary=primary)

    def _session_owner_window(self) -> SiesviewWindow:
        session = getattr(self, "_viewer_session", None)
        if session is None:
            return self
        primary = session.primary_window()
        return primary if primary is not None else self

    def _fbp_monitor_folder_reload_busy(self) -> bool:
        owner = self._session_owner_window()
        return bool(
            getattr(owner, "_pending_fbp_folder_ctx", None)
            or getattr(owner, "_fbp_import_chunk_state", None)
        )

    def _fbp_monitor_already_loaded_for_folder(
            self,
            folder: Path,
            *,
            win: FbpVelocityMonitorWindow | None = None,
        ) -> bool:
            owner = self._session_owner_window()
            loaded = getattr(owner, "_fbp_monitor_loaded_folder", None)
            if win is None:
                win = self._fbp_velocity_window_ref()
            return (
                win is not None
                and loaded is not None
                and self._same_path(loaded, folder)
                and win.series_count() > 0
                and not win.is_drag_active()
            )

    def _fbp_velocity_window_ref(self) -> FbpVelocityMonitorWindow | None:
        return getattr(self._session_owner_window(), "_fbp_velocity_window", None)

    def _broadcast_fbp_changed(
            self, fbp_path: Path, *, reload_monitor: bool = True
        ) -> None:
        monitor = self._fbp_velocity_window_ref()
        if monitor is not None and monitor.is_drag_active():
            return
        session = getattr(self, "_viewer_session", None)
        if session is not None:
            session.notify_fbp_changed(
                fbp_path, source=self, reload_monitor=reload_monitor
            )

    def _reload_breaks_from_peer_fbp(self, fbp_path: Path) -> None:
        loaded = getattr(self, "loaded_path", None)
        if loaded is None:
            return
        try:
            if not is_fbp_file(fbp_path) or not fbp_matches_seismogram(fbp_path, loaded):
                return
        except Exception:
            return
        monitor = self._fbp_velocity_window_ref()
        if monitor is not None and monitor.is_drag_active():
            return
        if not fbp_path.exists():
            return
        if (
            self._fbp_is_linked_to_open_sgy(fbp_path)
            and self._is_active_fbp(fbp_path)
            and self._open_fbp_has_unsaved_changes()
        ):
            if not self._flush_open_fbp_if_dirty():
                return
        if not self._apply_fbp_markers_from_file(fbp_path, trace_shift=0):
            return
        self._active_fbp_path = fbp_path
        if self._break_zone_gain_active and self.stream is not None:
            self._refresh_plot_with_break_gain()
        else:
            self._rebuild_arrival_overlay()

    def _apply_shared_folder(self, directory: Path, *, from_session: bool = True) -> None:
        self._set_folder_directory(directory, from_session=from_session)

    def _open_sibling_viewer_window(self) -> None:
        session = getattr(self, "_viewer_session", None)
        if session is None:
            return
        session.open_child_window(parent=self)

    def _rewire_fbp_monitor_callbacks(self) -> None:
        win = getattr(self, "_fbp_velocity_window", None)
        if win is None:
            return
        win._on_point_moved = self._update_fbp_time_point
        win._on_drag_finished = self._on_fbp_monitor_drag_finished
        win._on_batch_points_moved = self._batch_update_fbp_time_points
        win._on_batch_write_fbp_from_memory = self._batch_write_fbp_from_memory_exports
        win._on_batch_points_saved = self._refresh_monitor_after_batch_fbp_edits
        win._on_series_activated = self._on_dromocrona_monitor_series_selected
        win._get_folder = lambda: getattr(self, "_current_folder", None)
        win._on_shot_registry_changed = lambda: self._refresh_fbp_velocity_from_folder(
            show_window=True,
            force=True,
        )
        win._on_export_dromocrona_grid = self._export_dromocrona_grid_excel
        win._get_shot_registry = lambda: dict(
            getattr(self._session_owner_window(), "_shot_registry", {}) or {}
        )
        win._get_line_morphology = lambda: getattr(
            self._session_owner_window(), "_line_morphology", None
        )
        win._seismogram_fail_overlay_wanted = bool(
            getattr(self, "_seismogram_fail_colors_enabled", False)
        )
        win._on_reciprocal_fail_changed = self._on_reciprocal_fail_seismogram_sync
        win._edit_reciprocal_fail_colors_request = (
            self._edit_reciprocal_fail_display_colors
        )
        win._rewire_dromocrona_grid_callbacks()

    def _on_reciprocal_fail_seismogram_sync(self) -> None:
        """Aggiorna i colori FAIL sul sismogramma (solo se l'opzione è attiva)."""
        if not getattr(self, "_seismogram_fail_colors_enabled", False):
            return
        if self._break_gesture_in_progress():
            return
        self._rebuild_arrival_overlay()

    def _reciprocal_fail_deltas_for_active_seismogram(self) -> dict[int, float]:
        """Δ FAIL del .fbp attivo (da monitor dromocrone)."""
        if not getattr(self, "_seismogram_fail_colors_enabled", False):
            return {}
        path = getattr(self, "_active_fbp_path", None) or self._paired_fbp_path()
        if path is None:
            return {}
        win = self._fbp_velocity_window_ref()
        if win is None:
            return {}
        try:
            return dict(win.reciprocal_fail_deltas_for_source(path))
        except Exception:
            return {}

    def _fail_pen_for_band(self, color: str) -> "pg.QtGui.QPen":
        fail_w = float(getattr(self, "_arrival_marker_width", 3.0)) + 1.0
        return pg.mkPen(QtGui.QColor(color), width=fail_w)

    def reciprocal_fail_display_settings(self) -> dict[str, str]:
        return {
            "positive_color": str(
                getattr(self, "_arrival_fail_positive_color", "#22c55e")
            ),
            "negative_color": str(
                getattr(self, "_arrival_fail_negative_color", "#111827")
            ),
        }

    def apply_reciprocal_fail_display_settings(
            self,
            settings: dict[str, object],
            *,
            persist: bool = True,
        ) -> None:
            from reciprocal_fail_display_prefs import (
                save_reciprocal_fail_display_prefs,
                _normalize_prefs,
            )

            norm = _normalize_prefs(dict(settings or {}))
            self._arrival_fail_positive_color = str(norm["positive_color"])
            self._arrival_fail_negative_color = str(norm["negative_color"])
            fail_w = float(getattr(self, "_arrival_marker_width", 3.0)) + 1.0
            self._arrival_fail_pen_positive = pg.mkPen(
                QtGui.QColor(self._arrival_fail_positive_color),
                width=fail_w,
            )
            self._arrival_fail_pen_negative = pg.mkPen(
                QtGui.QColor(self._arrival_fail_negative_color),
                width=fail_w,
            )
            if persist:
                save_reciprocal_fail_display_prefs(norm)
                session = getattr(self, "_viewer_session", None)
                if session is not None:
                    session.broadcast_reciprocal_fail_display(norm, source=self)
            monitor = self._fbp_velocity_window_ref()
            if monitor is not None:
                monitor.refresh_reciprocal_fail_display_colors()
            if getattr(self, "_seismogram_fail_colors_enabled", False):
                self._rebuild_arrival_overlay()

    def _edit_reciprocal_fail_display_colors(self) -> None:
        dlg = ReciprocalFailDisplayColorsDialog(
            self,
            settings=self.reciprocal_fail_display_settings(),
        )
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        result = dlg.settings()
        if result:
            self.apply_reciprocal_fail_display_settings(result, persist=True)

    @staticmethod
    def _menu_widget_action(menu: QtWidgets.QMenu, widget: QtWidgets.QWidget) -> None:
        action = QtWidgets.QWidgetAction(menu)
        action.setDefaultWidget(widget)
        menu.addAction(action)

    def _build_menu_bar(self) -> None:
        menubar = self.menuBar()

        menu_file = menubar.addMenu("&File")
        act_open_file = menu_file.addAction("Apri sismogramma…")
        act_open_file.setShortcut(QtGui.QKeySequence.StandardKey.Open)
        act_open_file.triggered.connect(self._choose_file)
        act_open_folder = menu_file.addAction("Apri cartella dati…")
        act_open_folder.triggered.connect(self._choose_data_folder)
        act_new_window = menu_file.addAction("Nuova finestra")
        act_new_window.triggered.connect(self._open_sibling_viewer_window)
        menu_file.addSeparator()
        act_export = menu_file.addAction("Salva break…")
        act_export.triggered.connect(self._export_breaks)

        menu_break = menubar.addMenu("&Break")
        self.act_break_ruler = menu_break.addAction("Righello break")
        self.act_break_ruler.setCheckable(True)
        self.act_break_ruler.toggled.connect(self._on_break_ruler_toggled)
        self.act_break_zone_gain = menu_break.addAction("Amplifica segnale vicino ai break")
        self.act_break_zone_gain.setCheckable(True)
        self.act_break_zone_gain.setChecked(False)
        self.act_break_zone_gain.toggled.connect(self._on_break_zone_gain_toggled)
        menu_break.addSeparator()
        act_generate_s = menu_break.addAction("Genera break S da P…")
        act_generate_s.triggered.connect(self._generate_s_breaks_from_p)
        menu_break.addSeparator()
        act_clear_all_breaks = menu_break.addAction("Cancella tutti i break…")
        act_clear_all_breaks.setToolTip(
            "Rimuove tutti i break dal sismogramma aperto.\n"
            "Se c'è un file .fbp collegato, le tracce vengono salvate con tempo 0 "
            "(pick mancante, ignorato nei reciproci)."
        )
        act_clear_all_breaks.triggered.connect(self._clear_all_seismogram_breaks)

        menu_dromo = menubar.addMenu("&Dromocrona")
        act_monitor = menu_dromo.addAction("Monitor dromocrone")
        act_monitor.triggered.connect(self._open_dromocrona_monitor)
        act_shot_editor = menu_dromo.addAction("Editor degli shot…")
        act_shot_editor.triggered.connect(self._open_shot_registry_editor)
        act_export_grid = menu_dromo.addAction("Esporta tempi…")
        act_export_grid.triggered.connect(self._export_dromocrona_grid_excel)
        act_export_abs = menu_dromo.addAction("Esporta tempi assoluti…")
        act_export_abs.triggered.connect(self._export_absolute_times_excel)
        menu_dromo.addSeparator()
        act_sync_monitor_memory = menu_dromo.addAction("Aggiorna monitor da memoria")
        act_sync_monitor_memory.triggered.connect(self._sync_monitor_from_memory_now)
        self.fbp_autosync_checkbox = QtWidgets.QCheckBox("Sincronizza break live → dromocrona")
        self.fbp_autosync_checkbox.setChecked(True)
        self.fbp_autosync_checkbox.setToolTip(
            "Attivo: ogni modifica break aggiorna il monitor (e la griglia/reciproci se aperti). "
            "Con molte dromocrona può causare freeze.\n\n"
            "Disattivo: le modifiche restano solo in memoria sul sismogramma; "
            "il salvataggio su disco avviene al cambio file. "
            "Usa «Aggiorna monitor da memoria» quando vuoi allineare il monitor."
        )
        self.fbp_autosync_checkbox.toggled.connect(self._on_fbp_autosync_toggled)
        self._menu_widget_action(menu_dromo, self.fbp_autosync_checkbox)
        self.seismogram_fail_checkbox = QtWidgets.QCheckBox(
            "Colora FAIL reciproci sul sismogramma"
        )
        self.seismogram_fail_checkbox.setChecked(
            bool(getattr(self, "_seismogram_fail_colors_enabled", False))
        )
        self.seismogram_fail_checkbox.setToolTip(
            "Attivo: i break FAIL (Δ+/Δ−) si colorano sul sismogramma, "
            "così vedi dove mettere in ordine i reciproci.\n\n"
            "Richiede il monitor dromocrone aperto (con Evidenzia FAIL "
            "o griglia reciproci) per calcolare i punti.\n"
            "Disattivo: overlay più leggero (solo colori sul monitor)."
        )
        self.seismogram_fail_checkbox.toggled.connect(
            self._on_seismogram_fail_colors_toggled
        )
        self._menu_widget_action(menu_dromo, self.seismogram_fail_checkbox)

        menu_morph = menubar.addMenu("&Morfologia")
        act_import_line_excel = menu_morph.addAction("Importa da Excel…")
        act_import_line_excel.triggered.connect(self._import_line_morphology_excel)
        act_import_line_json = menu_morph.addAction("Importa da JSON…")
        act_import_line_json.triggered.connect(self._import_line_morphology_json)
        act_show_line_map = menu_morph.addAction("Mostra mappa satellite…")
        act_show_line_map.triggered.connect(self._open_line_morphology_map)
        menu_morph.addSeparator()
        act_export_vel = menu_morph.addAction("Esporta geo…")
        act_export_vel.triggered.connect(self._export_velocity_morphology_file)
        menu_morph.addSeparator()
        act_clear_line_morph = menu_morph.addAction("Rimuovi morfologia")
        act_clear_line_morph.triggered.connect(self._clear_line_morphology)

        menu_settings = menubar.addMenu("Impos&tazioni")
        act_fail_colors = menu_settings.addAction("Colori FAIL…")
        act_fail_colors.triggered.connect(self._edit_reciprocal_fail_display_colors)
        act_trace_display = menu_settings.addAction("Aspetto tracce…")
        act_trace_display.triggered.connect(self._open_trace_display_dialog)
        act_rotate = menu_settings.addAction("Ruota 90°")
        act_rotate.triggered.connect(self._rotate_view_90)
        menu_settings.addSeparator()
        act_shortcuts = menu_settings.addAction("Scorciatoie tastiera…")
        act_shortcuts.triggered.connect(self._open_keyboard_shortcuts_dialog)
        menu_settings.addSeparator()
        # Visibile solo dopo Alt+F1 (strumenti sviluppatori).
        self._developer_mode_unlocked = False
        self.act_developers = menu_settings.addAction("Sviluppatori…")
        self.act_developers.setVisible(False)
        self.act_developers.setToolTip(
            "Strumenti di manutenzione (sblocco: Alt+F1)."
        )
        self.act_developers.triggered.connect(self._open_developer_tools_dialog)
        self._install_developer_mode_shortcut()

    def _install_developer_mode_shortcut(self) -> None:
        """Alt+F1 sblocca la voce Impostazioni → Sviluppatori."""
        if getattr(self, "_developer_mode_shortcut", None) is not None:
            return
        shortcut = QtGui.QShortcut(QtGui.QKeySequence("Alt+F1"), self)
        shortcut.setContext(QtCore.Qt.ShortcutContext.WindowShortcut)
        shortcut.activated.connect(self._unlock_developer_tools)
        self._developer_mode_shortcut = shortcut

    def _unlock_developer_tools(self) -> None:
        self._developer_mode_unlocked = True
        act = getattr(self, "act_developers", None)
        if act is not None:
            act.setVisible(True)
        QtWidgets.QToolTip.showText(
            QtGui.QCursor.pos(),
            "Modalità sviluppatori attiva — menu Impostazioni → Sviluppatori…",
            self,
            QtCore.QRect(),
            2500,
        )
        self._open_developer_tools_dialog()

    def _open_developer_tools_dialog(self) -> None:
        if not getattr(self, "_developer_mode_unlocked", False):
            return
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("Sviluppatori")
        dlg.setModal(True)
        dlg.setMinimumWidth(420)
        layout = QtWidgets.QVBoxLayout(dlg)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        title = QtWidgets.QLabel("Strumenti sviluppatori")
        title.setStyleSheet("font-size: 15px; font-weight: 700;")
        layout.addWidget(title)

        hint = QtWidgets.QLabel(
            "Funzioni di manutenzione non esposte nel menu principale."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #64748b;")
        layout.addWidget(hint)

        btn_repair = QtWidgets.QPushButton("Ripara .fbp corrotti nella cartella…")
        btn_repair.setToolTip(
            "Normalizza i .fbp con canali duplicati o placeholder 0 "
            "(solo su richiesta; non viene eseguito al caricamento del monitor)."
        )

        def _run_repair() -> None:
            dlg.accept()
            self._repair_corrupted_fbp_in_current_folder()

        btn_repair.clicked.connect(_run_repair)
        layout.addWidget(btn_repair)

        btn_perf = QtWidgets.QPushButton("Salva report prestazioni…")
        btn_perf.setToolTip(
            "Esporta un report testuale con tempi e contatori di performance."
        )

        def _run_perf() -> None:
            dlg.accept()
            self._save_perf_report()

        btn_perf.clicked.connect(_run_perf)
        layout.addWidget(btn_perf)
        layout.addStretch(1)

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButton.Close
        )
        buttons.rejected.connect(dlg.reject)
        layout.addWidget(buttons)
        dlg.exec()

    def _toolbar_caption(self, text: str) -> QtWidgets.QLabel:
        label = QtWidgets.QLabel(text)
        label.setObjectName("viewerToolbarCaption")
        return label

    def _toolbar_value_control(
        self,
        caption: str | None,
        spin: QtWidgets.QAbstractSpinBox,
    ) -> QtWidgets.QWidget:
        frame = QtWidgets.QFrame()
        frame.setObjectName("viewerToolbarControl")
        layout = QtWidgets.QHBoxLayout(frame)
        layout.setContentsMargins(4, 1, 3, 1)
        layout.setSpacing(3)
        if caption:
            layout.addWidget(self._toolbar_caption(caption))
        spin.setButtonSymbols(QtWidgets.QAbstractSpinBox.ButtonSymbols.NoButtons)
        spin.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight)
        layout.addWidget(spin)

        btn_down = QtWidgets.QToolButton()
        btn_down.setText("−")
        btn_down.setObjectName("viewerSpinStepButton")
        btn_down.setAutoRepeat(True)
        btn_down.setAutoRepeatDelay(300)
        btn_down.setAutoRepeatInterval(60)
        btn_down.clicked.connect(spin.stepDown)

        btn_up = QtWidgets.QToolButton()
        btn_up.setText("+")
        btn_up.setObjectName("viewerSpinStepButton")
        btn_up.setAutoRepeat(True)
        btn_up.setAutoRepeatDelay(300)
        btn_up.setAutoRepeatInterval(60)
        btn_up.clicked.connect(spin.stepUp)

        step_layout = QtWidgets.QVBoxLayout()
        step_layout.setContentsMargins(0, 0, 0, 0)
        step_layout.setSpacing(1)
        step_layout.addWidget(btn_up)
        step_layout.addWidget(btn_down)
        layout.addLayout(step_layout)
        return frame

    def _build_main_toolbar(self) -> None:
        toolbar = QtWidgets.QToolBar("Principale", self)
        toolbar.setMovable(False)
        toolbar.setIconSize(QtCore.QSize(18, 18))
        self.addToolBar(toolbar)

        self.open_btn = QtWidgets.QPushButton("Apri")
        self.open_btn.setObjectName("viewerPrimaryButton")
        self.open_btn.clicked.connect(self._choose_file)
        toolbar.addWidget(self.open_btn)

        self.new_window_btn = QtWidgets.QPushButton("Nuova finestra")
        self.new_window_btn.clicked.connect(self._open_sibling_viewer_window)
        toolbar.addWidget(self.new_window_btn)

        toolbar.addSeparator()

        self.scale_spin = QtWidgets.QDoubleSpinBox()
        self.scale_spin.setRange(MIN_DISPLAY_GAIN_LINEAR, MAX_DISPLAY_GAIN_LINEAR)
        self.scale_spin.setSingleStep(0.05)
        self.scale_spin.setDecimals(2)
        self.scale_spin.setValue(DEFAULT_GAIN)
        self.scale_spin.setFixedWidth(54)
        self.scale_spin.setToolTip("Guadagno di visualizzazione")
        self.scale_spin.valueChanged.connect(self._on_gain_spin_changed)
        toolbar.addWidget(self._toolbar_value_control("Guadagno", self.scale_spin))

        self.window_spin = QtWidgets.QDoubleSpinBox()
        self.window_spin.setRange(100.0, 30_000.0)
        self.window_spin.setSingleStep(50.0)
        self.window_spin.setDecimals(0)
        self.window_spin.setValue(float(DEFAULT_TIME_WINDOW_S) * 1000.0)
        self.window_spin.setSuffix(" ms")
        self.window_spin.setFixedWidth(72)
        self.window_spin.setToolTip("Finestra temporale visualizzata (millisecondi)")
        self.window_spin.valueChanged.connect(self._handle_time_window_change)
        toolbar.addWidget(self._toolbar_value_control("Tempo", self.window_spin))

        self.spacing_spin = QtWidgets.QDoubleSpinBox()
        self.spacing_spin.setRange(0.5, 6.0)
        self.spacing_spin.setSingleStep(0.1)
        self.spacing_spin.setDecimals(2)
        self.spacing_spin.setValue(self._trace_spacing_factor)
        self.spacing_spin.setFixedWidth(50)
        self.spacing_spin.setToolTip("Spaziatura tra le tracce")
        self.spacing_spin.valueChanged.connect(self._apply_spacing_factor_change)
        toolbar.addWidget(self._toolbar_value_control("Spaz.", self.spacing_spin))

        toolbar.addSeparator()

        self.auto_gain_checkbox = QtWidgets.QCheckBox("Guadagno automatico")
        self.auto_gain_checkbox.setChecked(True)
        self.auto_gain_checkbox.toggled.connect(self._on_auto_gain_toggled)
        toolbar.addWidget(self.auto_gain_checkbox)

        # AGC: controlli nella schermata Filtro (widget nascosti per stato/sessione).
        self.agc_checkbox = QtWidgets.QCheckBox("AGC", self)
        self.agc_checkbox.setChecked(False)
        self.agc_checkbox.hide()
        self.agc_checkbox.toggled.connect(self._on_agc_enabled_toggled)

        self.agc_window_spin = QtWidgets.QDoubleSpinBox(self)
        self.agc_window_spin.setRange(1.0, 5000.0)
        self.agc_window_spin.setDecimals(1)
        self.agc_window_spin.setSingleStep(10.0)
        self.agc_window_spin.setSuffix(" ms")
        self.agc_window_spin.setValue(DEFAULT_AGC_WINDOW_MS)
        self.agc_window_spin.hide()
        self.agc_window_spin.valueChanged.connect(self._on_agc_window_spin_changed)

        self.fill_neg_checkbox = QtWidgets.QCheckBox("Riempimento negativo")
        self.fill_neg_checkbox.toggled.connect(self._on_fill_neg_toggled)
        toolbar.addWidget(self.fill_neg_checkbox)

        toolbar.addSeparator()

        btn_monitor = QtWidgets.QPushButton("Dromo")
        btn_monitor.setToolTip("Apri il monitor dromocrone")
        btn_monitor.clicked.connect(self._open_dromocrona_monitor)
        toolbar.addWidget(btn_monitor)

        btn_ruler = QtWidgets.QPushButton("Righello")
        btn_ruler.setCheckable(True)
        btn_ruler.toggled.connect(self._on_break_ruler_toggled)
        self._toolbar_ruler_btn = btn_ruler
        toolbar.addWidget(btn_ruler)

        btn_filter = QtWidgets.QPushButton("Filtro")
        btn_filter.clicked.connect(self._open_filter_dialog)
        toolbar.addWidget(btn_filter)

    def _build_status_bar(self) -> None:
        status = self.statusBar()
        self.path_label = QtWidgets.QLabel("Nessun file caricato")
        self.path_label.setObjectName("viewerPathLabel")
        status.addWidget(self.path_label, stretch=1)
        self._track_label = QtWidgets.QLabel("Traccia: —")
        self._track_label.setObjectName("viewerPathLabel")
        status.addPermanentWidget(self._track_label)
    def _build_ui(self) -> None:
        central = QtWidgets.QWidget(self)
        central.setObjectName("viewerCentral")
        layout = QtWidgets.QVBoxLayout(central)
        layout.setContentsMargins(8, 0, 8, 8)
        layout.setSpacing(6)
        self.setCentralWidget(central)

        self._build_menu_bar()
        self._build_main_toolbar()
        self._build_status_bar()

        splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)

        sidebar = QtWidgets.QFrame()
        sidebar.setObjectName("viewerSidebar")
        sidebar.setMinimumWidth(SIDEBAR_MIN_WIDTH)
        sidebar.setMaximumWidth(SIDEBAR_MAX_WIDTH)
        sidebar.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Fixed,
            QtWidgets.QSizePolicy.Policy.Expanding,
        )
        sidebar_layout = QtWidgets.QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(10, 10, 10, 10)
        sidebar_layout.setSpacing(8)

        folder_label = QtWidgets.QLabel("Sismogrammi")
        folder_label.setObjectName("viewerSectionTitle")
        sidebar_layout.addWidget(folder_label)

        self.folder_path_label = QtWidgets.QLabel("Nessuna cartella")
        self.folder_path_label.setObjectName("viewerPathLabel")
        self.folder_path_label.setWordWrap(True)
        sidebar_layout.addWidget(self.folder_path_label)

        self.folder_files_list = QtWidgets.QListWidget()
        self.folder_files_list.setSelectionMode(
            QtWidgets.QAbstractItemView.SelectionMode.SingleSelection
        )
        self.folder_files_list.itemClicked.connect(self._handle_folder_item_activated)
        sidebar_layout.addWidget(self.folder_files_list, stretch=2)

        self.folder_list_hint = QtWidgets.QLabel("Seleziona una cartella dati dal menu File")
        self.folder_list_hint.setObjectName("viewerSectionHint")
        self.folder_list_hint.setWordWrap(True)
        sidebar_layout.addWidget(self.folder_list_hint)

        breaks_label = QtWidgets.QLabel("Break (.fbp)")
        breaks_label.setObjectName("viewerSectionTitle")
        sidebar_layout.addWidget(breaks_label)

        self.break_files_list = QtWidgets.QListWidget()
        self.break_files_list.setSelectionMode(
            QtWidgets.QAbstractItemView.SelectionMode.SingleSelection
        )
        self.break_files_list.itemClicked.connect(self._handle_break_item_activated)
        sidebar_layout.addWidget(self.break_files_list, stretch=2)

        self.fbp_sync_status_label = QtWidgets.QLabel("Sinc: in attesa")
        self.fbp_sync_status_label.setObjectName("viewerPathLabel")
        self.fbp_sync_status_label.setWordWrap(True)
        sidebar_layout.addWidget(self.fbp_sync_status_label)

        self.break_list_hint = QtWidgets.QLabel("")
        self.break_list_hint.setObjectName("viewerSectionHint")
        self.break_list_hint.setWordWrap(True)
        sidebar_layout.addWidget(self.break_list_hint)

        splitter.addWidget(sidebar)

        pg.setConfigOptions(antialias=False)
        view_box = SiesviewViewBox()
        view_box.set_swap_break_mouse_buttons(
            bool(getattr(self, "_swap_break_mouse_buttons", False))
        )
        view_box.set_right_press_callback(lambda *_a: self._handle_right_break_press())
        view_box.set_right_action_callback(
            lambda pos, mods: self._handle_right_break_action(pos, mods)
        )
        view_box.set_ruler_click_callback(
            lambda: bool(getattr(self, "_break_ruler_enabled", False)),
            self._handle_ruler_vertex_click,
        )
        self.plot_widget = pg.PlotWidget(self, viewBox=view_box)
        self.plot_widget.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Expanding,
        )
        self.plot_widget.setMenuEnabled(False)
        plot_item = self.plot_widget.getPlotItem()
        plot_item.setMouseEnabled(x=True, y=True)
        plot_item.setClipToView(True)
        plot_item.invertY(True)
        plot_item.getAxis("bottom").setTicks([])
        plot_item.getAxis("right").setTicks([])
        plot_item.getAxis("top").setTicks([])
        plot_item.enableAutoRange(x=False, y=False)
        plot_item.disableAutoRange()
        view_box.disableAutoRange()
        top_axis = plot_item.getAxis("top")
        top_axis.setLabel("")
        top_axis.enableAutoSIPrefix(False)
        top_axis.setStyle(tickLength=0, tickTextOffset=4)
        self._apply_plot_chrome_style()
        splitter.addWidget(self.plot_widget)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([SIDEBAR_DEFAULT_WIDTH, 10_000])
        self._main_splitter = splitter
        layout.addWidget(splitter, stretch=1)

        plot_item.sigXRangeChanged.connect(self._handle_x_range_changed)
        plot_item.sigYRangeChanged.connect(self._handle_y_range_changed)
        self._mouse_proxy = pg.SignalProxy(
            self.plot_widget.scene().sigMouseMoved, rateLimit=60, slot=self._on_mouse_moved
        )
        view_box.set_right_release_callback(lambda *_: self._handle_right_break_release())

        self._show_empty_state()
        self._install_gain_key_event_filter()
        self._populate_folder_file_list(self._current_folder)

    def _apply_plot_chrome_style(self) -> None:
        """Sfondo e griglia sul sismogramma (colore sfondo da preferenze utente)."""
        pi = self.plot_widget.getPlotItem()
        bg = str(getattr(self, "_plot_background_color", "#f5f5f5") or "#f5f5f5")
        self.plot_widget.setBackground(bg)
        # Griglia più chiara su sfondi scuri, più scura su chiari.
        bg_q = QtGui.QColor(bg)
        grid_alpha = 0.22 if bg_q.isValid() and bg_q.lightness() < 128 else 0.28
        pi.showGrid(x=False, y=True, alpha=float(grid_alpha))
        axis_color = "#e8eaed" if bg_q.isValid() and bg_q.lightness() < 128 else "#202124"
        axis_pen = pg.mkPen(axis_color)
        for name in ("left", "bottom", "right", "top"):
            ax = pi.getAxis(name)
            ax.setPen(axis_pen)
            ax.setTextPen(axis_pen)
        self._apply_rotation_axis_labels(int(getattr(self, "_view_rotation_deg", 0)))

    def _apply_rotation_axis_labels(self, _rot: int) -> None:
        pi = self.plot_widget.getPlotItem()
        for name in ("left", "bottom", "top", "right"):
            pi.getAxis(name).setLabel("")

    @staticmethod
    def _rotation_axis_maps(
            rot: int,
        ) -> tuple[str, str, object, object]:
            """(asse tempo, asse tracce, y_u→coord, x_u→coord) nel sistema view."""
            rot = int(rot) % 360
            if rot == 0:
                return "left", "top", (lambda y: float(y)), (lambda x: float(x))
            if rot == 90:
                return "bottom", "left", (lambda y: float(y)), (lambda x: float(-x))
            if rot == 180:
                return "left", "top", (lambda y: float(-y)), (lambda x: float(-x))
            return "bottom", "left", (lambda y: float(-y)), (lambda x: float(x))

    def _build_trace_tick_labels(
            self, x_lo: float, x_hi: float
        ) -> list[tuple[float, str]]:
            baseline = getattr(self, "_current_baseline", None)
            if baseline is None or getattr(baseline, "size", 0) == 0:
                return []
            if x_hi <= x_lo:
                return []
            visible_range = x_hi - x_lo
            width = max(1, self.plot_widget.width())
            approx_ticks = max(4, min(30, int(width / 80)))
            step = max(1, int(math.ceil(visible_range / approx_ticks)))
            start = max(0, int(math.floor(x_lo)))
            stop = min(int(baseline.size) - 1, int(math.ceil(x_hi)))
            ticks = np.arange(start, stop + 1, step, dtype=int)
            ticks = ticks[(ticks >= 0) & (ticks < len(baseline))]
            return [(float(baseline[t]), str(t + 1)) for t in ticks]

    def _sync_plot_axis_ticks(self) -> None:
        rot = int(getattr(self, "_view_rotation_deg", 0)) % 360
        plot_item = self.plot_widget.getPlotItem()
        if self.stream is None:
            for name in ("left", "bottom", "right", "top"):
                plot_item.getAxis(name).setTicks([])
            self._last_track_tick_labels = None
            return

        (x_lo, x_hi), (y_lo, y_hi) = self._view_unrotated_axis_ranges()
        if rot == 0:
            try:
                _, y_range = plot_item.viewRange()
                y0, y1 = self._clamp_y_range(y_range)
                y_lo = float(min(y0, y1))
                y_hi = float(max(y0, y1))
            except Exception:
                y_lo, y_hi = self._time_axis_limits()

        trace_labels = self._build_trace_tick_labels(x_lo, x_hi)
        time_lo = float(min(y_lo, y_hi))
        time_hi = float(max(y_lo, y_hi))
        time_axis, trace_axis, map_time, map_trace = self._rotation_axis_maps(rot)
        time_pairs = [
            (map_time(float(tick)), self._format_ms_tick(float(tick)))
            for tick in self._build_time_ticks(time_lo, time_hi)
        ]
        for name in ("left", "bottom", "right", "top"):
            if name not in (time_axis, trace_axis):
                plot_item.getAxis(name).setTicks([])

        plot_item.getAxis(time_axis).setTicks([time_pairs])

        if rot == 0 and trace_labels == getattr(self, "_last_track_tick_labels", None):
            self._apply_rotation_axis_labels(rot)
            return
        self._last_track_tick_labels = trace_labels if rot == 0 else None
        plot_item.getAxis(trace_axis).setTicks(
            [[(map_trace(x_u), label) for x_u, label in trace_labels]]
        )
        self._apply_rotation_axis_labels(rot)

    def _install_gain_key_event_filter(self) -> None:
        app = QtWidgets.QApplication.instance()
        if app is None or self._app_gain_event_filter_installed:
            return
        app.installEventFilter(self)
        self._app_gain_event_filter_installed = True

    def _wait_fbp_batch_pending(self, timeout_s: float = 8.0) -> bool:
        """Attende il batch già inviato al worker, senza accettare nuovi input."""
        if not getattr(self, "_fbp_batch_write_pending", None):
            return True
        flags = QtCore.QEventLoop.ProcessEventsFlag.ExcludeUserInputEvents
        t0 = time.monotonic()
        while getattr(self, "_fbp_batch_write_pending", None):
            if (time.monotonic() - t0) >= float(timeout_s):
                return False
            QtWidgets.QApplication.processEvents(flags, 50)
        return True

    def _flush_fbp_batches_before_close(self) -> bool:
        """Scrive la coda rimasta. False se un file non è stato salvato."""
        failed_before = list(getattr(self, "_fbp_batch_write_failed", None) or [])
        self._fbp_hold_batch_queue = True
        ok = True
        try:
            if not self._wait_fbp_batch_pending(8.0):
                _LOG.warning("Batch .fbp ancora in corso alla chiusura")
                ok = False
            failed_now = list(getattr(self, "_fbp_batch_write_failed", None) or [])
            if failed_now and failed_now != failed_before:
                ok = False
            queued = list(getattr(self, "_fbp_batch_write_queue", None) or [])
            self._fbp_batch_write_queue = []
            for files, _cb in queued:
                try:
                    _saved, file_failed = self._write_fbp_files_sync(files)
                except Exception:
                    _LOG.exception("Flush sync coda FBP in chiusura non riuscito")
                    ok = False
                    continue
                if file_failed:
                    ok = False
        finally:
            self._fbp_hold_batch_queue = False
        return ok

    def _confirm_close_with_unsaved_breaks(self, detail: str) -> bool:
        answer = QtWidgets.QMessageBox.warning(
            self,
            "Salvataggio break",
            f"{detail} Chiudere comunque?",
            QtWidgets.QMessageBox.StandardButton.Yes
            | QtWidgets.QMessageBox.StandardButton.No,
            QtWidgets.QMessageBox.StandardButton.No,
        )
        return answer == QtWidgets.QMessageBox.StandardButton.Yes

    def changeEvent(self, event: QtCore.QEvent) -> None:
        # Alt-Tab / perdita focus: chiude i gesti tastiera (e destro) così la preview non resta appiccicata.
        if (
            event.type() == QtCore.QEvent.Type.WindowDeactivate
            and self._break_gesture_in_progress()
        ):
            self._finish_any_break_gesture()
        super().changeEvent(event)

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        if getattr(self, "_close_flush_active", False):
            event.ignore()
            return
        self._close_flush_active = True
        batch_ok = self._flush_fbp_batches_before_close()
        active_ok = self._flush_active_fbp_to_disk(force=True)
        if not batch_ok or not active_ok:
            parts: list[str] = []
            if not active_ok:
                parts.append("Il sismogramma attivo non è stato salvato.")
            if not batch_ok:
                parts.append("Alcuni break in coda non sono stati scritti su disco.")
            if not self._confirm_close_with_unsaved_breaks(" ".join(parts)):
                self._close_flush_active = False
                event.ignore()
                return
        session = getattr(self, "_viewer_session", None)
        monitor = self._fbp_velocity_window_ref()
        if session is not None:
            session.unregister(self)
        last_session_window = session is None or session.window_count() == 0
        if last_session_window:
            if monitor is not None:
                try:
                    monitor.close()
                except Exception:
                    pass
                owner = self._session_owner_window()
                if getattr(owner, "_fbp_velocity_window", None) is monitor:
                    owner._fbp_velocity_window = None
                if getattr(self, "_fbp_velocity_window", None) is monitor:
                    self._fbp_velocity_window = None
            for attr in ("_line_morphology_map_window", "_load_wait_dialog"):
                win = getattr(self, attr, None)
                if win is None:
                    continue
                try:
                    win.close()
                except Exception:
                    pass
                if attr != "_load_wait_dialog":
                    setattr(self, attr, None)
        if self._app_gain_event_filter_installed:
            app = QtWidgets.QApplication.instance()
            if app is not None:
                app.removeEventFilter(self)
            self._app_gain_event_filter_installed = False
        worker = getattr(self, "_gui_worker", None)
        if worker is not None:
            worker.shutdown()
        super().closeEvent(event)

    @staticmethod
    def _focus_is_text_input(fw: QtWidgets.QWidget | None) -> bool:
        if fw is None:
            return False
        w: QtWidgets.QWidget | None = fw
        while w is not None:
            if isinstance(
                w,
                (QtWidgets.QLineEdit, QtWidgets.QTextEdit, QtWidgets.QPlainTextEdit),
            ):
                return True
            w = w.parentWidget()
        return False

    def _shortcut_matches(self, event: QtGui.QKeyEvent, action_id: str) -> bool:
        return event_matches_action(
            event,
            action_id,
            getattr(self, "_keyboard_shortcuts", None) or {},
        )

    # Il tasto resta quello di vista 0°. La rotazione (e invertY) decide
    # se quel verso a schermo è tempo o tracce, e con quale segno.
    _ARROW_BREAK_ACTION_IDS = (
        "nudge_hover_break_ms_decrease",
        "nudge_hover_break_ms_increase",
        "nudge_hover_break_traces_decrease",
        "nudge_hover_break_traces_increase",
        "shift_breaks_ms_decrease",
        "shift_breaks_ms_increase",
        "shift_breaks_traces_decrease",
        "shift_breaks_traces_increase",
    )
    _HOVER_NUDGE_ACTION_IDS = frozenset(
        {
            "nudge_hover_break_ms_decrease",
            "nudge_hover_break_ms_increase",
            "nudge_hover_break_traces_decrease",
            "nudge_hover_break_traces_increase",
        }
    )
    _SHIFT_BREAK_ACTION_IDS = frozenset(
        {
            "shift_breaks_ms_decrease",
            "shift_breaks_ms_increase",
            "shift_breaks_traces_decrease",
            "shift_breaks_traces_increase",
        }
    )

    def _resolve_arrow_break_action(self, event: QtGui.QKeyEvent) -> str | None:
        """Azione break associata al tasto freccia, riallineata alla rotazione vista."""
        matched: str | None = None
        for action_id in self._ARROW_BREAK_ACTION_IDS:
            if self._shortcut_matches(event, action_id):
                matched = action_id
                break
        if matched is None:
            return None
        rot = int(getattr(self, "_view_rotation_deg", 0)) % 360
        return arrow_break_action_for_rotation(matched, rot)

    def _dispatch_arrow_break_action(
        self, action_id: str, *, is_auto_repeat: bool
    ) -> bool:
        """Esegue l'azione freccia break (già risolta per rotazione). True se gestita."""
        if action_id == "nudge_hover_break_ms_decrease":
            self._nudge_hover_break_by_ms(
                -self._break_ms_shift_step(),
                push_undo=not is_auto_repeat,
            )
            return True
        if action_id == "nudge_hover_break_ms_increase":
            self._nudge_hover_break_by_ms(
                self._break_ms_shift_step(),
                push_undo=not is_auto_repeat,
            )
            return True
        if action_id == "nudge_hover_break_traces_decrease":
            self._nudge_hover_break_by_traces(
                -self._break_trace_shift_step(),
                push_undo=not is_auto_repeat,
            )
            return True
        if action_id == "nudge_hover_break_traces_increase":
            self._nudge_hover_break_by_traces(
                self._break_trace_shift_step(),
                push_undo=not is_auto_repeat,
            )
            return True
        if action_id == "shift_breaks_ms_decrease":
            self._shift_all_breaks_by_ms(
                -self._break_ms_shift_step(),
                push_undo=not is_auto_repeat,
            )
            return True
        if action_id == "shift_breaks_ms_increase":
            self._shift_all_breaks_by_ms(
                self._break_ms_shift_step(),
                push_undo=not is_auto_repeat,
            )
            return True
        if action_id == "shift_breaks_traces_decrease":
            self._shift_all_breaks_by_traces(
                -self._break_trace_shift_step(),
                push_undo=not is_auto_repeat,
            )
            return True
        if action_id == "shift_breaks_traces_increase":
            self._shift_all_breaks_by_traces(
                self._break_trace_shift_step(),
                push_undo=not is_auto_repeat,
            )
            return True
        return False

    def _open_keyboard_shortcuts_dialog(self) -> None:
        current = dict(getattr(self, "_keyboard_shortcuts", None) or load_keyboard_shortcuts())
        updated = run_keyboard_shortcuts_dialog(self, current)
        if updated is None:
            return
        save_keyboard_shortcuts(updated)
        merged = load_keyboard_shortcuts()
        self._keyboard_shortcuts = dict(merged)
        session = getattr(self, "_viewer_session", None)
        if session is not None:
            apply_shortcuts_to_windows(session._windows, merged)
        else:
            apply_shortcuts_to_windows([self], merged)

    def eventFilter(self, watched: QtCore.QObject, event: QtCore.QEvent) -> bool:
        """Scorciatoie tastiera app-wide: gain, spaziatura tracce, spostamento break."""
        if event.type() == QtCore.QEvent.Type.MouseButtonRelease:
            ev = event
            if (
                isinstance(ev, QtGui.QMouseEvent)
                and ev.button() == self._break_mouse_button()
                and getattr(self, "_break_right_gesture_active", False)
            ):
                self._finish_right_break_gesture()
            return super().eventFilter(watched, event)
        if event.type() == QtCore.QEvent.Type.KeyRelease:
            ev = event
            if (
                isinstance(ev, QtGui.QKeyEvent)
                and not ev.isAutoRepeat()
                and (
                    getattr(self, "_hover_break_nudge_active", False)
                    or getattr(self, "_shift_breaks_gesture_active", False)
                )
            ):
                released = self._resolve_arrow_break_action(ev)
                if released in self._HOVER_NUDGE_ACTION_IDS:
                    self._finish_hover_break_nudge_gesture()
                elif released in self._SHIFT_BREAK_ACTION_IDS:
                    self._finish_shift_breaks_gesture()
                elif released is None:
                    # Focus/layout strano: se è una freccia chiudi comunque i gesti tastiera.
                    key = ev.key()
                    if key in (
                        QtCore.Qt.Key.Key_Left,
                        QtCore.Qt.Key.Key_Right,
                        QtCore.Qt.Key.Key_Up,
                        QtCore.Qt.Key.Key_Down,
                    ):
                        if getattr(self, "_hover_break_nudge_active", False):
                            self._finish_hover_break_nudge_gesture()
                        if getattr(self, "_shift_breaks_gesture_active", False):
                            self._finish_shift_breaks_gesture()
            return super().eventFilter(watched, event)
        if event.type() != QtCore.QEvent.Type.KeyPress:
            return super().eventFilter(watched, event)
        if not getattr(self, "scale_spin", None):
            return super().eventFilter(watched, event)
        fw = QtWidgets.QApplication.focusWidget()
        if fw is not None and fw.window() is not self:
            return super().eventFilter(watched, event)
        if not self.isActiveWindow():
            return super().eventFilter(watched, event)
        if self._focus_is_text_input(fw):
            return super().eventFilter(watched, event)
        ev = event
        if not isinstance(ev, QtGui.QKeyEvent):
            return super().eventFilter(watched, event)
        if getattr(self, "_break_ruler_enabled", False):
            if self._shortcut_matches(ev, "break_ruler_confirm"):
                if self._ruler_line_ready():
                    self._confirm_break_ruler()
                return True
            if self._shortcut_matches(ev, "break_ruler_cancel"):
                self._clear_break_ruler_preview()
                return True
        if self._shortcut_matches(ev, "copy_break_times"):
            self._copy_break_times_to_clipboard()
            return True
        step = float(self.scale_spin.singleStep())
        if self._shortcut_matches(ev, "gain_up"):
            self._nudge_global_gain(step)
            return True
        if self._shortcut_matches(ev, "gain_down"):
            self._nudge_global_gain(-step)
            return True
        if self._shortcut_matches(ev, "snap_positive"):
            self._apply_break_key_x()
            return True
        if self._shortcut_matches(ev, "undo_snap"):
            self._apply_break_key_c()
            return True
        if self._shortcut_matches(ev, "smooth_breaks"):
            self._apply_break_smoothing_key_s()
            return True
        if self._shortcut_matches(ev, "spacing_decrease"):
            self._nudge_track_spacing(-1)
            return True
        if self._shortcut_matches(ev, "spacing_increase"):
            self._nudge_track_spacing(+1)
            return True
        if self._shortcut_matches(ev, "rotate_view_90"):
            self._rotate_view_90()
            return True
        arrow_action = self._resolve_arrow_break_action(ev)
        if arrow_action is not None and self._dispatch_arrow_break_action(
            arrow_action, is_auto_repeat=ev.isAutoRepeat()
        ):
            return True
        return super().eventFilter(watched, event)

    def _per_trace_auto_gain_enabled(self) -> bool:
        checkbox = getattr(self, "auto_gain_checkbox", None)
        if checkbox is None:
            return False
        return checkbox.isChecked()

    def _agc_enabled(self) -> bool:
        checkbox = getattr(self, "agc_checkbox", None)
        return bool(checkbox is not None and checkbox.isChecked())

    def _agc_window_ms(self) -> float:
        spin = getattr(self, "agc_window_spin", None)
        if spin is None:
            return float(DEFAULT_AGC_WINDOW_MS)
        return float(spin.value())

    def _apply_agc_window_spin_value(self, window_ms: float) -> None:
        """Aggiorna solo lo spin finestra (sync sessione), senza attivare AGC."""
        spin = getattr(self, "agc_window_spin", None)
        if spin is None:
            return
        spin.blockSignals(True)
        try:
            spin.setValue(float(window_ms))
        finally:
            spin.blockSignals(False)
        if self._agc_enabled() and self.stream is not None:
            self._reset_view_on_plot = False
            self._invalidate_plot_cache(reset_graphics=False, reset_view=False)
            self._build_plot_cache(follow_up="fast_redraw")

    def _publish_agc_window_ms_suggestion(self) -> None:
        window_ms = self._agc_window_ms()
        session = getattr(self, "_viewer_session", None)
        if session is not None:
            session.set_shared_agc_window_ms(window_ms, source=self)
            return
        from trace_display_prefs import load_trace_display_prefs, save_trace_display_prefs

        merged = load_trace_display_prefs()
        merged["agc_window_ms"] = float(window_ms)
        save_trace_display_prefs(merged)

    def _apply_suggested_agc_window_from_stream(
            self,
            *,
            rebuild_cache: bool = False,
        ) -> float | None:
            """Calcola e mostra la finestra AGC consigliata; non attiva l'AGC."""
            if self.stream is None:
                return None
            try:
                if len(self.stream) <= 0:
                    return None
            except TypeError:
                return None

            from agc import suggest_agc_window_ms_for_stream

            suggested = suggest_agc_window_ms_for_stream(
                self.stream,
                display_window_ms=self._effective_time_window_ms(),
            )
            self._apply_agc_window_spin_value(float(suggested))
            self._publish_agc_window_ms_suggestion()

            if rebuild_cache and self._agc_enabled():
                self._reset_view_on_plot = False
                self._invalidate_plot_cache(reset_graphics=False, reset_view=False)
                self._build_plot_cache(follow_up="fast_redraw")
            return float(suggested)

    def _break_zone_gain_user_enabled(self) -> bool:
        action = getattr(self, "act_break_zone_gain", None)
        if action is None:
            return False
        return action.isChecked()

    def _on_break_zone_gain_toggled(self, checked: bool) -> None:
        if not checked:
            self._clear_break_zone_gain_display()
            if self.stream and self._arrival_markers:
                self._rebuild_arrival_overlay()
            return
        if self.stream and self._arrival_markers:
            self._refresh_plot_with_break_gain()

    def _effective_time_window_ms(self) -> float | None:
        """Finestra Tempo della toolbar: vale anche al primo apertura, senza reinserirla."""
        spin = getattr(self, "window_spin", None)
        if spin is not None:
            try:
                value = float(spin.value())
                if math.isfinite(value) and value > 0.0:
                    return value
            except Exception:
                pass
        if self._time_window_override_ms is not None:
            return float(self._time_window_override_ms)
        return float(DEFAULT_TIME_WINDOW_S) * 1000.0

    def _handle_time_window_change(self, ms: float) -> None:
        self._time_window_override_ms = max(1.0, float(ms))
        self._reset_view_on_plot = True
        self._invalidate_plot_cache(reset_graphics=False)
        if self.stream:
            self._apply_suggested_agc_window_from_stream(rebuild_cache=False)
            self._build_plot_cache(follow_up="plot_stream")

    def _nudge_global_gain(self, delta: float) -> None:
        spin = getattr(self, "scale_spin", None)
        if spin is None:
            return
        new_val = float(spin.value()) + float(delta)
        new_val = float(np.clip(new_val, spin.minimum(), spin.maximum()))
        spin.setValue(new_val)

    @staticmethod
    def _fill_blob_vertex_indices(
            seg: np.ndarray,
            trace_vals: np.ndarray,
            max_pts: int,
            *,
            positive_blob: bool,
        ) -> np.ndarray:
            """
            Contorno del fill: estremi del lobo + massimi (rosso) o minimi (blu) locali,
            integrati con campionatura uniforme se serve. Riduce “tagli” rispetto al solo subsample.
            """
            n = int(seg.size)
            si = seg.astype(np.intp, copy=False)
            if n <= max_pts:
                return si
            v = trace_vals[si]
            blob_ix = {0, n - 1}
            for j in range(1, n - 1):
                if positive_blob:
                    if v[j] >= v[j - 1] and v[j] >= v[j + 1]:
                        blob_ix.add(j)
                else:
                    if v[j] <= v[j - 1] and v[j] <= v[j + 1]:
                        blob_ix.add(j)
            arr = np.array(sorted(blob_ix), dtype=np.intp)
            if arr.size > max(12, max_pts - 8):
                step = max(1, arr.size // max(12, max_pts // 4))
                arr = arr[::step]
                arr[0] = 0
                arr[-1] = n - 1
                arr = np.unique(arr)
            fill = np.linspace(0, n - 1, num=max(4, max_pts - arr.size + 2))
            fill = np.unique(np.clip(np.round(fill).astype(np.intp), 0, n - 1))
            merged = np.unique(np.concatenate([arr, fill]))
            if merged.size > max_pts:
                sel = np.linspace(0, merged.size - 1, num=max_pts).round().astype(np.intp)
                merged = merged[sel]
            merged = np.sort(np.unique(np.concatenate([[0], merged, [n - 1]])))
            if merged.size > max_pts:
                mid = merged[1:-1]
                if mid.size > max_pts - 2:
                    mid = mid[
                        np.linspace(0, mid.size - 1, num=max_pts - 2)
                        .round()
                        .astype(np.intp)
                    ]
                merged = np.unique(np.concatenate([[0], mid, [n - 1]]))
            return si[merged]

    def _display_trace_vals(
            self, norm: np.ndarray, baseline_val: float, amp_scale: float
        ) -> np.ndarray:
            trace_vals = norm * amp_scale + baseline_val
            clip = float(getattr(self, "_display_clip_factor", 2.0) or 2.0)
            if clip <= 0:
                return trace_vals
            half = 0.5 * clip
            dev = np.asarray(trace_vals, dtype=np.float64) - float(baseline_val)
            return float(baseline_val) + np.clip(dev, -half, half)

    def trace_display_settings(self) -> dict[str, object]:
        gain_db = TraceDisplayDialog.gain_db_from_linear(float(self.scale_spin.value()))
        scale_type = (
            TraceDisplayDialog.SCALE_TRACE_RMS
            if self._per_trace_auto_gain_enabled()
            else TraceDisplayDialog.SCALE_UNIFORM
        )
        return {
            "scale_type": scale_type,
            "clip": float(getattr(self, "_display_clip_factor", 2.0)),
            "wiggle_fill": bool(getattr(self, "_wiggle_fill_on", True)),
            "fill_positive": bool(getattr(self, "_fill_positive_on", True)),
            "fill_negative": bool(getattr(self, "_fill_negative_on", False)),
            "positive_color": self._trace_fill_color,
            "negative_color": self._trace_fill_negative_color,
            "trace_color": str(getattr(self, "_trace_color", "#4a4a4a")),
            "break_color": str(getattr(self, "_arrival_marker_color", "#0066ff")),
            "background_color": str(
                getattr(self, "_plot_background_color", "#f5f5f5")
            ),
            "gain_db": gain_db,
            "agc_enabled": False,
            "agc_window_ms": self._agc_window_ms(),
            "swap_break_mouse_buttons": bool(
                getattr(self, "_swap_break_mouse_buttons", False)
            ),
        }

    def _break_mouse_button(self) -> QtCore.Qt.MouseButton:
        """Tasto usato per pick/trascina break sul sismogramma."""
        if getattr(self, "_swap_break_mouse_buttons", False):
            return QtCore.Qt.MouseButton.LeftButton
        return QtCore.Qt.MouseButton.RightButton

    def _break_mouse_button_held(self) -> bool:
        return bool(
            QtWidgets.QApplication.mouseButtons() & self._break_mouse_button()
        )

    def _sync_viewbox_break_mouse_buttons(self) -> None:
        plot_widget = getattr(self, "plot_widget", None)
        if plot_widget is None:
            return
        try:
            vb = plot_widget.getPlotItem().getViewBox()
        except Exception:
            return
        if isinstance(vb, SiesviewViewBox):
            vb.set_swap_break_mouse_buttons(
                bool(getattr(self, "_swap_break_mouse_buttons", False))
            )

    def _apply_trace_appearance_colors(
        self,
        *,
        trace_color: str | None = None,
        break_color: str | None = None,
        background_color: str | None = None,
    ) -> bool:
        """Aggiorna penne/sfondo; True se qualcosa è cambiato."""
        changed = False
        if trace_color:
            new_c = str(trace_color).strip()
            if new_c and new_c != str(getattr(self, "_trace_color", "")):
                self._trace_color = new_c
                changed = True
            self._default_trace_pen = pg.mkPen(
                color=self._trace_color, width=0.9, cosmetic=True
            )
        if break_color:
            new_b = str(break_color).strip()
            if new_b and new_b != str(getattr(self, "_arrival_marker_color", "")):
                self._arrival_marker_color = new_b
                changed = True
            self._arrival_pen = pg.mkPen(
                QtGui.QColor(self._arrival_marker_color),
                width=float(getattr(self, "_arrival_marker_width", 3.0)),
            )
        if background_color:
            new_bg = str(background_color).strip()
            if new_bg and new_bg != str(
                getattr(self, "_plot_background_color", "")
            ):
                self._plot_background_color = new_bg
                changed = True
            if getattr(self, "plot_widget", None) is not None:
                self._apply_plot_chrome_style()
        return changed

    def _publish_trace_display_settings(self) -> None:
        settings = self.trace_display_settings()
        session = getattr(self, "_viewer_session", None)
        if session is not None:
            session.set_shared_trace_display(settings, source=self)
        else:
            save_trace_display_prefs(settings)

    def set_trace_fill_colors(
            self, *, positive: str | None = None, negative: str | None = None
        ) -> None:
            if positive:
                self._trace_fill_color = str(positive)
            if negative:
                self._trace_fill_negative_color = str(negative)

    def apply_trace_display_gain_db(self, db: int) -> None:
        gain = TraceDisplayDialog.gain_linear_from_db(int(db))
        spin = getattr(self, "scale_spin", None)
        if spin is None:
            return
        spin.blockSignals(True)
        try:
            spin.setValue(gain)
        finally:
            spin.blockSignals(False)
        self._on_gain_spin_changed()

    def apply_trace_display_settings(
            self,
            settings: dict[str, object],
            *,
            gain_only: bool = False,
            fill_only: bool = False,
            from_session: bool = False,
        ) -> None:
            if from_session:
                self._trace_display_applying = True
            try:
                cache_rebuild = False
                if not gain_only:
                    scale_type = settings.get("scale_type")
                    auto = scale_type == TraceDisplayDialog.SCALE_TRACE_RMS
                    checkbox = getattr(self, "auto_gain_checkbox", None)
                    if checkbox is not None and checkbox.isChecked() != auto:
                        checkbox.setChecked(auto)
                        cache_rebuild = True

                    agc_window_ms = float(
                        settings.get("agc_window_ms", DEFAULT_AGC_WINDOW_MS)
                    )
                    agc_spin = getattr(self, "agc_window_spin", None)
                    if agc_spin is not None:
                        if abs(float(agc_spin.value()) - agc_window_ms) > 1e-9:
                            agc_spin.setValue(agc_window_ms)
                            cache_rebuild = True

                    self._display_clip_factor = float(settings.get("clip", 2.0))

                    pos_color = settings.get("positive_color")
                    neg_color = settings.get("negative_color")
                    if pos_color:
                        self._trace_fill_color = str(pos_color)
                    if neg_color:
                        self._trace_fill_negative_color = str(neg_color)

                    appearance_changed = self._apply_trace_appearance_colors(
                        trace_color=(
                            str(settings["trace_color"])
                            if settings.get("trace_color")
                            else None
                        ),
                        break_color=(
                            str(settings["break_color"])
                            if settings.get("break_color")
                            else None
                        ),
                        background_color=(
                            str(settings["background_color"])
                            if settings.get("background_color")
                            else None
                        ),
                    )

                    if "swap_break_mouse_buttons" in settings:
                        self._swap_break_mouse_buttons = bool(
                            settings.get("swap_break_mouse_buttons")
                        )
                        self._sync_viewbox_break_mouse_buttons()

                    wiggle = bool(settings.get("wiggle_fill", True))
                    pos = bool(settings.get("fill_positive", True))
                    neg = bool(settings.get("fill_negative", False))
                    self._wiggle_fill_on = wiggle
                    if wiggle:
                        if not pos and not neg:
                            pos = True
                        self._fill_positive_on = pos
                        self._fill_negative_on = neg
                    else:
                        self._fill_positive_on = False
                        self._fill_negative_on = False

                    chk = getattr(self, "fill_neg_checkbox", None)
                    if chk is not None:
                        chk.blockSignals(True)
                        try:
                            chk.setChecked(bool(wiggle and neg and not pos))
                        finally:
                            chk.blockSignals(False)

                    if appearance_changed and self.stream and self._arrival_markers:
                        self._rebuild_arrival_overlay()

                if not fill_only:
                    db = int(settings.get("gain_db", 0))
                    gain = TraceDisplayDialog.gain_linear_from_db(db)
                    spin = getattr(self, "scale_spin", None)
                    if spin is not None:
                        spin.blockSignals(True)
                        try:
                            spin.setValue(gain)
                        finally:
                            spin.blockSignals(False)

                if cache_rebuild:
                    self._on_auto_gain_toggled(
                        bool(
                            getattr(self, "auto_gain_checkbox", None)
                            and self.auto_gain_checkbox.isChecked()
                        )
                    )
                elif self.stream:
                    self._reset_view_on_plot = False
                    if self._seismogram_graphics_ready(len(self.stream)):
                        if self._plot_cache is not None:
                            self._sync_trace_entries_from_cache(self._plot_cache)
                        # Fill/colori devono aggiornare anche le tracce fuori zoom.
                        self._fast_visual_redraw(all_traces=bool(fill_only) or not gain_only)
                    else:
                        self._plot_stream()
            finally:
                if from_session:
                    self._trace_display_applying = False
            if not from_session:
                self._publish_trace_display_settings()

    def _sync_trace_display_dialog_gain(self) -> None:
        dlg = getattr(self, "_trace_display_dialog", None)
        if dlg is None:
            return
        try:
            if dlg.isVisible():
                db = TraceDisplayDialog.gain_db_from_linear(float(self.scale_spin.value()))
                dlg.sync_gain_db(db)
        except RuntimeError:
            self._trace_display_dialog = None

    def _build_fill_path_for_trace(
            self,
            trace_entry: dict[str, object],
            baseline_val: float,
            amp_scale: float,
            *,
            positive: bool,
            trace_vals: np.ndarray | None = None,
            times_ms: np.ndarray | None = None,
        ) -> QtGui.QPainterPath:
            if trace_vals is not None and times_ms is not None:
                return self._build_trace_fill_path(
                    trace_vals, times_ms, baseline_val, positive=positive
                )
            return QtGui.QPainterPath()

    def _build_trace_fill_path(
            self,
            trace_vals: np.ndarray,
            times_ms: np.ndarray,
            base_val: float,
            *,
            positive: bool,
        ) -> QtGui.QPainterPath:
            return self._build_trace_fill_path_impl(
                trace_vals, times_ms, base_val, positive=positive
            )

    def _build_trace_fill_path_impl(
            self,
            trace_vals: np.ndarray,
            times_ms: np.ndarray,
            base_val: float,
            *,
            positive: bool,
        ) -> QtGui.QPainterPath:
            if positive:
                mask = trace_vals > base_val
            else:
                mask = trace_vals < base_val
            path = QtGui.QPainterPath()
            if not np.any(mask):
                return path
            max_edge = max(
                48, int(getattr(self, "_fill_max_points_per_blob", 200) or 200)
            )
            indices = np.where(mask)[0]
            splits = np.split(indices, np.where(np.diff(indices) != 1)[0] + 1)
            for seg in splits:
                if seg.size == 0:
                    continue
                start_idx = int(seg[0])
                end_idx = int(seg[-1])
                start_y = float(times_ms[start_idx])
                if positive:
                    crosses_start = start_idx > 0 and trace_vals[start_idx - 1] <= base_val
                    crosses_end = (
                        end_idx + 1 < trace_vals.size
                        and trace_vals[end_idx + 1] <= base_val
                    )
                else:
                    crosses_start = start_idx > 0 and trace_vals[start_idx - 1] >= base_val
                    crosses_end = (
                        end_idx + 1 < trace_vals.size
                        and trace_vals[end_idx + 1] >= base_val
                    )
                if crosses_start:
                    prev_val = float(trace_vals[start_idx - 1])
                    curr_val = float(trace_vals[start_idx])
                    if curr_val != prev_val:
                        ratio = (base_val - prev_val) / (curr_val - prev_val)
                        start_y = float(
                            times_ms[start_idx - 1]
                            + (times_ms[start_idx] - times_ms[start_idx - 1]) * ratio
                        )
                end_y = float(times_ms[end_idx])
                if crosses_end:
                    next_val = float(trace_vals[end_idx + 1])
                    curr_val = float(trace_vals[end_idx])
                    if curr_val != next_val:
                        ratio = (base_val - curr_val) / (next_val - curr_val)
                        end_y = float(
                            times_ms[end_idx]
                            + (times_ms[end_idx + 1] - times_ms[end_idx]) * ratio
                        )
                ii = self._fill_blob_vertex_indices(
                    seg, trace_vals, max_edge, positive_blob=positive
                )
                xs = np.asarray(trace_vals[ii], dtype=np.float64)
                ys = np.asarray(times_ms[ii], dtype=np.float64)
                x_poly = np.concatenate(
                    (np.array([float(base_val)], dtype=np.float64), xs, [float(base_val)])
                )
                y_poly = np.concatenate(
                    (np.array([start_y], dtype=np.float64), ys, [end_y])
                )
                self._append_fill_polygon_to_path(path, x_poly, y_poly)
            return path

    def _ensure_trace_fill_path_item(
            self,
            trace_entry: dict[str, object],
            plot_item: pg.PlotItem,
            *,
            negative: bool,
            slot: int = 0,
        ) -> QtWidgets.QGraphicsPathItem:
            pool = trace_entry.setdefault("fill_path_pool", [])
            while len(pool) <= slot:
                pool.append(None)
            item = pool[slot]
            color = (
                self._trace_fill_negative_color if negative else self._trace_fill_color
            )
            fill_color = QtGui.QColor(color)
            fill_color.setAlpha(self._trace_fill_alpha)
            brush = QtGui.QBrush(fill_color)
            if item is None:
                item = QtWidgets.QGraphicsPathItem()
                item.setPen(QtGui.QPen(QtCore.Qt.PenStyle.NoPen))
                item.setZValue(1)
                plot_item.addItem(item)
                pool[slot] = item
            if slot == 0:
                trace_entry["fill_path"] = item
            item.setBrush(brush)
            return item

    def _sync_trace_fill_items(
            self,
            trace_vals: np.ndarray,
            times_ms: np.ndarray,
            baseline_val: float,
            plot_item: pg.PlotItem,
            trace_entry: dict[str, object],
        ) -> list[QtWidgets.QGraphicsPathItem]:
            """Aggiorna il fill di una traccia; riusa l'item grafico se Fase 2A attiva."""
            if not getattr(self, "_wiggle_fill_on", True):
                self._clear_fill_items(trace_entry)
                return []
            layers: list[bool] = []
            if getattr(self, "_fill_positive_on", True):
                layers.append(False)
            if getattr(self, "_fill_negative_on", False):
                layers.append(True)
            if not layers:
                self._clear_fill_items(trace_entry)
                return []

            amp_scale = self._effective_amplitude_scale()
            if not getattr(self, "_fill_path_reuse_enabled", True):
                self._dispose_trace_fill_items(trace_entry, plot_item)
                fill_items: list[QtWidgets.QGraphicsPathItem] = []
                for negative in layers:
                    path = self._build_fill_path_for_trace(
                        trace_entry,
                        baseline_val,
                        amp_scale,
                        positive=not negative,
                        trace_vals=trace_vals,
                        times_ms=times_ms,
                    )
                    if path.isEmpty():
                        continue
                    fill_item = QtWidgets.QGraphicsPathItem(path)
                    fill_color = QtGui.QColor(
                        self._trace_fill_negative_color
                        if negative
                        else self._trace_fill_color
                    )
                    fill_color.setAlpha(self._trace_fill_alpha)
                    fill_item.setBrush(QtGui.QBrush(fill_color))
                    fill_item.setPen(QtGui.QPen(QtCore.Qt.PenStyle.NoPen))
                    fill_item.setZValue(1)
                    plot_item.addItem(fill_item)
                    fill_items.append(fill_item)
                trace_entry["fills"] = fill_items
                return fill_items

            fill_items: list[QtWidgets.QGraphicsPathItem] = []
            for slot, negative in enumerate(layers):
                path = self._build_fill_path_for_trace(
                    trace_entry,
                    baseline_val,
                    amp_scale,
                    positive=not negative,
                    trace_vals=trace_vals,
                    times_ms=times_ms,
                )
                if path.isEmpty():
                    continue
                fill_item = self._ensure_trace_fill_path_item(
                    trace_entry, plot_item, negative=negative, slot=slot
                )
                fill_item.setPath(path)
                fill_item.setVisible(True)
                fill_items.append(fill_item)
            pool = trace_entry.get("fill_path_pool") or []
            for j in range(len(layers), len(pool)):
                extra = pool[j]
                if extra is not None:
                    extra.setPath(QtGui.QPainterPath())
                    extra.setVisible(False)
            trace_entry["fills"] = fill_items
            return fill_items

    def _create_positive_fill_items(
            self,
            trace_vals: np.ndarray,
            times_ms: np.ndarray,
            base_val: float,
            plot_item: pg.PlotItem,
        ) -> list[QtWidgets.QGraphicsPathItem]:
            path = self._build_trace_fill_path(
                trace_vals, times_ms, base_val, positive=True
            )
            fill_items: list[QtWidgets.QGraphicsPathItem] = []
            if path.isEmpty():
                return fill_items
            fill_item = QtWidgets.QGraphicsPathItem(path)
            fill_color = QtGui.QColor(self._trace_fill_color)
            fill_color.setAlpha(self._trace_fill_alpha)
            fill_item.setBrush(QtGui.QBrush(fill_color))
            fill_item.setPen(QtGui.QPen(QtCore.Qt.PenStyle.NoPen))
            fill_item.setZValue(1)
            plot_item.addItem(fill_item)
            fill_items.append(fill_item)
            return fill_items

    def _create_negative_fill_items(
            self,
            trace_vals: np.ndarray,
            times_ms: np.ndarray,
            base_val: float,
            plot_item: pg.PlotItem,
        ) -> list[QtWidgets.QGraphicsPathItem]:
            path = self._build_trace_fill_path(
                trace_vals, times_ms, base_val, positive=False
            )
            fill_items: list[QtWidgets.QGraphicsPathItem] = []
            if path.isEmpty():
                return fill_items
            fill_item = QtWidgets.QGraphicsPathItem(path)
            fill_color = QtGui.QColor(self._trace_fill_negative_color)
            fill_color.setAlpha(self._trace_fill_alpha)
            fill_item.setBrush(QtGui.QBrush(fill_color))
            fill_item.setPen(QtGui.QPen(QtCore.Qt.PenStyle.NoPen))
            fill_item.setZValue(1)
            plot_item.addItem(fill_item)
            fill_items.append(fill_item)
            return fill_items

    def _append_trace_fill_items(
            self,
            trace_vals: np.ndarray,
            times_ms: np.ndarray,
            baseline_val: float,
            plot_item: pg.PlotItem,
            trace_entry: dict[str, object] | None = None,
        ) -> list[QtWidgets.QGraphicsPathItem]:
            if trace_entry is not None and getattr(
                self, "_fill_path_reuse_enabled", True
            ):
                return self._sync_trace_fill_items(
                    trace_vals, times_ms, baseline_val, plot_item, trace_entry
                )
            if not getattr(self, "_wiggle_fill_on", True):
                return []
            fill_items: list[QtWidgets.QGraphicsPathItem] = []
            if getattr(self, "_fill_positive_on", True):
                fill_items.extend(
                    self._create_positive_fill_items(
                        trace_vals, times_ms, baseline_val, plot_item
                    )
                )
            if getattr(self, "_fill_negative_on", False):
                fill_items.extend(
                    self._create_negative_fill_items(
                        trace_vals, times_ms, baseline_val, plot_item
                    )
                )
            return fill_items

    def _dispose_trace_fill_items(
            self,
            trace_entry: dict[str, object],
            plot_item: pg.PlotItem | None = None,
        ) -> None:
            pool = trace_entry.pop("fill_path_pool", None)
            trace_entry.pop("fill_path", None)
            trace_entry["fills"] = []
            items: list[QtWidgets.QGraphicsPathItem] = []
            if pool:
                items.extend(i for i in pool if i is not None)
            if not items:
                return
            if plot_item is None:
                try:
                    plot_item = self.plot_widget.getPlotItem()
                except Exception:
                    plot_item = None
            if plot_item is None:
                return
            for item in items:
                try:
                    plot_item.removeItem(item)
                except Exception:
                    pass

    def _clear_fill_items(self, trace_entry: dict[str, object]) -> None:
        if getattr(self, "_fill_path_reuse_enabled", True):
            pool = trace_entry.get("fill_path_pool") or []
            legacy = trace_entry.get("fill_path")
            items = list(pool)
            if legacy is not None and legacy not in items:
                items.append(legacy)
            for item in items:
                if item is None:
                    continue
                item.setPath(QtGui.QPainterPath())
                item.setVisible(False)
            trace_entry["fills"] = []
            return
        self._dispose_trace_fill_items(trace_entry)

    def _update_trace_offsets_and_range(self, cache, base_min, base_max):
        overall_min = math.inf
        overall_max = -math.inf
        for idx, entry in enumerate(cache):
            times = entry["times"]
            if times.size == 0:
                continue
            overall_min = min(overall_min, float(times[0]))
            overall_max = max(overall_max, float(times[-1]))
        if not math.isfinite(overall_min):
            overall_min = base_min
        if not math.isfinite(overall_max):
            overall_max = base_max
        self._time_range_full = (float(overall_min), float(overall_max))

    def _apply_spacing_visual_update(self, old_baseline: np.ndarray, new_baseline: np.ndarray) -> None:
        if self.stream is None or not self._trace_items:
            return
        self._current_baseline = new_baseline
        plot_item = self.plot_widget.getPlotItem()
        view_box = plot_item.getViewBox()
        for idx, entry in enumerate(self._trace_items):
            if entry is None:
                continue
            baseline_val = float(new_baseline[idx])
            entry["baseline"] = baseline_val
            norm = entry.get("norm")
            times = entry.get("times")
            curve = entry.get("curve")
            if norm is None or times is None or curve is None:
                continue
            amp_scale = self._effective_amplitude_scale()
            trace_vals = self._display_trace_vals(norm, baseline_val, amp_scale)
            x_plot, y_plot = self._map_unrotated_to_view(trace_vals, times)
            curve.setData(x_plot, y_plot)
            entry["fills"] = self._append_trace_fill_items(
                trace_vals, times, baseline_val, plot_item, entry
            )
            self._apply_trace_curve_style(idx)
        self._last_track_tick_labels = None
        self._sync_track_ticks()
        # Aggiorna i limiti di pan: senza questo le tracce escono dalla vista
        # e non si possono raggiungere (solo zoom “sblocca” i limiti).
        self._apply_view_limits(view_box)
        old_span = (
            float(old_baseline[-1] - old_baseline[0])
            if getattr(old_baseline, "size", 0) > 1
            else 0.0
        )
        new_span = (
            float(new_baseline[-1] - new_baseline[0])
            if getattr(new_baseline, "size", 0) > 1
            else 0.0
        )
        if old_span > 1e-9 and new_span > 1e-9:
            scale = new_span / old_span
            try:
                (tr0, tr1), (tm0, tm1) = self._view_unrotated_axis_ranges()
            except Exception:
                tr0 = tr1 = tm0 = tm1 = None
            if tr0 is not None:
                new_tr0 = float(tr0) * scale
                new_tr1 = float(tr1) * scale
                if abs(new_tr1 - new_tr0) < 1e-6:
                    new_tr1 = new_tr0 + 1.0
                corners = [
                    self._map_unrotated_to_view(new_tr0, float(tm0)),
                    self._map_unrotated_to_view(new_tr0, float(tm1)),
                    self._map_unrotated_to_view(new_tr1, float(tm0)),
                    self._map_unrotated_to_view(new_tr1, float(tm1)),
                ]
                xs = [c[0] for c in corners]
                ys = [c[1] for c in corners]
                view_box.setRange(
                    xRange=(min(xs), max(xs)),
                    yRange=(min(ys), max(ys)),
                    padding=0.0,
                )
        self._rebuild_arrival_overlay()

    def _choose_file(self) -> None:
        if obspy_read is None:
            QtWidgets.QMessageBox.critical(
                self,
                "ObsPy mancante",
                "Installa ObsPy (pip install obspy) per poter aprire i sismogrammi.",
            )
            return

        path_str, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Seleziona file sismico",
            "",
            "Sismogrammi (*.sgy *.segy *.seg2 *.sg2 *.dat *.mrg);;Tutti i file (*.*)",
        )
        if not path_str:
            return

        path = Path(path_str)
        self._load_file_from_disk(path)

    def _choose_data_folder(self) -> None:
        start = str(self._current_folder) if self._current_folder else ""
        path_str = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Seleziona cartella dati",
            start,
        )
        if not path_str:
            return
        self._set_folder_directory(Path(path_str))

    def _ensure_load_wait_dialog(self) -> SeismogramLoadWaitDialog:
        dlg = getattr(self, "_load_wait_dialog", None)
        if dlg is None:
            dlg = SeismogramLoadWaitDialog(self)
            self._load_wait_dialog = dlg
        return dlg

    def _bind_load_wait_dialog(
        self,
        host: QtWidgets.QWidget,
        *,
        modal: bool,
    ) -> SeismogramLoadWaitDialog:
        """Aggancia la finestra di attesa a ``host`` (z-order Windows = owner)."""
        dlg = self._ensure_load_wait_dialog()
        flags = (
            QtCore.Qt.WindowType.Dialog
            | QtCore.Qt.WindowType.CustomizeWindowHint
            | QtCore.Qt.WindowType.WindowTitleHint
        )
        if dlg.parentWidget() is not host:
            was_visible = dlg.isVisible()
            if was_visible:
                dlg.hide()
            dlg.setParent(host, flags)
        dlg.setModal(bool(modal))
        return dlg

    def _show_seismogram_loading(self, path: Path, step: str) -> None:
        dlg = self._bind_load_wait_dialog(self, modal=True)
        dlg.set_status(f"{step}\n{path.name}")
        dlg.show_centered_on(self)

    def _hide_seismogram_loading(self) -> None:
        dlg = getattr(self, "_load_wait_dialog", None)
        if dlg is not None and dlg.isVisible():
            dlg.hide()
        QtWidgets.QApplication.processEvents(
            QtCore.QEventLoop.ProcessEventsFlag.ExcludeUserInputEvents
        )

    def _dromocrona_loading_parent(self) -> QtWidgets.QWidget:
        win = self._fbp_velocity_window_ref()
        if win is not None and win.isVisible():
            return win
        return self

    def _raise_fbp_monitor_now(self, win: FbpVelocityMonitorWindow | None) -> None:
        if win is None:
            return
        try:
            if win.isMinimized():
                win.showNormal()
            if not win.isVisible():
                return
            win.raise_()
            win.activateWindow()
            app = QtWidgets.QApplication.instance()
            if app is not None:
                app.setActiveWindow(win)
            # Dialog di attesa (se figlio del monitor) resta sopra il grafico.
            dlg = getattr(self, "_load_wait_dialog", None)
            if (
                dlg is not None
                and dlg.isVisible()
                and dlg.parentWidget() is win
            ):
                dlg.raise_()
        except RuntimeError:
            return

    def _bring_fbp_monitor_to_front(
            self, win: FbpVelocityMonitorWindow | None = None
        ) -> None:
            """Porta il monitor dromocrone sopra il sismogramma (Windows z-order)."""
            if win is None:
                win = self._fbp_velocity_window_ref()
            if win is None:
                return
            # Non riagganciare come figlia del sismogramma: su Windows le owned
            # window minimizzano a titlebar fluttuante invece che in taskbar.
            if win.parent() is not None:
                win.setParent(None, QtCore.Qt.WindowType.Window)
            if win.isMinimized():
                win.showNormal()
            elif not win.isVisible():
                win.show()
            self._raise_fbp_monitor_now(win)
            QtCore.QTimer.singleShot(
                0, lambda w=win: self._raise_fbp_monitor_now(w)
            )
            # Secondo passaggio: dopo hide del dialog di attesa / processEvents.
            QtCore.QTimer.singleShot(
                50, lambda w=win: self._raise_fbp_monitor_now(w)
            )

    def _show_dromocrona_loading(self, step: str, *, detail: str = "") -> None:
        host = self._dromocrona_loading_parent()
        # Parent = monitor → Windows non alza il sismogramma sopra le dromocrone.
        dlg = self._bind_load_wait_dialog(host, modal=False)
        text = str(step)
        if detail:
            text = f"{text}\n{detail}"
        dlg.set_status(text)
        dlg.show_centered_on(host)
        win = self._fbp_velocity_window_ref()
        if win is not None and win.isVisible():
            self._raise_fbp_monitor_now(win)

    def _hide_dromocrona_loading(self) -> None:
        self._hide_seismogram_loading()
        # Riporta il dialog sul sismogramma per i caricamenti successivi.
        try:
            self._bind_load_wait_dialog(self, modal=True)
        except RuntimeError:
            pass
        win = self._fbp_velocity_window_ref()
        if win is not None and win.isVisible():
            self._bring_fbp_monitor_to_front(win)

    def _load_file_from_disk(
            self,
            path: Path,
            *,
            paired_fbp: Path | None = None,
        ) -> bool:
            if not self._autosave_breaks_for_current():
                answer = QtWidgets.QMessageBox.warning(
                    self,
                    "Break non salvati",
                    (
                        "Non è stato possibile salvare il file .fbp corrente "
                        "prima di aprire un altro sismogramma.\n\n"
                        "Vuoi aprire il nuovo file comunque? "
                        "(le modifiche non salvate andranno perse)"
                    ),
                    QtWidgets.QMessageBox.StandardButton.Yes
                    | QtWidgets.QMessageBox.StandardButton.No,
                    QtWidgets.QMessageBox.StandardButton.No,
                )
                if answer != QtWidgets.QMessageBox.StandardButton.Yes:
                    return False
            fbp_path = (
                paired_fbp
                if paired_fbp is not None
                else default_fbp_path_for_seismogram(path)
            )
            self._fbp_save_target_override = None
            self._break_zone_gain_active = False
            self._invalidate_plot_cache(reset_graphics=True, reset_view=True)
            self._gui_worker.invalidate("apply_filter")
            self._gui_worker.invalidate("snap_breaks")
            self._invalidate_build_cache_jobs()
            self._stream_epoch = int(getattr(self, "_stream_epoch", 0)) + 1
            dlg = getattr(self, "_filter_dialog", None)
            if dlg is not None:
                try:
                    dlg.set_apply_status("", error=False)
                except Exception:
                    pass
            self._show_seismogram_loading(path, "Lettura file in corso…")
            payload = {
                "path": str(path),
                "fbp_path": str(fbp_path),
                "points_budget": 0,
                "max_plot_points": int(self.max_plot_points),
                "max_total_plot_points": int(self.max_total_plot_points),
                "max_display_ms": self._effective_time_window_ms(),
                "use_auto_gain": self._per_trace_auto_gain_enabled(),
                "display_scale_percentile": float(
                    getattr(self, "_display_scale_percentile", 98.0) or 98.0
                ),
                "break_zone_gain_user_enabled": self._break_zone_gain_user_enabled(),
                "break_near_window_ms": float(
                    getattr(self, "_break_near_window_ms", BREAK_NEAR_WINDOW_MS_DEFAULT)
                ),
                "break_near_gain": float(
                    getattr(self, "_break_near_gain", BREAK_NEAR_GAIN_DEFAULT)
                ),
                "agc_enabled": self._agc_enabled(),
                "agc_window_ms": self._agc_window_ms(),
            }
            self._gui_worker.submit(
                "load_file",
                payload,
                extra={
                    "paired_fbp": str(fbp_path),
                },
            )
            return True

    def _sync_plot_with_fbp_after_display(
            self,
            *,
            paired_fbp: Path | None = None,
            plot_already_done: bool = False,
        ) -> None:
            """Dopo _plot_stream: sidebar, highlight e (se serve) break .fbp."""
            loaded = getattr(self, "loaded_path", None)
            if loaded is not None:
                self._sync_folder_browser_with_path(loaded)
                if paired_fbp is None:
                    paired_fbp = default_fbp_path_for_seismogram(loaded)
            else:
                paired_fbp = paired_fbp or getattr(self, "_active_fbp_path", None)

            if plot_already_done:
                if paired_fbp is not None and paired_fbp.exists():
                    self._set_fbp_sync_status("caricato da disco")
                elif loaded is not None:
                    self._set_fbp_sync_status("pronto (nuovo .fbp)")
                if self._arrival_markers:
                    self._rebuild_arrival_overlay()
            elif paired_fbp is not None and paired_fbp.exists():
                self._apply_fbp_markers_from_file(paired_fbp, trace_shift=0)
                self._active_fbp_path = paired_fbp
                self._refresh_plot_with_break_gain()
                self._set_fbp_sync_status("caricato da disco")
            else:
                self._rebuild_arrival_overlay()
                if loaded is not None:
                    self._set_fbp_sync_status("pronto (nuovo .fbp)")

            if loaded is not None:
                self._highlight_break_item(self._default_fbp_path_for_loaded())

            active = paired_fbp or getattr(self, "_active_fbp_path", None)
            if (
                active is not None
                and self._arrival_markers
                and self._fbp_velocity_window_ref() is not None
            ):
                self._sync_monitor_series_from_markers(active)

    def _persist_breaks_before_view_reset(self) -> None:
        """Salva i break in memoria sul .fbp prima di ricaricare la vista."""
        self._flush_active_fbp_to_disk(force=True)

    def _set_folder_directory(
            self,
            directory: Path,
            *,
            from_session: bool = False,
        ) -> None:
            prev_folder = getattr(self, "_current_folder", None)
            self._current_folder = directory
            owner = self._session_owner_window()
            folder_changed = prev_folder is None or not self._same_path(prev_folder, directory)
            if folder_changed:
                if self is owner:
                    owner._fbp_monitor_loaded_folder = None
                    owner._schedule_fbp_monitor_preload()
                elif not from_session:
                    owner._fbp_monitor_loaded_folder = None
                    owner._schedule_fbp_monitor_preload()
            if hasattr(self, "folder_path_label"):
                self.folder_path_label.setText(str(directory))
            refresh_monitor = self is owner
            self._populate_folder_file_list(
                directory,
                refresh_dromocrona_monitor=refresh_monitor,
            )
            if not from_session:
                session = getattr(self, "_viewer_session", None)
                if session is not None:
                    session.set_shared_folder(directory, source=self)

    def _schedule_fbp_monitor_preload(self) -> None:
        timer = getattr(self, "_fbp_monitor_preload_timer", None)
        if timer is None:
            return
        timer.start()

    def _preload_fbp_dromocrona_monitor(self) -> None:
        owner = self._session_owner_window()
        if self is not owner:
            return
        # Evita di caricare tutte le dromocrona finché l'utente non apre il monitor.
        if owner._fbp_velocity_window_ref() is None:
            return
        folder = getattr(owner, "_current_folder", None)
        if folder is None or not folder.exists():
            return
        loaded = getattr(owner, "_fbp_monitor_loaded_folder", None)
        if loaded is not None and self._same_path(loaded, folder):
            win = self._fbp_velocity_window_ref()
            if win is not None and win.series_count() > 0:
                return
        has_fbp = any(
            p.is_file() and is_fbp_file(p) for p in folder.iterdir()
        )
        if not has_fbp:
            return
        owner._ensure_fbp_velocity_window()
        owner._refresh_fbp_velocity_from_folder(show_window=False)

    def _populate_folder_file_list(
            self,
            directory: Path | None,
            *,
            refresh_dromocrona_monitor: bool = False,
        ) -> None:
            file_list = getattr(self, "folder_files_list", None)
            hint_label = getattr(self, "folder_list_hint", None)
            path_label = getattr(self, "folder_path_label", None)
            break_list = getattr(self, "break_files_list", None)
            break_hint = getattr(self, "break_list_hint", None)
            if file_list is None:
                return
            file_list.clear()
            if break_list is not None:
                break_list.clear()
            if directory is None:
                if hint_label:
                    hint_label.setText("Seleziona una cartella")
                if path_label:
                    path_label.setText("Nessuna cartella")
                if break_hint:
                    break_hint.setText("Seleziona una cartella")
                return
            if not directory.exists():
                if hint_label:
                    hint_label.setText("Cartella non disponibile")
                if break_hint:
                    break_hint.setText("Cartella non disponibile")
                return
            files = []
            break_files = []
            try:
                for entry in directory.iterdir():
                    if entry.is_file() and entry.suffix.lower() in self._folder_extensions:
                        files.append(entry)
                    elif entry.is_file() and is_fbp_file(entry):
                        break_files.append(entry)
            except PermissionError:
                if hint_label:
                    hint_label.setText("Accesso negato alla cartella")
                if break_hint:
                    break_hint.setText("Accesso negato alla cartella")
                return
            except OSError:
                if hint_label:
                    hint_label.setText("Errore durante la lettura della cartella")
                if break_hint:
                    break_hint.setText("Errore durante la lettura della cartella")
                return
            files.sort(key=lambda p: natural_sort_key(p.name))
            for entry in files:
                item = QtWidgets.QListWidgetItem(entry.name)
                item.setToolTip(str(entry))
                item.setData(QtCore.Qt.ItemDataRole.UserRole, str(entry))
                file_list.addItem(item)
            if hint_label:
                if not files:
                    hint_label.setText("Nessun file sismico trovato")
                else:
                    hint_label.setText("")
            if break_list is not None:
                break_files.sort(key=lambda p: natural_sort_key(p.name))
                for entry in break_files:
                    item = QtWidgets.QListWidgetItem(entry.name)
                    item.setToolTip(str(entry))
                    item.setData(QtCore.Qt.ItemDataRole.UserRole, str(entry))
                    break_list.addItem(item)
                if break_hint:
                    break_hint.setText(
                        "Nessun file .fbp/.FBP trovato" if not break_files else ""
                    )

            current_loaded = getattr(self, "loaded_path", None)
            if current_loaded and current_loaded.parent == directory:
                self._highlight_folder_item(current_loaded)
            else:
                self._highlight_folder_item(None)
            self._highlight_break_item(self._default_fbp_path_for_loaded())
            if refresh_dromocrona_monitor:
                win = self._fbp_velocity_window_ref()
                if win is not None and win.isVisible():
                    self._refresh_fbp_velocity_from_folder(show_window=False)

    def _handle_folder_item_activated(self, item) -> None:
        if not item:
            return
        path_data = item.data(QtCore.Qt.ItemDataRole.UserRole)
        if not path_data:
            return
        path = Path(path_data)
        if self._should_skip_duplicate_list_load(path):
            return
        self._load_file_from_disk(path)

    def _handle_break_item_activated(self, item) -> None:
        if not item:
            return
        path_data = item.data(QtCore.Qt.ItemDataRole.UserRole)
        if not path_data:
            return
        path = Path(path_data)
        if self._should_skip_duplicate_list_load(path):
            return
        self._ensure_fbp_parent_folder(path)
        if self.stream is not None:
            self._load_breaks_from_fbp(path, trace_shift=0)
            self._highlight_break_item(path)
            return
        sgy_path = self._find_seismogram_for_fbp(path)
        if sgy_path is not None:
            self._open_seismogram_with_fbp(sgy_path, path)
            return
        self._load_breaks_from_fbp(path, trace_shift=0)
        self._highlight_break_item(path)

    def _ensure_fbp_parent_folder(self, fbp_path: Path) -> None:
        folder = fbp_path.parent
        current = getattr(self, "_current_folder", None)
        if current is None or current != folder:
            self._set_folder_directory(folder)

    def _selected_break_path(self) -> Path | None:
        file_list = getattr(self, "break_files_list", None)
        if file_list is None:
            return None
        item = file_list.currentItem()
        if item is None:
            return None
        path_data = item.data(QtCore.Qt.ItemDataRole.UserRole)
        if not path_data:
            return None
        return Path(path_data)

    def _generate_s_breaks_from_p(self) -> None:
        """Genera .fbp S da pick P: ordine associato + scaling (t−t_shot)×T+t_shot."""
        if self.stream is None or self.loaded_path is None:
            QtWidgets.QMessageBox.information(
                self,
                "Apri un sismogramma S",
                "Apri prima il sismogramma S su cui lavorare, poi genera i break da P.",
            )
            return
        loaded = self.loaded_path
        p_initial = guess_p_folder_for_s_seismogram(loaded)
        p_paths = select_p_fbp_files(self, p_initial)
        if not p_paths:
            return
        p_paths = sorted(p_paths, key=lambda p: natural_sort_key(p.name))
        if len(p_paths) == 1:
            s_paths = [loaded]
        else:
            s_initial = guess_s_folder_for_seismogram(loaded)
            folder = self._current_folder
            use_folder = False
            if folder is not None and folder.is_dir():
                folder_s = list_seismograms_in_folder(folder)
                if len(folder_s) == len(p_paths):
                    answer = QtWidgets.QMessageBox.question(
                        self,
                        "Sismogrammi S",
                        (
                            f"Hai selezionato {len(p_paths)} file P.\n\n"
                            f"Usare i {len(folder_s)} sismogrammi S nella cartella corrente?\n"
                            f"{folder}\n\n"
                            "Sì = cartella corrente\n"
                            "No = selezione manuale (anche da un'altra cartella)"
                        ),
                        QtWidgets.QMessageBox.StandardButton.Yes
                        | QtWidgets.QMessageBox.StandardButton.No
                        | QtWidgets.QMessageBox.StandardButton.Cancel,
                        QtWidgets.QMessageBox.StandardButton.Yes,
                    )
                    if answer == QtWidgets.QMessageBox.StandardButton.Cancel:
                        return
                    use_folder = answer == QtWidgets.QMessageBox.StandardButton.Yes
            if use_folder and folder is not None:
                s_paths = list_seismograms_in_folder(folder)
            else:
                s_paths = select_s_seismogram_files(
                    self,
                    s_initial,
                    required_count=len(p_paths),
                )
                if not s_paths:
                    return
        dlg = GenerateSFromPDialog(self, p_paths=p_paths, s_paths=s_paths)
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        params = dlg.params()
        if params is None:
            return
        try:
            pairings = pair_p_to_s_seismograms(
                p_paths,
                s_paths,
                same_order=params.same_order,
            )
            result = generate_s_fbp_files(pairings, params.time_factor)
        except ValueError as exc:
            QtWidgets.QMessageBox.warning(self, "Generazione S", str(exc))
            return
        except OSError as exc:
            QtWidgets.QMessageBox.critical(
                self,
                "Errore scrittura .fbp",
                f"Impossibile scrivere i file S:\n{exc}",
            )
            return
        applied = False
        try:
            # I .fbp S su disco sono la fonte di verità: non flushare RAM stale sopra.
            active = getattr(self, "_active_fbp_path", None)
            if active is not None and any(
                self._same_path(active, p) for p in result.written_paths
            ):
                self._finish_any_break_gesture()
                self._fbp_autosave_dirty_traces.clear()
                self._fbp_monitor_dirty_traces.clear()
            folder = self._current_folder
            if folder is not None:
                self._populate_folder_file_list(folder)
            # Non aggiornare il monitor file-per-file: N× append_series + morpho/FAIL
            # può congelare/crashare (timer Qt su plot già clear). Un solo reload batch.
            for s_fbp in result.written_paths:
                self._broadcast_fbp_changed(s_fbp, reload_monitor=False)
            for pair in result.pairs:
                if self._same_path(pair.s_seismogram, self.loaded_path):
                    self._load_breaks_from_fbp(pair.s_fbp, trace_shift=0)
                    applied = True
                    break
            if self._fbp_velocity_window_ref() is not None:
                # Sync marker→monitor deferito a fine import (evita race su clear_series).
                self._refresh_fbp_velocity_from_folder(
                    show_window=False, force=True
                )
            elif applied:
                self._sync_monitor_from_active_markers()
        except Exception as exc:
            _LOG.exception("Aggiornamento UI dopo generazione break S da P")
            QtWidgets.QMessageBox.warning(
                self,
                "Break S generati (UI)",
                (
                    f"I file .fbp S sono stati scritti ({len(result.written_paths)}), "
                    f"ma l'aggiornamento della vista ha avuto un problema:\n{exc}"
                ),
            )
        summary = "\n".join(
            f"{pair.p_fbp.name} → {pair.s_fbp.name}" for pair in result.pairs
        )
        note = (
            f"\n\nFattore T = {params.time_factor:g}"
            f" ({'stesso ordine' if params.same_order else 'ordine invertito'})."
        )
        if applied:
            note += "\nI break del sismogramma aperto sono stati caricati."
        QtWidgets.QMessageBox.information(
            self,
            "Break S generati",
            f"Creati {len(result.written_paths)} file .fbp S:\n\n{summary}{note}",
        )

    def _sync_folder_browser_with_path(self, path: Path | None) -> None:
        if path is None:
            self._highlight_folder_item(None)
            self._highlight_break_item(None)
            return
        directory = path.parent
        if not directory.exists():
            return
        current = getattr(self, "_current_folder", None)
        if current is None or current != directory:
            self._set_folder_directory(directory)
        else:
            self._populate_folder_file_list(directory)
        self._highlight_folder_item(path)
        self._highlight_break_item(self._default_fbp_path_for_loaded())

    def _highlight_folder_item(self, path: Path | None) -> None:
        file_list = getattr(self, "folder_files_list", None)
        if file_list is None:
            return
        target = str(path) if path is not None else None
        highlight_bg = QtGui.QBrush(QtGui.QColor("#b7f7a6"))
        highlight_fg = QtGui.QBrush(QtGui.QColor("#000000"))
        default_bg = QtGui.QBrush()
        default_fg = QtGui.QBrush(QtGui.QColor("#ffffff"))
        for idx in range(file_list.count()):
            item = file_list.item(idx)
            item_path = item.data(QtCore.Qt.ItemDataRole.UserRole)
            if target and item_path == target:
                item.setBackground(highlight_bg)
                item.setForeground(highlight_fg)
                file_list.setCurrentItem(item)
            else:
                item.setBackground(default_bg)
                item.setForeground(default_fg)
        if target is None:
            file_list.clearSelection()

    def _highlight_break_item(self, path: Path | None) -> None:
        file_list = getattr(self, "break_files_list", None)
        if file_list is None:
            return
        target = str(path) if path is not None else None
        highlight_bg = QtGui.QBrush(QtGui.QColor("#b7f7a6"))
        highlight_fg = QtGui.QBrush(QtGui.QColor("#000000"))
        default_bg = QtGui.QBrush()
        default_fg = QtGui.QBrush(QtGui.QColor("#ffffff"))
        for idx in range(file_list.count()):
            item = file_list.item(idx)
            item_path = item.data(QtCore.Qt.ItemDataRole.UserRole)
            if target and item_path == target:
                item.setBackground(highlight_bg)
                item.setForeground(highlight_fg)
                file_list.setCurrentItem(item)
            else:
                item.setBackground(default_bg)
                item.setForeground(default_fg)
        if target is None:
            file_list.clearSelection()

    def _default_fbp_path_for_loaded(self) -> Path | None:
        loaded = getattr(self, "loaded_path", None)
        if not loaded:
            return None
        return find_fbp_for_seismogram(loaded)

    @staticmethod
    def _same_path(a: Path | None, b: Path | None) -> bool:
        if a is None or b is None:
            return False
        try:
            return a.resolve() == b.resolve()
        except Exception:
            return str(a) == str(b)

    def _should_skip_duplicate_list_load(self, path: Path) -> bool:
        now = time.monotonic()
        try:
            key = path.resolve()
        except Exception:
            key = path
        if (
            self._list_load_guard_path == key
            and now < self._list_load_guard_until
        ):
            return True
        self._list_load_guard_path = key
        self._list_load_guard_until = now + 0.35
        return False

    def _is_active_fbp(self, path: Path) -> bool:
        paired = self._paired_fbp_path()
        if paired is not None and self.stream is not None:
            return self._same_path(path, paired)
        return self._same_path(getattr(self, "_active_fbp_path", None), path)

    def _paired_fbp_path(self) -> Path | None:
        loaded = getattr(self, "loaded_path", None)
        if loaded is None:
            return None
        return default_fbp_path_for_seismogram(loaded)

    def _fbp_is_linked_to_open_sgy(self, fbp_path: Path) -> bool:
        paired = self._paired_fbp_path()
        return paired is not None and self._same_path(fbp_path, paired)

    def _fbp_raw_line_trace_idx(self, raw: str) -> int | None:
        """Indice traccia 0-based se la riga ha un canale esplicito, altrimenti None."""
        parsed = parse_fbp_line(str(raw), 0)
        if parsed is None:
            return None
        channel_no, _mapped_idx, _t_ms = parsed
        if int(channel_no) > 0:
            return int(channel_no) - 1
        return None

    def _fbp_line_index_for_trace(self, lines: list[str], trace_idx: int) -> int:
        wanted = int(trace_idx)
        wanted_ch = wanted + 1
        data_line_no = 0
        sequential_idx = -1
        for line_no, raw in enumerate(lines):
            parsed = parse_fbp_line(raw, data_line_no)
            if parsed is None:
                continue
            channel_no, mapped_idx, _t_ms = parsed
            if int(channel_no) == wanted_ch:
                return int(line_no)
            if sequential_idx < 0 and int(channel_no) == 0 and int(mapped_idx) == wanted:
                sequential_idx = int(line_no)
            if int(channel_no) == 0:
                data_line_no += 1
        return sequential_idx

    def _lookup_fbp_line_index(
            self,
            lines: list[str],
            trace_idx: int,
            line_by_trace: object = None,
        ) -> int:
            wanted = int(trace_idx)
            del line_by_trace
            rebuilt = _fbp_line_by_trace_from_lines(lines)
            mapped = int(rebuilt.get(wanted, -1))
            if 0 <= mapped < len(lines):
                raw_tr = self._fbp_raw_line_trace_idx(lines[mapped])
                if raw_tr is None or int(raw_tr) == wanted:
                    return mapped
            return self._fbp_line_index_for_trace(lines, wanted)

    def _fbp_target_n_traces(self, path: Path | None = None) -> int:
        """Numero tracce atteso per un .fbp (stream aperto > meta > file)."""
        if self.stream is not None and (
            path is None
            or self._fbp_is_linked_to_open_sgy(path)
            or self._is_active_fbp(path)
        ):
            return int(len(self.stream))
        win = self._fbp_velocity_window_ref()
        if win is not None and path is not None:
            series_idx = win.find_series_index(path)
            if series_idx is not None:
                raw_n = win._series_meta[series_idx].get("fbp_n_traces")
                if raw_n is not None and int(raw_n) > 0:
                    return int(raw_n)
                trace_arr = win._series_meta[series_idx].get("trace_idx")
                if trace_arr is not None:
                    arr = np.asarray(trace_arr, dtype=np.int64)
                    if arr.size:
                        return int(arr.max()) + 1
        if path is not None and path.exists():
            _ref, disk_n, _samples = fbp_disk_export_meta(path)
            if int(disk_n) > 0:
                return int(disk_n)
            return max(0, self._fbp_line_count(path))
        return 0

    def _build_fbp_disk_lines_from_series_meta(
            self,
            meta: dict[str, object],
            *,
            fbp_path: Path | None = None,
        ) -> list[str]:
            """Costruisce righe .fbp dai tempi relativi in memoria del monitor."""
            trace_arr = np.asarray(meta.get("trace_idx"), dtype=np.int64)
            y = np.asarray(meta.get("y"), dtype=np.float64)
            n = min(int(trace_arr.size), int(y.size))
            raw_ref = meta.get("shot_abs_ref_ms")
            try:
                ref = float(raw_ref) if raw_ref is not None else 0.0
            except (TypeError, ValueError):
                ref = 0.0
            if not math.isfinite(ref):
                ref = 0.0
            break_map: dict[int, float] = {}
            for i in range(n):
                tr = int(trace_arr[i])
                if tr < 0:
                    continue
                y_val = float(y[i])
                if not math.isfinite(y_val):
                    continue
                # y relativo allo shot: assoluto = ref + y (shot resta a ref).
                break_map[tr] = max(0.0, float(ref) + max(0.0, y_val))
            if (
                not break_map
                and self._fbp_is_linked_to_open_sgy(fbp_path)
                and self._arrival_markers
            ):
                for tr, stored in self._arrival_markers.items():
                    break_map[int(tr)] = self._marker_time_for_export(
                        int(tr), float(stored)
                    )
            n_traces = int(meta.get("fbp_n_traces") or 0)
            if n_traces <= 0:
                n_traces = self._fbp_target_n_traces(fbp_path)
            if n_traces <= 0 and break_map:
                n_traces = max(break_map.keys()) + 1
            if n_traces <= 0:
                return []
            samples = meta.get("fbp_samples")
            preserved = (
                {int(k): int(v) for k, v in samples.items()}
                if isinstance(samples, dict)
                else None
            )
            return self._build_fbp_lines_from_break_map(
                n_traces,
                break_map,
                sample_source=fbp_path,
                preserved_samples=preserved,
                linked_fbp=bool(
                    fbp_path is not None and self._fbp_is_linked_to_open_sgy(fbp_path)
                ),
            )

    def _resolve_fbp_disk_lines_for_write(
            self,
            fbp_path: Path,
            meta: dict[str, object] | None = None,
        ) -> list[str] | None:
            """Righe .fbp pronte per scrittura; crea template anche se il file non esiste."""
            if meta is not None:
                raw = meta.get("fbp_disk_lines")
                if isinstance(raw, list) and raw:
                    return list(raw)
            if fbp_path.exists():
                try:
                    lines = fbp_path.read_text(
                        encoding="utf-8", errors="replace"
                    ).splitlines()
                except Exception:
                    lines = []
                if lines:
                    return lines
            if meta is not None:
                built = self._build_fbp_disk_lines_from_series_meta(
                    meta, fbp_path=fbp_path
                )
                if built:
                    return built
            if self._fbp_is_linked_to_open_sgy(fbp_path) and self._arrival_markers:
                lines = self._build_fbp_lines_from_markers(fbp_path)
                if lines:
                    return lines
            n_traces = self._fbp_target_n_traces(fbp_path)
            if n_traces <= 0:
                return None
            return self._build_fbp_lines_from_break_map(
                n_traces,
                {},
                sample_source=fbp_path if fbp_path.exists() else None,
                linked_fbp=self._fbp_is_linked_to_open_sgy(fbp_path),
            )
    def _upsert_fbp_trace_line(
            self,
            disk_lines: list[str],
            trace_idx: int,
            new_line: str,
            line_by_trace: dict | None = None,
            *,
            n_traces: int | None = None,
        ) -> tuple[list[str], dict[int, int], int]:
            """Aggiorna la riga .fbp della traccia senza mai creare duplicati."""
            target_n = int(n_traces) if n_traces is not None and int(n_traces) > 0 else 0
            if target_n <= 0:
                target_n = max(
                    len(disk_lines),
                    int(trace_idx) + 1,
                    max(line_by_trace.keys()) + 1 if line_by_trace else 0,
                )
            # Espandi con placeholder canale-corretti, poi aggiorna.
            disk_lines = normalize_fbp_disk_lines(disk_lines, n_traces=target_n)
            tr = int(trace_idx)
            if tr < 0:
                mapping = _fbp_line_by_trace_from_lines(disk_lines)
                return disk_lines, mapping, -1
            if tr >= len(disk_lines):
                disk_lines = normalize_fbp_disk_lines(
                    disk_lines, n_traces=tr + 1
                )
            disk_lines[tr] = new_line
            mapping = {i: i for i in range(len(disk_lines))}
            return disk_lines, mapping, tr

    def _write_fbp_text(
            self,
            fbp_path: Path,
            disk_lines: list[str],
            *,
            n_traces: int | None = None,
        ) -> bool:
        target_n = int(n_traces) if n_traces is not None and int(n_traces) > 0 else 0
        if target_n <= 0:
            target_n = self._fbp_target_n_traces(fbp_path)
        if target_n <= 0:
            target_n = len(disk_lines)
        normalized = normalize_fbp_disk_lines(disk_lines, n_traces=target_n)
        if not normalized:
            _LOG.warning("Scrittura .fbp annullata (nessuna riga): %s", fbp_path)
            return False
        if fbp_lines_have_corruption(disk_lines) or len(disk_lines) != len(normalized):
            _LOG.info(
                "Normalizzazione .fbp %s: %d → %d righe",
                fbp_path.name,
                len(disk_lines),
                len(normalized),
            )
        text = "\n".join(normalized) + "\n"
        return write_fbp_text_atomic(fbp_path, text)

    def _fbp_trace_line_index_map(self, lines: list[str]) -> dict[int, int]:
        """Mappa trace_idx → indice riga nel file .fbp (una scansione per file)."""
        return _fbp_line_by_trace_from_lines(lines)

    def _patch_fbp_trace_in_file(
            self,
            fbp_path: Path,
            trace_idx: int,
            time_rel_ms: float,
            *,
            shot_abs_ref_ms: float | None = None,
        ) -> tuple[bool, float]:
            """Aggiorna una sola riga nel file .fbp indicato (non tocca gli altri file)."""
            if trace_idx < 0:
                return False, 0.0
            win = self._fbp_velocity_window_ref()
            series_idx = win.find_series_index(fbp_path) if win is not None else None
            meta = (
                win._series_meta[series_idx]
                if win is not None and series_idx is not None
                else None
            )
            if shot_abs_ref_ms is None and meta is not None:
                raw_ref = meta.get("shot_abs_ref_ms")
                if raw_ref is not None:
                    try:
                        ref_f = float(raw_ref)
                    except (TypeError, ValueError):
                        ref_f = float("nan")
                    if math.isfinite(ref_f):
                        shot_abs_ref_ms = ref_f
            lines = self._resolve_fbp_disk_lines_for_write(fbp_path, meta)
            if not lines:
                return False, 0.0
            self._ensure_shot_registry_loaded(fbp_path)
            registry = getattr(self, "_shot_registry", None) or {}
            new_abs = fbp_relative_to_absolute_ms(
                fbp_path,
                time_rel_ms,
                registry=registry,
                shot_abs_ref_ms=shot_abs_ref_ms,
            )
            if new_abs is None and shot_abs_ref_ms is not None:
                new_abs = float(shot_abs_ref_ms) + float(time_rel_ms)
            if new_abs is None:
                new_abs = max(0.0, float(time_rel_ms))
            line_by_trace = None if meta is None else meta.get("fbp_line_by_trace")
            if not isinstance(line_by_trace, dict):
                line_by_trace = {}
            line_idx = self._lookup_fbp_line_index(lines, trace_idx, line_by_trace)
            row = (
                str(lines[line_idx]).strip()
                if 0 <= line_idx < len(lines)
                else ""
            )
            parts = row.split() if row else []
            linked = self._fbp_is_linked_to_open_sgy(fbp_path)
            if linked and self.stream is not None and 0 <= int(trace_idx) < len(self.stream):
                sample_idx = self._samples_from_time(int(trace_idx), new_abs)
            elif len(parts) >= 3:
                try:
                    sample_idx = int(float(parts[2].replace(",", ".")))
                except Exception:
                    sample_idx = 0
            elif len(parts) >= 2:
                try:
                    sample_idx = int(float(parts[1].replace(",", ".")))
                except Exception:
                    sample_idx = 0
            else:
                sample_idx = 0
            channel_no = self._break_channel_number(trace_idx)
            time_txt = self._format_fbp_time_ms(new_abs)
            new_line = f"{channel_no}\t{time_txt}\t{int(sample_idx)}"
            lines, line_by_trace, _line_idx = self._upsert_fbp_trace_line(
                lines, trace_idx, new_line, line_by_trace
            )
            if not self._write_fbp_text(fbp_path, lines):
                return False, 0.0
            invalidate_fbp_parse_cache(fbp_path)
            if win is not None and meta is not None:
                win._store_fbp_disk_meta(
                    meta,
                    fbp_disk_lines=lines,
                    fbp_line_by_trace=line_by_trace,
                )
            self._broadcast_fbp_changed(fbp_path)
            return True, new_abs

    def _batch_patch_fbp_traces_in_files(
            self,
            file_updates: dict[Path, dict[int, float]],
        ) -> tuple[int, list[Path]]:
            """Aggiorna più tracce per file con una sola lettura/scrittura per .fbp."""
            if not file_updates:
                return 0, []
            saved_paths: list[Path] = []
            failed_paths: list[Path] = []
            saved_points = 0
            linked_refresh = False
            first_path = next(iter(file_updates.keys()), None)
            if first_path is not None:
                self._ensure_shot_registry_loaded(Path(first_path))
            registry = getattr(self, "_shot_registry", None) or {}

            for file_no, (fbp_path_raw, trace_times) in enumerate(
                file_updates.items()
            ):
                fbp_path = Path(fbp_path_raw)
                if not trace_times:
                    continue
                win = self._fbp_velocity_window_ref()
                series_idx = (
                    win.find_series_index(fbp_path) if win is not None else None
                )
                meta = (
                    win._series_meta[series_idx]
                    if win is not None and series_idx is not None
                    else None
                )
                lines = self._resolve_fbp_disk_lines_for_write(fbp_path, meta)
                if not lines:
                    failed_paths.append(fbp_path)
                    continue
                line_by_trace = self._fbp_trace_line_index_map(lines)
                file_changed = False
                file_points = 0
                linked = self._fbp_is_linked_to_open_sgy(fbp_path)
                file_ref = self._monitor_shot_abs_ref_ms(fbp_path)

                for trace_idx, time_rel_ms in trace_times.items():
                    tr = int(trace_idx)
                    new_abs = fbp_relative_to_absolute_ms(
                        fbp_path,
                        float(time_rel_ms),
                        registry=registry,
                        shot_abs_ref_ms=file_ref,
                    )
                    if new_abs is None and file_ref is not None:
                        new_abs = float(file_ref) + float(time_rel_ms)
                    if new_abs is None:
                        new_abs = max(0.0, float(time_rel_ms))
                    line_idx = line_by_trace.get(tr, -1)
                    row = (
                        lines[line_idx].strip()
                        if 0 <= line_idx < len(lines)
                        else ""
                    )
                    parts = row.split() if row else []
                    if self.stream is not None and 0 <= tr < len(self.stream):
                        sample_idx = self._samples_from_time(tr, new_abs)
                    elif len(parts) >= 3:
                        try:
                            sample_idx = int(float(parts[2].replace(",", ".")))
                        except Exception:
                            sample_idx = 0
                    elif len(parts) >= 2:
                        try:
                            sample_idx = int(float(parts[1].replace(",", ".")))
                        except Exception:
                            sample_idx = 0
                    else:
                        sample_idx = 0
                    channel_no = self._break_channel_number(tr)
                    time_txt = self._format_fbp_time_ms(new_abs)
                    new_line = f"{channel_no}\t{time_txt}\t{int(sample_idx)}"
                    lines, line_by_trace, _line_idx = self._upsert_fbp_trace_line(
                        lines, tr, new_line, line_by_trace
                    )
                    file_changed = True
                    file_points += 1
                    if linked:
                        self._arrival_markers[tr] = new_abs
                        self._arrival_base_times[tr] = max(0.0, new_abs)
                        linked_refresh = True

                if not file_changed:
                    continue
                try:
                    n_out = max(
                        len(lines),
                        max((int(tr) for tr in trace_times), default=-1) + 1,
                    )
                    lines = normalize_fbp_disk_lines(lines, n_traces=n_out)
                    if not self._write_fbp_text(fbp_path, lines, n_traces=n_out):
                        failed_paths.append(fbp_path)
                        continue
                except Exception:
                    failed_paths.append(fbp_path)
                    continue
                invalidate_fbp_parse_cache(fbp_path)
                saved_paths.append(fbp_path)
                saved_points += file_points
                if file_no % 4 == 3:
                    QtWidgets.QApplication.processEvents()

            for fbp_path in saved_paths:
                self._broadcast_fbp_changed(fbp_path)

            if linked_refresh and self.stream is not None:
                self._clear_break_zone_gain_display()
                self._rebuild_arrival_overlay()

            if saved_paths or failed_paths:
                last = saved_paths[-1] if saved_paths else failed_paths[-1]
                if failed_paths and not saved_paths:
                    self._set_fbp_sync_status(
                        f"errore salvataggio su {len(failed_paths)} file .fbp",
                        tone="error",
                        path=last,
                    )
                elif failed_paths:
                    self._set_fbp_sync_status(
                        f"salvati {saved_points} punti su {len(saved_paths)} file "
                        f"({len(failed_paths)} errori)",
                        tone="warn",
                        path=last,
                    )
                else:
                    self._active_fbp_path = last
                    self._last_monitor_edit_path = last
                    self._highlight_break_item(last)
                    self._set_fbp_sync_status(
                        f"salvati {saved_points} punti su {len(saved_paths)} file",
                        tone="ok",
                        path=last,
                    )

            return saved_points, saved_paths

    def _batch_write_fbp_from_memory_exports(
            self,
            exports: dict[Path, dict[str, object]],
            *,
            batch_mode: bool = True,
            async_write: bool = True,
            on_complete: Callable[[list[Path], list[Path], int], None] | None = None,
        ) -> tuple[int, list[Path], list[Path]]:
            """Aggiorna su disco solo le righe .fbp modificate (template in memoria)."""
            if not exports:
                return 0, [], []
            saved_paths: list[Path] = []
            failed_paths: list[Path] = []
            saved_points = 0
            linked_refresh = False
            dirty_files: list[dict[str, str]] = []

            with perf_section(
                "auto_fix_reciprocal.persist.prepare_disk_payload",
                n_files=len(exports),
            ):
                for fbp_path_raw, payload in exports.items():
                    fbp_path = Path(fbp_path_raw)
                    try:
                        ref = float(payload["shot_abs_ref_ms"])
                    except (KeyError, TypeError, ValueError):
                        continue
                    if not math.isfinite(ref):
                        continue
                    changed_traces = payload.get("changed_traces")
                    if not isinstance(changed_traces, dict) or not changed_traces:
                        continue
                    linked = self._fbp_is_linked_to_open_sgy(fbp_path)
                    samples = dict(payload.get("samples_by_trace") or {})
                    use_stream = self.stream is not None and linked
                    disk_lines = payload.get("fbp_disk_lines")
                    line_by_trace = payload.get("fbp_line_by_trace")
                    wrote = False

                    if (
                        isinstance(disk_lines, list)
                        and disk_lines
                        and isinstance(line_by_trace, dict)
                        and line_by_trace
                    ):
                        n_traces = int(payload.get("n_traces") or 0)
                        if n_traces <= 0:
                            n_traces = max(len(disk_lines), max(int(tr) for tr in changed_traces) + 1)
                        disk_lines = normalize_fbp_disk_lines(disk_lines, n_traces=n_traces)
                        file_dirty = False
                        for tr_i, y_f in changed_traces.items():
                            y_val = float(y_f)
                            if not math.isfinite(y_val):
                                continue
                            tr_i = int(tr_i)
                            if tr_i < 0 or tr_i >= len(disk_lines):
                                continue
                            abs_ms = ref + y_val
                            if use_stream:
                                sample_idx = self._samples_from_time(tr_i, abs_ms)
                            else:
                                sample_idx = samples.get(tr_i, 0)
                            channel_no = self._break_channel_number(tr_i)
                            time_txt = self._format_fbp_time_ms(abs_ms)
                            new_line = f"{channel_no}\t{time_txt}\t{int(sample_idx)}"
                            if disk_lines[tr_i] != new_line:
                                disk_lines[tr_i] = new_line
                                file_dirty = True
                                saved_points += 1
                            if linked:
                                self._arrival_markers[tr_i] = abs_ms
                                self._arrival_base_times[tr_i] = max(0.0, abs_ms)
                                linked_refresh = True
                        if not file_dirty:
                            continue
                        dirty_files.append(
                            {
                                "path": str(fbp_path),
                                "content": "\n".join(disk_lines) + "\n",
                            }
                        )
                        wrote = True
                    else:
                        # Nessun template: leggi il file esistente e fondi le modifiche
                        # (non riscrivere solo le tracce cambiate — cancellerebbe gli altri pick).
                        n_traces = int(payload.get("n_traces") or 0)
                        existing_lines: list[str] = []
                        if fbp_path.exists():
                            try:
                                existing_lines = fbp_path.read_text(
                                    encoding="utf-8", errors="replace"
                                ).splitlines()
                            except Exception:
                                existing_lines = []
                        if n_traces <= 0:
                            n_traces = max(
                                len(existing_lines),
                                max(int(tr) for tr in changed_traces) + 1,
                            )
                        disk_lines = normalize_fbp_disk_lines(
                            existing_lines, n_traces=n_traces
                        )
                        for tr_i, y_f in changed_traces.items():
                            y_val = float(y_f)
                            if not math.isfinite(y_val):
                                continue
                            tr_i = int(tr_i)
                            if tr_i < 0:
                                continue
                            if tr_i >= len(disk_lines):
                                disk_lines = normalize_fbp_disk_lines(
                                    disk_lines, n_traces=tr_i + 1
                                )
                            abs_ms = ref + y_val
                            if use_stream:
                                sample_idx = self._samples_from_time(tr_i, abs_ms)
                            else:
                                sample_idx = samples.get(tr_i, 0)
                            channel_no = self._break_channel_number(tr_i)
                            time_txt = self._format_fbp_time_ms(abs_ms)
                            disk_lines[tr_i] = (
                                f"{channel_no}\t{time_txt}\t{int(sample_idx)}"
                            )
                            saved_points += 1
                            if linked:
                                self._arrival_markers[tr_i] = abs_ms
                                self._arrival_base_times[tr_i] = max(0.0, abs_ms)
                                linked_refresh = True
                        if not disk_lines:
                            continue
                        dirty_files.append(
                            {
                                "path": str(fbp_path),
                                "content": "\n".join(
                                    normalize_fbp_disk_lines(disk_lines, n_traces=n_traces)
                                )
                                + "\n",
                            }
                        )
                        wrote = True

                    if not wrote:
                        continue

            if dirty_files:
                # Mantieni i template in RAM allineati al payload in scrittura,
                # così un edit intermedio non rilegge un .fbp ancora vecchio/assente.
                win = self._fbp_velocity_window_ref()
                if win is not None:
                    for item in dirty_files:
                        fbp_path = Path(item["path"])
                        series_idx = win.find_series_index(fbp_path)
                        if series_idx is None:
                            continue
                        lines = str(item.get("content") or "").splitlines()
                        if not lines:
                            continue
                        win._store_fbp_disk_meta(
                            win._series_meta[series_idx],
                            fbp_disk_lines=lines,
                            fbp_line_by_trace={i: i for i in range(len(lines))},
                            fbp_n_traces=len(lines),
                        )
                with perf_section(
                    "auto_fix_reciprocal.persist.disk_write_blocking",
                    n_files=len(dirty_files),
                ):
                    if async_write and self._write_fbp_batch_async(
                        dirty_files,
                        on_complete=(
                            None
                            if on_complete is None
                            else lambda saved, failed: on_complete(
                                saved, failed, int(saved_points)
                            )
                        ),
                    ):
                        # Invalida solo la cache parse: i template restano fino a
                        # _finish_fbp_batch_write (dopo scrittura riuscita).
                        for item in dirty_files:
                            invalidate_fbp_parse_cache(Path(item["path"]))
                        return -1, [], []
                    saved_paths, failed_paths = self._write_fbp_batch_blocking(
                        dirty_files
                    )
                for fbp_path in saved_paths:
                    invalidate_fbp_parse_cache(fbp_path)
                    if win is not None:
                        series_idx = win.find_series_index(fbp_path)
                        if series_idx is not None:
                            m = win._series_meta[series_idx]
                            m.pop("fbp_disk_lines", None)
                            m.pop("fbp_line_by_trace", None)

            if linked_refresh and self.stream is not None:
                self._clear_break_zone_gain_display()
                self._rebuild_arrival_overlay()

            if saved_paths and not batch_mode:
                last = saved_paths[-1]
                self._active_fbp_path = last
                self._last_monitor_edit_path = last
                self._highlight_break_item(last)
            if saved_paths:
                status_tone = "ok"
                status_msg = (
                    f"salvati {saved_points} punti su {len(saved_paths)} file"
                )
                if failed_paths:
                    status_tone = "warn"
                    status_msg += f" ({len(failed_paths)} errori)"
                self._set_fbp_sync_status(
                    status_msg,
                    tone=status_tone,
                    path=saved_paths[-1],
                )
            elif failed_paths:
                self._set_fbp_sync_status(
                    f"errore salvataggio su {len(failed_paths)} file .fbp",
                    tone="error",
                    path=failed_paths[-1],
                )

            return saved_points, saved_paths, failed_paths

    def _try_patch_fbp_via_monitor_memory(
            self,
            fbp_path: Path,
            trace_idx: int,
            time_rel_ms: float,
        ) -> tuple[bool, float]:
            """Salva un pick dal monitor scrivendo subito il .fbp (senza worker)."""
            win = self._fbp_velocity_window_ref()
            if win is None:
                return False, 0.0
            series_idx = win.find_series_index(fbp_path)
            if series_idx is None:
                return False, 0.0
            meta = win._series_meta[series_idx]
            try:
                win._ensure_fbp_disk_template(meta, fbp_path)
            except Exception:
                pass
            raw_ref = meta.get("shot_abs_ref_ms")
            try:
                ref = float(raw_ref) if raw_ref is not None else float("nan")
            except (TypeError, ValueError):
                ref = float("nan")
            if not math.isfinite(ref):
                self._ensure_shot_registry_loaded(fbp_path)
                converted = fbp_relative_to_absolute_ms(
                    fbp_path,
                    time_rel_ms,
                    registry=getattr(self, "_shot_registry", None) or {},
                )
                if converted is None:
                    new_abs = max(0.0, float(time_rel_ms))
                else:
                    new_abs = float(converted)
            else:
                new_abs = float(ref) + float(time_rel_ms)
            disk_lines = self._resolve_fbp_disk_lines_for_write(fbp_path, meta)
            if not disk_lines:
                return False, 0.0
            meta["fbp_disk_lines"] = disk_lines
            line_by_trace = meta.get("fbp_line_by_trace")
            if not isinstance(line_by_trace, dict):
                line_by_trace = _fbp_line_by_trace_from_lines(disk_lines)
            line_idx = self._lookup_fbp_line_index(
                disk_lines,
                trace_idx,
                line_by_trace,
            )
            row = (
                str(disk_lines[line_idx]).strip()
                if 0 <= line_idx < len(disk_lines)
                else ""
            )
            parts = row.split() if row else []
            samples = meta.get("fbp_samples")
            if not isinstance(samples, dict):
                samples = {}
            linked = self._fbp_is_linked_to_open_sgy(fbp_path)
            if linked and self.stream is not None and 0 <= int(trace_idx) < len(self.stream):
                sample_idx = self._samples_from_time(int(trace_idx), new_abs)
            else:
                sample_idx = samples.get(int(trace_idx), 0)
                if not sample_idx and len(parts) >= 3:
                    try:
                        sample_idx = int(float(parts[2].replace(",", ".")))
                    except Exception:
                        sample_idx = 0
            channel_no = self._break_channel_number(int(trace_idx))
            time_txt = self._format_fbp_time_ms(new_abs)
            new_line = f"{channel_no}\t{time_txt}\t{int(sample_idx)}"
            disk_lines, line_by_trace, line_idx = self._upsert_fbp_trace_line(
                list(disk_lines), int(trace_idx), new_line, line_by_trace
            )
            if not self._write_fbp_text(fbp_path, disk_lines):
                return False, 0.0
            invalidate_fbp_parse_cache(fbp_path)
            samples[int(trace_idx)] = int(sample_idx)
            win._store_fbp_disk_meta(
                meta,
                shot_abs_ref_ms=ref if math.isfinite(ref) else None,
                fbp_samples=samples,
                fbp_disk_lines=disk_lines,
                fbp_line_by_trace=line_by_trace,
            )
            return True, float(new_abs)

    def _fbp_files_in_folder(self, folder: Path) -> list[Path]:
        return sorted(
            (
                p
                for p in folder.iterdir()
                if p.is_file() and is_fbp_file(p)
            ),
            key=lambda p: natural_sort_key(p.name),
        )

    def _rebuild_shot_registry(
            self,
            fbp_paths: list[Path] | None = None,
        ) -> dict[str, int]:
            folder = getattr(self, "_current_folder", None)
            if folder is None or not folder.exists():
                self._shot_registry = {}
                return {}
            if fbp_paths is None:
                fbp_paths = self._fbp_files_in_folder(folder)
            auto_registry = build_shot_registry_for_folder(
                folder,
                list(fbp_paths),
            )
            merged = dict(auto_registry)
            overrides = getattr(self, "_shot_registry_overrides", None) or {}
            merged.update(overrides)
            self._shot_registry = merged
            session = getattr(self, "_viewer_session", None)
            if session is not None:
                session.set_shared_shot_registry(self._shot_registry)
            return self._shot_registry

    def _ensure_shot_registry_loaded(self, fbp_path: Path | None = None) -> None:
        """Aggiorna il registry shot in memoria (nessun file nella cartella dati)."""
        folder = getattr(self, "_current_folder", None)
        if folder is None or not folder.exists():
            self._shot_registry = {}
            return
        registry = getattr(self, "_shot_registry", None) or {}
        needs_refresh = not registry
        if fbp_path is not None and fbp_path.parent == folder:
            key = _fbp_registry_key(fbp_path.name)
            if key not in registry:
                needs_refresh = True
        if not needs_refresh:
            return
        try:
            self._rebuild_shot_registry()
        except Exception:
            self._shot_registry = registry

    def _open_shot_registry_editor(self) -> None:
        folder = getattr(self, "_current_folder", None)
        if folder is None or not folder.exists():
            QtWidgets.QMessageBox.information(
                self,
                "Editor degli shot",
                "Seleziona prima una cartella dati con file .fbp.",
            )
            return
        fbp_paths = self._fbp_files_in_folder(folder)
        if not fbp_paths:
            QtWidgets.QMessageBox.information(
                self,
                "Editor degli shot",
                "Nessun file .fbp nella cartella dati.",
            )
            return
        self._rebuild_shot_registry(fbp_paths)
        registry = dict(getattr(self, "_shot_registry", {}) or {})
        overrides = dict(getattr(self, "_shot_registry_overrides", {}) or {})
        rows: list[ShotRegistryRow] = []
        for fbp_path in fbp_paths:
            key = _fbp_registry_key(fbp_path.name)
            detected = detect_shot_from_fbp_path(fbp_path)
            auto_channel = (
                int(detected.shot_channel)
                if detected is not None and detected.is_valid
                else 0
            )
            effective_channel = int(registry.get(key, 0) or auto_channel)
            rows.append(
                ShotRegistryRow(
                    path=fbp_path,
                    auto_channel=auto_channel,
                    effective_channel=effective_channel,
                    is_override=key in overrides,
                )
            )
        new_overrides = run_shot_registry_editor_dialog(self, rows)
        if new_overrides is None:
            return
        self._shot_registry_overrides = dict(new_overrides)
        self._rebuild_shot_registry(fbp_paths)
        session = getattr(self, "_viewer_session", None)
        if session is not None:
            session.set_shared_shot_registry_overrides(self._shot_registry_overrides)
        self._refresh_monitor_after_shot_registry_edit()

    def _refresh_monitor_after_shot_registry_edit(self) -> None:
        session = getattr(self, "_viewer_session", None)
        if session is not None:
            session.set_shared_shot_registry(dict(self._shot_registry))
        win = self._fbp_velocity_window_ref()
        if win is not None:
            for meta in list(win._series_meta):
                source = meta.get("source_path")
                if source is None:
                    continue
                fbp_path = Path(source)
                if (
                    self._fbp_is_linked_to_open_sgy(fbp_path)
                    and self._is_active_fbp(fbp_path)
                    and self._arrival_markers
                ):
                    self._sync_monitor_series_from_markers(fbp_path)
                else:
                    self._refresh_monitor_series_from_fbp_file(fbp_path)
            win.schedule_dromocrona_grid_refresh(immediate=False)
        self._refresh_morphology_map_shot_highlights()

    def _export_dromocrona_grid_excel(self) -> None:
        monitor = self._fbp_velocity_window_ref()
        grid_win = (
            getattr(monitor, "_dromocrona_grid_window", None) if monitor is not None else None
        )
        if grid_win is not None:
            grid_win.export_excel(parent=self)
            return

        if monitor is None or not getattr(monitor, "_series_meta", None):
            QtWidgets.QMessageBox.information(
                self,
                "Esporta griglia dromocrone",
                "Apri il monitor dromocrone e carica i file .fbp prima di esportare.",
            )
            return

        folder = getattr(self, "_current_folder", None)
        if folder is not None:
            self._rebuild_shot_registry()
        shot_registry = getattr(self, "_shot_registry", None) or {}
        try:
            series_meta = list(monitor._series_meta)
        except Exception:
            series_meta = []
        grid = build_dromocrona_grid_data(series_meta, shot_registry=shot_registry)
        if not grid.column_labels:
            QtWidgets.QMessageBox.information(
                self,
                "Esporta griglia dromocrone",
                "Nessuna dromocrona da esportare.",
            )
            return

        run_dromocrona_grid_export_dialog(
            self,
            grid,
            folder=folder,
        )

    def _export_absolute_times_excel(self) -> None:
        monitor = self._fbp_velocity_window_ref()
        if monitor is None or not getattr(monitor, "_series_meta", None):
            QtWidgets.QMessageBox.information(
                self,
                "Esporta tempi assoluti FBP",
                "Apri il monitor dromocrone e carica i file .fbp prima di esportare.",
            )
            return

        folder = getattr(self, "_current_folder", None)
        if folder is not None:
            self._rebuild_shot_registry()
        shot_registry = getattr(self, "_shot_registry", None) or {}
        try:
            series_meta = list(monitor._series_meta)
        except Exception:
            series_meta = []

        grid = build_dromocrona_absolute_grid_data(series_meta, shot_registry=shot_registry)
        if not grid.column_labels:
            QtWidgets.QMessageBox.information(
                self,
                "Esporta tempi assoluti FBP",
                "Nessuna dromocrona da esportare.",
            )
            return

        run_absolute_times_export_dialog(
            self,
            grid,
            folder=folder,
        )

    def _export_velocity_morphology_file(self) -> None:
        self._flush_open_fbp_if_dirty()
        morph = getattr(self._session_owner_window(), "_line_morphology", None)
        if not morphology_has_velocity_export(morph):
            QtWidgets.QMessageBox.information(
                self,
                "Esporta file velocità",
                "Carica prima la morfologia della linea (Excel o JSON) "
                "e apri il monitor dromocrone con i file .fbp.",
            )
            return

        monitor = self._fbp_velocity_window_ref()
        if monitor is None or not getattr(monitor, "_series_meta", None):
            QtWidgets.QMessageBox.information(
                self,
                "Esporta file velocità",
                "Apri il monitor dromocrone e carica i file .fbp prima di esportare.",
            )
            return

        folder = getattr(self, "_current_folder", None)
        if folder is not None:
            self._rebuild_shot_registry()
        shot_registry = getattr(self, "_shot_registry", None) or {}
        try:
            series_meta = list(monitor._series_meta)
        except Exception:
            series_meta = []
        grid = build_dromocrona_grid_data(series_meta, shot_registry=shot_registry)
        if not grid.column_labels:
            QtWidgets.QMessageBox.information(
                self,
                "Esporta file velocità",
                "Nessuna dromocrona da esportare.",
            )
            return

        default_name = suggested_velocity_export_filename(
            morph, folder=folder, extension=".geo"
        )
        initial = str(folder / default_name) if folder is not None else default_name
        path_str, selected_filter = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Esporta file velocità",
            initial,
            "File GEO (*.geo);;Excel (*.xlsx);;Testo (*.txt);;Tutti i file (*.*)",
        )
        if not path_str:
            return
        output_path = Path(path_str)
        suffix = output_path.suffix.lower()
        if not suffix:
            if "Excel" in str(selected_filter):
                suffix = ".xlsx"
            elif "Testo" in str(selected_filter):
                suffix = ".txt"
            else:
                suffix = ".geo"
            output_path = output_path.with_suffix(suffix)
        elif suffix not in {".xlsx", ".geo", ".txt"}:
            output_path = output_path.with_suffix(".geo")
        try:
            export_velocity_morphology_file(output_path, morph, grid)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(
                self,
                "Esporta file velocità",
                str(exc),
            )
            return
        QtWidgets.QMessageBox.information(
            self,
            "Esporta file velocità",
            f"File salvato:\n{output_path}",
        )

    def _registry_shot_channel_for_fbp(self, fbp_path: Path) -> int:
        registry = getattr(self, "_shot_registry", None) or {}
        return registry_shot_channel_for_fbp(fbp_path, registry)

    def _refresh_monitor_series_from_fbp_file(self, fbp_path: Path) -> bool:
        win = self._fbp_velocity_window_ref()
        if win is None or win.is_drag_active():
            return False
        self._ensure_shot_registry_loaded(fbp_path)
        profile = self._velocity_profile_for_fbp(fbp_path)
        if profile is None:
            return False
        x_vals, time_ms_rel, shot_trace_idx, shot_channel = profile
        registry_shot_channel = self._registry_shot_channel_for_fbp(fbp_path)
        shot_ref, n_traces, samples = fbp_disk_export_meta(fbp_path)
        if win.set_series_profile(
            fbp_path,
            x_vals,
            time_ms_rel,
            fit_range=False,
            shot_trace_idx=shot_trace_idx,
            shot_channel=shot_channel,
            registry_shot_channel=registry_shot_channel,
            shot_abs_ref_ms=shot_ref,
            fbp_n_traces=n_traces,
            fbp_samples=samples,
        ):
            return True
        win.append_series(
            x_vals,
            time_ms_rel,
            fbp_path,
            fbp_path.stem,
            sgy_path=self._find_seismogram_for_fbp(fbp_path),
            fit_view=False,
            shot_trace_idx=shot_trace_idx,
            shot_channel=shot_channel,
            registry_shot_channel=registry_shot_channel,
            shot_abs_ref_ms=shot_ref,
            fbp_n_traces=n_traces,
            fbp_samples=samples,
        )
        win.refresh_line_morphology_ui(fit_view=False)
        win.schedule_dromocrona_grid_refresh()
        return True

    def _fbp_line_count(self, path: Path) -> int:
        try:
            return len(path.read_text(encoding="utf-8", errors="replace").splitlines())
        except Exception:
            return 0

    def _read_fbp_sample_column(self, path: Path) -> dict[int, int]:
        samples: dict[int, int] = {}
        try:
            for line_no, raw in enumerate(
                path.read_text(encoding="utf-8", errors="replace").splitlines()
            ):
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                if len(parts) < 2:
                    continue
                sample_token = parts[2] if len(parts) >= 3 else parts[1]
                try:
                    trace_idx = line_no
                    if len(parts) >= 3:
                        channel_no = int(float(parts[0].replace(",", ".")))
                        if channel_no > 0:
                            trace_idx = channel_no - 1
                    samples[trace_idx] = int(float(sample_token.replace(",", ".")))
                except ValueError:
                    continue
        except Exception:
            _LOG.warning("Lettura colonna campioni .fbp fallita: %s", path, exc_info=True)
        return samples

    def _parse_fbp_row(
            self,
            raw: str,
            line_no: int,
            trace_shift: int = 0,
            *,
            n_traces: int | None = None,
            data_line_no: int | None = None,
        ) -> tuple[int, float] | None:
            return parse_fbp_row(
                raw,
                line_no,
                trace_shift,
                n_traces=n_traces,
                stream=self.stream,
                data_line_no=data_line_no,
            )

    def _apply_fbp_markers_from_file(self, path: Path, trace_shift: int = 0) -> bool:
        if not path.exists():
            return False
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return False
        markers: dict[int, float] = {}
        base_times: dict[int, float] = {}
        lines = text.splitlines()
        n_traces = len(self.stream) if self.stream is not None else None
        data_line_no = 0
        for line_no, raw in enumerate(lines):
            parsed = self._parse_fbp_row(
                raw,
                line_no,
                trace_shift,
                n_traces=n_traces,
                data_line_no=data_line_no,
            )
            if parsed is None:
                continue
            shifted_idx, t_val = parsed
            markers[shifted_idx] = float(t_val)
            base_times[shifted_idx] = max(0.0, float(t_val))
            parts = raw.strip().split()
            if len(parts) < 3:
                data_line_no += 1
        # Sostituzione totale: niente residui del .fbp precedente (più lungo).
        self._clear_break_markers()
        self._arrival_markers = dict(markers)
        self._arrival_base_times = dict(base_times)
        if n_traces is not None and n_traces > 0:
            self._prune_break_markers(int(n_traces))
        return True

    def _load_breaks_from_fbp(
            self,
            path: Path,
            trace_shift: int = 0,
        ) -> None:
        if trace_shift != 0 and self.stream is None:
            QtWidgets.QMessageBox.information(
                self,
                "Spostamento tracce",
                "Per caricare un .fbp traslato serve prima un sismogramma aperto.",
            )
            return
        if not path.exists():
            QtWidgets.QMessageBox.warning(self, "File non trovato", str(path))
            return
        if not self._flush_open_fbp_if_dirty():
            QtWidgets.QMessageBox.warning(
                self,
                "Salvataggio .fbp",
                "Impossibile salvare le modifiche in memoria prima di caricare il file.",
            )
            return
        old_keys = set(self._arrival_markers.keys())
        try:
            if not self._apply_fbp_markers_from_file(path, trace_shift):
                QtWidgets.QMessageBox.critical(
                    self,
                    "Errore lettura .fbp",
                    f"Impossibile leggere:\n{path}",
                )
                return
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Errore lettura .fbp", f"{exc}")
            return
        # Pick rimossi (vecchio .fbp più lungo) devono sparire anche su disco/monitor.
        removed = old_keys - set(self._arrival_markers.keys())
        if removed or self._arrival_markers:
            dirty = set(self._arrival_markers.keys()) | removed
            if self.stream is not None and len(self.stream) > 0:
                dirty |= set(range(len(self.stream)))
            self._mark_fbp_traces_dirty(dirty)

        self._rebuild_arrival_overlay()
        if self._break_zone_gain_active:
            self._refresh_plot_with_break_gain()

        self._fbp_save_target_override = None
        paired = self._paired_fbp_path() if self.stream is not None else None
        if paired is not None:
            self._active_fbp_path = paired
            # Riscrittura completa sul .fbp del sismogramma aperto: evita che
            # un patch incrementale lasci i pick in eccesso del file precedente.
            n_traces = len(self.stream) if self.stream is not None else 0
            if n_traces <= 0 and self._arrival_markers:
                n_traces = max(self._arrival_markers.keys()) + 1
            if n_traces > 0:
                break_map = {
                    int(i): self._marker_time_for_export(int(i), float(t))
                    for i, t in self._arrival_markers.items()
                    if 0 <= int(i) < n_traces
                }
                ok, _n = self._write_fbp_from_break_map(paired, n_traces, break_map)
                if ok:
                    self._fbp_autosave_dirty_traces.clear()
                    self._fbp_monitor_dirty_traces.clear()
                    self._broadcast_fbp_changed(paired, reload_monitor=True)
                else:
                    self._set_fbp_sync_status(
                        f"break da {path.name} — scrittura su {paired.name} non riuscita",
                        tone="error",
                        path=paired,
                    )
            self._highlight_break_item(paired)
            self._sync_monitor_from_active_markers()
            self._refresh_plot_with_break_gain()
            self._set_fbp_sync_status(
                f"break da {path.name} — salvataggio su {paired.name}",
                tone="ok",
                path=paired,
            )
            return
        self._active_fbp_path = path
        self._highlight_break_item(path)
        self._set_fbp_sync_status("caricato da disco", path=path)

    def _find_seismogram_for_fbp(self, fbp_path: Path) -> Path | None:
        parent = fbp_path.parent
        if not parent.is_dir():
            return None
        stem = fbp_path.stem
        stem_lower = stem.lower()

        def _is_sgy(entry: Path) -> bool:
            return entry.is_file() and entry.suffix.lower() in self._folder_extensions

        for ext in self._folder_extensions:
            candidate = parent / f"{stem}{ext}"
            if candidate.is_file():
                return candidate

        try:
            entries = list(parent.iterdir())
        except OSError:
            return None

        for entry in entries:
            if _is_sgy(entry) and entry.stem.lower() == stem_lower:
                return entry

        suffix_matches: list[Path] = []
        for entry in entries:
            if not _is_sgy(entry):
                continue
            sgy_stem = entry.stem.lower()
            if sgy_stem == stem_lower:
                return entry
            if sgy_stem.endswith(f"_{stem_lower}") or (
                sgy_stem.endswith(stem_lower) and len(sgy_stem) > len(stem_lower)
            ):
                suffix_matches.append(entry)
        if len(suffix_matches) == 1:
            return suffix_matches[0]
        if len(suffix_matches) > 1:
            return min(suffix_matches, key=lambda p: len(p.stem))
        return None

    def _open_seismogram_with_fbp(
            self,
            sgy_path: Path,
            fbp_path: Path,
        ) -> bool:
            if not sgy_path.is_file():
                return False
            folder = sgy_path.parent
            if getattr(self, "_current_folder", None) != folder:
                self._set_folder_directory(folder)
            paired = fbp_path if fbp_path.exists() else None
            self._pending_load_followup = {
                "highlight_sgy": sgy_path,
                "highlight_fbp": fbp_path if fbp_path.exists() else None,
            }
            return self._load_file_from_disk(
                sgy_path,
                paired_fbp=paired,
            )

    def _on_dromocrona_monitor_series_selected(
            self, fbp_path: Path, sgy_path: Path | None = None
        ) -> None:
            """Apre nel viewer principale il sismogramma associato al .fbp cliccato."""
            if sgy_path is None:
                sgy_path = self._find_seismogram_for_fbp(fbp_path)
            if sgy_path is None:
                QtWidgets.QMessageBox.information(
                    self,
                    "Sismogramma non trovato",
                    f"Nessun file sismogramma associato a:\n{fbp_path.name}",
                )
                return
            loaded = getattr(self, "loaded_path", None)
            active_fbp = getattr(self, "_active_fbp_path", None)
            if (
                loaded is not None
                and self._same_path(loaded, sgy_path)
                and active_fbp is not None
                and self._same_path(active_fbp, fbp_path)
            ):
                self._highlight_folder_item(sgy_path)
                self._highlight_break_item(fbp_path)
                self._set_fbp_sync_status("caricato da disco")
                return
            if not self._open_seismogram_with_fbp(sgy_path, fbp_path):
                QtWidgets.QMessageBox.warning(
                    self,
                    "Errore caricamento",
                    f"Impossibile aprire il sismogramma:\n{sgy_path.name}",
                )

    def _open_dromocrona_monitor(self) -> None:
        folder = getattr(self, "_current_folder", None)
        if folder is None or not folder.exists():
            QtWidgets.QMessageBox.information(
                self,
                "Cartella dati",
                "Seleziona prima una cartella con file .fbp.",
            )
            return
        try:
            selected = self._selected_break_path()
            if selected is not None:
                self._load_breaks_from_fbp(selected, trace_shift=0)
                self._highlight_break_item(selected)
            self._refresh_fbp_velocity_from_folder(show_window=True)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(
                self,
                "Monitor dromocrone",
                f"Errore apertura monitor dromocrone:\n{exc}",
            )

    def _repair_corrupted_fbp_in_current_folder(self) -> None:
        """Ripara tutti i .fbp con canali duplicati / placeholder 0 nella cartella aperta."""
        if not self._flush_open_fbp_if_dirty():
            return
        folder = getattr(self, "_current_folder", None)
        if folder is None or not folder.exists():
            QtWidgets.QMessageBox.information(
                self,
                "Ripara .fbp",
                "Seleziona prima una cartella con file .fbp.",
            )
            return
        repaired, scanned = repair_corrupted_fbp_files_in_folder(folder)
        if repaired == 0:
            QtWidgets.QMessageBox.information(
                self,
                "Ripara .fbp",
                f"Nessun file corrotto trovato tra {scanned} .fbp in:\n{folder}",
            )
            return
        self._set_fbp_sync_status(
            f"riparati {repaired} / {scanned} file .fbp",
            tone="ok",
        )
        win = self._fbp_velocity_window_ref()
        if win is not None:
            for p in folder.iterdir():
                if not (p.is_file() and is_fbp_file(p)):
                    continue
                series_idx = win.find_series_index(p)
                if series_idx is None:
                    continue
                m = win._series_meta[series_idx]
                m.pop("fbp_disk_lines", None)
                m.pop("fbp_line_by_trace", None)
            self._refresh_fbp_velocity_from_folder(show_window=win.isVisible(), force=True)
        QtWidgets.QMessageBox.information(
            self,
            "Ripara .fbp",
            f"Riparati {repaired} file .fbp su {scanned} esaminati in:\n{folder}\n\n"
            "I duplicati e i placeholder con canale 0 sono stati rimossi.",
        )

    def _reset_fbp_velocity_monitor(self) -> None:
        win = self._fbp_velocity_window_ref()
        if win is not None:
            win.clear_series()

    def _ensure_fbp_velocity_window(self) -> FbpVelocityMonitorWindow:
        from fbp_monitor import FbpVelocityMonitorWindow

        owner = self._session_owner_window()
        if owner is not self:
            return owner._ensure_fbp_velocity_window()
        win = getattr(self, "_fbp_velocity_window", None)
        if win is None:
            # parent=None: finestra top-level → minimize nella taskbar Windows
            # (con parent=sismogramma resta una titlebar fluttuante a metà schermo).
            win = FbpVelocityMonitorWindow(
                parent=None,
                on_point_moved=self._update_fbp_time_point,
                on_drag_finished=self._on_fbp_monitor_drag_finished,
                on_series_activated=self._on_dromocrona_monitor_series_selected,
                get_folder=lambda: getattr(self, "_current_folder", None),
                on_shot_registry_changed=lambda: self._refresh_fbp_velocity_from_folder(
                    show_window=True,
                    force=True,
                ),
                on_export_dromocrona_grid=self._export_dromocrona_grid_excel,
                get_shot_registry=lambda: dict(
                    getattr(self._session_owner_window(), "_shot_registry", {}) or {}
                ),
                get_line_morphology=lambda: getattr(
                    self._session_owner_window(), "_line_morphology", None
                ),
            )
            icon = self.windowIcon()
            if icon is not None and not icon.isNull():
                win.setWindowIcon(icon)
            self._fbp_velocity_window = win
        self._rewire_fbp_monitor_callbacks()
        win.set_gui_worker(getattr(self, "_gui_worker", None))
        win.refresh_line_morphology_ui()
        return win

    def _on_fbp_monitor_drag_finished(self) -> None:
        target = (
            getattr(self, "_last_monitor_edit_path", None)
            or getattr(self, "_active_fbp_path", None)
        )
        if target is not None:
            # Il monitor ha già i tempi in RAM: un reload da disco azzerebbe
            # la cache reciproci e ritarderebbe (o perderebbe) l'aggiornamento FAIL.
            self._broadcast_fbp_changed(target, reload_monitor=False)
        if (
            self._open_fbp_has_unsaved_changes()
            and getattr(self, "_fbp_autosync_enabled", True)
        ):
            self._flush_active_fbp_to_disk(force=False)

    def _refresh_monitor_after_batch_fbp_edits(
            self,
            fbp_paths: list[Path],
            *,
            reload_from_disk: bool = True,
            refresh_ui: bool = True,
        ) -> None:
        unique_paths = list(dict.fromkeys(Path(p) for p in fbp_paths if p is not None))
        if not unique_paths:
            return
        win = self._fbp_velocity_window_ref()
        if win is not None and win.is_drag_active():
            return
        if not reload_from_disk:
            if refresh_ui and win is not None:
                win.schedule_dromocrona_grid_refresh(immediate=False)
            return
        for fbp_path in unique_paths:
            invalidate_fbp_parse_cache(fbp_path)
        grid_refresh_scheduled = False
        for fbp_path in unique_paths:
            profile = self._velocity_profile_for_fbp(fbp_path)
            if profile is None or win is None:
                continue
            x_vals, time_ms_rel, shot_trace_idx, shot_channel = profile
            registry_shot_channel = self._registry_shot_channel_for_fbp(fbp_path)
            shot_ref, n_traces, samples = fbp_disk_export_meta(fbp_path)
            if win.set_series_profile(
                fbp_path,
                x_vals,
                time_ms_rel,
                fit_range=False,
                shot_trace_idx=shot_trace_idx,
                shot_channel=shot_channel,
                registry_shot_channel=registry_shot_channel,
                shot_abs_ref_ms=shot_ref,
                fbp_n_traces=n_traces,
                fbp_samples=samples,
            ):
                grid_refresh_scheduled = True
            else:
                win.append_series(
                    x_vals,
                    time_ms_rel,
                    fbp_path,
                    fbp_path.stem,
                    sgy_path=self._find_seismogram_for_fbp(fbp_path),
                    fit_view=False,
                    shot_trace_idx=shot_trace_idx,
                    shot_channel=shot_channel,
                    registry_shot_channel=registry_shot_channel,
                    shot_abs_ref_ms=shot_ref,
                    fbp_n_traces=n_traces,
                    fbp_samples=samples,
                )
                grid_refresh_scheduled = True
        if win is not None:
            win.refresh_line_morphology_ui(fit_view=False)
            if grid_refresh_scheduled:
                win.schedule_dromocrona_grid_refresh()
        for fbp_path in unique_paths:
            self._broadcast_fbp_changed(fbp_path)

    def _on_fbp_autosync_toggled(self, checked: bool) -> None:
        self._fbp_autosync_enabled = bool(checked)
        if self._fbp_autosync_enabled:
            self._update_fbp_memory_status()
            if not self._open_fbp_has_unsaved_changes():
                self._set_fbp_sync_status(
                    "sincronizzazione live attiva — salvataggio su disco al cambio file",
                    tone="ok",
                )
            self._on_seismogram_markers_changed(update_status=True, immediate_sync=True)
        else:
            timer = getattr(self, "_deferred_monitor_sync_timer", None)
            if timer is not None:
                timer.stop()
            grid_timer = getattr(self, "_deferred_grid_refresh_timer", None)
            if grid_timer is not None:
                grid_timer.stop()
            self._set_fbp_sync_status(
                "sincronizzazione live disattivata — break in memoria, niente aggiornamenti monitor",
                tone="warn",
            )

    def _set_fbp_sync_status(
            self,
            message: str,
            *,
            tone: str = "muted",
            path: Path | None = None,
        ) -> None:
            label = getattr(self, "fbp_sync_status_label", None)
            if label is None:
                return
            styles = {
                "muted": "color: #b0b3b8",
                "ok": "color: #86efac; font-weight: 600",
                "warn": "color: #fcd34d; font-weight: 600",
                "error": "color: #fca5a5; font-weight: 600",
                "saving": "color: #93c5fd",
            }
            label.setStyleSheet(
                f"{styles.get(tone, styles['muted'])}; font-size: 11px;"
            )
            active = path if path is not None else getattr(self, "_active_fbp_path", None)
            suffix = f"\n{active.name}" if active is not None else ""
            label.setText(f"Sinc: {message}{suffix}")

    def _fbp_save_path_for_seismogram(self) -> Path | None:
        """File .fbp su cui scrivere i break editati sul sismogramma aperto."""
        loaded = getattr(self, "loaded_path", None)
        if loaded is None or self.stream is None:
            return None
        return default_fbp_path_for_seismogram(loaded)

    def _ensure_active_fbp_path(self) -> Path | None:
        override = getattr(self, "_fbp_save_target_override", None)
        if override is not None:
            self._active_fbp_path = override
            return override
        paired = self._fbp_save_path_for_seismogram()
        if paired is not None:
            self._active_fbp_path = paired
            return paired
        active = getattr(self, "_active_fbp_path", None)
        if active is not None:
            return active
        loaded = getattr(self, "loaded_path", None)
        if loaded is not None:
            self._active_fbp_path = default_fbp_path_for_seismogram(loaded)
            return self._active_fbp_path
        selected = self._selected_break_path()
        if selected is not None:
            self._active_fbp_path = selected
            return self._active_fbp_path
        return None

    def _should_sync_dromocrona_monitor(self) -> bool:
        if not getattr(self, "_fbp_autosync_enabled", True):
            return False
        win = self._fbp_velocity_window_ref()
        return win is not None and win.isVisible()

    def _sync_monitor_from_memory_now(self) -> None:
        """Allinea il monitor ai break in memoria senza scrivere su disco."""
        if not self._arrival_markers:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Nessun break in memoria da sincronizzare",
                self,
                QtCore.QRect(),
                2000,
            )
            return
        win = self._fbp_velocity_window_ref()
        if win is None or not win.isVisible():
            QtWidgets.QMessageBox.information(
                self,
                "Monitor dromocrona",
                "Apri il monitor dromocrona prima di sincronizzare.",
            )
            return
        timer = getattr(self, "_deferred_monitor_sync_timer", None)
        if timer is not None:
            timer.stop()
        self._sync_monitor_from_active_markers()
        self._schedule_deferred_monitor_grid_refresh(immediate=True, force=True)
        path = self._ensure_active_fbp_path()
        self._set_fbp_sync_status(
            "monitor aggiornato da memoria (disco invariato)",
            tone="ok",
            path=path,
        )

    def _schedule_monitor_sync_from_markers(self, *, immediate: bool = False) -> None:
        """Accorpa aggiornamenti rapidi della dromocrona (evita freeze a ogni pick)."""
        if not self._should_sync_dromocrona_monitor():
            return
        if getattr(self, "_fbp_folder_import_busy", False) and not immediate:
            return
        timer = getattr(self, "_deferred_monitor_sync_timer", None)
        if immediate or timer is None:
            if timer is not None:
                timer.stop()
            self._sync_monitor_from_active_markers()
            return
        timer.start()

    def _break_gesture_in_progress(self) -> bool:
        return bool(
            getattr(self, "_break_right_gesture_active", False)
            or getattr(self, "_hover_break_nudge_active", False)
            or getattr(self, "_shift_breaks_gesture_active", False)
        )

    def _abort_break_gestures_keep_markers(self) -> None:
        """Chiude ogni gesto break senza schedule sync/salvataggio."""
        any_active = self._break_gesture_in_progress()
        self._break_right_gesture_active = False
        self._hover_break_nudge_active = False
        self._shift_breaks_gesture_active = False
        self._last_right_track = None
        self._last_right_y = None
        self._break_undo_pushed_this_gesture = False
        try:
            self._break_ov_throttle_timer.stop()
        except Exception:
            pass
        self._break_ov_deferred = False
        self._set_trace_scene_cache(False)
        if any_active and self._arrival_markers:
            self._rebuild_arrival_overlay()

    def _finish_any_break_gesture(self) -> None:
        """Chiude i gesti aperti e sincronizza monitor/FBP a fine gesto."""
        if getattr(self, "_break_right_gesture_active", False):
            self._finish_right_break_gesture()
        if getattr(self, "_hover_break_nudge_active", False):
            self._finish_hover_break_nudge_gesture()
        if getattr(self, "_shift_breaks_gesture_active", False):
            self._finish_shift_breaks_gesture()

    def _flush_deferred_monitor_sync(self) -> None:
        if self._break_gesture_in_progress():
            self._schedule_monitor_sync_from_markers()
            return
        self._sync_monitor_from_active_markers()

    def _sync_monitor_from_active_markers(self) -> bool:
        """Aggiorna subito la dromocrona collegata al sismogramma aperto."""
        if not self._should_sync_dromocrona_monitor():
            return False
        path = self._ensure_active_fbp_path()
        if path is None:
            return False
        if not self._arrival_markers:
            win = self._fbp_velocity_window_ref()
            if win is None:
                return False
            win.clear_series_breaks(path)
            self._fbp_monitor_dirty_traces.clear()
            self._schedule_deferred_monitor_grid_refresh()
            return True
        self._sync_dromocrona_monitor_if_open(path)
        return True

    def _sync_dromocrona_monitor_if_open(self, fbp_path: Path) -> None:
        if not self._should_sync_dromocrona_monitor():
            return
        # Preferisci sempre i break in RAM del sismogramma aperto.
        if (
            self._fbp_is_linked_to_open_sgy(fbp_path)
            and self._is_active_fbp(fbp_path)
            and self._arrival_markers
            and self._sync_monitor_series_from_markers(fbp_path)
        ):
            return
        # Fallback disco solo se non abbiamo marker in memoria per questo .fbp.
        if self._is_active_fbp(fbp_path) and self._arrival_markers:
            return
        self._refresh_monitor_series_from_fbp_file(fbp_path)

    def _open_fbp_has_unsaved_changes(self) -> bool:
        if self._ensure_active_fbp_path() is None:
            return False
        return bool(self._fbp_autosave_dirty_traces)

    def _flush_open_fbp_if_dirty(self) -> bool:
        """Salva il .fbp del sismogramma aperto prima di leggere altri .fbp da disco."""
        if not self._open_fbp_has_unsaved_changes():
            return True
        self._finish_any_break_gesture()
        return self._flush_active_fbp_to_disk(force=True)

    def _update_fbp_memory_status(self) -> None:
        path = self._ensure_active_fbp_path()
        if path is None or not self._arrival_markers:
            return
        if self._open_fbp_has_unsaved_changes():
            self._set_fbp_sync_status(
                "modifiche in memoria — dromo da RAM, .fbp in salvataggio differito",
                tone="warn",
                path=path,
            )
        else:
            self._set_fbp_sync_status("allineato al disco", tone="ok", path=path)

    def _schedule_deferred_monitor_grid_refresh(
        self, *, immediate: bool = False, force: bool = False
    ) -> None:
        """Griglia/reciproci solo dopo una pausa (evita lavoro a ogni singolo break)."""
        if not force and not getattr(self, "_fbp_autosync_enabled", True):
            return
        if getattr(self, "_fbp_folder_import_busy", False) and not immediate:
            return
        win = self._fbp_velocity_window_ref()
        if win is None:
            return
        timer = getattr(self, "_deferred_grid_refresh_timer", None)
        # Durante il gesto break non ricalcolare FAIL/griglia: costa davvero con 400+ canali.
        if self._break_gesture_in_progress() and not immediate:
            if timer is not None:
                timer.start()
            return
        if immediate or timer is None:
            if timer is not None:
                timer.stop()
            win.schedule_dromocrona_grid_refresh(immediate=immediate)
            return
        # IMPORTANTE: anche con reciproci/griglia aperti si deve debounceare.
        # Prima `reciproci_on` forzava un refresh a ogni sync e bloccava il viewer.
        timer.start()

    def _flush_deferred_monitor_grid_refresh(self) -> None:
        if self._break_gesture_in_progress():
            self._schedule_deferred_monitor_grid_refresh()
            return
        win = self._fbp_velocity_window_ref()
        if win is None:
            return
        if not win._dromocrona_grid_refresh_wanted() and not win._reciprocals_compute_wanted():
            return
        win.schedule_dromocrona_grid_refresh(immediate=False)

    def _mark_fbp_traces_dirty(self, indices) -> None:
        for idx in indices:
            tr = int(idx)
            self._fbp_autosave_dirty_traces.add(tr)
            self._fbp_monitor_dirty_traces.add(tr)

    def _mark_all_fbp_traces_dirty(self) -> None:
        # Include anche le tracce senza pick: così un patch azzera i residui
        # di un .fbp precedente più lungo.
        if self.stream is not None and len(self.stream) > 0:
            self._mark_fbp_traces_dirty(range(len(self.stream)))
        else:
            self._mark_fbp_traces_dirty(self._arrival_markers.keys())

    def _on_seismogram_markers_changed(
        self, *, update_status: bool = False, immediate_sync: bool = False
    ) -> None:
        """Dopo modifica break: sync monitor da memoria (senza autosave timer)."""
        if self._break_gesture_in_progress() and not immediate_sync:
            if update_status:
                self._update_fbp_memory_status()
            return
        self._schedule_monitor_sync_from_markers(immediate=immediate_sync)
        if update_status:
            self._update_fbp_memory_status()

    def _sync_monitor_after_break_gesture(self) -> None:
        # Solo memoria: niente write/read .fbp qui (è quello che frezza il viewer).
        self._schedule_monitor_sync_from_markers(immediate=True)
        self._schedule_deferred_monitor_grid_refresh(immediate=False)
        self._update_fbp_memory_status()
        self._schedule_deferred_fbp_disk_flush()

    def _schedule_deferred_fbp_disk_flush(self) -> None:
        """Accoda la scrittura .fbp: il monitor resta aggiornato dalla RAM."""
        if not getattr(self, "_fbp_autosync_enabled", True):
            return
        if not self._open_fbp_has_unsaved_changes():
            return
        timer = getattr(self, "_deferred_fbp_disk_timer", None)
        if timer is None:
            self._flush_active_fbp_to_disk(force=False)
            return
        path = self._ensure_active_fbp_path()
        self._set_fbp_sync_status(
            "in memoria — salvataggio .fbp in pausa…",
            tone="warn",
            path=path,
        )
        timer.start()

    def _flush_deferred_fbp_disk(self) -> None:
        if self._break_gesture_in_progress():
            self._schedule_deferred_fbp_disk_flush()
            return
        if getattr(self, "_fbp_folder_import_busy", False):
            self._schedule_deferred_fbp_disk_flush()
            return
        if not self._open_fbp_has_unsaved_changes():
            return
        self._flush_active_fbp_to_disk(force=False, prefer_async=True)

    def _sync_monitor_series_from_markers(self, fbp_path: Path) -> bool:
        """Aggiorna la dromocrona nel monitor dai marker in memoria (no reload disco)."""
        win = self._fbp_velocity_window_ref()
        if win is None or win.is_drag_active():
            return False
        if not self._fbp_is_linked_to_open_sgy(fbp_path) or not self._is_active_fbp(fbp_path):
            return False
        dirty = {int(tr) for tr in (getattr(self, "_fbp_monitor_dirty_traces", set()) or ())}
        series_idx = win.find_series_index(fbp_path)
        deleted_dirty = {tr for tr in dirty if tr not in self._arrival_markers}
        updated_dirty = {tr for tr in dirty if tr in self._arrival_markers}
        if series_idx is not None and dirty:
            meta = win._series_meta[series_idx]
            registry_shot = self._registry_shot_channel_for_fbp(fbp_path)
            shot_tr = (
                int(registry_shot) - 1
                if registry_shot > 0
                else int(meta.get("shot_trace_idx", -1))
            )
            shot_touched = shot_tr >= 0 and shot_tr in dirty
            if not shot_touched:
                removed = False
                updated = False
                need_full_rebuild = False
                if deleted_dirty:
                    removed = bool(win.remove_series_traces(fbp_path, deleted_dirty))
                if updated_dirty:
                    rel_updates = self._marker_relative_y_updates(
                        fbp_path, updated_dirty, shot_trace_idx=shot_tr
                    )
                    if not rel_updates:
                        # Pick più precoce del ref (o shot spostato): rebuild
                        # completo invece di pinare a y=0.
                        need_full_rebuild = True
                    else:
                        updated = bool(
                            win.apply_trace_y_updates(
                                fbp_path,
                                rel_updates,
                                defer_reciprocal_patch=True,
                            )
                        )
                if (
                    not need_full_rebuild
                    and (
                        removed
                        or updated
                        or (deleted_dirty and not updated_dirty)
                    )
                ):
                    # Non ricalcolare shot_abs_ref_ms: la curva in RAM è già
                    # relativa a quel riferimento. Sovrascriverlo senza
                    # ribuild farebbe scendere sottozero i punti aggiornati.
                    self._patch_monitor_disk_lines_from_markers(fbp_path, dirty)
                    self._fbp_monitor_dirty_traces.difference_update(dirty)
                    self._schedule_deferred_monitor_grid_refresh()
                    return True
        profile = self._velocity_profile_from_markers(fbp_path)
        if profile is None:
            return False
        x_vals, time_ms_rel, shot_trace_idx, shot_channel = profile
        registry_shot_channel = self._registry_shot_channel_for_fbp(fbp_path)
        series_idx = win.find_series_index(fbp_path)
        shot_ref: float | None = None
        n_traces: int | None = None
        samples: dict[int, int] | None = None
        if series_idx is not None:
            meta = win._series_meta[series_idx]
            raw_n = meta.get("fbp_n_traces")
            if raw_n is not None and int(raw_n) > 0:
                n_traces = int(raw_n)
            raw_samples = meta.get("fbp_samples")
            if isinstance(raw_samples, dict):
                samples = {int(k): int(v) for k, v in raw_samples.items()}
        n_limit = len(self.stream) if self.stream is not None else None
        idx_sorted = sorted(
            idx
            for idx in self._arrival_markers.keys()
            if idx >= 0 and (n_limit is None or idx < n_limit)
        )
        if idx_sorted:
            times_ms = [
                self._marker_time_for_export(i, float(self._arrival_markers[i]))
                for i in idx_sorted
            ]
            # Zero display = minimo assoluto (allineato a build_relative_profile).
            # Non usare lo shot di registro se è più tardi: y relativi incoerenti.
            if int(shot_trace_idx) in self._arrival_markers:
                shot_ref = self._marker_time_for_export(
                    int(shot_trace_idx),
                    float(self._arrival_markers[int(shot_trace_idx)]),
                )
            else:
                shot_ref = float(min(times_ms))
            # Safety: ref non può superare il minimo dei pick (evita y pinate a 0).
            min_abs = float(min(times_ms))
            if shot_ref is None or float(shot_ref) > min_abs + 0.05:
                shot_ref = min_abs
        if n_traces is None or n_traces <= 0:
            n_traces = len(self.stream) if self.stream is not None else 0
            if n_traces <= 0 and self._arrival_markers:
                n_traces = max(self._arrival_markers.keys()) + 1
        if win.set_series_profile(
            fbp_path,
            x_vals,
            time_ms_rel,
            fit_range=False,
            shot_trace_idx=shot_trace_idx,
            shot_channel=shot_channel,
            registry_shot_channel=registry_shot_channel,
            shot_abs_ref_ms=shot_ref,
            fbp_n_traces=n_traces,
            fbp_samples=samples,
            schedule_grid_refresh=False,
            invalidate_reciprocals=False,
        ):
            self._patch_monitor_disk_lines_from_markers(
                fbp_path,
                self._fbp_autosave_dirty_traces or None,
            )
            self._fbp_monitor_dirty_traces.clear()
            self._schedule_deferred_monitor_grid_refresh()
            return True
        win.append_series(
            x_vals,
            time_ms_rel,
            fbp_path,
            fbp_path.stem,
            sgy_path=self._find_seismogram_for_fbp(fbp_path),
            fit_view=False,
            shot_trace_idx=shot_trace_idx,
            shot_channel=shot_channel,
            registry_shot_channel=registry_shot_channel,
            shot_abs_ref_ms=shot_ref,
            fbp_n_traces=n_traces,
            fbp_samples=samples,
        )
        self._patch_monitor_disk_lines_from_markers(
            fbp_path,
            self._fbp_autosave_dirty_traces or None,
        )
        self._fbp_monitor_dirty_traces.clear()
        win.refresh_line_morphology_ui(fit_view=False)
        self._schedule_deferred_monitor_grid_refresh()
        return True

    def _patch_monitor_disk_lines_from_markers(
            self,
            fbp_path: Path,
            trace_indices: set[int] | None = None,
        ) -> None:
        """Mantiene il template .fbp in memoria allineato ai marker (solo tracce modificate)."""
        win = self._fbp_velocity_window_ref()
        if win is None:
            return
        series_idx = win.find_series_index(fbp_path)
        if series_idx is None:
            return
        meta = win._series_meta[series_idx]
        if not win._ensure_fbp_disk_template(meta, fbp_path):
            return
        disk_lines = meta.get("fbp_disk_lines")
        line_by_trace = meta.get("fbp_line_by_trace")
        samples = meta.get("fbp_samples")
        if not isinstance(disk_lines, list) or not disk_lines:
            return
        if not isinstance(line_by_trace, dict):
            return
        if not isinstance(samples, dict):
            samples = {}
        linked = self._fbp_is_linked_to_open_sgy(fbp_path)
        use_stream = self.stream is not None and linked
        targets = (
            trace_indices
            if trace_indices is not None
            else set(self._arrival_markers.keys())
        )
        for tr_i in targets:
            if tr_i not in self._arrival_markers:
                zero_line = fbp_missing_pick_line(int(tr_i))
                disk_lines, line_by_trace, _line_idx = self._upsert_fbp_trace_line(
                    disk_lines, int(tr_i), zero_line, line_by_trace
                )
                continue
            abs_ms = self._marker_time_for_export(
                tr_i, float(self._arrival_markers[tr_i])
            )
            if use_stream:
                sample_idx = self._samples_from_time(tr_i, abs_ms)
                samples[tr_i] = int(sample_idx)
            else:
                sample_idx = samples.get(tr_i, 0)
            channel_no = self._break_channel_number(tr_i)
            time_txt = self._format_fbp_time_ms(abs_ms)
            new_line = f"{channel_no}\t{time_txt}\t{int(sample_idx)}"
            disk_lines, line_by_trace, _line_idx = self._upsert_fbp_trace_line(
                disk_lines, int(tr_i), new_line, line_by_trace
            )
        win._store_fbp_disk_meta(
            meta,
            fbp_samples=samples,
            fbp_disk_lines=disk_lines,
            fbp_line_by_trace=line_by_trace,
        )

    def _try_patch_markers_to_fbp_disk(
        self, path: Path, *, write: bool = True
    ) -> bool | None:
        """Scrittura incrementale .fbp; None se serve riscrittura completa.

        Con write=False prepara il payload in ``_fbp_pending_disk_payload``
        senza toccare il disco (per flush async sul worker).
        """
        dirty = set(self._fbp_autosave_dirty_traces)
        if not dirty:
            if not path.exists() and self._arrival_markers:
                return None
            return True
        if not path.exists():
            return None

        win = self._fbp_velocity_window_ref()
        series_idx = win.find_series_index(path) if win is not None else None
        meta = (
            win._series_meta[series_idx]
            if win is not None and series_idx is not None
            else None
        )
        disk_lines: list[str] | None = None
        line_by_trace: dict[int, int] = {}
        samples: dict[int, int] = {}
        if meta is not None:
            if not win._ensure_fbp_disk_template(meta, path):
                return None
            raw_lines = meta.get("fbp_disk_lines")
            if isinstance(raw_lines, list) and raw_lines:
                disk_lines = list(raw_lines)
            raw_map = meta.get("fbp_line_by_trace")
            if isinstance(raw_map, dict):
                line_by_trace = {int(k): int(v) for k, v in raw_map.items()}
            raw_samples = meta.get("fbp_samples")
            if isinstance(raw_samples, dict):
                samples = {int(k): int(v) for k, v in raw_samples.items()}
        if disk_lines is None:
            try:
                disk_lines = path.read_text(
                    encoding="utf-8", errors="replace"
                ).splitlines()
            except Exception:
                return None
            if not disk_lines:
                return None
            line_by_trace = _fbp_line_by_trace_from_lines(disk_lines)

        n_traces = self._fbp_target_n_traces(path)
        if n_traces <= 0:
            n_traces = max(len(disk_lines), max(dirty) + 1 if dirty else 0)
        if fbp_lines_have_corruption(disk_lines) or len(disk_lines) != n_traces:
            disk_lines = normalize_fbp_disk_lines(disk_lines, n_traces=n_traces)
            line_by_trace = {i: i for i in range(len(disk_lines))}
            file_dirty = True
        else:
            file_dirty = False

        linked = self._fbp_is_linked_to_open_sgy(path)
        use_stream = self.stream is not None and linked
        processed: set[int] = set()
        for tr_i in sorted(dirty):
            tr = int(tr_i)
            if tr not in self._arrival_markers:
                zero_line = fbp_missing_pick_line(tr)
                before = list(disk_lines)
                disk_lines, line_by_trace, _line_idx = self._upsert_fbp_trace_line(
                    list(disk_lines),
                    tr,
                    zero_line,
                    line_by_trace,
                    n_traces=n_traces,
                )
                if disk_lines != before:
                    file_dirty = True
                processed.add(tr)
                continue
            abs_ms = self._marker_time_for_export(
                tr, float(self._arrival_markers[tr])
            )
            line_idx = self._lookup_fbp_line_index(disk_lines, tr, line_by_trace)
            row = (
                str(disk_lines[line_idx]).strip()
                if 0 <= line_idx < len(disk_lines)
                else ""
            )
            parts = row.split() if row else []
            if use_stream:
                sample_idx = self._samples_from_time(tr, abs_ms)
                samples[tr] = int(sample_idx)
            else:
                sample_idx = samples.get(tr, 0)
                if not sample_idx and len(parts) >= 3:
                    try:
                        sample_idx = int(float(parts[2].replace(",", ".")))
                    except Exception:
                        sample_idx = 0
            channel_no = self._break_channel_number(tr)
            time_txt = self._format_fbp_time_ms(abs_ms)
            new_line = f"{channel_no}\t{time_txt}\t{int(sample_idx)}"
            before = list(disk_lines)
            disk_lines, line_by_trace, _line_idx = self._upsert_fbp_trace_line(
                list(disk_lines),
                tr,
                new_line,
                line_by_trace,
                n_traces=n_traces,
            )
            if disk_lines != before:
                file_dirty = True
            processed.add(tr)

        if processed:
            file_dirty = True

        if file_dirty:
            normalized = normalize_fbp_disk_lines(disk_lines, n_traces=n_traces)
            if not write:
                self._fbp_pending_disk_payload = {
                    "path": path,
                    "content": "\n".join(normalized) + "\n",
                    "n_traces": int(n_traces),
                    "samples": dict(samples),
                    "processed": set(processed),
                    "series_idx": series_idx,
                }
                return True
            if not self._write_fbp_text(path, disk_lines, n_traces=n_traces):
                _LOG.warning(
                    "Scrittura .fbp fallita (%s) — modifiche non salvate su disco", path
                )
                return False
            invalidate_fbp_parse_cache(path)
            if meta is not None and win is not None:
                win._store_fbp_disk_meta(
                    meta,
                    fbp_samples=samples,
                    fbp_disk_lines=normalized,
                    fbp_line_by_trace={i: i for i in range(n_traces)},
                    fbp_n_traces=n_traces,
                )
        elif not write:
            self._fbp_pending_disk_payload = None
        self._fbp_autosave_dirty_traces.difference_update(processed)
        if self._fbp_autosave_dirty_traces:
            return None
        return True

    def _flush_active_fbp_to_disk(
        self, *, force: bool = False, prefer_async: bool = False
    ) -> bool:
        if not force and not getattr(self, "_fbp_autosync_enabled", True):
            return True
        if self._break_gesture_in_progress() and not force:
            return True
        if force and self._break_gesture_in_progress():
            self._abort_break_gestures_keep_markers()
        win = self._fbp_velocity_window_ref()
        if win is not None and win.is_drag_active() and not force:
            self._set_fbp_sync_status(
                "salvataggio in attesa (drag monitor dromocrone)…",
                tone="warn",
            )
            return True
        path = self._ensure_active_fbp_path()
        if not self._arrival_markers and not self._fbp_autosave_dirty_traces:
            return True
        if path is None:
            if self._arrival_markers or self._fbp_autosave_dirty_traces:
                self._set_fbp_sync_status(
                    "nessun file .fbp di destinazione",
                    tone="error",
                )
                return False
            return True
        if prefer_async and not force:
            return self._flush_active_fbp_to_disk_async(path)
        self._set_fbp_sync_status("salvataggio in corso…", tone="saving", path=path)
        if not self._write_markers_to_fbp_path(path, refresh_monitor=False):
            self._set_fbp_sync_status("errore salvataggio", tone="error", path=path)
            return False
        self._active_fbp_path = path
        self._fbp_autosave_dirty_traces.clear()
        # Il monitor ha già i tempi dalla RAM: non rileggere il .fbp e non
        # rifare sync/griglia subito dopo la scrittura (freeze sul viewer).
        self._broadcast_fbp_changed(path, reload_monitor=False)
        self._set_fbp_sync_status("salvato su disco", tone="ok", path=path)
        return True

    def _flush_active_fbp_to_disk_async(self, path: Path) -> bool:
        """Prepara il .fbp in RAM e scrive sul worker (niente I/O sulla GUI)."""
        if getattr(self, "_fbp_async_disk_flush_busy", False):
            self._schedule_deferred_fbp_disk_flush()
            return True
        self._fbp_pending_disk_payload = None
        patched = self._try_patch_markers_to_fbp_disk(path, write=False)
        payload = getattr(self, "_fbp_pending_disk_payload", None)
        if patched is True and payload is None:
            # Niente da scrivere (già allineato).
            self._fbp_autosave_dirty_traces.clear()
            self._set_fbp_sync_status("salvato su disco", tone="ok", path=path)
            return True
        if patched is False:
            self._set_fbp_sync_status("errore salvataggio", tone="error", path=path)
            return False
        if payload is None:
            # Serve riscrittura completa: costruisci contenuto e invia al worker.
            lines = self._build_fbp_lines_from_markers(path)
            if not lines:
                return self._flush_active_fbp_to_disk(force=False, prefer_async=False)
            payload = {
                "path": path,
                "content": "\n".join(lines) + "\n",
                "n_traces": len(lines),
                "samples": {},
                "processed": set(self._fbp_autosave_dirty_traces),
                "series_idx": None,
                "full_rewrite": True,
            }
        write_path = Path(payload["path"])
        content = str(payload["content"])
        processed = set(payload.get("processed") or ())
        series_idx = payload.get("series_idx")
        samples = dict(payload.get("samples") or {})
        n_traces = int(payload.get("n_traces") or 0)
        full_rewrite = bool(payload.get("full_rewrite"))
        self._fbp_pending_disk_payload = None

        def _on_done(saved: list[Path], failed: list[Path]) -> None:
            self._fbp_async_disk_flush_busy = False
            if failed or not saved:
                self._set_fbp_sync_status(
                    "errore salvataggio", tone="error", path=write_path
                )
                self._schedule_deferred_fbp_disk_flush()
                return
            invalidate_fbp_parse_cache(write_path)
            win = self._fbp_velocity_window_ref()
            if win is not None:
                idx = (
                    int(series_idx)
                    if series_idx is not None
                    else win.find_series_index(write_path)
                )
                if idx is not None and 0 <= idx < len(win._series_meta):
                    meta = win._series_meta[idx]
                    if full_rewrite:
                        meta.pop("fbp_disk_lines", None)
                        meta.pop("fbp_line_by_trace", None)
                    else:
                        lines = content.splitlines()
                        win._store_fbp_disk_meta(
                            meta,
                            fbp_samples=samples,
                            fbp_disk_lines=lines,
                            fbp_line_by_trace={i: i for i in range(len(lines))},
                            fbp_n_traces=n_traces or len(lines),
                        )
            self._fbp_autosave_dirty_traces.difference_update(processed)
            self._active_fbp_path = write_path
            self._broadcast_fbp_changed(write_path, reload_monitor=False)
            if self._fbp_autosave_dirty_traces:
                self._set_fbp_sync_status(
                    "in memoria — salvataggio .fbp in pausa…",
                    tone="warn",
                    path=write_path,
                )
                self._schedule_deferred_fbp_disk_flush()
            else:
                self._set_fbp_sync_status(
                    "salvato su disco", tone="ok", path=write_path
                )

        self._fbp_async_disk_flush_busy = True
        self._set_fbp_sync_status("salvataggio in corso…", tone="saving", path=write_path)
        submitted = self._write_fbp_batch_async(
            [{"path": str(write_path), "content": content}],
            on_complete=_on_done,
        )
        if submitted:
            return True
        # Hub assente: on_complete già eseguito in sync da _write_fbp_batch_async.
        if not getattr(self, "_fbp_async_disk_flush_busy", False):
            return True
        self._fbp_async_disk_flush_busy = False
        return self._flush_active_fbp_to_disk(force=False, prefer_async=False)

    def _velocity_profile_from_markers(
            self, fbp_path: Path
        ) -> tuple[np.ndarray, np.ndarray, int, int] | None:
            if not self._arrival_markers:
                return None
            n_limit = len(self.stream) if self.stream is not None else None
            idx_sorted = sorted(
                idx
                for idx in self._arrival_markers.keys()
                if idx >= 0 and (n_limit is None or idx < n_limit)
            )
            if not idx_sorted:
                return None
            times_ms = np.array(
                [self._marker_time_for_export(i, float(self._arrival_markers[i])) for i in idx_sorted],
                dtype=np.float64,
            )
            registry = getattr(self, "_shot_registry", None) or {}
            registry_shot = registry_shot_channel_for_fbp(fbp_path, registry)
            if registry_shot > 0:
                shot_trace_idx = int(registry_shot) - 1
            else:
                shot_trace_idx = int(idx_sorted[int(np.argmin(times_ms))])
            if len(idx_sorted) == 1:
                x = np.array([float(idx_sorted[0])], dtype=np.float64)
                y_rel = np.array([0.0], dtype=np.float64)
                shot_channel = int(shot_trace_idx) + 1
                return x, y_rel, int(shot_trace_idx), shot_channel
            built = build_relative_profile(
                idx_sorted,
                times_ms,
                shot_trace_idx=shot_trace_idx,
            )
            if built is None:
                return None
            x, y_rel, shot_trace_idx = built
            shot_channel = int(shot_trace_idx) + 1
            return x, y_rel, int(shot_trace_idx), shot_channel

    def _monitor_shot_abs_ref_ms(self, fbp_path: Path) -> float | None:
        """Riferimento assoluto già usato dalla dromocrona in RAM (ms)."""
        win = self._fbp_velocity_window_ref()
        if win is None:
            return None
        series_idx = win.find_series_index(fbp_path)
        if series_idx is None:
            return None
        raw_ref = win._series_meta[series_idx].get("shot_abs_ref_ms")
        try:
            ref = float(raw_ref) if raw_ref is not None else float("nan")
        except (TypeError, ValueError):
            return None
        if not math.isfinite(ref):
            return None
        return float(ref)

    def _marker_relative_y_updates(
        self,
        fbp_path: Path,
        trace_indices: set[int] | frozenset[int],
        *,
        shot_trace_idx: int | None = None,
    ) -> dict[int, float]:
        """Tempi relativi per sync parziale. Se abs < ref → {} (forza rebuild).

        Non clampare a 0 i pick precoci: creerebbe falsi punti sulla linea shot
        nella fascia negativa del grafico.
        """
        wanted = {int(tr) for tr in trace_indices}
        if not wanted:
            return {}
        if shot_trace_idx is None:
            registry_shot = self._registry_shot_channel_for_fbp(fbp_path)
            if registry_shot > 0:
                shot_trace_idx = int(registry_shot) - 1
        shot_tr = int(shot_trace_idx) if shot_trace_idx is not None else None
        # Stesso zero della curva già disegnata, non il tempo shot dei marker
        # (può differire di decine di ms dal minimo copia-incolla del .fbp).
        stored_ref = self._monitor_shot_abs_ref_ms(fbp_path)
        if stored_ref is not None:
            updates: dict[int, float] = {}
            for tr in wanted:
                if tr not in self._arrival_markers:
                    continue
                abs_ms = self._marker_time_for_export(
                    tr, float(self._arrival_markers[tr])
                )
                if shot_tr is not None and tr == shot_tr:
                    # Shot spostato rispetto al ref in RAM → rebuild completo.
                    if abs(float(abs_ms) - float(stored_ref)) > 0.05:
                        return {}
                    updates[tr] = 0.0
                    continue
                rel = float(abs_ms) - float(stored_ref)
                # Pick più precoce del ref: clamp-to-0 nasconde il bug e mette
                # il punto a y=0 nella fascia sottozero. Forza rebase.
                if rel < -0.05:
                    return {}
                updates[tr] = max(0.0, rel)
            if updates:
                return updates
        profile = self._velocity_profile_from_markers(fbp_path)
        if profile is None:
            return {}
        x_vals, time_ms_rel, _, _ = profile
        wanted = {int(tr) for tr in trace_indices}
        updates = {}
        for idx in range(int(x_vals.size)):
            tr = int(x_vals[idx])
            if tr in wanted:
                updates[tr] = max(0.0, float(time_ms_rel[idx]))
        return updates

    def _velocity_profile_for_fbp(
            self,
            fbp_path: Path,
        ) -> tuple[np.ndarray, np.ndarray, int, int] | None:
            self._ensure_shot_registry_loaded(fbp_path)
            # Marker in memoria solo per il .fbp collegato al sismogramma aperto.
            if (
                self._fbp_is_linked_to_open_sgy(fbp_path)
                and self._is_active_fbp(fbp_path)
                and self._arrival_markers
            ):
                profile = self._velocity_profile_from_markers(fbp_path)
                if profile is not None:
                    return profile
            return self._velocity_profile_from_fbp_path(fbp_path)

    def _sync_fbp_monitor_series(self, fbp_path: Path) -> bool:
        win = self._fbp_velocity_window_ref()
        if win is None:
            return False
        if win.is_drag_active():
            return False
        if (
            self._fbp_is_linked_to_open_sgy(fbp_path)
            and self._is_active_fbp(fbp_path)
            and self._arrival_markers
            and self._sync_monitor_series_from_markers(fbp_path)
        ):
            return True
        return self._refresh_monitor_series_from_fbp_file(fbp_path)

    def _velocity_profile_from_fbp_path(
            self,
            fbp_path: Path,
        ) -> tuple[np.ndarray, np.ndarray, int, int] | None:
            self._flush_open_fbp_if_dirty()
            registry = getattr(self, "_shot_registry", None)
            loaded = load_fbp_relative_profile(fbp_path, registry=registry)
            if loaded is None:
                return None
            x, y_rel, shot = loaded
            return x, y_rel, int(shot.shot_trace_idx), int(shot.shot_channel)

    def _show_fbp_monitor_window(self, win: FbpVelocityMonitorWindow) -> None:
        win.set_gui_worker(getattr(self, "_gui_worker", None))
        win.refresh_line_morphology_ui()
        self._bring_fbp_monitor_to_front(win)

    def _refresh_fbp_velocity_from_folder(self, *, show_window: bool, force: bool = False) -> None:
        owner = self._session_owner_window()
        if self is not owner:
            return
        if not self._flush_open_fbp_if_dirty():
            return
        folder = getattr(owner, "_current_folder", None)
        if folder is None or not folder.exists():
            owner._fbp_monitor_loaded_folder = None
            win = self._fbp_velocity_window_ref()
            if win is not None:
                self._reset_fbp_velocity_monitor()
            return
        pending_ctx = getattr(owner, "_pending_fbp_folder_ctx", None)
        if pending_ctx and show_window:
            ctx_folder = pending_ctx.get("folder")
            if ctx_folder is not None and self._same_path(Path(ctx_folder), folder):
                pending_ctx["show_window"] = True
                if not pending_ctx.get("show_loading"):
                    total = int(pending_ctx.get("total_work") or 0)
                    if total > 0:
                        pending_ctx["show_loading"] = True
                        self._show_dromocrona_loading(
                            "Caricamento monitor dromocrone…",
                            detail=f"{total} file .fbp",
                        )
                return
        win = self._fbp_velocity_window_ref()
        if not force and self._fbp_monitor_folder_reload_busy():
            return
        if not force and self._fbp_monitor_already_loaded_for_folder(folder, win=win):
            if show_window and win is not None:
                self._show_fbp_monitor_window(win)
                active = getattr(owner, "_active_fbp_path", None)
                if active is not None:
                    self._sync_fbp_monitor_series(active)
            return
        if win is None:
            if not show_window:
                self._ensure_fbp_velocity_window()
                win = self._fbp_velocity_window_ref()
            else:
                win = self._ensure_fbp_velocity_window()
        if win is None:
            return
        if show_window:
            self._bring_fbp_monitor_to_front(win)
        if not force and win.is_drag_active():
            return
        fbp_files = sorted(
            (p for p in folder.iterdir() if p.is_file() and is_fbp_file(p)),
            key=lambda p: natural_sort_key(p.name),
        )
        active = getattr(self, "_active_fbp_path", None)
        extra_active = bool(
            active is not None
            and active.exists()
            and not any(self._same_path(active, p) for p in fbp_files)
        )
        total_work = len(fbp_files) + (1 if extra_active else 0)
        show_loading = bool(total_work) and show_window
        if show_loading:
            self._show_dromocrona_loading(
                "Caricamento monitor dromocrone…",
                detail=f"{total_work} file .fbp",
            )
        worker = getattr(self, "_gui_worker", None)
        if worker is None:
            if show_loading:
                self._hide_dromocrona_loading()
            QtWidgets.QMessageBox.warning(
                self,
                "Monitor dromocrone",
                "Caricamento in background non disponibile.",
            )
            return
        win.set_gui_worker(worker)
        self._pending_fbp_folder_ctx = {
            "win": win,
            "show_window": show_window,
            "show_loading": show_loading,
            "folder": folder,
            "total_work": total_work,
        }
        payload = {
            "folder": str(folder),
            "fbp_paths": [str(p) for p in fbp_files],
            "extra_active": str(active) if extra_active and active is not None else None,
        }
        self._gui_worker.submit("load_fbp_folder", payload)

    def _update_fbp_time_point(
            self,
            fbp_path: Path,
            trace_idx: int,
            time_rel_ms: float,
            *,
            refresh_monitor: bool = True,
        ) -> bool:
            if trace_idx < 0:
                return False
            ok, new_abs = self._try_patch_fbp_via_monitor_memory(
                fbp_path, trace_idx, time_rel_ms
            )
            if not ok:
                ok, new_abs = self._patch_fbp_trace_in_file(
                    fbp_path, trace_idx, time_rel_ms
                )
            if not ok:
                self._set_fbp_sync_status(
                    f"errore salvataggio: {fbp_path.name}",
                    tone="error",
                    path=fbp_path,
                )
                return False
            try:
                self._active_fbp_path = fbp_path
                self._last_monitor_edit_path = fbp_path
                if self._fbp_is_linked_to_open_sgy(fbp_path):
                    self._arrival_markers[trace_idx] = new_abs
                    self._arrival_base_times[trace_idx] = max(0.0, new_abs)
                    if self.stream is not None:
                        self._clear_break_zone_gain_display()
                        self._rebuild_arrival_overlay()
                self._highlight_break_item(fbp_path)
                if refresh_monitor:
                    self._refresh_monitor_series_from_fbp_file(fbp_path)
                self._set_fbp_sync_status("salvato su disco", tone="ok", path=fbp_path)
            except Exception:
                _LOG.exception(
                    "UI dopo salvataggio break (%s traccia %s)",
                    fbp_path.name,
                    trace_idx,
                )
            return True

    def _batch_update_fbp_time_points(
            self,
            file_updates: dict[Path, dict[int, float]],
        ) -> tuple[int, list[Path]]:
            return self._batch_patch_fbp_traces_in_files(file_updates)

    def _autosave_breaks_for_current(self) -> bool:
        """Salva sempre il .fbp attivo prima di cambiare sismogramma."""
        if not self._arrival_markers and not self._fbp_autosave_dirty_traces:
            return True
        self._abort_break_gestures_keep_markers()
        path = self._ensure_active_fbp_path()
        if path is None:
            QtWidgets.QMessageBox.warning(
                self,
                "Salvataggio .fbp",
                "Ci sono break in memoria ma non è definito un file .fbp "
                "su cui salvarli.\n\nUsa «Esporta break» o carica un .fbp associato.",
            )
            self._set_fbp_sync_status("nessun .fbp destinazione", tone="error")
            return False
        self._set_fbp_sync_status(
            "salvataggio prima del cambio file…",
            tone="saving",
            path=path,
        )
        QtWidgets.QApplication.processEvents()
        if not self._flush_active_fbp_to_disk(force=True):
            QtWidgets.QMessageBox.warning(
                self,
                "Salvataggio .fbp non riuscito",
                (
                    f"Impossibile scrivere:\n{path}\n\n"
                    "Verifica che il file non sia aperto in un altro programma "
                    "e che la cartella sia scrivibile."
                ),
            )
            return False
        folder = getattr(self, "_current_folder", None)
        if folder is not None and path.parent == folder:
            self._populate_folder_file_list(folder)
            self._highlight_break_item(path)
        self._set_fbp_sync_status(
            "salvato prima del cambio file",
            tone="ok",
            path=path,
        )
        return True

    def _export_breaks(self) -> None:
        """Formato .fbp: per ogni traccia `canale \\t tempo_ms (6 decimali) \\t campione (int)`."""
        if not self._arrival_markers:
            QtWidgets.QMessageBox.information(
                self,
                "Nessun break",
                "Inserisci almeno un break prima di esportare.",
            )
            return
        if self.loaded_path is not None:
            default_name = default_fbp_path_for_seismogram(self.loaded_path)
        elif self._active_fbp_path is not None:
            default_name = self._active_fbp_path
        else:
            default_name = Path("breaks.fbp")
        path_str, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Esporta break (.fbp)",
            str(default_name),
            "File break (*.fbp *.FBP);;Tutti i file (*.*)",
        )
        if not path_str:
            return
        path = Path(path_str)
        if path.suffix.lower() != ".fbp":
            path = path.with_suffix(DEFAULT_FBP_EXTENSION)
        if not self._confirm_save_with_missing_breaks(
            context=f"Stai per esportare i break in:\n{path}"
        ):
            return
        ok, n_lines, err = self._write_breaks_to_path(path)
        if not ok:
            QtWidgets.QMessageBox.critical(
                self,
                "Errore esportazione",
                f"Impossibile scrivere il file:\n{err}",
            )
            return
        if path.parent == getattr(self, "_current_folder", None):
            self._populate_folder_file_list(path.parent)
            self._highlight_break_item(path)
        QtWidgets.QMessageBox.information(
            self,
            "Esportazione completata",
            f"Salvati {n_lines} break in:\n{path}",
        )

    def _confirm_replace_line_morphology(self) -> bool:
        current = self._line_morphology_in_memory()
        if current is None:
            return True
        answer = QtWidgets.QMessageBox.question(
            self,
            "Sostituire morfologia?",
            (
                f"È già caricata una morfologia ({current.source_label}) "
                f"da:\n{current.source_path.name}\n\n"
                "Sostituirla con il nuovo file?"
            ),
            QtWidgets.QMessageBox.StandardButton.Yes
            | QtWidgets.QMessageBox.StandardButton.No,
            QtWidgets.QMessageBox.StandardButton.No,
        )
        return answer == QtWidgets.QMessageBox.StandardButton.Yes

    def _apply_line_morphology(
            self,
            morph: LineMorphology,
            *,
            from_session: bool = False,
            show_message: bool = True,
        ) -> None:
            self._line_morphology = morph
            win = self._fbp_velocity_window_ref()
            if win is not None:
                win.refresh_line_morphology_ui(fit_view=True)
            map_win = getattr(self, "_line_morphology_map_window", None)
            if map_win is not None and map_win.isVisible():
                map_win.set_morphology(morph)
                self._refresh_morphology_map_shot_highlights()
            if not from_session:
                session = getattr(self, "_viewer_session", None)
                if session is not None:
                    session.set_shared_line_morphology(morph, source=self)
            if not show_message:
                return
            line_txt = f", linea {morph.line_id}" if morph.line_id is not None else ""
            sheet_txt = f", foglio {morph.sheet_name}" if morph.sheet_name else ""
            QtWidgets.QMessageBox.information(
                self,
                "Morfologia caricata",
                (
                    f"Fonte: {morph.source_label}\n"
                    f"File: {morph.source_path.name}{sheet_txt}\n"
                    f"Geofoni: {morph.trace_count}{line_txt}\n"
                    f"Lunghezza: ~{morph.geophones[-1].cumulative_m:.2f} m\n"
                    f"Spaziatura Excel (mediana): ~{morph.typical_excel_spacing_m():.3f} m\n\n"
                    "Le distanze nel monitor dromocrone usano «dist pianta tot/geof» da Excel."
                ),
            )

    def _import_line_morphology_excel(self) -> None:
        initial = getattr(self, "_current_folder", None)
        path_str, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Importa morfologia linea da Excel",
            str(initial) if initial is not None else "",
            "Excel (*.xlsx *.xls);;Tutti i file (*.*)",
        )
        if not path_str:
            return
        if not self._confirm_replace_line_morphology():
            return
        path = Path(path_str)
        try:
            sheet_name = pick_line_morphology_excel_sheet(self, path)
            if sheet_name is None:
                return
            morph = load_line_morphology_excel(path, sheet_name=sheet_name)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(
                self,
                "Errore import morfologia",
                str(exc),
            )
            return
        self._apply_line_morphology(morph)

    def _import_line_morphology_json(self) -> None:
        initial = getattr(self, "_current_folder", None)
        path_str, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Importa morfologia linea da JSON",
            str(initial) if initial is not None else "",
            "JSON (*.json);;Tutti i file (*.*)",
        )
        if not path_str:
            return
        if not self._confirm_replace_line_morphology():
            return
        try:
            morph = load_line_morphology_json(Path(path_str))
        except Exception as exc:
            QtWidgets.QMessageBox.critical(
                self,
                "Errore import morfologia",
                str(exc),
            )
            return
        self._apply_line_morphology(morph)

    def _line_morphology_in_memory(self) -> LineMorphology | None:
        owner = self._session_owner_window()
        return getattr(owner, "_line_morphology", None) or getattr(
            self, "_line_morphology", None
        )

    def _clear_line_morphology(self, *, from_session: bool = False) -> None:
        current = self._line_morphology_in_memory()
        if current is None:
            if not from_session:
                self._notify_line_morphology_cleared(
                    removed_from_memory=True,
                    source_name="",
                    already_empty=True,
                )
            return
        source_name = ""
        try:
            source_name = str(current.source_path.name)
        except Exception:
            source_name = str(getattr(current, "source_label", "") or "")
        owner = self._session_owner_window()
        owner._line_morphology = None
        self._line_morphology = None
        win = self._fbp_velocity_window_ref()
        if win is not None:
            win.refresh_line_morphology_ui()
        map_win = getattr(self, "_line_morphology_map_window", None)
        if map_win is not None:
            map_win.close()
            self._line_morphology_map_window = None
        if owner is not self:
            owner_map = getattr(owner, "_line_morphology_map_window", None)
            if owner_map is not None:
                owner_map.close()
                owner._line_morphology_map_window = None
        if not from_session:
            session = getattr(self, "_viewer_session", None)
            if session is not None:
                session.clear_shared_line_morphology(source=self)
            still_in_memory = self._line_morphology_in_memory()
            monitor_still_loaded = None
            if win is not None:
                monitor_still_loaded = win._current_line_morphology()
            self._notify_line_morphology_cleared(
                removed_from_memory=(
                    still_in_memory is None and monitor_still_loaded is None
                ),
                source_name=source_name,
            )

    def _notify_line_morphology_cleared(
            self,
            *,
            removed_from_memory: bool,
            source_name: str = "",
            already_empty: bool = False,
        ) -> None:
        win = self._fbp_velocity_window_ref()
        if win is not None and (win.isVisible() or not already_empty):
            self._bring_fbp_monitor_to_front(win)
            if already_empty:
                QtWidgets.QMessageBox.information(
                    win,
                    "Morfologia linea",
                    "Nessuna morfologia in memoria.",
                )
                return
            win.notify_line_morphology_memory_status(
                removed_from_memory=removed_from_memory,
                source_name=source_name,
            )
            return
        if already_empty:
            QtWidgets.QMessageBox.information(
                self,
                "Morfologia linea",
                "Nessuna morfologia in memoria.",
            )
            return
        if removed_from_memory:
            file_txt = f"«{source_name}»" if source_name else "della linea"
            QtWidgets.QMessageBox.information(
                self,
                "Morfologia rimossa",
                f"Il file {file_txt} è stato tolto dalla memoria.",
            )
            return
        QtWidgets.QMessageBox.warning(
            self,
            "Morfologia non rimossa",
            "La morfologia risulta ancora presente in memoria.",
        )

    def _collect_shot_channels_for_map(self) -> set[int]:
        monitor = self._fbp_velocity_window_ref()
        if monitor is None:
            return set()
        series_meta = getattr(monitor, "_series_meta", None)
        if not series_meta:
            return set()
        self._rebuild_shot_registry()
        grid = build_dromocrona_grid_data(
            list(series_meta),
            shot_registry=getattr(self, "_shot_registry", None) or {},
        )
        return {int(ch) for ch in grid.shot_channels if int(ch) > 0}

    def _fbp_series_for_shot_channel(
        self, channel: int
    ) -> list[tuple[Path, Path | None]]:
        monitor = self._fbp_velocity_window_ref()
        if monitor is None:
            return []
        target = int(channel)
        matches: list[tuple[Path, Path | None]] = []
        for meta in monitor._series_meta:
            shot_ch = int(
                meta.get("registry_shot_channel") or meta.get("shot_channel") or 0
            )
            if shot_ch != target:
                continue
            source = meta.get("source_path")
            if source is None:
                continue
            fbp = Path(source)
            sgy_raw = meta.get("sgy_path")
            sgy = Path(sgy_raw) if sgy_raw else self._find_seismogram_for_fbp(fbp)
            matches.append((fbp, sgy))
        return matches

    def _pick_fbp_series_for_shot(
        self, matches: list[tuple[Path, Path | None]]
    ) -> tuple[Path, Path | None] | None:
        if not matches:
            return None
        if len(matches) == 1:
            return matches[0]
        labels = [fbp.name for fbp, _ in matches]
        label, ok = QtWidgets.QInputDialog.getItem(
            self,
            "Shot multiplo",
            "Più file .fbp usano questo shot — scegli quale aprire:",
            labels,
            0,
            False,
        )
        if not ok:
            return None
        return matches[labels.index(label)]

    def _refresh_morphology_map_shot_highlights(self) -> None:
        map_win = getattr(self, "_line_morphology_map_window", None)
        if map_win is None:
            return
        map_win.set_shot_channels(self._collect_shot_channels_for_map())

    def _on_morphology_map_geophone_clicked(self, trace_idx: int) -> None:
        morph = getattr(self, "_line_morphology", None)
        if morph is None:
            return
        geophone = morph.geophone_for_trace(trace_idx)
        if geophone is None:
            return
        channel = geophone_channel_number(geophone)
        shot_channels = self._collect_shot_channels_for_map()
        map_win = getattr(self, "_line_morphology_map_window", None)
        if not shot_channels:
            QtWidgets.QMessageBox.information(
                self,
                "Shot non disponibili",
                "Carica prima una cartella .fbp nel monitor dromocrone.",
            )
            return
        if channel not in shot_channels:
            if map_win is not None:
                map_win.set_status(
                    f"Geofono {channel} — non è uno shot nelle dromocrone caricate"
                )
            return
        matches = self._fbp_series_for_shot_channel(channel)
        if not matches:
            QtWidgets.QMessageBox.information(
                self,
                "Sismogramma non trovato",
                f"Nessun file .fbp associato allo shot geofono {channel}.",
            )
            return
        picked = self._pick_fbp_series_for_shot(matches)
        if picked is None:
            return
        fbp_path, sgy_path = picked
        self._on_dromocrona_monitor_series_selected(fbp_path, sgy_path)

    def _open_line_morphology_map(self) -> None:
        morph = getattr(self, "_line_morphology", None)
        if morph is None:
            QtWidgets.QMessageBox.information(
                self,
                "Mappa morfologia",
                "Importa prima una morfologia linea (Excel o JSON).",
            )
            return
        if not WEBENGINE_AVAILABLE:
            QtWidgets.QMessageBox.critical(
                self,
                "Mappa morfologia",
                "Serve PyQt6-WebEngine:\n\npip install PyQt6-WebEngine",
            )
            return
        try:
            morphology_geophones_wgs84(morph)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(
                self,
                "Mappa morfologia",
                str(exc),
            )
            return
        shot_channels = self._collect_shot_channels_for_map()
        map_win = getattr(self, "_line_morphology_map_window", None)
        if map_win is None:
            map_win = LineMorphologyMapWindow(
                morph, parent=None, shot_channels=shot_channels
            )
            map_win.geophone_clicked.connect(self._on_morphology_map_geophone_clicked)
            self._line_morphology_map_window = map_win
        else:
            map_win.set_morphology(morph)
            map_win.set_shot_channels(shot_channels)
        map_win.show()
        map_win.raise_()
        map_win.activateWindow()

    def _show_empty_state(self) -> None:
        self._plot_cache = None
        self._plot_time_bounds = (0.0, 1.0)
        self._cache_points_budget = None
        self._reset_view_on_plot = True
        self._time_range_full = (0.0, 1.0)
        self._hover_track_idx = None
        self._global_scale = 1.0
        self._clear_break_ruler_preview()
        self._clear_break_markers()
        self._reset_fbp_velocity_monitor()
        plot_item = self.plot_widget.getPlotItem()
        self._reset_seismogram_plot_items(plot_item, clear_empty_text=True)
        plot_item.getAxis("top").setTicks([])
        plot_item.clear()
        view_box = plot_item.getViewBox()
        view_box.setMouseEnabled(x=False, y=False)
        view_box.setLimits(yMin=0.0, yMax=1.0)
        view_box.setRange(xRange=(0, 1), yRange=(0, 1), padding=0.0)
        text = pg.TextItem(
            "Nessun sismogramma caricato\nUsa “Apri file SEG-Y/SEG-2…”",
            color="#4c566a",
            anchor=(0.5, 0.5),
        )
        text.setFont(QtWidgets.QApplication.font())
        text.setPos(0.5, 0.5)
        plot_item.addItem(text)
        self._empty_text_item = text
        self._apply_plot_chrome_style()

    def _on_fill_neg_toggled(self, checked: bool) -> None:
        """Solo i fill cambiano: riusa curve e cache (tutte le tracce, anche fuori zoom)."""
        self._wiggle_fill_on = True
        if checked:
            self._fill_positive_on = False
            self._fill_negative_on = True
        else:
            self._fill_positive_on = True
            self._fill_negative_on = False
        if not self.stream:
            return
        self._reset_view_on_plot = False
        if self._seismogram_graphics_ready(len(self.stream)):
            self._fast_visual_redraw(all_traces=True)
        else:
            self._plot_stream()
        if not getattr(self, "_trace_display_applying", False):
            self._publish_trace_display_settings()

    def _on_auto_gain_toggled(self, _checked: bool) -> None:
        """La normalizzazione è nella cache: ricostruiscila senza distruggere le curve."""
        if not self.stream:
            return
        self._reset_view_on_plot = False
        self._invalidate_plot_cache(reset_graphics=False, reset_view=False)
        self._build_plot_cache(follow_up="fast_redraw")
        if not getattr(self, "_trace_display_applying", False):
            self._publish_trace_display_settings()

    def _on_agc_enabled_toggled(self, _checked: bool) -> None:
        """Solo l'utente attiva/disattiva l'AGC; qui si aggiorna il grafico."""
        self._sync_filter_dialog_agc()
        if not getattr(self, "_trace_display_applying", False):
            self._publish_trace_display_settings()
        if not self.stream:
            return
        self._reset_view_on_plot = False
        self._invalidate_plot_cache(reset_graphics=False, reset_view=False)
        self._build_plot_cache(follow_up="fast_redraw")

    def _on_agc_window_spin_changed(self, *_args) -> None:
        if getattr(self, "_trace_display_applying", False):
            return
        self._sync_filter_dialog_agc()
        self._publish_agc_window_ms_suggestion()
        if not self.stream or not self._agc_enabled():
            return
        self._reset_view_on_plot = False
        self._invalidate_plot_cache(reset_graphics=False, reset_view=False)
        self._build_plot_cache(follow_up="fast_redraw")
        self._publish_trace_display_settings()

    def _on_gain_spin_changed(self, *_args) -> None:
        """Gain: aggiornamento veloce con curve e fill (Fase 2A: setPath)."""
        if not self.stream:
            return
        self._reset_view_on_plot = False
        cache = self._plot_cache
        items = getattr(self, "_trace_items", None)
        if (
            cache
            and items
            and len(items) == len(cache)
            and all(items[i] is not None for i in range(len(items)))
        ):
            self._sync_trace_entries_from_cache(cache)
            self._fast_visual_redraw()
        else:
            self._plot_stream()
        self._sync_trace_display_dialog_gain()
        if not getattr(self, "_trace_display_applying", False):
            self._publish_trace_display_settings()

    def _seismogram_graphics_ready(self, n_traces: int) -> bool:
        items = getattr(self, "_trace_items", None)
        if not items or n_traces <= 0 or len(items) != n_traces:
            return False
        return all(
            entry is not None and entry.get("curve") is not None for entry in items
        )

    def _sync_trace_entries_from_cache(self, cache) -> None:
        for idx, cache_entry in enumerate(cache):
            if idx >= len(self._trace_items):
                break
            trace_entry = self._trace_items[idx]
            if not trace_entry:
                continue
            trace_entry["norm"] = cache_entry["norm"]
            trace_entry["times"] = cache_entry["times"]

    def _fast_visual_redraw(self, *, all_traces: bool = False) -> None:
        """Aggiorna curve e fill senza ricreare gli item grafici.

        Di default solo le tracce in viewport (gain/pan). Con ``all_traces=True``
        aggiorna tutto il sismogramma (fill/stile: evita fill stale fuori zoom).
        """
        n_traces = len(self._trace_items or [])
        if n_traces <= 0:
            return
        visible = (
            range(n_traces)
            if all_traces
            else self._visible_trace_index_range(margin=3)
        )
        with perf_section(
            "fast_redraw.all_traces" if all_traces else "fast_redraw.visible",
            n_traces=n_traces if all_traces else len(visible),
        ):
            self._global_scale = float(self.scale_spin.value())
            plot_item = self.plot_widget.getPlotItem()
            amp_scale = self._effective_amplitude_scale()
            baseline = getattr(self, "_current_baseline", None)
            plot_w = getattr(self, "plot_widget", None)
            updates_off = False
            if plot_w is not None:
                plot_w.setUpdatesEnabled(False)
                updates_off = True
            try:
                for idx in visible:
                    if idx < 0 or idx >= n_traces:
                        continue
                    entry = self._trace_items[idx]
                    if not entry:
                        continue
                    if baseline is not None and idx < int(getattr(baseline, "size", 0)):
                        entry["baseline"] = float(baseline[idx])
                    norm = entry.get("norm")
                    times_ms = entry.get("times")
                    curve = entry.get("curve")
                    if norm is None or times_ms is None or curve is None:
                        continue
                    baseline_val = float(entry.get("baseline", 0.0))
                    trace_vals = self._display_trace_vals(norm, baseline_val, amp_scale)
                    x_plot, y_plot = self._map_unrotated_to_view(trace_vals, times_ms)
                    curve.setData(x_plot, y_plot)
                    curve.setVisible(True)
                    entry["fills"] = self._append_trace_fill_items(
                        trace_vals, times_ms, baseline_val, plot_item, entry
                    )
                    self._apply_trace_curve_style(idx)
            finally:
                if updates_off and plot_w is not None:
                    plot_w.setUpdatesEnabled(True)
                    plot_w.update()

    def _apply_spacing_factor_change(self, value: float) -> None:
        baseline_before = (
            self._current_baseline.copy() if self._current_baseline is not None else None
        )
        self._trace_spacing_factor = float(np.clip(value, 0.5, 6.0))
        if not self.stream:
            return
        if baseline_before is None or not self._trace_items:
            self._reset_view_on_plot = False
            self._plot_stream()
            return
        count = len(baseline_before)
        new_baseline = self._compute_baseline_positions(count)
        self._apply_spacing_visual_update(baseline_before, new_baseline)

    def _nudge_track_spacing(self, direction: int) -> None:
        """Modifica spaziatura tracce tramite spin."""
        if direction == 0:
            return
        spin = getattr(self, "spacing_spin", None)
        if spin is None:
            return
        step = 0.1
        new_val = float(spin.value()) + (step if direction > 0 else -step)
        new_val = float(np.clip(new_val, spin.minimum(), spin.maximum()))
        spin.setValue(new_val)

    def _effective_amplitude_scale(self) -> float:
        squeeze = float(getattr(self, "_amplitude_squeeze", 1.0) or 1.0)
        return self._global_scale * squeeze

    def _purge_path_items_under(self, root: QtWidgets.QGraphicsItem) -> None:
        """Rimuove ogni QGraphicsPathItem nel sottoalbero (fill spesso annidati)."""
        stack = list(root.childItems())
        while stack:
            ch = stack.pop()
            stack.extend(ch.childItems())
            if isinstance(ch, QtWidgets.QGraphicsPathItem):
                try:
                    sc = ch.scene()
                    if sc is not None:
                        sc.removeItem(ch)
                except Exception:
                    pass

    def _reset_seismogram_plot_items(
            self,
            plot_item: pg.PlotItem | None = None,
            *,
            clear_empty_text: bool = False,
            reset_tick_labels: bool = True,
        ) -> None:
            """Rimuove curve, fill, rette traccia e grafica orfana dal plot sismogramma."""
            if plot_item is None:
                if not hasattr(self, "plot_widget"):
                    return
                plot_item = self.plot_widget.getPlotItem()

            for entry in getattr(self, "_trace_items", None) or []:
                if not entry:
                    continue
                curve = entry.get("curve")
                if curve is not None:
                    try:
                        plot_item.removeItem(curve)
                    except Exception:
                        pass
                self._dispose_trace_fill_items(entry, plot_item)
            self._trace_items = []

            try:
                for item in list(plot_item.listDataItems()):
                    try:
                        plot_item.removeItem(item)
                    except Exception:
                        pass
            except Exception:
                pass
            self._purge_path_items_under(plot_item.vb)

            if reset_tick_labels:
                self._last_track_tick_labels = None

            if clear_empty_text:
                empty = getattr(self, "_empty_text_item", None)
                if empty is not None:
                    try:
                        plot_item.removeItem(empty)
                    except Exception:
                        pass
                    self._empty_text_item = None

    def _plot_stream(self, *, force_rebuild_graphics: bool = False) -> None:
        self._cancel_chunked_plot()
        assert self.stream is not None
        n_traces = len(self.stream)
        with perf_section(
            "plot_stream.total",
            n_traces=n_traces,
            force_rebuild=force_rebuild_graphics,
        ):
            self._plot_stream_impl(force_rebuild_graphics=force_rebuild_graphics)

    def _plot_stream_impl(self, *, force_rebuild_graphics: bool = False) -> None:
        assert self.stream is not None

        scale = float(self.scale_spin.value())
        self._global_scale = scale

        desired_budget = self._desired_points_budget(scale)
        with perf_section("plot_stream.ensure_cache"):
            cache = self._ensure_plot_cache(desired_budget)
        if not cache:
            if getattr(self, "_cache_build_in_flight", False):
                path = self.loaded_path
                if path is not None:
                    self._show_seismogram_loading(path, "Preparazione tracce…")
            else:
                self._show_empty_state()
            return

        plot_item = self.plot_widget.getPlotItem()
        view_box = plot_item.getViewBox()
        view_box.setMouseEnabled(True, True)
        plot_item.getAxis("top").show()
        prev_view = None
        if not self._reset_view_on_plot:
            try:
                prev_view = plot_item.vb.viewRange()
            except Exception:
                prev_view = None

        n_traces = len(cache)
        reuse_graphics = (
            not force_rebuild_graphics
            and self._seismogram_graphics_ready(n_traces)
        )

        hov = getattr(self, "_hover_track_idx", None)
        if hov is not None and (hov < 0 or hov >= n_traces):
            self._hover_track_idx = None

        baseline = self._baseline_for(n_traces)
        self._current_baseline = baseline

        if reuse_graphics:
            self._sync_trace_entries_from_cache(cache)
            for idx in range(n_traces):
                entry = self._trace_items[idx]
                if entry is not None:
                    entry["baseline"] = float(baseline[idx])
        else:
            with perf_section("plot_stream.reset_graphics", n_traces=n_traces):
                self._reset_seismogram_plot_items(plot_item, clear_empty_text=True)
                self._trace_items = [None] * n_traces
                for idx, entry in enumerate(cache):
                    norm = entry["norm"]
                    times_ms = entry["times"]
                    baseline_val = (
                        float(baseline[idx]) if getattr(baseline, "size", 0) else float(idx)
                    )
                    curve = pg.PlotCurveItem(pen=self._default_trace_pen)
                    self._configure_curve_item(curve)
                    curve.setVisible(False)
                    plot_item.addItem(curve)
                    self._trace_items[idx] = {
                        "curve": curve,
                        "fills": [],
                        "fill_path": None,
                        "baseline": baseline_val,
                        "norm": norm,
                        "times": times_ms,
                    }

        time_min_ms, time_max_ms = self._plot_time_bounds
        self._update_trace_offsets_and_range(cache, time_min_ms, time_max_ms)

        self._update_time_axis_ticks()
        x_lo, x_hi = self._x_axis_limits()
        vx_lo, vx_hi, vy_lo, vy_hi = self._plot_bounds_for_rotation(
            x_lo, x_hi, time_min_ms, time_max_ms
        )
        self._apply_view_limits(view_box)
        if prev_view and all(len(rng) == 2 and np.isfinite(rng).all() for rng in prev_view):
            prev_x = sorted(prev_view[0])
            x_prev = (
                max(vx_lo, float(prev_x[0])),
                min(vx_hi, float(prev_x[1])),
            )
            if x_prev[1] - x_prev[0] < 1e-3:
                x_prev = (vx_lo, min(vx_hi, vx_lo + 1.0))
            if int(getattr(self, "_view_rotation_deg", 0)) % 360 == 0:
                y_range = self._clamp_y_range(prev_view[1])
            else:
                y_prev = sorted(prev_view[1])
                y_range = (
                    max(vy_lo, float(y_prev[0])),
                    min(vy_hi, float(y_prev[1])),
                )
            view_box.setRange(xRange=x_prev, yRange=y_range, padding=0.0)
        else:
            init_x, init_y = self._initial_view_ranges(x_lo, x_hi, time_min_ms, time_max_ms)
            if int(getattr(self, "_view_rotation_deg", 0)) % 360 != 0:
                init_x = (vx_lo, vx_hi)
                init_y = (vy_lo, vy_hi)
            else:
                init_x = (max(vx_lo, init_x[0]), min(vx_hi, init_x[1]))
                if init_x[1] - init_x[0] < 1e-3:
                    init_x = (vx_lo, min(vx_hi, vx_lo + 1.0))
            view_box.setRange(
                xRange=init_x,
                yRange=init_y,
                padding=0.0,
            )
        if reuse_graphics:
            self._fast_visual_redraw()
        else:
            path = self.loaded_path
            if path is not None:
                self._show_seismogram_loading(path, "Disegno sismogramma…")
            with perf_section("plot_stream.overlay_axes"):
                self._prune_break_markers(n_traces)
                self._rebuild_arrival_overlay()
            with perf_section("plot_stream.show_traces", n_traces=len(self._trace_items)):
                self._start_chunked_show_traces()
            return
        with perf_section("plot_stream.overlay_axes"):
            self._sync_track_ticks()
            self._prune_break_markers(n_traces)
            self._rebuild_arrival_overlay()
        self._reset_view_on_plot = False

    def _handle_x_range_changed(self, *_):
        self._x_range_debounce_timer.stop()
        self._x_range_debounce_timer.start(int(self._x_range_debounce_ms))

    def _on_x_range_debounced(self) -> None:
        self._sync_track_ticks()
        self._refresh_break_overlay_paint()
        # Zoom fluido: non ricostruire fill; solo tracce ancora senza setData.
        if self.stream and self._seismogram_graphics_ready(len(self.stream)):
            self._ensure_visible_traces_drawn()

    def _handle_y_range_changed(self, *_):
        self._update_time_axis_ticks()
        self._refresh_break_overlay_paint()

    def _curve_has_plot_data(self, curve) -> bool:
        if curve is None:
            return False
        try:
            xd = getattr(curve, "xData", None)
            if xd is not None and len(xd) > 0:
                return True
        except Exception:
            pass
        try:
            data = curve.getData()
            if data is not None and len(data) >= 2 and data[0] is not None:
                return len(data[0]) > 0
        except Exception:
            pass
        return False

    def _ensure_visible_traces_drawn(self) -> None:
        """
        Dopo zoom/pan: rende visibili le tracce in viewport ancora senza setData
        (es. chunk di plot incompleto). Non ricostruisce fill delle tracce già disegnate.
        """
        items = getattr(self, "_trace_items", None) or []
        if not items:
            return
        n_traces = len(items)
        to_show: list[int] = []
        for idx in self._visible_trace_index_range(margin=3):
            if idx < 0 or idx >= n_traces:
                continue
            entry = items[idx]
            if not entry:
                continue
            curve = entry.get("curve")
            if curve is None:
                continue
            if self._curve_has_plot_data(curve):
                try:
                    if not curve.isVisible():
                        curve.setVisible(True)
                except Exception:
                    pass
                continue
            to_show.append(idx)
        if not to_show:
            return
        plot_w = getattr(self, "plot_widget", None)
        updates_off = False
        if plot_w is not None:
            plot_w.setUpdatesEnabled(False)
            updates_off = True
        try:
            for idx in to_show:
                self._show_trace(idx)
        finally:
            if updates_off and plot_w is not None:
                plot_w.setUpdatesEnabled(True)
                plot_w.update()

    def _view_unrotated_axis_ranges(
            self,
        ) -> tuple[tuple[float, float], tuple[float, float]]:
            """Angoli visibili del viewbox nel sistema traccia×tempo (non ruotato)."""
            plot_item = self.plot_widget.getPlotItem()
            (vx0, vx1), (vy0, vy1) = plot_item.viewRange()
            corners = [
                self._map_view_to_unrotated(float(vx0), float(vy0)),
                self._map_view_to_unrotated(float(vx0), float(vy1)),
                self._map_view_to_unrotated(float(vx1), float(vy0)),
                self._map_view_to_unrotated(float(vx1), float(vy1)),
            ]
            xs = [c[0] for c in corners]
            ys = [c[1] for c in corners]
            return (min(xs), max(xs)), (min(ys), max(ys))

    def _break_overlay_paint_trace_bounds(self) -> tuple[int, int]:
        """Range tracce da disegnare nell'overlay break (viewport o tutte in caricamento)."""
        n_traces = len(getattr(self, "_trace_items", None) or [])
        if n_traces <= 0:
            return 0, 0
        if getattr(self, "_plot_chunk_state", None) is not None:
            return 0, n_traces
        if getattr(self, "_reset_view_on_plot", False):
            return 0, n_traces
        return self._visible_trace_index_range_bounds(margin=1.0)

    def _visible_trace_index_range_bounds(self, *, margin: float = 1.0) -> tuple[int, int]:
        n_traces = len(getattr(self, "_trace_items", None) or [])
        if n_traces <= 0:
            return 0, 0
        baseline = getattr(self, "_current_baseline", None)
        if baseline is None or getattr(baseline, "size", 0) == 0:
            return 0, n_traces
        (x_lo, x_hi), _ = self._view_unrotated_axis_ranges()
        try:
            start = int(np.searchsorted(baseline, float(x_lo) - float(margin), side="left"))
            end = int(np.searchsorted(baseline, float(x_hi) + float(margin), side="right"))
        except Exception:
            return 0, n_traces
        start = max(0, min(start, n_traces))
        end = max(start, min(end, n_traces))
        if end <= start:
            return 0, n_traces
        return start, end

    def _visible_trace_index_range(self, *, margin: int = 2) -> range:
        """Indici traccia in viewport (baseline + spaziatura, anche con rotazione)."""
        n_traces = len(getattr(self, "_trace_items", None) or [])
        if n_traces <= 0:
            return range(0)
        start, end = self._visible_trace_index_range_bounds(margin=float(margin))
        if end <= start:
            return range(n_traces)
        return range(start, end)

    def _apply_trace_curve_style(self, idx: int | None) -> None:
        """Applica penna e z-order: traccia sotto il mouse in giallo, altrimenti default/shot."""
        if idx is None:
            return
        items = getattr(self, "_trace_items", None)
        if not items or idx < 0 or idx >= len(items):
            return
        entry = items[idx]
        if not entry:
            return
        curve = entry.get("curve")
        if curve is None:
            return
        hover = getattr(self, "_hover_track_idx", None)
        if idx == hover:
            curve.setPen(self._hover_trace_pen)
            curve.setZValue(5)
        else:
            curve.setPen(self._default_trace_pen)
            curve.setZValue(2)

    def _configure_curve_item(self, curve: pg.PlotCurveItem) -> None:
        setter = getattr(curve, "setClipToView", None)
        if callable(setter):
            try:
                setter(True)
            except Exception:
                pass
        downsampler = getattr(curve, "setDownsampling", None)
        if callable(downsampler):
            try:
                downsampler(auto=True, method="peak")
            except Exception:
                pass

    def _show_trace(self, idx: int) -> None:
        if idx < 0 or idx >= len(self._trace_items):
            return
        entry = self._trace_items[idx]
        if not entry:
            return
        norm = entry.get("norm")
        times_ms = entry.get("times")
        if norm is None or times_ms is None or norm.size == 0 or times_ms.size == 0:
            return
        baseline_val = float(entry.get("baseline", float(idx)))
        amp_scale = self._effective_amplitude_scale()
        trace_vals = self._display_trace_vals(norm, baseline_val, amp_scale)
        curve = entry.get("curve")
        if curve is None:
            return
        t0 = time.perf_counter()
        x_plot, y_plot = self._map_unrotated_to_view(trace_vals, times_ms)
        curve.setData(x_plot, y_plot)
        curve.setVisible(True)
        record("show_trace.curve_setdata", time.perf_counter() - t0)
        plot_item = self.plot_widget.getPlotItem()
        t1 = time.perf_counter()
        entry["fills"] = self._append_trace_fill_items(
            trace_vals, times_ms, baseline_val, plot_item, entry
        )
        record("show_trace.fill", time.perf_counter() - t1)
        self._apply_trace_curve_style(idx)

    def _initial_view_ranges(
            self,
            x_lo: float,
            x_hi: float,
            time_min_ms: float,
            time_max_ms: float,
        ) -> tuple[tuple[float, float], tuple[float, float]]:
            span_x = max(1.0, float(x_hi - x_lo))
            ratio_x = float(np.clip(self._initial_zoom_ratio_x, 0.05, 1.0))
            if ratio_x >= 0.999:
                x_range = (x_lo, x_hi)
            else:
                half = span_x * ratio_x * 0.5
                center = 0.5 * (x_hi + x_lo)
                left = max(x_lo, center - half)
                right = min(x_hi, center + half)
                if right - left < 1e-3:
                    x_range = (x_lo, x_hi)
                else:
                    x_range = (left, right)
            total_time = max(1.0, float(abs(time_max_ms - time_min_ms)))
            ratio_y = float(np.clip(self._initial_zoom_ratio_y, 0.05, 1.0))
            if ratio_y >= 0.999:
                target = (time_max_ms, time_min_ms)
            else:
                visible = total_time * ratio_y
                top = float(time_min_ms)
                bottom = min(float(time_max_ms), top + visible)
                if bottom - top < 1e-3:
                    target = (time_max_ms, time_min_ms)
                else:
                    target = (bottom, top)
            y_range = self._clamp_y_range(target)
            return x_range, y_range

    def _sync_track_ticks(self) -> None:
        self._sync_plot_axis_ticks()

    def _on_mouse_moved(self, event):
        def _clear_hover() -> None:
            old = getattr(self, "_hover_track_idx", None)
            self._hover_track_idx = None
            if old is not None:
                self._apply_trace_curve_style(old)

        if self.stream is None:
            self._track_label.setText("Traccia: -")
            _clear_hover()
            self._last_track_label_idx = None
            return
        # Durante il gesto break la preview opaca copre il plot: evita lavoro inutile.
        if self._break_gesture_in_progress():
            return
        pos = event[0] if isinstance(event, tuple) else event
        if pos is None:
            self._track_label.setText("Traccia: -")
            _clear_hover()
            return
        vb = self.plot_widget.getPlotItem().getViewBox()
        if not vb.sceneBoundingRect().contains(pos):
            self._track_label.setText("Traccia: -")
            _clear_hover()
            self._last_track_label_idx = None
            return
        mouse_point = vb.mapSceneToView(pos)
        baseline = getattr(self, "_current_baseline", None)
        x_u, _ = self._map_view_to_unrotated(float(mouse_point.x()), float(mouse_point.y()))
        track_idx = self._track_index_from_x(x_u)
        if baseline is None or track_idx is None or track_idx < 0 or track_idx >= len(baseline):
            self._track_label.setText("Traccia: -")
            _clear_hover()
            self._last_track_label_idx = None
            return
        prev_hover = getattr(self, "_hover_track_idx", None)
        self._hover_track_idx = track_idx
        if prev_hover != track_idx:
            if prev_hover is not None:
                self._apply_trace_curve_style(prev_hover)
            self._apply_trace_curve_style(track_idx)
        # Aggiornare QLabel ad ogni mouseMove è sorprendentemente costoso; aggiorna solo quando cambia traccia.
        if self._last_track_label_idx != track_idx:
            label = f"Traccia: {track_idx + 1}"
            if getattr(self, "_break_ruler_enabled", False):
                if self._ruler_line_ready():
                    label += " ” righello: Invio applica, Esc annulla"
                elif self._ruler_vertex_a is not None:
                    label += " — righello: 2° click destro per il secondo vertice"
                else:
                    label += " — righello: 1° click destro per il primo vertice"
            else:
                t_br = self._arrival_markers.get(track_idx)
                if t_br is not None:
                    label += f" · break {float(t_br):.2f} ms"
            self._track_label.setText(label)
            self._last_track_label_idx = track_idx

    def _update_time_axis_ticks(self) -> None:
        plot_item = self.plot_widget.getPlotItem()
        self._apply_view_limits(plot_item.getViewBox())
        self._sync_plot_axis_ticks()

    def _ensure_plot_cache(self, desired_budget: int | None = None):
        if self._plot_cache is None and self.stream:
            if not getattr(self, "_cache_build_in_flight", False):
                self._build_plot_cache(
                    points_budget=desired_budget,
                    follow_up="plot_stream",
                )
        elif desired_budget is not None:
            current_budget = self._cache_points_budget or 0
            if (
                desired_budget > current_budget + 200
                and not getattr(self, "_cache_build_in_flight", False)
            ):
                self._build_plot_cache(
                    points_budget=desired_budget,
                    follow_up="fast_redraw",
                )
        return self._plot_cache or []

    def _baseline_for(self, n_traces: int) -> np.ndarray:
        baseline = self._compute_baseline_positions(n_traces)
        return baseline

    def _compute_baseline_positions(self, n_traces: int) -> np.ndarray:
        if n_traces <= 0:
            return np.zeros(0, dtype=np.float32)
        baseline = np.arange(n_traces, dtype=np.float32)
        spacing_factor = float(getattr(self, "_trace_spacing_factor", 1.0) or 1.0)
        if abs(spacing_factor - 1.0) > 1e-6:
            baseline *= spacing_factor
        offset = float(getattr(self, "_trace_baseline_offset", 0.0) or 0.0)
        if offset:
            baseline += offset
        return baseline

    def _trace_point_budget(self, n_traces: int) -> int:
        widget = getattr(self, "plot_widget", None)
        height = widget.height() if widget else 800
        if height <= 0:
            height = 800
        ratio = widget.devicePixelRatioF() if widget and hasattr(widget, "devicePixelRatioF") else 1.0
        height_budget = int(max(280.0, height * ratio * 1.0))
        avg_budget = int(max(280, self.max_total_plot_points // max(1, n_traces)))
        return max(280, min(self.max_plot_points, height_budget, avg_budget))

    def _desired_points_budget(self, scale: float) -> int:
        detail = 1.0
        effective = scale
        if effective > 1.0:
            detail += min(3.0, (effective - 1.0) * 1.5)
        zoom_factor = self._zoom_detail_factor()
        detail *= zoom_factor
        base = self.max_plot_points
        # Tetto: evita richieste enormi allo zoom (prima potevano spingere fino a 20k punti/traccia).
        cap = max(int(base * 1.7), 2200)
        return min(int(base * detail), cap)

    def _zoom_detail_factor(self) -> float:
        baseline = getattr(self, "_current_baseline", None)
        if baseline is None or baseline.size == 0:
            return 1.0
        try:
            x_range, _ = self.plot_widget.getPlotItem().viewRange()
        except Exception:
            return 1.0
        if not x_range or len(x_range) != 2:
            return 1.0
        span = x_range[1] - x_range[0]
        if span <= 0:
            return 1.0
        total = float(len(baseline))
        zoom_ratio = total / max(1.0, span)
        return float(min(2.5, max(1.0, zoom_ratio)))

    def _x_axis_limits(self) -> tuple[float, float]:
        margin = float(getattr(self, "_x_axis_negative_margin", 0.0) or 0.0)
        x_min = -abs(margin)
        baseline = getattr(self, "_current_baseline", None)
        if baseline is not None and getattr(baseline, "size", 0):
            x_max = float(baseline[-1]) + 1.5
        else:
            length = len(self._trace_items) if getattr(self, "_trace_items", None) else 0
            x_max = float(length) + 1.0
        if x_max <= x_min + 1e-3:
            x_max = x_min + 1.0
        return (x_min, max(x_min + 1.0, x_max))

    def _time_axis_limits(self) -> tuple[float, float]:
        base_min, base_max = self._time_range_full
        headroom = float(getattr(self, "_time_axis_headroom_ms", 0.0) or 0.0)
        min_limit = min(float(base_min), 0.0) - headroom
        max_limit = max(min_limit + 1.0, float(base_max))
        return (min_limit, max_limit)

    def _apply_view_limits(self, view_box):
        x_min, x_max = self._x_axis_limits()
        y_min, y_max = self._time_axis_limits()
        if int(getattr(self, "_view_rotation_deg", 0)) % 360 != 0:
            bx0, bx1, by0, by1 = self._plot_bounds_for_rotation(x_min, x_max, y_min, y_max)
            view_box.setLimits(xMin=bx0, xMax=bx1, yMin=by0, yMax=by1)
            return
        view_box.setLimits(xMin=x_min, xMax=x_max, yMin=y_min, yMax=y_max)

    def _track_index_from_x(self, x_value: float) -> int | None:
        baseline = getattr(self, "_current_baseline", None)
        if baseline is None:
            return None
        if not hasattr(baseline, "size"):
            baseline = np.asarray(baseline, dtype=np.float32)
            self._current_baseline = baseline
        if baseline.size == 0:
            return None
        idx = int(np.searchsorted(baseline, x_value))
        candidates = []
        if 0 <= idx < baseline.size:
            candidates.append(idx)
        if idx - 1 >= 0:
            candidates.append(idx - 1)
        if idx + 1 < baseline.size:
            candidates.append(idx + 1)
        if not candidates:
            return None
        best = min(candidates, key=lambda i: abs(float(baseline[i]) - x_value))
        if 0 <= best < baseline.size:
            return best
        return None

    def _clamp_time_value(self, value: float) -> float:
        lo, hi = self._time_axis_limits()
        return float(min(hi, max(lo, value)))

    def _rotate_view_90(self) -> None:
        if self.stream is None:
            return
        self._persist_breaks_before_view_reset()
        self._view_rotation_deg = (int(getattr(self, "_view_rotation_deg", 0)) + 90) % 360
        self._detach_arrival_overlay()
        self._reset_view_on_plot = True
        self._plot_stream()
        self._sync_plot_with_fbp_after_display()

    def _map_unrotated_to_view(self, x_u, y_u):
        rot = int(getattr(self, "_view_rotation_deg", 0)) % 360
        if rot == 0:
            return x_u, y_u
        if rot == 90:
            return y_u, -x_u
        if rot == 180:
            return -x_u, -y_u
        return -y_u, x_u  # 270

    def _map_unrotated_to_view_arrays(
            self, x_u: np.ndarray, y_u: np.ndarray
        ) -> tuple[np.ndarray, np.ndarray]:
            x_a = np.asarray(x_u, dtype=np.float64)
            y_a = np.asarray(y_u, dtype=np.float64)
            rot = int(getattr(self, "_view_rotation_deg", 0)) % 360
            if rot == 0:
                return x_a, y_a
            if rot == 90:
                return y_a, -x_a
            if rot == 180:
                return -x_a, -y_a
            return -y_a, x_a

    def _append_fill_polygon_to_path(
            self,
            path: QtGui.QPainterPath,
            x_u: np.ndarray,
            y_u: np.ndarray,
        ) -> None:
            if x_u.size < 3:
                return
            x_v, y_v = self._map_unrotated_to_view_arrays(x_u, y_u)
            poly = QtGui.QPolygonF(
                [QtCore.QPointF(float(x_v[i]), float(y_v[i])) for i in range(x_v.size)]
            )
            path.addPolygon(poly)

    def _map_view_to_unrotated(self, x_v, y_v):
        rot = int(getattr(self, "_view_rotation_deg", 0)) % 360
        if rot == 0:
            return x_v, y_v
        if rot == 90:
            return -y_v, x_v
        if rot == 180:
            return -x_v, -y_v
        return y_v, -x_v  # 270

    def _plot_bounds_for_rotation(
            self, x_lo: float, x_hi: float, y_lo: float, y_hi: float
        ) -> tuple[float, float, float, float]:
            pts = [
                self._map_unrotated_to_view(x_lo, y_lo),
                self._map_unrotated_to_view(x_lo, y_hi),
                self._map_unrotated_to_view(x_hi, y_lo),
                self._map_unrotated_to_view(x_hi, y_hi),
            ]
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            return float(min(xs)), float(max(xs)), float(min(ys)), float(max(ys))

    def _clamp_y_range(self, y_range):
        if not y_range or len(y_range) != 2:
            return self._time_axis_limits()
        y0, y1 = y_range
        lo = min(y0, y1)
        hi = max(y0, y1)
        min_limit, max_limit = self._time_axis_limits()
        lo = max(min_limit, lo)
        hi = min(max_limit, max(lo + 1e-3, hi))
        if y0 <= y1:
            return (lo, hi)
        return (hi, lo)

    def _refresh_plot_with_break_gain(self) -> None:
        """Ricostruisce la cache con amplificazione locale sui tempi break (da .fbp / ricarica)."""
        if not self.stream or not self._arrival_markers:
            self._rebuild_arrival_overlay()
            return
        if not self._break_zone_gain_user_enabled():
            self._break_zone_gain_active = False
            self._rebuild_arrival_overlay()
            return
        self._break_zone_gain_active = True
        self._invalidate_plot_cache(reset_graphics=False, reset_view=False)
        self._build_plot_cache(follow_up="break_gain")

    def _clear_break_zone_gain_display(self) -> None:
        """Rimuove l'amplificazione locale quando i break vengono modificati a mano."""
        if not getattr(self, "_break_zone_gain_active", False):
            return
        self._break_zone_gain_active = False
        if not self.stream:
            return
        self._invalidate_plot_cache(reset_graphics=False, reset_view=False)
        self._build_plot_cache(follow_up="plot_stream")

    def _invalidate_plot_cache(
            self,
            *,
            reset_graphics: bool = True,
            reset_view: bool = True,
        ) -> None:
            self._plot_cache = None
            self._plot_time_bounds = (0.0, 1.0)
            if reset_view:
                self._reset_view_on_plot = True
            self._cache_points_budget = None
            if reset_graphics:
                self._reset_seismogram_plot_items()

    def _build_plot_cache(
            self,
            points_budget: int | None = None,
            *,
            follow_up: str = "none",
            load_sync_extra: dict[str, object] | None = None,
            sync: bool = False,
        ) -> None:
            """Costruisce la cache plot sul worker (non blocca la GUI)."""
            if self.stream is None:
                self._invalidate_plot_cache()
                return
            payload = self._cache_worker_payload(points_budget)
            hub = getattr(self, "_gui_worker", None)
            if sync or hub is None:
                from worker_tasks import build_plot_cache

                with perf_section("gui.build_plot_cache", n_traces=len(self.stream)):
                    result = build_plot_cache(
                        self.stream,
                        points_budget=int(payload["points_budget"]),
                        max_display_ms=payload.get("max_display_ms"),  # type: ignore[arg-type]
                        use_auto_gain=bool(payload["use_auto_gain"]),
                        display_scale_percentile=float(payload["display_scale_percentile"]),
                        break_zone_gain_active=bool(payload["break_zone_gain_active"]),
                        arrival_markers=dict(payload.get("arrival_markers") or {}),
                        break_near_window_ms=float(payload["break_near_window_ms"]),
                        break_near_gain=float(payload["break_near_gain"]),
                        agc_enabled=bool(payload.get("agc_enabled")),
                        agc_window_ms=float(payload.get("agc_window_ms", DEFAULT_AGC_WINDOW_MS)),
                    )
                if not result.get("cache"):
                    self._invalidate_plot_cache()
                    return
                self._apply_cache_worker_result(result)
                self._run_cache_follow_up(follow_up)
                return
            payload["stream"] = self.stream
            self._cache_build_in_flight = True
            extra: dict[str, object] = {
                "stream_epoch": int(getattr(self, "_stream_epoch", 0)),
            }
            if load_sync_extra is not None:
                extra["load_sync_extra"] = load_sync_extra
            hub.submit(
                "build_cache",
                payload,
                follow_up=follow_up,
                extra=extra,
            )

    def _cancel_chunked_plot(self) -> None:
        self._plot_chunk_timer.stop()
        self._plot_chunk_state = None

    def _start_chunked_show_traces(self) -> None:
        self._cancel_chunked_plot()
        n_traces = len(self._trace_items or [])
        if n_traces <= 0:
            self._finish_plot_stream_after_chunks()
            return
        self._plot_chunk_state = {"next_idx": 0}
        self._plot_chunk_timer.start(0)

    def _process_plot_chunk(self) -> None:
        state = self._plot_chunk_state
        if state is None:
            self._plot_chunk_timer.stop()
            return
        items = self._trace_items or []
        idx = int(state["next_idx"])
        chunk_size = int(getattr(self, "_plot_chunk_size", 24))
        end = min(idx + chunk_size, len(items))
        plot_w = getattr(self, "plot_widget", None)
        if plot_w is not None:
            plot_w.setUpdatesEnabled(False)
        try:
            for trace_idx in range(idx, end):
                self._show_trace(trace_idx)
        finally:
            if plot_w is not None:
                plot_w.setUpdatesEnabled(True)
                plot_w.update()
        if self._arrival_markers:
            self._refresh_break_overlay_paint()
        state["next_idx"] = end
        if end >= len(items):
            self._plot_chunk_timer.stop()
            self._plot_chunk_state = None
            self._finish_plot_stream_after_chunks()
        else:
            self._plot_chunk_timer.start(0)

    def _finish_plot_stream_after_chunks(self) -> None:
        with perf_section("plot_stream.overlay_axes"):
            self._sync_track_ticks()
            if self.stream is not None:
                self._prune_break_markers(len(self.stream))
            self._rebuild_arrival_overlay()
        self._reset_view_on_plot = False
        self._hide_seismogram_loading()

    @staticmethod
    def _build_time_ticks(time_min_ms: float, time_max_ms: float) -> np.ndarray:
        span = max(1.0, time_max_ms - time_min_ms)
        target_ticks = 14
        raw_step = span / target_ticks
        scale = 10 ** math.floor(math.log10(raw_step)) if raw_step > 0 else 1.0
        for mult in (1, 2, 5, 10):
            step = mult * scale
            if step >= raw_step:
                break
        else:
            step = raw_step or 1.0
        start = math.floor(time_min_ms / step) * step
        stop = math.ceil(time_max_ms / step) * step
        ticks = np.arange(start, stop + step, step)
        return ticks

    @staticmethod
    def _format_ms_tick(value: float) -> str:
        return f"{int(round(value))}"

    @staticmethod
    def _trace_sampling_rate_hz(trace: object) -> float:
        sr = float(getattr(getattr(trace, "stats", None), "sampling_rate", 0.0) or 0.0)
        if sr > 0.0:
            return sr
        dt = float(getattr(getattr(trace, "stats", None), "delta", 0.0) or 0.0)
        if dt > 0.0:
            return 1.0 / dt
        return 1000.0

    def _stream_sampling_rate_hz(self) -> float:
        if self.stream is None or len(self.stream) == 0:
            return 1000.0
        for tr in self.stream:
            stats = getattr(tr, "stats", None)
            if stats is None:
                continue
            sr = float(getattr(stats, "sampling_rate", 0.0) or 0.0)
            if sr > 0.0:
                return sr
            dt = float(getattr(stats, "delta", 0.0) or 0.0)
            if dt > 0.0:
                return 1.0 / dt
        return self._trace_sampling_rate_hz(self.stream[0])

    def _effective_break_half_span(self) -> float:
        spacing = float(getattr(self, "_trace_spacing_factor", 1.0) or 1.0)
        return float(max(0.35, min(0.9, 0.42 * spacing)))

    def _track_at_scene_pos(self, scene_pos) -> tuple[int | None, float | None]:
        vb = self.plot_widget.getPlotItem().getViewBox()
        if not vb.sceneBoundingRect().contains(scene_pos):
            return None, None
        view_point = vb.mapSceneToView(scene_pos)
        x_u, y_u = self._map_view_to_unrotated(float(view_point.x()), float(view_point.y()))
        track_idx = self._track_index_from_x(x_u)
        baseline = getattr(self, "_current_baseline", None)
        if baseline is None or track_idx is None or track_idx < 0 or track_idx >= len(baseline):
            return None, None
        y_val = self._clamp_time_value(y_u)
        return track_idx, y_val

    def _on_break_ruler_toggled(self, checked: bool) -> None:
        self._break_ruler_enabled = bool(checked)
        for widget in (
            getattr(self, "act_break_ruler", None),
            getattr(self, "_toolbar_ruler_btn", None),
        ):
            if widget is None:
                continue
            if widget.isChecked() != bool(checked):
                widget.blockSignals(True)
                widget.setChecked(bool(checked))
                widget.blockSignals(False)
        if not checked:
            self._clear_break_ruler_preview()

    def _clear_break_ruler_preview(self) -> None:
        self._ruler_vertex_a = None
        self._ruler_vertex_b = None
        self._remove_ruler_preview_graphics()

    def _ruler_line_ready(self) -> bool:
        return (
            self._ruler_vertex_a is not None and self._ruler_vertex_b is not None
        )

    def _confirm_break_ruler(self) -> None:
        if not self._ruler_line_ready() or self.stream is None:
            return
        x0, y0 = self._ruler_vertex_a  # type: ignore[misc]
        x1, y1 = self._ruler_vertex_b  # type: ignore[misc]
        self._apply_break_ruler_line(x0, y0, x1, y1)
        self._clear_break_ruler_preview()

    def _remove_ruler_preview_graphics(self) -> None:
        line = getattr(self, "_ruler_preview_item", None)
        if line is not None:
            try:
                self.plot_widget.getPlotItem().removeItem(line)
            except Exception:
                pass
            self._ruler_preview_item = None
        scatter = getattr(self, "_ruler_vertex_scatter", None)
        if scatter is not None:
            try:
                self.plot_widget.getPlotItem().removeItem(scatter)
            except Exception:
                pass
            self._ruler_vertex_scatter = None

    def _update_ruler_vertex_markers(self) -> None:
        plot_item = self.plot_widget.getPlotItem()
        scatter = self._ruler_vertex_scatter
        if scatter is None:
            scatter = pg.ScatterPlotItem(
                size=10,
                pen=pg.mkPen("#0d5c24", width=1.2),
                brush=pg.mkBrush(22, 163, 74, 240),
                symbol="o",
            )
            scatter.setZValue(51)
            plot_item.addItem(scatter)
            self._ruler_vertex_scatter = scatter
        xs: list[float] = []
        ys: list[float] = []
        sizes: list[float] = []
        if self._ruler_vertex_a is not None:
            vx, vy = self._map_unrotated_to_view(*self._ruler_vertex_a)
            xs.append(vx)
            ys.append(vy)
            sizes.append(11.0)
        if self._ruler_vertex_b is not None:
            vx, vy = self._map_unrotated_to_view(*self._ruler_vertex_b)
            xs.append(vx)
            ys.append(vy)
            sizes.append(9.0)
        if not xs:
            scatter.setData([], [])
            scatter.setVisible(False)
            return
        scatter.setData(xs, ys, size=sizes)
        scatter.setVisible(True)

    def _scene_to_unrotated(self, scene_pos) -> tuple[float, float]:
        vb = self.plot_widget.getPlotItem().getViewBox()
        view_point = vb.mapSceneToView(scene_pos)
        return self._map_view_to_unrotated(float(view_point.x()), float(view_point.y()))

    def _update_break_ruler_preview(
            self, x0: float, y0: float, x1: float, y1: float
        ) -> None:
            plot_item = self.plot_widget.getPlotItem()
            vx0, vy0 = self._map_unrotated_to_view(x0, y0)
            vx1, vy1 = self._map_unrotated_to_view(x1, y1)
            item = self._ruler_preview_item
            if item is None:
                pen = pg.mkPen(
                    "#16a34a",
                    width=3.2,
                    cosmetic=True,
                )
                item = pg.PlotCurveItem(pen=pen)
                item.setZValue(50)
                plot_item.addItem(item)
                self._ruler_preview_item = item
            if self._ruler_vertex_b is None:
                item.setVisible(False)
            else:
                item.setData([vx0, vx1], [vy0, vy1])
                item.setVisible(True)
                item.update()
            self._update_ruler_vertex_markers()

    def _handle_ruler_vertex_click(self, scene_pos, modifiers) -> None:
        del modifiers
        if not self._break_ruler_enabled or self.stream is None:
            return
        x, y = self._scene_to_unrotated(scene_pos)
        if self._ruler_vertex_a is None:
            self._ruler_vertex_a = (x, y)
            self._ruler_vertex_b = None
            self._update_break_ruler_preview(x, y, x, y)
            return
        if self._ruler_vertex_b is None:
            self._ruler_vertex_b = (x, y)
            x0, y0 = self._ruler_vertex_a
            self._update_break_ruler_preview(x0, y0, x, y)
            return
        self._ruler_vertex_a = (x, y)
        self._ruler_vertex_b = None
        self._update_break_ruler_preview(x, y, x, y)

    def _apply_break_ruler_line(
            self, x0: float, y0: float, x1: float, y1: float
        ) -> None:
            baseline = getattr(self, "_current_baseline", None)
            if baseline is None or getattr(baseline, "size", 0) == 0:
                return
            n = int(len(baseline))
            self._clear_break_zone_gain_display()
            self._break_undo_push()
            dx = float(x1 - x0)
            dy = float(y1 - y0)
            x_lo, x_hi = (min(x0, x1), max(x0, x1))
            spacing = float(getattr(self, "_trace_spacing_factor", 1.0) or 1.0)
            margin = max(0.35, spacing * 0.6)
            updates: list[tuple[int, float]] = []

            for idx in range(n):
                bx = float(baseline[idx])
                if bx < x_lo - margin or bx > x_hi + margin:
                    continue
                if abs(dx) < 1e-9:
                    y = 0.5 * (y0 + y1)
                else:
                    y = y0 + ((bx - x0) / dx) * dy
                y = self._clamp_time_value(y)
                updates.append((idx, y))

            if not updates:
                i0 = self._track_index_from_x(x0)
                i1 = self._track_index_from_x(x1)
                if i0 is not None and i1 is not None:
                    lo, hi = min(i0, i1), max(i0, i1)
                    for idx in range(lo, hi + 1):
                        bx = float(baseline[idx])
                        if abs(dx) < 1e-9:
                            y = 0.5 * (y0 + y1)
                        else:
                            y = y0 + ((bx - x0) / dx) * dy
                        y = self._clamp_time_value(y)
                        updates.append((idx, y))
                elif i0 is not None:
                    updates.append((i0, self._clamp_time_value(0.5 * (y0 + y1))))

            if not updates:
                return

            for idx, y in updates:
                self._arrival_base_times[idx] = max(0.0, float(y))
                self._arrival_markers[idx] = float(y)
            self._mark_fbp_traces_dirty(idx for idx, _ in updates)
            self._ensure_break_overlay_structure()
            self._rebuild_arrival_overlay()
            self._on_seismogram_markers_changed(immediate_sync=True)

    def _set_trace_scene_cache(self, enabled: bool) -> None:
        """Durante il gesto break Qt riusa le bitmap delle tracce invece di ricalcolarle."""
        if bool(getattr(self, "_break_trace_cache_on", False)) == bool(enabled):
            return
        self._break_trace_cache_on = bool(enabled)
        mode = (
            QtWidgets.QGraphicsItem.CacheMode.DeviceCoordinateCache
            if enabled
            else QtWidgets.QGraphicsItem.CacheMode.NoCache
        )
        for entry in getattr(self, "_trace_items", None) or ():
            if not entry:
                continue
            curve = entry.get("curve")
            if curve is not None:
                try:
                    curve.setCacheMode(mode)
                except Exception:
                    pass
            for fill in entry.get("fills") or ():
                try:
                    fill.setCacheMode(mode)
                except Exception:
                    pass

    def _break_fail_deltas_for_paint(self) -> dict[int, float]:
        """Δ FAIL per colorare i break sul sismogramma (se opzione attiva)."""
        return self._reciprocal_fail_deltas_for_active_seismogram()

    def _on_seismogram_fail_colors_toggled(self, checked: bool) -> None:
        self._seismogram_fail_colors_enabled = bool(checked)
        monitor = self._fbp_velocity_window_ref()
        if monitor is not None:
            monitor._seismogram_fail_overlay_wanted = bool(checked)
            if checked:
                # Avvia/aggiorna il calcolo FAIL e ridisegna i break.
                monitor.schedule_dromocrona_grid_refresh(immediate=False)
                cached = getattr(monitor, "_reciprocal_pairs_cache", None)
                if cached is not None:
                    monitor._refresh_reciprocal_fail_highlights(
                        reciprocal_pairs=cached
                    )
            else:
                monitor._notify_reciprocal_fail_changed()
        self._rebuild_arrival_overlay()

    def _handle_right_break_press(self) -> None:
        """Inizio nuovo gesto tasto destro: azzera ancoraggio precedente (evita linea spuria)."""
        if getattr(self, "_break_right_gesture_active", False):
            self._finish_right_break_gesture()
        self._break_right_gesture_active = True
        self._last_right_track = None
        self._last_right_y = None
        self._break_undo_pushed_this_gesture = False
        self._set_trace_scene_cache(True)
        self._deferred_grid_refresh_timer.stop()
        timer = getattr(self, "_deferred_monitor_sync_timer", None)
        if timer is not None:
            timer.stop()
        disk_timer = getattr(self, "_deferred_fbp_disk_timer", None)
        if disk_timer is not None:
            disk_timer.stop()

    def _handle_right_break_action(self, scene_pos, modifiers) -> None:
        if getattr(self, "_break_ruler_enabled", False):
            return
        if self.stream is None:
            return
        track_idx, y_val = self._track_at_scene_pos(scene_pos)
        if track_idx is None or y_val is None:
            return
        ctrl_pressed = bool(
            modifiers & QtCore.Qt.KeyboardModifier.ControlModifier
        )
        if ctrl_pressed:
            self._apply_break_delete(track_idx)
            return
        self._apply_break_insert(track_idx, y_val)

    def _apply_break_delete(self, track_idx: int) -> None:
        """Rimuove break su Ctrl+destro; in drag cancella anche le tracce intermedie (come insert)."""
        baseline = getattr(self, "_current_baseline", None)
        if baseline is None or track_idx < 0 or track_idx >= len(baseline):
            return

        break_held = self._break_mouse_button_held()
        prev_idx = self._last_right_track if break_held else None
        if prev_idx is None:
            indices = [track_idx]
        elif prev_idx == track_idx:
            indices = [track_idx]
        else:
            step = 1 if track_idx >= prev_idx else -1
            indices = list(range(prev_idx, track_idx + step, step))

        removed: list[int] = []
        for idx in indices:
            if idx < 0 or idx >= len(baseline):
                continue
            if idx not in self._arrival_markers:
                continue
            removed.append(idx)

        if not removed:
            # Solo click singolo (non drag): feedback se non c'è nulla da cancellare.
            if not break_held or prev_idx is None:
                QtWidgets.QToolTip.showText(
                    QtGui.QCursor.pos(),
                    f"Nessun break sulla traccia {track_idx + 1}",
                    self,
                    QtCore.QRect(),
                    1600,
                )
            if break_held:
                self._last_right_track = track_idx
                self._last_right_y = None
            return

        self._clear_break_zone_gain_display()
        if not getattr(self, "_break_undo_pushed_this_gesture", False):
            self._break_undo_push()
            self._break_undo_pushed_this_gesture = True

        for idx in removed:
            self._arrival_markers.pop(idx, None)
            self._arrival_base_times.pop(idx, None)
        self._mark_fbp_traces_dirty(removed)

        if not self._arrival_markers:
            self._detach_arrival_overlay()
        else:
            self._ensure_break_overlay_structure()
            self._throttle_break_overlay_paint()

        if break_held:
            self._last_right_track = track_idx
            self._last_right_y = None
        else:
            self._last_right_track = None
            self._last_right_y = None

        self._on_seismogram_markers_changed(update_status=True, immediate_sync=False)

    def _handle_right_break_release(self, *_args) -> None:
        self._finish_right_break_gesture()

    def _finish_right_break_gesture(self) -> None:
        if not getattr(self, "_break_right_gesture_active", False):
            return
        self._break_right_gesture_active = False
        self._set_trace_scene_cache(False)
        self._break_ov_throttle_timer.stop()
        self._break_ov_deferred = False
        self._rebuild_arrival_overlay()
        self._last_right_track = None
        self._last_right_y = None
        self._break_undo_pushed_this_gesture = False
        # Qt invia mouseRelease prima di mouseClick: differiamo la sync così
        # il pick singolo aggiorna prima i marker e poi la dromocrona.
        QtCore.QTimer.singleShot(0, self._sync_monitor_after_break_gesture)

    def _apply_break_insert(self, track_idx: int, y_val: float) -> None:
        """Inserisce break sulla traccia corrente; col tasto break premuto interpola le tracce intermedie."""
        self._clear_break_zone_gain_display()
        baseline = getattr(self, "_current_baseline", None)
        if baseline is None or track_idx < 0 or track_idx >= len(baseline):
            return
        break_held = self._break_mouse_button_held()
        prev_idx = self._last_right_track if break_held else None
        prev_y = self._last_right_y if break_held else None
        if prev_idx is None:
            if not getattr(self, "_break_undo_pushed_this_gesture", False):
                self._break_undo_push()
                self._break_undo_pushed_this_gesture = True
        if prev_idx is None:
            indices = [track_idx]
            y_values = [y_val]
        elif prev_idx == track_idx:
            indices = [track_idx]
            y_values = [y_val]
        else:
            step = 1 if track_idx >= prev_idx else -1
            indices = list(range(prev_idx, track_idx + step, step))
            total = len(indices) - 1 or 1
            if prev_y is None:
                prev_y = y_val
            y_values = [
                prev_y + (y_val - prev_y) * (i / total) for i in range(len(indices))
            ]
        dirty_traces: list[int] = []
        for idx, y_local in zip(indices, y_values):
            if idx < 0 or idx >= len(baseline):
                continue
            self._arrival_base_times[idx] = max(0.0, float(y_local))
            self._arrival_markers[idx] = float(y_local)
            dirty_traces.append(idx)
        if dirty_traces:
            self._mark_fbp_traces_dirty(dirty_traces)
        self._ensure_break_overlay_structure()
        self._throttle_break_overlay_paint()
        if break_held:
            self._last_right_track = track_idx
            self._last_right_y = y_val
        else:
            self._last_right_track = None
            self._last_right_y = None

    @staticmethod
    def _qt_wrapper_alive(obj) -> bool:
        if obj is None:
            return False
        try:
            from PyQt6 import sip
            return not sip.isdeleted(obj)
        except Exception:
            try:
                obj.isVisible()
                return True
            except RuntimeError:
                return False

    def _ensure_break_overlay_structure(self) -> None:
        """Crea/mostra/nascondi l'item overlay; senza repaint ripetuto (gestito a parte)."""
        plot_widget = getattr(self, "plot_widget", None)
        if plot_widget is None:
            return
        plot_item = plot_widget.getPlotItem()
        markers = self._arrival_markers
        baseline = getattr(self, "_current_baseline", None)
        if self._arrival_overlay_item is not None and not self._qt_wrapper_alive(
            self._arrival_overlay_item
        ):
            self._arrival_overlay_item = None
        if not markers or baseline is None or getattr(baseline, "size", 0) == 0:
            if self._arrival_overlay_item is not None:
                try:
                    self._arrival_overlay_item.setVisible(False)
                except RuntimeError:
                    self._arrival_overlay_item = None
            return
        if getattr(self, "_arrival_pen", None) is None:
            self._arrival_pen = pg.mkPen(
                QtGui.QColor(self._arrival_marker_color),
                width=float(getattr(self, "_arrival_marker_width", 2.0)),
            )
        fail_w = float(getattr(self, "_arrival_marker_width", 2.0)) + 1.0
        if getattr(self, "_arrival_fail_pen_positive", None) is None:
            self._arrival_fail_pen_positive = pg.mkPen(
                QtGui.QColor(
                    getattr(self, "_arrival_fail_positive_color", "#22c55e")
                ),
                width=fail_w,
            )
        if getattr(self, "_arrival_fail_pen_negative", None) is None:
            self._arrival_fail_pen_negative = pg.mkPen(
                QtGui.QColor(
                    getattr(self, "_arrival_fail_negative_color", "#111827")
                ),
                width=fail_w,
            )
        if self._arrival_overlay_item is None:
            self._arrival_overlay_item = ArrivalBreakOverlayItem(
                get_baseline=lambda: getattr(self, "_current_baseline", None),
                get_markers=lambda: self._arrival_markers,
                get_pen=lambda: getattr(self, "_arrival_pen", None),
                get_half_span=self._effective_break_half_span,
                get_viewbox=lambda: plot_widget.getPlotItem().getViewBox(),
                map_xy=lambda x, y: self._map_unrotated_to_view(x, y),
                get_trace_range=lambda: self._break_overlay_paint_trace_bounds(),
                get_fail_deltas=self._break_fail_deltas_for_paint,
                get_fail_pen_positive=lambda: getattr(
                    self, "_arrival_fail_pen_positive", None
                ),
                get_fail_pen_negative=lambda: getattr(
                    self, "_arrival_fail_pen_negative", None
                ),
            )
            self._arrival_overlay_item.setZValue(25)
            plot_item.addItem(self._arrival_overlay_item, ignoreBounds=True)
        else:
            self._arrival_overlay_item._get_fail_deltas = self._break_fail_deltas_for_paint
            self._arrival_overlay_item._get_fail_pen_positive = (
                lambda: getattr(self, "_arrival_fail_pen_positive", None)
            )
            self._arrival_overlay_item._get_fail_pen_negative = (
                lambda: getattr(self, "_arrival_fail_pen_negative", None)
            )
        try:
            self._arrival_overlay_item.setVisible(True)
        except RuntimeError:
            self._arrival_overlay_item = None

    def _throttle_break_overlay_paint(self) -> None:
        now = time.monotonic()
        if now - self._break_overlay_last_paint_t >= self._break_overlay_min_interval_s:
            self._break_ov_throttle_timer.stop()
            self._break_overlay_last_paint_t = now
            self._break_ov_deferred = False
            self._paint_break_overlay_now()
        else:
            self._break_ov_deferred = True
            if not self._break_ov_throttle_timer.isActive():
                rem = self._break_overlay_min_interval_s - (now - self._break_overlay_last_paint_t)
                self._break_ov_throttle_timer.start(int(max(1, rem * 1000)))

    def _break_overlay_throttled_flush(self) -> None:
        if self._break_ov_deferred:
            self._break_overlay_last_paint_t = time.monotonic()
            self._break_ov_deferred = False
            self._paint_break_overlay_now()

    def _rebuild_arrival_overlay(self) -> None:
        self._ensure_break_overlay_structure()
        markers = self._arrival_markers
        baseline = getattr(self, "_current_baseline", None)
        if not markers or baseline is None or getattr(baseline, "size", 0) == 0:
            ov = self._arrival_overlay_item
            if ov is not None and self._qt_wrapper_alive(ov):
                try:
                    ov.update()
                except RuntimeError:
                    self._arrival_overlay_item = None
            return
        self._paint_break_overlay_now()

    def _paint_break_overlay_now(self) -> None:
        ov = self._arrival_overlay_item
        if ov is None or not self._qt_wrapper_alive(ov):
            self._arrival_overlay_item = None
            return
        try:
            if not ov.isVisible():
                return
            ov.update()
        except RuntimeError:
            self._arrival_overlay_item = None

    def _detach_arrival_overlay(self) -> None:
        self._set_trace_scene_cache(False)
        try:
            self._break_ov_throttle_timer.stop()
        except Exception:
            pass
        self._break_ov_deferred = False
        if self._arrival_overlay_item is None:
            return
        if not self._qt_wrapper_alive(self._arrival_overlay_item):
            self._arrival_overlay_item = None
            return
        try:
            self.plot_widget.getPlotItem().removeItem(self._arrival_overlay_item)
        except Exception:
            pass
        self._arrival_overlay_item = None

    def _clear_all_seismogram_breaks(self) -> None:
        """Rimuove tutti i break dal sismogramma (e opzionalmente azzera il .fbp)."""
        if not self._arrival_markers:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Nessun break da cancellare",
                self,
                QtCore.QRect(),
                2000,
            )
            return
        if self.stream is None or len(self.stream) == 0:
            QtWidgets.QMessageBox.information(
                self,
                "Nessun sismogramma",
                "Apri un sismogramma prima di cancellare i break.",
            )
            return
        n_traces = len(self.stream)
        answer = QtWidgets.QMessageBox.question(
            self,
            "Cancellare tutti i break?",
            (
                f"Rimuovere tutti i {len(self._arrival_markers)} break "
                f"dal sismogramma ({n_traces} tracce)?\n\n"
                "Se esiste un file .fbp collegato, ogni traccia verrà scritta "
                "con tempo 0 (pick mancante, ignorato nei reciproci)."
            ),
            QtWidgets.QMessageBox.StandardButton.Yes
            | QtWidgets.QMessageBox.StandardButton.No,
            QtWidgets.QMessageBox.StandardButton.No,
        )
        if answer != QtWidgets.QMessageBox.StandardButton.Yes:
            return
        self._break_undo_push()
        path = self._active_fbp_path
        if path is None:
            path = self._ensure_active_fbp_path()
        self._clear_break_zone_gain_display()
        if getattr(self, "act_break_ruler", None) is not None:
            self.act_break_ruler.blockSignals(True)
            self.act_break_ruler.setChecked(False)
            self.act_break_ruler.blockSignals(False)
        self._break_ruler_enabled = False
        self._clear_break_ruler_preview()
        self._arrival_markers.clear()
        self._arrival_base_times.clear()
        self._last_right_track = None
        self._last_right_y = None
        self._detach_arrival_overlay()
        win = self._fbp_velocity_window_ref()
        if path is not None and win is not None:
            win.clear_series_breaks(path)
        if path is not None:
            ok, _n_lines = self._write_fbp_from_break_map(path, n_traces, {})
            if ok:
                self._fbp_autosave_dirty_traces.clear()
                self._fbp_monitor_dirty_traces.clear()
                self._active_fbp_path = path
                if win is not None:
                    win._invalidate_reciprocal_pairs_cache()
                self._broadcast_fbp_changed(path)
                self._set_fbp_sync_status(
                    "break rimossi — .fbp con pick mancanti (0)",
                    tone="ok",
                    path=path,
                )
            else:
                # Memoria già vuota: marca dirty così un flush successivo riprova.
                self._fbp_autosave_dirty_traces.update(range(n_traces))
                QtWidgets.QMessageBox.warning(
                    self,
                    "Salvataggio .fbp",
                    f"Break rimossi in memoria ma scrittura file non riuscita:\n{path}",
                )
        else:
            self._fbp_autosave_dirty_traces.clear()
            self._fbp_monitor_dirty_traces.clear()
            self._set_fbp_sync_status("break rimossi (solo memoria)", tone="ok")
        self._schedule_deferred_monitor_grid_refresh(immediate=True, force=True)

    def _clear_break_markers(self) -> None:
        self._fbp_autosave_dirty_traces.clear()
        self._fbp_monitor_dirty_traces.clear()
        self._clear_break_ruler_preview()
        if getattr(self, "act_break_ruler", None) is not None:
            self.act_break_ruler.blockSignals(True)
            self.act_break_ruler.setChecked(False)
            self.act_break_ruler.blockSignals(False)
        self._break_ruler_enabled = False
        self._arrival_markers.clear()
        self._arrival_base_times.clear()
        self._last_right_track = None
        self._last_right_y = None
        self._break_undo_stack.clear()
        self._detach_arrival_overlay()

    def _break_undo_push(self) -> None:
        markers = dict(self._arrival_markers)
        base_times = dict(self._arrival_base_times)
        if self._break_undo_stack:
            last_m, last_b = self._break_undo_stack[-1]
            if last_m == markers and last_b == base_times:
                return
        self._break_undo_stack.append((markers, base_times))
        while len(self._break_undo_stack) > self._break_undo_max:
            self._break_undo_stack.pop(0)

    def _break_ms_shift_step(self) -> float:
        spin = getattr(self, "break_ms_shift_spin", None)
        if spin is None:
            return 1.0
        return max(0.001, float(spin.value()))

    def _break_trace_shift_step(self) -> int:
        spin = getattr(self, "break_trace_shift_spin", None)
        if spin is None:
            return 1
        return max(1, int(spin.value()))

    def _nudge_hover_break_by_ms(
        self, delta_ms: float, *, push_undo: bool = True
    ) -> bool:
        """Sposta solo il break della traccia verde (hover) di Δ ms."""
        if abs(float(delta_ms)) < 1e-12:
            return False
        if self.stream is None or len(self.stream) == 0:
            return False
        track_idx = getattr(self, "_hover_track_idx", None)
        if track_idx is None:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Passa il mouse sulla traccia per spostare il suo break",
                self,
                QtCore.QRect(),
                2000,
            )
            return False
        track_idx = int(track_idx)
        if track_idx < 0 or track_idx >= len(self.stream):
            return False
        t_val = self._arrival_markers.get(track_idx)
        if t_val is None:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                f"Nessun break sulla traccia {track_idx + 1}",
                self,
                QtCore.QRect(),
                2000,
            )
            return False
        new_t = self._clamp_time_value(float(t_val) + float(delta_ms))
        new_t = max(0.0, new_t)
        if abs(new_t - float(t_val)) < 1e-9:
            return False
        if push_undo:
            self._break_undo_push()
        self._hover_break_nudge_active = True
        self._set_trace_scene_cache(True)
        self._arrival_markers[track_idx] = new_t
        self._arrival_base_times[track_idx] = new_t
        self._mark_fbp_traces_dirty([track_idx])
        self._clear_break_zone_gain_display()
        self._ensure_break_overlay_structure()
        self._throttle_break_overlay_paint()
        self._on_seismogram_markers_changed(update_status=True, immediate_sync=False)
        label = f"Traccia: {track_idx + 1} · break {new_t:.2f} ms"
        self._track_label.setText(label)
        self._last_track_label_idx = track_idx
        return True

    def _nudge_hover_break_by_traces(
        self, delta_traces: int, *, push_undo: bool = True
    ) -> bool:
        """Sposta il break della traccia verde (hover) di Δ tracce."""
        if int(delta_traces) == 0:
            return False
        if self.stream is None or len(self.stream) == 0:
            return False
        track_idx = getattr(self, "_hover_track_idx", None)
        if track_idx is None:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Passa il mouse sulla traccia per spostare il suo break",
                self,
                QtCore.QRect(),
                2000,
            )
            return False
        src = int(track_idx)
        n_traces = len(self.stream)
        if src < 0 or src >= n_traces:
            return False
        t_val = self._arrival_markers.get(src)
        if t_val is None:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                f"Nessun break sulla traccia {src + 1}",
                self,
                QtCore.QRect(),
                2000,
            )
            return False
        dst = src + int(delta_traces)
        if dst < 0 or dst >= n_traces:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Limite traccia raggiunto",
                self,
                QtCore.QRect(),
                1500,
            )
            return False
        if dst in self._arrival_markers and dst != src:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                f"Traccia {dst + 1} ha già un break",
                self,
                QtCore.QRect(),
                2000,
            )
            return False
        if push_undo:
            self._break_undo_push()
        self._hover_break_nudge_active = True
        self._set_trace_scene_cache(True)
        new_t = float(t_val)
        base_t = float(self._arrival_base_times.get(src, t_val))
        del self._arrival_markers[src]
        self._arrival_base_times.pop(src, None)
        self._arrival_markers[dst] = new_t
        self._arrival_base_times[dst] = base_t
        self._mark_fbp_traces_dirty([src, dst])
        self._clear_break_zone_gain_display()
        self._ensure_break_overlay_structure()
        self._throttle_break_overlay_paint()
        self._hover_track_idx = dst
        self._apply_trace_curve_style(src)
        self._apply_trace_curve_style(dst)
        self._on_seismogram_markers_changed(update_status=True, immediate_sync=False)
        label = f"Traccia: {dst + 1} · break {new_t:.2f} ms"
        self._track_label.setText(label)
        self._last_track_label_idx = dst
        return True

    def _finish_hover_break_nudge_gesture(self) -> None:
        if not getattr(self, "_hover_break_nudge_active", False):
            return
        self._hover_break_nudge_active = False
        self._set_trace_scene_cache(False)
        self._break_ov_throttle_timer.stop()
        self._break_ov_deferred = False
        self._rebuild_arrival_overlay()
        QtCore.QTimer.singleShot(0, self._sync_monitor_after_break_gesture)

    def _shift_arrival_markers_in_memory(self, delta_ms: float) -> bool:
        """Sposta i break in memoria senza undo né messaggi (uso interno)."""
        if abs(float(delta_ms)) < 1e-12 or not self._arrival_markers:
            return False
        if self.stream is None or len(self.stream) == 0:
            return False
        lo, hi = self._time_axis_limits()
        changed = False
        for idx, t_val in list(self._arrival_markers.items()):
            if idx < 0 or idx >= len(self.stream):
                continue
            new_t = float(t_val) + float(delta_ms)
            new_t = float(max(lo, min(hi, new_t)))
            new_t = max(0.0, new_t)
            if abs(new_t - float(t_val)) < 1e-9:
                continue
            self._arrival_markers[idx] = new_t
            self._arrival_base_times[idx] = new_t
            changed = True
        if changed:
            self._mark_all_fbp_traces_dirty()
        return changed

    def _shift_all_breaks_by_ms(self, delta_ms: float, *, push_undo: bool = True) -> None:
        """Sposta tutti i break di N millisecondi (asse tempo del grafico)."""
        if abs(float(delta_ms)) < 1e-12:
            return
        if self.stream is None or len(self.stream) == 0:
            QtWidgets.QMessageBox.information(
                self,
                "Nessun sismogramma",
                "Apri un sismogramma prima di spostare i break.",
            )
            return
        if not self._arrival_markers:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Nessun break da spostare",
                self,
                QtCore.QRect(),
                2000,
            )
            return
        if push_undo:
            self._break_undo_push()
        changed = self._shift_arrival_markers_in_memory(float(delta_ms))
        if not changed:
            if push_undo and self._break_undo_stack:
                self._break_undo_stack.pop()
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Nessun break spostabile (limite asse tempo)",
                self,
                QtCore.QRect(),
                2500,
            )
            return
        self._shift_breaks_gesture_active = True
        self._set_trace_scene_cache(True)
        self._mark_all_fbp_traces_dirty()
        self._clear_break_zone_gain_display()
        self._ensure_break_overlay_structure()
        self._throttle_break_overlay_paint()
        self._on_seismogram_markers_changed(immediate_sync=False)

    def _shift_all_breaks_by_traces(
        self, delta_traces: int, *, push_undo: bool = True
    ) -> None:
        """Sposta tutti i break di N tracce (asse orizzontale del grafico)."""
        if delta_traces == 0:
            return
        if self.stream is None or len(self.stream) == 0:
            QtWidgets.QMessageBox.information(
                self,
                "Nessun sismogramma",
                "Apri un sismogramma prima di spostare i break.",
            )
            return
        if not self._arrival_markers:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Nessun break da spostare",
                self,
                QtCore.QRect(),
                2000,
            )
            return
        n_traces = len(self.stream)
        if push_undo:
            self._break_undo_push()
        new_markers: dict[int, float] = {}
        new_base: dict[int, float] = {}
        for idx, t_val in self._arrival_markers.items():
            new_idx = int(idx) + int(delta_traces)
            if new_idx < 0 or new_idx >= n_traces:
                continue
            new_markers[new_idx] = float(t_val)
            new_base[new_idx] = float(self._arrival_base_times.get(idx, t_val))
        if new_markers == self._arrival_markers:
            if push_undo and self._break_undo_stack:
                self._break_undo_stack.pop()
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Nessun break spostabile (limite traccia)",
                self,
                QtCore.QRect(),
                2500,
            )
            return
        self._arrival_markers.clear()
        self._arrival_markers.update(new_markers)
        self._arrival_base_times.clear()
        self._arrival_base_times.update(new_base)
        self._shift_breaks_gesture_active = True
        self._set_trace_scene_cache(True)
        self._mark_all_fbp_traces_dirty()
        self._clear_break_zone_gain_display()
        self._ensure_break_overlay_structure()
        self._throttle_break_overlay_paint()
        self._on_seismogram_markers_changed(immediate_sync=False)

    def _finish_shift_breaks_gesture(self) -> None:
        if not getattr(self, "_shift_breaks_gesture_active", False):
            return
        self._shift_breaks_gesture_active = False
        self._set_trace_scene_cache(False)
        self._break_ov_throttle_timer.stop()
        self._break_ov_deferred = False
        self._rebuild_arrival_overlay()
        QtCore.QTimer.singleShot(0, self._sync_monitor_after_break_gesture)

    def _apply_break_key_x(self) -> None:
        """
        X: su ogni traccia che ha un break, sposta il pick al tempo positivo
        più vicino al break attuale (dati completi traccia).
        """
        if self.stream is None or len(self.stream) == 0:
            return
        n = len(self.stream)
        keys = [k for k in self._arrival_markers if 0 <= k < n]
        if not keys:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Nessun break: inseriscine almeno uno col tasto destro",
                self,
                QtCore.QRect(),
                3000,
            )
            return
        lo, hi = self._time_axis_limits()
        self._break_undo_push()
        payload = self._cache_worker_payload(None)
        payload["marker_keys"] = keys
        payload["markers"] = dict(self._arrival_markers)
        payload["time_limits"] = (float(lo), float(hi))
        self._gui_worker.submit(
            "snap_breaks",
            payload,
            extra={"stream_epoch": int(getattr(self, "_stream_epoch", 0))},
        )

    def _marker_time_for_export(self, track_idx: int, stored_value: float) -> float:
        del track_idx
        return max(0.0, float(stored_value))

    @staticmethod
    def _format_export_value(value: float) -> str:
        v = float(value)
        if not math.isfinite(v):
            return "0"
        text = f"{v:.8f}".rstrip("0").rstrip(".")
        return text or "0"

    @staticmethod
    def _format_fbp_time_ms(value: float) -> str:
        return format_fbp_time_ms(value)

    @staticmethod
    def _avoid_equal_consecutive_times(times: list[float]) -> list[float]:
        if not times:
            return []
        out = [float(times[0])]
        for i in range(1, len(times)):
            t = float(times[i])
            if abs(t - out[-1]) < 1e-9:
                t = max(0.0, t - 0.01)
            out.append(t)
        return out

    def _trace_dt_seconds(self, track_idx: int) -> float:
        """Intervallo di campionamento (s) coerente con l'asse tempo del plot."""
        if self.stream is None or track_idx < 0 or track_idx >= len(self.stream):
            return 1e-3
        trace = self.stream[track_idx]
        dt = float(getattr(trace.stats, "delta", 0.0) or 0.0)
        if dt <= 0:
            seg2 = getattr(trace.stats, "seg2", None) or {}
            try:
                dt = float(seg2.get("SAMPLE_INTERVAL", 0.0) or 0.0)
            except (TypeError, ValueError):
                dt = 0.0
        if dt <= 0:
            dt = 1e-3
        return dt

    def _trace_dt_ms(self, track_idx: int) -> float:
        return self._trace_dt_seconds(track_idx) * 1000.0

    def _samples_from_time(self, track_idx: int, time_ms: float) -> int:
        """Indice campione 0-based: campione i ha tempo i * dt_ms (come nel plot)."""
        if self.stream is None or track_idx < 0 or track_idx >= len(self.stream):
            return 0
        dt_ms = self._trace_dt_ms(track_idx)
        npts = int(np.asarray(self.stream[track_idx].data).size)
        max_idx = max(0, npts - 1)
        sample_idx = int(round(float(time_ms) / dt_ms))
        return int(max(0, min(sample_idx, max_idx)))

    def _time_from_samples(self, track_idx: int, sample_idx: int) -> float:
        return time_from_samples_ms(self._trace_dt_ms(track_idx), sample_idx)

    @staticmethod
    def _break_channel_number(track_idx: int) -> int:
        """Numero canale/traccia 1-based (come etichetta «Traccia: N»)."""
        return int(track_idx) + 1

    def _copy_break_times_to_clipboard(self) -> None:
        """
        Come v5: tempi break rispetto al minimo, una riga per traccia con break
        (ordine per indice); avviso se mancano break su alcune tracce.
        """
        if self.stream is None:
            return
        if not self._arrival_markers:
            QtWidgets.QMessageBox.information(
                self,
                "Nessun break",
                "Non ci sono break da copiare.",
            )
            return
        n_traces = len(self.stream)
        missing = [i + 1 for i in range(n_traces) if i not in self._arrival_markers]
        if missing:
            msg = "Le seguenti tracce non hanno un break inserito:\n\n"
            if len(missing) <= 30:
                msg += ", ".join(str(t) for t in missing)
            else:
                msg += ", ".join(str(t) for t in missing[:25])
                msg += f", ... e altre {len(missing) - 25} tracce."
            msg += "\n\nI tempi copiati riguardano solo le tracce con break."
            QtWidgets.QMessageBox.warning(
                self,
                "Tracce senza break",
                msg,
            )
        idx_sorted = sorted(self._arrival_markers.keys())
        break_map: dict[int, float] = {}
        raw_times: list[float] = []
        for idx in idx_sorted:
            stored = self._arrival_markers.get(idx)
            if stored is None:
                continue
            export_time = self._marker_time_for_export(idx, float(stored))
            break_map[idx] = export_time
            raw_times.append(export_time)
        if not raw_times:
            return
        raw_times = self._avoid_equal_consecutive_times(raw_times)
        t_min = min(raw_times)
        times = [self._format_export_value(t - t_min) for t in raw_times]
        text = "\n".join(times)
        QtWidgets.QApplication.clipboard().setText(text)

    def _build_fbp_lines_from_break_map(
            self,
            n_traces: int,
            break_map: dict[int, float],
            *,
            sample_source: Path | None = None,
            preserved_samples: dict[int, int] | None = None,
            linked_fbp: bool | None = None,
        ) -> list[str]:
            if n_traces <= 0:
                return []
            samples: dict[int, int] = {}
            if preserved_samples:
                samples = dict(preserved_samples)
            elif self.stream is None and sample_source is not None and sample_source.exists():
                samples = self._read_fbp_sample_column(sample_source)
            use_stream = self.stream is not None and (
                linked_fbp if linked_fbp is not None else True
            )
            return build_fbp_lines_from_break_map(
                n_traces,
                break_map,
                samples=samples,
                samples_from_time=self._samples_from_time,
                use_stream_samples=use_stream,
            )

    def _build_fbp_lines_from_markers(self, path: Path | None = None) -> list[str]:
        sample_source = path or self._active_fbp_path
        n_traces = self._fbp_target_n_traces(sample_source)
        break_map: dict[int, float] = {}
        for idx, stored in self._arrival_markers.items():
            ti = int(idx)
            if ti < 0:
                continue
            if n_traces > 0 and ti >= n_traces:
                continue
            break_map[ti] = self._marker_time_for_export(ti, float(stored))
        if n_traces <= 0:
            if not break_map:
                return []
            n_traces = max(break_map.keys()) + 1
        return self._build_fbp_lines_from_break_map(
            n_traces,
            break_map,
            sample_source=sample_source,
        )

    def _missing_break_indices(self) -> list[int]:
        if self.stream is not None:
            n_traces = len(self.stream)
        elif self._arrival_markers:
            n_traces = max(self._arrival_markers.keys()) + 1
        else:
            return []
        if n_traces <= 0:
            return []
        return [idx for idx in range(n_traces) if idx not in self._arrival_markers]

    def _confirm_save_with_missing_breaks(self, *, context: str) -> bool:
        missing = self._missing_break_indices()
        if not missing:
            return True
        warn_max = int(getattr(self, "_missing_break_warn_max", 5))
        if len(missing) > warn_max:
            # Molti pick assenti: scelta intenzionale (rumore ecc.) — salva senza popup.
            return True
        n_traces = len(self.stream) if self.stream is not None else missing[-1] + 1
        sample = ", ".join(str(idx + 1) for idx in missing)
        answer = QtWidgets.QMessageBox.warning(
            self,
            "Break incompleti",
            (
                f"{context}\n\n"
                f"Mancano {len(missing)} break su {n_traces} tracce "
                f"(senza pick: {sample}).\n\n"
                "Le tracce senza break verranno salvate con tempo 0 "
                "(pick mancante: ignorato nel controllo reciproci).\n\n"
                "Salvare comunque?"
            ),
            QtWidgets.QMessageBox.StandardButton.Yes
            | QtWidgets.QMessageBox.StandardButton.No,
            QtWidgets.QMessageBox.StandardButton.No,
        )
        return answer == QtWidgets.QMessageBox.StandardButton.Yes

    def _write_fbp_from_break_map(
            self,
            path: Path,
            n_traces: int,
            break_map: dict[int, float],
        ) -> tuple[bool, int]:
            lines = self._build_fbp_lines_from_break_map(
                n_traces, break_map, sample_source=path
            )
            if not lines:
                return False, 0
            if not self._write_fbp_text(path, lines, n_traces=n_traces):
                return False, 0
            invalidate_fbp_parse_cache(path)
            return True, len(lines)

    def _write_markers_to_fbp_path(self, path: Path, *, refresh_monitor: bool = True) -> bool:
        patched = self._try_patch_markers_to_fbp_disk(path)
        if patched is True:
            if (
                refresh_monitor
                and getattr(self, "_fbp_autosync_enabled", True)
                and self._should_sync_dromocrona_monitor()
            ):
                self._sync_monitor_series_from_markers(path)
            if refresh_monitor:
                self._broadcast_fbp_changed(path)
            return True
        if patched is False:
            return False
        lines = self._build_fbp_lines_from_markers(path)
        if not lines:
            _LOG.warning(
                "Riscrittura completa .fbp impossibile (%s): nessuna riga generata — "
                "tentativo patch incrementale di emergenza",
                path,
            )
            # Ultimo tentativo: ri-prova la patch incrementale da disco
            patched2 = self._try_patch_markers_to_fbp_disk(path)
            if patched2 is True:
                return True
            return False
        if not self._write_fbp_text(path, lines):
            _LOG.warning("Scrittura .fbp fallita (%s) — riscrittura completa", path)
            return False
        invalidate_fbp_parse_cache(path)
        win = self._fbp_velocity_window_ref()
        if win is not None:
            series_idx = win.find_series_index(path)
            if series_idx is not None:
                m = win._series_meta[series_idx]
                m.pop("fbp_disk_lines", None)
                m.pop("fbp_line_by_trace", None)
        if (
            refresh_monitor
            and getattr(self, "_fbp_autosync_enabled", True)
            and self._should_sync_dromocrona_monitor()
        ):
            if self._fbp_is_linked_to_open_sgy(path) and self._is_active_fbp(path):
                self._sync_monitor_series_from_markers(path)
            else:
                self._refresh_monitor_series_from_fbp_file(path)
        self._fbp_autosave_dirty_traces.clear()
        self._broadcast_fbp_changed(path)
        return True

    def _write_breaks_to_path(self, path: Path) -> tuple[bool, int, str]:
        if self.stream is None and not self._arrival_markers:
            return False, 0, "Nessun break da esportare."
        lines = self._build_fbp_lines_from_markers(path)
        if not lines:
            return False, 0, "Nessun break da esportare."
        try:
            path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        except Exception as exc:
            return False, 0, f"{exc}"
        invalidate_fbp_parse_cache(path)
        self._active_fbp_path = path
        if self._should_sync_dromocrona_monitor():
            self._refresh_monitor_series_from_fbp_file(path)
        return True, len(lines), ""

    def _apply_break_smoothing_key_s(self) -> None:
        """
        S: smussa i break usando i vicini (traccia precedente/successiva con break),
        con correzione locale morbida e limite di spostamento (come siesview v6).
        """
        if self.stream is None or len(self.stream) == 0:
            return
        n = len(self.stream)
        keys = sorted(k for k in self._arrival_markers if 0 <= k < n)
        if len(keys) < 3:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Servono almeno 3 break per lo smusso (tasto S).",
                self,
                QtCore.QRect(),
                2500,
            )
            return

        lo, hi = self._time_axis_limits()

        def _clamp_t(t: float) -> float:
            return float(max(lo, min(hi, t)))

        smooth_alpha = 0.35
        max_shift_ms = 25.0
        min_delta_ms = 0.01

        original = {k: float(self._arrival_markers[k]) for k in keys}
        self._break_undo_push()
        changed_indices: list[int] = []

        for pos, idx in enumerate(keys):
            if pos == 0 or pos == len(keys) - 1:
                continue
            prev_idx = keys[pos - 1]
            next_idx = keys[pos + 1]
            if next_idx <= prev_idx:
                continue
            prev_t = original[prev_idx]
            cur_t = original[idx]
            next_t = original[next_idx]

            ratio = (idx - prev_idx) / float(next_idx - prev_idx)
            interp_t = prev_t + (next_t - prev_t) * ratio
            target_t = cur_t * (1.0 - smooth_alpha) + interp_t * smooth_alpha

            delta = float(np.clip(target_t - cur_t, -max_shift_ms, max_shift_ms))
            new_t = _clamp_t(cur_t + delta)
            if abs(new_t - cur_t) >= min_delta_ms:
                self._arrival_markers[idx] = new_t
                self._arrival_base_times[idx] = max(0.0, new_t)
                changed_indices.append(idx)

        if not changed_indices:
            if self._break_undo_stack:
                self._break_undo_stack.pop()
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Smusso: nessuna modifica utile sui break.",
                self,
                QtCore.QRect(),
                2200,
            )
            return

        self._mark_fbp_traces_dirty(changed_indices)
        self._clear_break_zone_gain_display()
        self._rebuild_arrival_overlay()
        self._on_seismogram_markers_changed(immediate_sync=True)
        QtWidgets.QToolTip.showText(
            QtGui.QCursor.pos(),
            f"Smusso break applicato: {len(changed_indices)} tracce aggiornate.",
            self,
            QtCore.QRect(),
            2200,
        )

    def _apply_break_key_c(self) -> None:
        """C: annulla l'ultimo X (ripristina markers/base_times precedenti)."""
        if not self._break_undo_stack:
            QtWidgets.QToolTip.showText(
                QtGui.QCursor.pos(),
                "Niente da annullare (premi X per modificare i break)",
                self,
                QtCore.QRect(),
                2000,
            )
            return
        m, b = self._break_undo_stack.pop()
        self._arrival_markers.clear()
        self._arrival_base_times.clear()
        self._arrival_markers.update(m)
        self._arrival_base_times.update(b)
        self._mark_all_fbp_traces_dirty()
        self._clear_break_zone_gain_display()
        self._rebuild_arrival_overlay()
        self._on_seismogram_markers_changed(immediate_sync=True)

    def _prune_break_markers(self, n_traces: int) -> None:
        self._arrival_markers = {
            i: v for i, v in self._arrival_markers.items() if 0 <= i < n_traces
        }
        self._arrival_base_times = {
            i: v for i, v in self._arrival_base_times.items() if 0 <= i < n_traces
        }

    def _refresh_break_overlay_paint(self) -> None:
        ov = getattr(self, "_arrival_overlay_item", None)
        if ov is None or not self._qt_wrapper_alive(ov):
            if ov is not None:
                self._arrival_overlay_item = None
            return
        try:
            if ov.isVisible():
                ov.prepareGeometryChange()
                ov.update()
        except RuntimeError:
            self._arrival_overlay_item = None

    def _filter_dialog_trace_sample(self) -> np.ndarray:
        if self.stream is None or len(self.stream) == 0:
            return np.zeros(256, dtype=np.float64)
        return np.asarray(self.stream[0].data, dtype=np.float64)

    def _sync_filter_dialog_from_stream(self) -> None:
        dlg = getattr(self, "_filter_dialog", None)
        if dlg is None or self.stream is None or len(self.stream) == 0:
            return
        try:
            if not dlg.isVisible():
                return
        except RuntimeError:
            self._filter_dialog = None
            return
        try:
            dlg.configure_from_stream(
                self._stream_sampling_rate_hz(),
                self._filter_dialog_trace_sample(),
            )
        except Exception:
            pass

    def _save_perf_report(self) -> None:
        path = flush_report(note="menu_save")
        if path is None:
            QtWidgets.QMessageBox.information(
                self,
                "Profiler disattivato",
                "Imposta PROGEOVIEW_PERF=1 (default) per abilitare il report.",
            )
            return
        QtWidgets.QMessageBox.information(
            self,
            "Report prestazioni",
            f"Report aggiornato:\n{path}",
        )

    def _open_trace_display_dialog(self) -> None:
        existing = getattr(self, "_trace_display_dialog", None)
        if existing is not None:
            try:
                if existing.isVisible():
                    existing._load_from_viewer()
                    existing.raise_()
                    existing.activateWindow()
                    return
            except RuntimeError:
                self._trace_display_dialog = None
        dlg = TraceDisplayDialog(self, parent=self)
        dlg.finished.connect(self._on_trace_display_dialog_closed)
        self._trace_display_dialog = dlg
        dlg.show()

    def _on_trace_display_dialog_closed(self, _result: int) -> None:
        self._trace_display_dialog = None

    def _update_filter_restore_action_state(self) -> None:
        enabled = bool(getattr(self, "_filter_params_active", None))
        dlg = getattr(self, "_filter_dialog", None)
        if dlg is None:
            return
        try:
            dlg.set_restore_enabled(enabled)
        except RuntimeError:
            self._filter_dialog = None

    def _restore_unfiltered_stream(self) -> None:
        raw = getattr(self, "_raw_stream", None)
        if raw is None or self.stream is None:
            QtWidgets.QMessageBox.information(
                self,
                "Ripristino filtro",
                "Carica un sismogramma prima di ripristinare il segnale grezzo.",
            )
            return
        if not getattr(self, "_filter_params_active", None):
            QtWidgets.QMessageBox.information(
                self,
                "Ripristino filtro",
                "Nessun filtro attivo sul sismogramma corrente.",
            )
            return
        self._gui_worker.invalidate("apply_filter")
        self.stream = copy_stream(raw)
        self._filter_params_active = None
        self._update_filter_restore_action_state()
        self._invalidate_plot_cache(reset_graphics=True, reset_view=False)
        self._build_plot_cache(follow_up="replot_if_possible")
        self._rebuild_arrival_overlay()
        dialog = getattr(self, "_filter_dialog", None)
        if dialog is not None:
            try:
                dialog.set_apply_status("Segnale grezzo ripristinato.", error=False)
                dialog._on_refresh_clicked()
            except RuntimeError:
                self._filter_dialog = None

    def _open_filter_dialog(self) -> None:
        if filter_module is None:
            QtWidgets.QMessageBox.warning(
                self,
                "Filtro non disponibile",
                "Modulo filtri (core/filter.py) non disponibile.",
            )
            return
        if self.stream is None or len(self.stream) == 0:
            QtWidgets.QMessageBox.information(
                self,
                "Nessun dato",
                "Carica un sismogramma prima di applicare un filtro.",
            )
            return
        existing = getattr(self, "_filter_dialog", None)
        sampling_rate_hz = self._stream_sampling_rate_hz()
        tr0 = self._filter_dialog_trace_sample()
        if existing is not None:
            try:
                if existing.isVisible():
                    existing.configure_from_stream(sampling_rate_hz, tr0)
                    existing.set_agc_state(self._agc_enabled(), self._agc_window_ms())
                    existing.set_restore_enabled(
                        bool(getattr(self, "_filter_params_active", None))
                    )
                    existing.raise_()
                    existing.activateWindow()
                    return
            except RuntimeError:
                self._filter_dialog = None
        dlg = FilterDialog(
            sampling_rate_hz,
            parent=self,
            trace_data=tr0,
            get_trace_data=self._filter_dialog_trace_sample,
            get_sampling_rate_hz=self._stream_sampling_rate_hz,
        )
        dlg.configure_from_stream(
            sampling_rate_hz,
            tr0,
            reset_frequencies=True,
        )
        dlg.set_agc_state(self._agc_enabled(), self._agc_window_ms())
        dlg.set_restore_enabled(bool(getattr(self, "_filter_params_active", None)))
        dlg.agc_enabled_changed.connect(self._on_filter_dialog_agc_enabled)
        dlg.agc_window_ms_changed.connect(self._on_filter_dialog_agc_window)
        dlg.restore_raw_requested.connect(self._restore_unfiltered_stream)
        dlg.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.apply_requested.connect(lambda: self._apply_filter(dlg.get_params(), dialog=dlg))
        dlg.finished.connect(self._on_filter_dialog_closed)
        self._filter_dialog = dlg
        dlg.show()

    def _on_filter_dialog_agc_enabled(self, enabled: bool) -> None:
        checkbox = getattr(self, "agc_checkbox", None)
        if checkbox is None:
            return
        if bool(checkbox.isChecked()) == bool(enabled):
            return
        checkbox.setChecked(bool(enabled))

    def _on_filter_dialog_agc_window(self, window_ms: float) -> None:
        spin = getattr(self, "agc_window_spin", None)
        if spin is None:
            return
        if abs(float(spin.value()) - float(window_ms)) < 1e-9:
            return
        spin.setValue(float(window_ms))

    def _sync_filter_dialog_agc(self) -> None:
        dlg = getattr(self, "_filter_dialog", None)
        if dlg is None:
            return
        try:
            dlg.set_agc_state(self._agc_enabled(), self._agc_window_ms())
        except RuntimeError:
            self._filter_dialog = None

    def _on_filter_dialog_closed(self, _result: int = 0) -> None:
        if getattr(self, "_filter_dialog", None) is self.sender():
            self._filter_dialog = None

    def _apply_filter(
            self,
            params: dict,
            *,
            dialog: FilterDialog | None = None,
        ) -> None:
            if filter_module is None or self.stream is None:
                return
            if dialog is not None:
                dialog.set_apply_status("Filtro in corso…", error=False)
            payload = self._cache_worker_payload(None)
            payload["filter_params"] = dict(params)
            payload["raw_stream"] = self._raw_stream
            self._gui_worker.submit(
                "apply_filter",
                payload,
                extra={
                    "dialog": dialog,
                    "filter_params": dict(params),
                    "stream_epoch": int(getattr(self, "_stream_epoch", 0)),
                },
            )
