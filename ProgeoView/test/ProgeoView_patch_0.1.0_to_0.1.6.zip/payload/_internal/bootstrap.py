"""Percorsi di import condivisi per tutti gli entry point ProgeoView."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path


def is_frozen() -> bool:
    """True se l'app gira come eseguibile PyInstaller (onefile o onedir)."""
    return bool(getattr(sys, "frozen", False))


def _silence_platform_syscmd_ver() -> None:
    """Evita ``cmd /c ver`` di platform.win32_ver() (flash console con exe windowed)."""
    if not sys.platform.startswith("win"):
        return
    try:
        import platform
    except Exception:
        return
    if getattr(platform, "_progeo_syscmd_ver_patched", False):
        return

    def _syscmd_ver(*_args, **_kwargs):  # type: ignore[no-untyped-def]
        try:
            winver = sys.getwindowsversion()
            version = f"{winver.major}.{winver.minor}.{winver.build}"
            return "Windows", str(winver.major), version, ""
        except Exception:
            return "", "", "", ""

    platform._syscmd_ver = _syscmd_ver  # type: ignore[assignment]
    platform._progeo_syscmd_ver_patched = True  # type: ignore[attr-defined]


def suppress_subprocess_console_windows() -> None:
    """
    Evita il flash della console Windows all'avvio (exe windowed).

    Cause tipiche:
    - platform.win32_ver() → ``cmd /c ver`` (via numpy.testing)
    - ObsPy get_git_version() → ``git rev-parse`` / ``git describe``
    """
    if not sys.platform.startswith("win"):
        return
    _silence_platform_syscmd_ver()
    if getattr(subprocess, "_progeo_no_console_patched", False):
        return

    create_no_window = int(getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
    orig_init = subprocess.Popen.__init__

    def _popen_init(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        cmd = args[0] if args else kwargs.get("args")
        # In build frozen ObsPy non è un checkout git: salta i probe inutili.
        if is_frozen() and isinstance(cmd, (list, tuple)) and cmd:
            exe = str(cmd[0]).lower()
            if exe in {"git", "git.exe"} or exe.endswith("\\git.exe"):
                raise FileNotFoundError(cmd[0])
        # Anche ``shell=True`` → cmd.exe: nascondi sempre la console.
        flags = int(kwargs.get("creationflags") or 0)
        kwargs["creationflags"] = flags | create_no_window
        if kwargs.get("shell") or (
            isinstance(cmd, str) and not isinstance(cmd, (list, tuple))
        ):
            # shell=True crea comunque cmd.exe; STARTF_USESHOWWINDOW riduce il flash.
            pass
        si = kwargs.get("startupinfo")
        if si is None and hasattr(subprocess, "STARTUPINFO"):
            si = subprocess.STARTUPINFO()
            kwargs["startupinfo"] = si
        if si is not None and hasattr(subprocess, "STARTF_USESHOWWINDOW"):
            si.dwFlags |= int(subprocess.STARTF_USESHOWWINDOW)
            si.wShowWindow = 0  # SW_HIDE
        return orig_init(self, *args, **kwargs)

    subprocess.Popen.__init__ = _popen_init  # type: ignore[method-assign]
    subprocess._progeo_no_console_patched = True  # type: ignore[attr-defined]


# Prima di qualsiasi import che possa spawnare cmd/git (numpy/obspy).
suppress_subprocess_console_windows()

# Solo Windows 10: WebEngine/Chromium a volte crasha con GPU driver vecchi.
# Su Windows 11 (build >= 22000) non tocchiamo nulla.
if (
    sys.platform.startswith("win")
    and "QTWEBENGINE_CHROMIUM_FLAGS" not in os.environ
):
    try:
        _build = int(sys.getwindowsversion().build)
    except Exception:
        _build = 0
    if 0 < _build < 22000:
        os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (
            "--disable-gpu --disable-gpu-compositing "
            "--disable-features=CalculateNativeWinOcclusion"
        )

def bundle_root() -> Path:
    """Directory dei file impacchettati (sola lettura in release)."""
    if is_frozen():
        return Path(getattr(sys, "_MEIPASS"))
    return Path(__file__).resolve().parent


def install_root() -> Path:
    """Directory installazione (accanto all'exe in release; spesso sola lettura)."""
    if is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def _user_data_root() -> Path:
    """Directory scrivibile per dati utente (AppData su Windows)."""
    if sys.platform.startswith("win"):
        base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
        if base:
            return Path(base) / "ProgeoView"
    # Linux/macOS / fallback
    return Path.home() / ".progeoview"


def _dir_is_writable(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".write_probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        return True
    except OSError:
        return False


# Compatibilità codice esistente
PROJECT_ROOT = install_root()
VIEWER_DIR = bundle_root() / "viewer" if is_frozen() else PROJECT_ROOT / "viewer"
CROSS_DIR = bundle_root() / "cross" if is_frozen() else PROJECT_ROOT / "cross"

_PATHS = (str(bundle_root()), str(VIEWER_DIR), str(CROSS_DIR))


def config_dir(*, create: bool = True) -> Path:
    """
    Cartella config utente persistente.

    - override: env ``PROGEOVIEW_CONFIG_DIR`` (test / deploy custom)
    - sviluppo: {progetto}/config
    - installato (frozen): %LOCALAPPDATA%\\ProgeoView\\config
      (Program Files non è scrivibile senza admin)
    """
    override = (os.environ.get("PROGEOVIEW_CONFIG_DIR") or "").strip()
    if override:
        path = Path(override)
        if create:
            path.mkdir(parents=True, exist_ok=True)
        return path

    if is_frozen():
        path = _user_data_root() / "config"
    else:
        # In dev preferisci config nel repo; se non scrivibile → AppData.
        candidate = install_root() / "config"
        if create:
            if _dir_is_writable(candidate):
                return candidate
            path = _user_data_root() / "config"
        else:
            path = candidate if candidate.is_dir() else (_user_data_root() / "config")
            return path
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def seed_user_config() -> None:
    """Copia i template di config dal bundle alla cartella utente (solo se mancanti)."""
    try:
        target = config_dir(create=True)
    except OSError:
        return
    sources: list[Path] = []
    bundle_cfg = bundle_root() / "config"
    if bundle_cfg.is_dir():
        sources.append(bundle_cfg)
    # Eventuali template lasciati in Program Files dall'installer (sola lettura).
    install_cfg = install_root() / "config"
    if install_cfg.is_dir() and install_cfg.resolve() != bundle_cfg.resolve():
        sources.append(install_cfg)
    for source in sources:
        for item in source.iterdir():
            if not item.is_file():
                continue
            dest = target / item.name
            if dest.exists():
                continue
            try:
                shutil.copy2(item, dest)
            except OSError:
                continue


def setup_project_paths() -> Path:
    """Aggiunge le directory del progetto a sys.path (idempotente)."""
    suppress_subprocess_console_windows()
    try:
        seed_user_config()
    except OSError:
        # Non bloccare l'avvio se la config non è scrivibile.
        pass
    # Migra update.json AppData (es. example.com rimasto dopo uninstall).
    try:
        from updater.version_service import migrate_update_settings

        migrate_update_settings()
    except Exception:
        pass
    for entry in _PATHS:
        if entry not in sys.path:
            sys.path.insert(0, entry)
    return install_root()
