"""Griglia dromocrone stile foglio Excel per il monitor FBP."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

from PyQt6 import QtCore, QtGui, QtWidgets

from export.dromocrona_fbp_export import run_dromocrona_grid_export_dialog
from siesview_reciprocal_analysis import (
    DEFAULT_RECIPROCAL_TOLERANCE_BANDS,
    ReciprocalGridCellMark,
    ReciprocalToleranceBands,
    format_reciprocal_cell_tooltip,
    reciprocal_grid_marks_from_pairs,
)
from dromocrona_grid_data import (
    DromocronaGridData,
    build_dromocrona_grid_data,
    format_dromocrona_ms_display,
    remap_reciprocal_pairs_to_grid_columns,
    short_column_label,
    sort_series_meta_by_file_order,
)

# Re-export pubblico.
__all__ = [
    "DromocronaGridData",
    "DromocronaGridTable",
    "DromocronaGridWindow",
    "ReciprocalToleranceBandsDialog",
    "build_dromocrona_grid_data",
    "run_dromocrona_grid_export_dialog",
]

_RECIPROCAL_OK_BG = QtGui.QColor("#dcfce7")
_RECIPROCAL_OK_FG = QtGui.QColor("#166534")
_RECIPROCAL_FAIL_BG = QtGui.QColor("#ef4444")
_RECIPROCAL_FAIL_FG = QtGui.QColor("#ffffff")

_GRID_FONT_PX = 10
_GRID_NUM_FONT_PX = 9
_GRID_ROW_HEIGHT_PX = 18
_GRID_COL_MIN_PX = 44
_GRID_COL_DEFAULT_PX = 58
_GRID_ZOOM_MIN = 0.6
_GRID_ZOOM_MAX = 2.5
_GRID_ZOOM_STEP = 0.1


def _table_style(font_px: int) -> str:
    return f"""
QTableWidget {{
  background: #ffffff;
  color: #1a1a1a;
  gridline-color: #c8c8c8;
  border: 1px solid #a0a0a0;
  font-family: "Segoe UI", "Calibri", sans-serif;
  font-size: {font_px}px;
  selection-background-color: #cce4f7;
  selection-color: #1a1a1a;
}}
QHeaderView::section {{
  background: #f2f2f2;
  color: #333333;
  padding: 2px 4px;
  border: none;
  border-right: 1px solid #c8c8c8;
  border-bottom: 1px solid #c8c8c8;
  font-size: {font_px}px;
  font-weight: 600;
}}
QTableCornerButton::section {{
  background: #f2f2f2;
  border: none;
  border-right: 1px solid #c8c8c8;
  border-bottom: 1px solid #c8c8c8;
}}
"""


class ReciprocalToleranceBandsDialog(QtWidgets.QDialog):
    """Editor fasce distanza / soglie tempo per i reciproci FAIL."""

    def __init__(
        self,
        parent: QtWidgets.QWidget | None = None,
        *,
        bands: ReciprocalToleranceBands | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Tolleranze reciproci FAIL")
        self.setMinimumWidth(420)
        self._result: ReciprocalToleranceBands | None = None
        current = (bands or DEFAULT_RECIPROCAL_TOLERANCE_BANDS).normalized()

        intro = QtWidgets.QLabel(
            "Fasce in base alla distanza tra gli shot (n° tracce).\n"
            "Esempio default: ≤12 → 2,0 ms · ≤24 → 3,5 ms · oltre → 5,0 ms."
        )
        intro.setWordWrap(True)

        form = QtWidgets.QFormLayout()
        form.setSpacing(8)

        self._dist_near = QtWidgets.QDoubleSpinBox()
        self._dist_near.setRange(0.0, 10_000.0)
        self._dist_near.setDecimals(0)
        self._dist_near.setValue(float(current.dist_near))
        self._dist_near.setToolTip("Distanza massima (tracce) per la fascia vicina.")

        self._dist_mid = QtWidgets.QDoubleSpinBox()
        self._dist_mid.setRange(0.0, 10_000.0)
        self._dist_mid.setDecimals(0)
        self._dist_mid.setValue(float(current.dist_mid))
        self._dist_mid.setToolTip("Distanza massima (tracce) per la fascia intermedia.")

        self._tol_near = QtWidgets.QDoubleSpinBox()
        self._tol_near.setRange(0.0, 1_000.0)
        self._tol_near.setDecimals(2)
        self._tol_near.setSingleStep(0.1)
        self._tol_near.setSuffix(" ms")
        self._tol_near.setValue(float(current.tol_near_ms))

        self._tol_mid = QtWidgets.QDoubleSpinBox()
        self._tol_mid.setRange(0.0, 1_000.0)
        self._tol_mid.setDecimals(2)
        self._tol_mid.setSingleStep(0.1)
        self._tol_mid.setSuffix(" ms")
        self._tol_mid.setValue(float(current.tol_mid_ms))

        self._tol_far = QtWidgets.QDoubleSpinBox()
        self._tol_far.setRange(0.0, 1_000.0)
        self._tol_far.setDecimals(2)
        self._tol_far.setSingleStep(0.1)
        self._tol_far.setSuffix(" ms")
        self._tol_far.setValue(float(current.tol_far_ms))

        form.addRow("Distanza vicina ≤", self._dist_near)
        form.addRow("Tolleranza vicina", self._tol_near)
        form.addRow("Distanza media ≤", self._dist_mid)
        form.addRow("Tolleranza media", self._tol_mid)
        form.addRow("Tolleranza lontana (oltre)", self._tol_far)

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButton.Ok
            | QtWidgets.QDialogButtonBox.StandardButton.Cancel
            | QtWidgets.QDialogButtonBox.StandardButton.RestoreDefaults
        )
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self.reject)
        buttons.button(
            QtWidgets.QDialogButtonBox.StandardButton.RestoreDefaults
        ).clicked.connect(self._restore_defaults)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(intro)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def bands(self) -> ReciprocalToleranceBands | None:
        return self._result

    def _restore_defaults(self) -> None:
        d = DEFAULT_RECIPROCAL_TOLERANCE_BANDS
        self._dist_near.setValue(float(d.dist_near))
        self._dist_mid.setValue(float(d.dist_mid))
        self._tol_near.setValue(float(d.tol_near_ms))
        self._tol_mid.setValue(float(d.tol_mid_ms))
        self._tol_far.setValue(float(d.tol_far_ms))

    def _on_accept(self) -> None:
        bands = ReciprocalToleranceBands(
            dist_near=float(self._dist_near.value()),
            dist_mid=float(self._dist_mid.value()),
            tol_near_ms=float(self._tol_near.value()),
            tol_mid_ms=float(self._tol_mid.value()),
            tol_far_ms=float(self._tol_far.value()),
        ).normalized()
        if bands.dist_mid < bands.dist_near:
            QtWidgets.QMessageBox.warning(
                self,
                "Distanze non valide",
                "La distanza media deve essere ≥ della distanza vicina.",
            )
            return
        self._result = bands
        self.accept()


class DromocronaGridTable(QtWidgets.QTableWidget):
    """Tabella dromocrone con aspetto simile a un foglio Excel."""

    zoomChanged = QtCore.pyqtSignal(float)

    def __init__(self, parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent)
        self._zoom = 1.0
        self.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setSelectionBehavior(
            QtWidgets.QAbstractItemView.SelectionBehavior.SelectItems
        )
        self.setSelectionMode(
            QtWidgets.QAbstractItemView.SelectionMode.ExtendedSelection
        )
        self.setAlternatingRowColors(True)
        self.setShowGrid(True)
        self.setWordWrap(False)
        self.verticalHeader().setVisible(False)
        self.setHorizontalScrollMode(
            QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel
        )
        self.setVerticalScrollMode(
            QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel
        )
        self.setToolTip(
            "Ctrl + rotella: zoom\n"
            "Ctrl + tasto sinistro (trascina): sposta la vista"
        )
        self.viewport().setToolTip(self.toolTip())
        self._loaded_struct_key: tuple | None = None
        self._channel_row_map: dict[int, int] = {}
        self._pan_active = False
        self._pan_last_global = QtCore.QPoint()
        self.viewport().installEventFilter(self)
        self._apply_zoom_chrome()

    def zoom(self) -> float:
        return float(self._zoom)

    def _clamp_zoom(self, zoom: float) -> float:
        stepped = round(float(zoom) / _GRID_ZOOM_STEP) * _GRID_ZOOM_STEP
        return max(_GRID_ZOOM_MIN, min(_GRID_ZOOM_MAX, stepped))

    def _scaled_font_px(self) -> tuple[int, int]:
        z = self._zoom
        font_px = max(7, int(round(_GRID_FONT_PX * z)))
        num_px = max(7, int(round(_GRID_NUM_FONT_PX * z)))
        return font_px, num_px

    def _scaled_layout_px(self) -> tuple[int, int, int]:
        z = self._zoom
        row_h = max(14, int(round(_GRID_ROW_HEIGHT_PX * z)))
        col_min = max(28, int(round(_GRID_COL_MIN_PX * z)))
        col_def = max(col_min, int(round(_GRID_COL_DEFAULT_PX * z)))
        return row_h, col_min, col_def

    def _make_num_font(self) -> QtGui.QFont:
        _, num_px = self._scaled_font_px()
        num_font = QtGui.QFont("Consolas")
        num_font.setStyleHint(QtGui.QFont.StyleHint.Monospace)
        num_font.setPixelSize(num_px)
        return num_font

    def _make_geo_font(self) -> QtGui.QFont:
        font_px, _ = self._scaled_font_px()
        geo_font = QtGui.QFont(self.font())
        geo_font.setPixelSize(font_px)
        geo_font.setBold(True)
        return geo_font

    def _apply_zoom_chrome(self) -> None:
        font_px, _ = self._scaled_font_px()
        row_h, col_min, col_def = self._scaled_layout_px()
        self.setStyleSheet(_table_style(font_px))
        header = self.horizontalHeader()
        header.setMinimumSectionSize(col_min)
        header.setDefaultSectionSize(col_def)
        self.verticalHeader().setDefaultSectionSize(row_h)
        self.verticalHeader().setMinimumSectionSize(max(12, row_h - 4))

    def _restyle_item_fonts(self) -> None:
        """Aggiorna font celle già caricate dopo un cambio zoom."""
        num_font = self._make_num_font()
        geo_font = self._make_geo_font()
        rows = self.rowCount()
        cols = self.columnCount()
        self.setUpdatesEnabled(False)
        try:
            for row in range(rows):
                geo_item = self.item(row, 0)
                if geo_item is not None:
                    geo_item.setFont(geo_font)
                for col in range(1, cols):
                    item = self.item(row, col)
                    if item is None or not item.text():
                        continue
                    font = QtGui.QFont(num_font)
                    if item.font().bold():
                        font.setBold(True)
                    item.setFont(font)
        finally:
            self.setUpdatesEnabled(True)

    def _scale_section_sizes(self, ratio: float) -> None:
        if ratio <= 0.0 or abs(ratio - 1.0) < 1e-6:
            return
        _, col_min, _ = self._scaled_layout_px()
        row_h, _, _ = self._scaled_layout_px()
        header = self.horizontalHeader()
        self.setUpdatesEnabled(False)
        try:
            for col in range(self.columnCount()):
                if col == 0:
                    continue
                w = header.sectionSize(col)
                header.resizeSection(col, max(col_min, int(round(w * ratio))))
            for row in range(self.rowCount()):
                self.setRowHeight(row, row_h)
        finally:
            self.setUpdatesEnabled(True)

    def set_zoom(self, zoom: float) -> None:
        new_zoom = self._clamp_zoom(zoom)
        old = self._zoom
        if abs(new_zoom - old) < 1e-6:
            return
        self._zoom = new_zoom
        ratio = new_zoom / old if old > 0 else 1.0
        self._apply_zoom_chrome()
        self._scale_section_sizes(ratio)
        self._restyle_item_fonts()
        self.zoomChanged.emit(self._zoom)

    def nudge_zoom(self, steps: int) -> None:
        self.set_zoom(self._zoom + steps * _GRID_ZOOM_STEP)

    def reset_zoom(self) -> None:
        self.set_zoom(1.0)

    def wheelEvent(self, event: QtGui.QWheelEvent) -> None:
        if event.modifiers() & QtCore.Qt.KeyboardModifier.ControlModifier:
            delta = event.angleDelta().y()
            if delta == 0:
                delta = event.pixelDelta().y()
            if delta != 0:
                self.nudge_zoom(1 if delta > 0 else -1)
                event.accept()
                return
        super().wheelEvent(event)

    def _end_pan(self) -> None:
        if not self._pan_active:
            return
        self._pan_active = False
        vp = self.viewport()
        if QtWidgets.QWidget.mouseGrabber() is vp:
            vp.releaseMouse()
        vp.unsetCursor()

    def _begin_pan(self, event: QtGui.QMouseEvent) -> None:
        self._pan_active = True
        self._pan_last_global = event.globalPosition().toPoint()
        vp = self.viewport()
        vp.setCursor(QtCore.Qt.CursorShape.ClosedHandCursor)
        vp.grabMouse()

    def _pan_by_event(self, event: QtGui.QMouseEvent) -> None:
        global_pos = event.globalPosition().toPoint()
        delta = global_pos - self._pan_last_global
        self._pan_last_global = global_pos
        if delta.x() == 0 and delta.y() == 0:
            return
        hbar = self.horizontalScrollBar()
        vbar = self.verticalScrollBar()
        hbar.setValue(hbar.value() - int(delta.x()))
        vbar.setValue(vbar.value() - int(delta.y()))

    def eventFilter(self, obj: QtCore.QObject, event: QtCore.QEvent) -> bool:
        if obj is self.viewport() and isinstance(event, QtGui.QMouseEvent):
            et = event.type()
            ctrl_left = (
                event.button() == QtCore.Qt.MouseButton.LeftButton
                and bool(
                    event.modifiers() & QtCore.Qt.KeyboardModifier.ControlModifier
                )
            )
            if et == QtCore.QEvent.Type.MouseButtonPress and ctrl_left:
                self._begin_pan(event)
                return True
            if et == QtCore.QEvent.Type.MouseMove and self._pan_active:
                self._pan_by_event(event)
                return True
            if (
                et == QtCore.QEvent.Type.MouseButtonRelease
                and self._pan_active
                and event.button() == QtCore.Qt.MouseButton.LeftButton
            ):
                self._end_pan()
                return True
            if et == QtCore.QEvent.Type.MouseButtonDblClick and ctrl_left:
                return True
        return super().eventFilter(obj, event)

    def keyReleaseEvent(self, event: QtGui.QKeyEvent) -> None:
        if (
            self._pan_active
            and event.key()
            in (QtCore.Qt.Key.Key_Control, QtCore.Qt.Key.Key_Meta)
        ):
            self._end_pan()
            event.accept()
            return
        super().keyReleaseEvent(event)

    @staticmethod
    def _grid_structure_key(grid: DromocronaGridData) -> tuple:
        return (grid.row_channels, grid.column_labels, grid.shot_channels)

    def _cell_style(
        self,
        *,
        val: float | None,
        shot_ch: int,
        ch: int,
        mark: ReciprocalGridCellMark | None,
        num_font: QtGui.QFont,
    ) -> tuple[str, QtGui.QColor, QtGui.QColor, QtGui.QFont]:
        shot_bg = QtGui.QColor("#fff4e5")
        shot_fg = QtGui.QColor("#9a3412")
        empty_bg = QtGui.QColor("#fafafa")
        if val is None:
            return "", empty_bg, QtGui.QColor(), num_font
        text = format_dromocrona_ms_display(float(val))
        is_shot = shot_ch > 0 and ch == shot_ch
        font = QtGui.QFont(num_font)
        bg = QtGui.QColor("#ffffff")
        fg = QtGui.QColor("#1a1a1a")
        if mark is not None and mark.failed:
            bg = _RECIPROCAL_FAIL_BG
            fg = _RECIPROCAL_FAIL_FG
            font.setBold(True)
        elif mark is not None and mark.passed_compare:
            bg = _RECIPROCAL_OK_BG
            fg = _RECIPROCAL_OK_FG
        elif is_shot:
            bg = shot_bg
            fg = shot_fg
            font.setBold(True)
        return text, bg, fg, font

    def _patch_grid_values(
        self,
        grid: DromocronaGridData,
        *,
        reciprocal_marks: dict[tuple[int, int], ReciprocalGridCellMark] | None = None,
    ) -> None:
        file_count = len(grid.column_labels)
        row_count = len(grid.row_channels)
        num_font = self._make_num_font()
        row_h, _, _ = self._scaled_layout_px()
        self._channel_row_map = {
            int(ch): int(i)
            for i, ch in enumerate(grid.row_channels)
            if int(ch) > 0
        }
        self.setUpdatesEnabled(False)
        try:
            for row in range(row_count):
                self.setRowHeight(row, row_h)
                ch = grid.row_channels[row] if row < len(grid.row_channels) else 0
                row_vals = grid.values[row] if row < len(grid.values) else ()
                for file_idx in range(file_count):
                    table_col = file_idx + 1
                    shot_ch = (
                        grid.shot_channels[file_idx]
                        if file_idx < len(grid.shot_channels)
                        else 0
                    )
                    val = row_vals[file_idx] if file_idx < len(row_vals) else None
                    mark = None
                    if reciprocal_marks is not None and ch > 0:
                        mark = reciprocal_marks.get((ch, file_idx))
                    text, bg, fg, font = self._cell_style(
                        val=val,
                        shot_ch=shot_ch,
                        ch=ch,
                        mark=mark,
                        num_font=num_font,
                    )
                    item = self.item(row, table_col)
                    if item is None:
                        item = QtWidgets.QTableWidgetItem()
                        item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
                        self.setItem(row, table_col, item)
                    if item.text() != text:
                        item.setText(text)
                    if item.background().color() != bg:
                        item.setBackground(bg)
                    if fg.isValid() and item.foreground().color() != fg:
                        item.setForeground(fg)
                    if item.font() != font:
                        item.setFont(font)
                    tip = ""
                    if mark is not None and mark.failed and ch > 0:
                        col_lbl = (
                            short_column_label(grid.column_labels[file_idx])
                            if file_idx < len(grid.column_labels)
                            else "—"
                        )
                        tip = format_reciprocal_cell_tooltip(
                            mark, geophone=ch, column_label=col_lbl
                        )
                    if item.toolTip() != tip:
                        item.setToolTip(tip)
        finally:
            self.setUpdatesEnabled(True)

    def load_data(
        self,
        grid: DromocronaGridData,
        *,
        reciprocal_marks: dict[tuple[int, int], ReciprocalGridCellMark] | None = None,
    ) -> None:
        file_count = len(grid.column_labels)
        col_count = 1 + file_count
        row_count = len(grid.row_channels)
        struct_key = self._grid_structure_key(grid)
        if (
            struct_key == self._loaded_struct_key
            and self.rowCount() == row_count
            and self.columnCount() == col_count
        ):
            self._patch_grid_values(grid, reciprocal_marks=reciprocal_marks)
            return

        h_scroll = self.horizontalScrollBar().value()
        v_scroll = self.verticalScrollBar().value()
        selected = {
            (int(index.row()), int(index.column()))
            for index in self.selectedIndexes()
        }

        self._channel_row_map = {
            int(ch): int(i)
            for i, ch in enumerate(grid.row_channels)
            if int(ch) > 0
        }
        self.setUpdatesEnabled(False)
        try:
            self.clear()
            self.setRowCount(row_count)
            self.setColumnCount(col_count)

            headers = [""]
            headers.extend(short_column_label(label) for label in grid.column_labels)
            self.setHorizontalHeaderLabels(headers)

            header = self.horizontalHeader()
            channel_header = self.horizontalHeaderItem(0)
            if channel_header is not None:
                channel_header.setToolTip("Canale geofono")
            for file_idx, label in enumerate(grid.column_labels):
                shot_ch = (
                    grid.shot_channels[file_idx]
                    if file_idx < len(grid.shot_channels)
                    else 0
                )
                tip = f"Dromocrona: {label}"
                if shot_ch > 0:
                    tip += f"\nCanale shot: {shot_ch}"
                header_item = self.horizontalHeaderItem(file_idx + 1)
                if header_item is not None:
                    header_item.setToolTip(tip)

            empty_bg = QtGui.QColor("#fafafa")
            geo_bg = QtGui.QColor("#f2f2f2")
            num_font = self._make_num_font()
            geo_font = self._make_geo_font()
            row_h, col_min, col_def = self._scaled_layout_px()
            self._apply_zoom_chrome()

            for row in range(row_count):
                self.setRowHeight(row, row_h)
                ch = grid.row_channels[row] if row < len(grid.row_channels) else 0

                geo_item = QtWidgets.QTableWidgetItem(str(ch) if ch > 0 else "—")
                geo_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
                geo_item.setBackground(geo_bg)
                geo_item.setFont(geo_font)
                self.setItem(row, 0, geo_item)

                row_vals = grid.values[row] if row < len(grid.values) else ()
                for file_idx in range(file_count):
                    table_col = file_idx + 1
                    shot_ch = (
                        grid.shot_channels[file_idx]
                        if file_idx < len(grid.shot_channels)
                        else 0
                    )
                    val = row_vals[file_idx] if file_idx < len(row_vals) else None
                    mark = None
                    if reciprocal_marks is not None and ch > 0:
                        mark = reciprocal_marks.get((ch, file_idx))
                    text, bg, fg, font = self._cell_style(
                        val=val,
                        shot_ch=shot_ch,
                        ch=ch,
                        mark=mark,
                        num_font=num_font,
                    )
                    if not text:
                        item = QtWidgets.QTableWidgetItem("")
                        item.setBackground(empty_bg)
                    else:
                        item = QtWidgets.QTableWidgetItem(text)
                        item.setFont(font)
                        item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
                        item.setBackground(bg)
                        if fg.isValid():
                            item.setForeground(fg)
                    if mark is not None and mark.failed and ch > 0:
                        col_lbl = short_column_label(grid.column_labels[file_idx])
                        item.setToolTip(
                            format_reciprocal_cell_tooltip(
                                mark, geophone=ch, column_label=col_lbl
                            )
                        )
                    self.setItem(row, table_col, item)
        finally:
            self.setUpdatesEnabled(True)

        self._loaded_struct_key = struct_key
        self.horizontalScrollBar().setValue(h_scroll)
        self.verticalScrollBar().setValue(v_scroll)
        if selected:
            self.clearSelection()
            for row, col in selected:
                if 0 <= row < self.rowCount() and 0 <= col < self.columnCount():
                    idx = self.model().index(row, col)
                    self.selectionModel().select(
                        idx,
                        QtCore.QItemSelectionModel.SelectionFlag.Select,
                    )

        header = self.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        for col in range(1, col_count):
            header.setSectionResizeMode(
                col, QtWidgets.QHeaderView.ResizeMode.Interactive
            )
            if header.sectionSize(col) < col_min:
                header.resizeSection(col, col_def)


class DromocronaGridWindow(QtWidgets.QMainWindow):
    """Finestra separata con griglia dromocrone (stile Excel)."""

    def __init__(
        self,
        parent: QtWidgets.QWidget | None = None,
        get_series_meta: Callable[[], list[dict[str, object]]] | None = None,
        get_folder: Callable[[], Path | None] | None = None,
        get_shot_registry: Callable[[], dict[str, int]] | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Griglia dromocrone")
        self.resize(1180, 640)
        self.setMinimumSize(720, 360)
        self.setWindowModality(QtCore.Qt.WindowModality.NonModal)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, False)
        self.setWindowFlags(
            QtCore.Qt.WindowType.Window
            | QtCore.Qt.WindowType.WindowMinimizeButtonHint
            | QtCore.Qt.WindowType.WindowMaximizeButtonHint
            | QtCore.Qt.WindowType.WindowCloseButtonHint
        )
        self._get_series_meta = get_series_meta
        self._get_folder = get_folder
        self._get_shot_registry = get_shot_registry
        self._last_grid: DromocronaGridData | None = None
        self._last_reciprocal_marks: dict[tuple[int, int], ReciprocalGridCellMark] | None = (
            None
        )
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        root = QtWidgets.QVBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        self._table = DromocronaGridTable()
        self._table.cellClicked.connect(self._on_grid_cell_clicked)
        self._table.zoomChanged.connect(self._on_table_zoom_changed)

        toolbar = QtWidgets.QHBoxLayout()
        toolbar.setSpacing(8)

        refresh_btn = QtWidgets.QPushButton("Aggiorna")
        refresh_btn.setToolTip(
            "Ricarica manualmente i dati dai .fbp. "
            "La griglia si aggiorna da sola quando modifichi i break nel monitor."
        )
        refresh_btn.setStyleSheet(
            "color: #e8eaed; background: #252d3d; border: 1px solid #3d4657; "
            "padding: 5px 12px; border-radius: 4px;"
        )
        refresh_btn.clicked.connect(self.refresh)
        toolbar.addWidget(refresh_btn)

        export_btn = QtWidgets.QPushButton("Esporta Excel")
        export_btn.setToolTip(
            "Esporta il foglio P (Excel FBP). Titolo A1 a scelta; "
            "colonna B = n° geofono. Zero shot in giallo, pick mancanti in arancio."
        )
        export_btn.setStyleSheet(
            "color: #e8eaed; background: #252d3d; border: 1px solid #3d4657; "
            "padding: 5px 12px; border-radius: 4px;"
        )
        export_btn.clicked.connect(self.export_excel)
        toolbar.addWidget(export_btn)

        self._reciprocal_chk = QtWidgets.QCheckBox("Evidenzia reciproci")
        self._reciprocal_chk.setChecked(True)
        self._reciprocal_chk.setStyleSheet("color: #e8eaed; font-size: 12px;")
        self._reciprocal_chk.setToolTip(
            "Colora le celle usate nel controllo reciproco "
            "(verde = OK, rosso = FAIL).\n"
            "Clic su un FAIL: messaggio con colonna e sensore del reciproco.\n"
            "Passa il mouse sulla cella per i dettagli Δt."
        )
        self._reciprocal_chk.toggled.connect(self._on_reciprocal_toggle)
        toolbar.addWidget(self._reciprocal_chk)

        self._tol_btn = QtWidgets.QPushButton("Tolleranze…")
        self._tol_btn.setStyleSheet(
            "color: #e8eaed; background: #252d3d; border: 1px solid #3d4657; "
            "padding: 5px 12px; border-radius: 4px;"
        )
        self._tol_btn.setToolTip(
            "Fasce distanza (n° tracce) e soglie tempo (ms) per i reciproci FAIL."
        )
        self._tol_btn.clicked.connect(self._on_edit_tolerance_bands)
        toolbar.addWidget(self._tol_btn)

        toolbar.addSpacing(12)
        zoom_style = (
            "color: #e8eaed; background: #252d3d; border: 1px solid #3d4657; "
            "padding: 5px 10px; border-radius: 4px; min-width: 28px;"
        )
        self._zoom_out_btn = QtWidgets.QPushButton("−")
        self._zoom_out_btn.setStyleSheet(zoom_style)
        self._zoom_out_btn.setToolTip("Riduci zoom tabella (Ctrl+rotella / Ctrl+−)")
        self._zoom_out_btn.clicked.connect(lambda: self._table.nudge_zoom(-1))
        toolbar.addWidget(self._zoom_out_btn)

        self._zoom_label = QtWidgets.QLabel("100%")
        self._zoom_label.setStyleSheet(
            "color: #e8eaed; font-size: 12px; min-width: 44px;"
        )
        self._zoom_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self._zoom_label.setToolTip("Click per ripristinare zoom 100% (Ctrl+0)")
        self._zoom_label.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self._zoom_label.installEventFilter(self)
        toolbar.addWidget(self._zoom_label)

        self._zoom_in_btn = QtWidgets.QPushButton("+")
        self._zoom_in_btn.setStyleSheet(zoom_style)
        self._zoom_in_btn.setToolTip("Aumenta zoom tabella (Ctrl+rotella / Ctrl++)")
        self._zoom_in_btn.clicked.connect(lambda: self._table.nudge_zoom(1))
        toolbar.addWidget(self._zoom_in_btn)

        toolbar.addStretch(1)
        root.addLayout(toolbar)

        self._tolerance_bands = DEFAULT_RECIPROCAL_TOLERANCE_BANDS
        self._on_tolerance_bands_changed: Callable[
            [ReciprocalToleranceBands], None
        ] | None = None

        table_frame = QtWidgets.QFrame()
        table_frame.setStyleSheet(
            "QFrame { background: #ffffff; border: 1px solid #a0a0a0; border-radius: 4px; }"
        )
        table_layout = QtWidgets.QVBoxLayout(table_frame)
        table_layout.setContentsMargins(1, 1, 1, 1)
        table_layout.addWidget(self._table)
        root.addWidget(table_frame, stretch=1)

        self._cell_tip = QtWidgets.QLabel(
            None,
            QtCore.Qt.WindowType.ToolTip
            | QtCore.Qt.WindowType.FramelessWindowHint
            | QtCore.Qt.WindowType.WindowStaysOnTopHint,
        )
        self._cell_tip.setWordWrap(True)
        self._cell_tip.setMaximumWidth(360)
        self._cell_tip.setStyleSheet(
            "QLabel {"
            "  background: #fffbeb;"
            "  color: #1a1a1a;"
            "  border: 1px solid #f59e0b;"
            "  border-radius: 6px;"
            "  padding: 8px 10px;"
            "  font-size: 12px;"
            "}"
        )
        self._cell_tip.hide()
        self._cell_tip_timer = QtCore.QTimer(self)
        self._cell_tip_timer.setSingleShot(True)
        self._cell_tip_timer.setInterval(7000)
        self._cell_tip_timer.timeout.connect(self._hide_cell_tip)
        self._table.horizontalScrollBar().valueChanged.connect(self._hide_cell_tip)
        self._table.verticalScrollBar().valueChanged.connect(self._hide_cell_tip)

        self.setStyleSheet("background-color: #1a2233;")
        self._install_zoom_shortcuts()
        self._on_table_zoom_changed(self._table.zoom())

    def _install_zoom_shortcuts(self) -> None:
        for key, steps in (
            (QtGui.QKeySequence.StandardKey.ZoomIn, 1),
            (QtGui.QKeySequence("Ctrl+="), 1),
            (QtGui.QKeySequence("Ctrl++"), 1),
            (QtGui.QKeySequence.StandardKey.ZoomOut, -1),
            (QtGui.QKeySequence("Ctrl+-"), -1),
        ):
            sc = QtGui.QShortcut(key, self)
            sc.setContext(QtCore.Qt.ShortcutContext.WindowShortcut)
            sc.activated.connect(lambda s=steps: self._table.nudge_zoom(s))
        reset = QtGui.QShortcut(QtGui.QKeySequence("Ctrl+0"), self)
        reset.setContext(QtCore.Qt.ShortcutContext.WindowShortcut)
        reset.activated.connect(self._table.reset_zoom)

    def _on_table_zoom_changed(self, zoom: float) -> None:
        pct = int(round(float(zoom) * 100.0))
        self._zoom_label.setText(f"{pct}%")
        self._zoom_out_btn.setEnabled(zoom > _GRID_ZOOM_MIN + 1e-6)
        self._zoom_in_btn.setEnabled(zoom < _GRID_ZOOM_MAX - 1e-6)

    def eventFilter(self, obj: QtCore.QObject, event: QtCore.QEvent) -> bool:
        if obj is self._zoom_label and event.type() == QtCore.QEvent.Type.MouseButtonPress:
            self._table.reset_zoom()
            return True
        return super().eventFilter(obj, event)

    def _shot_registry_for_grid(self) -> dict[str, int]:
        getter = getattr(self, "_get_shot_registry", None)
        if getter is None:
            return {}
        try:
            return dict(getter())
        except Exception:
            return {}

    def _update_tol_summary(self) -> None:
        # Riepilogo testuale rimosso dalla UI (resta il dialogo «Tolleranze…»).
        return

    def tolerance_bands(self) -> ReciprocalToleranceBands:
        bands = getattr(self, "_tolerance_bands", None)
        if isinstance(bands, ReciprocalToleranceBands):
            return bands.normalized()
        return DEFAULT_RECIPROCAL_TOLERANCE_BANDS

    def sync_tolerance_bands_from_monitor(
        self, bands: ReciprocalToleranceBands | None
    ) -> None:
        self._tolerance_bands = (
            bands.normalized()
            if isinstance(bands, ReciprocalToleranceBands)
            else DEFAULT_RECIPROCAL_TOLERANCE_BANDS
        )
        self._update_tol_summary()

    def _on_edit_tolerance_bands(self) -> None:
        dlg = ReciprocalToleranceBandsDialog(self, bands=self.tolerance_bands())
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        bands = dlg.bands()
        if bands is None:
            return
        self._tolerance_bands = bands
        self._update_tol_summary()
        cb = getattr(self, "_on_tolerance_bands_changed", None)
        if cb is not None:
            cb(bands)

    def _on_reciprocal_toggle(self, checked: bool) -> None:
        del checked
        cb = getattr(self, "_schedule_reciprocal_refresh", None)
        if cb is not None:
            cb()
            return
        self.refresh()

    def refresh(self, *, reciprocal_pairs: tuple | None = None) -> None:
        raw_series_meta: list[dict[str, object]] = []
        if self._get_series_meta is not None:
            try:
                raw_series_meta = list(self._get_series_meta())
            except Exception:
                raw_series_meta = []
        series_meta = sort_series_meta_by_file_order(raw_series_meta)
        shot_registry = self._shot_registry_for_grid()
        grid = build_dromocrona_grid_data(series_meta, shot_registry=shot_registry)
        self.apply_grid_data(
            grid,
            raw_series_meta=raw_series_meta,
            reciprocal_pairs=reciprocal_pairs,
        )

    def apply_grid_data(
        self,
        grid: DromocronaGridData,
        *,
        raw_series_meta: list[dict[str, object]] | None = None,
        reciprocal_pairs: tuple | None = None,
    ) -> None:
        """Aggiorna tabella/info griglia (solo Qt; dati già calcolati)."""
        if raw_series_meta is None:
            raw_series_meta = []
            if self._get_series_meta is not None:
                try:
                    raw_series_meta = list(self._get_series_meta())
                except Exception:
                    raw_series_meta = []
        show_reciprocal = bool(
            getattr(self, "_reciprocal_chk", None) is not None
            and self._reciprocal_chk.isChecked()
        )
        reciprocal_marks: dict[tuple[int, int], ReciprocalGridCellMark] | None = None
        pairs = ()
        if show_reciprocal and raw_series_meta and reciprocal_pairs is not None:
            pairs = remap_reciprocal_pairs_to_grid_columns(
                reciprocal_pairs,
                raw_series_meta,
            )
            reciprocal_marks = reciprocal_grid_marks_from_pairs(pairs)
        self.setUpdatesEnabled(False)
        try:
            self._table.load_data(grid, reciprocal_marks=reciprocal_marks)
        finally:
            self.setUpdatesEnabled(True)
        self._last_grid = grid
        self._last_reciprocal_marks = reciprocal_marks

    def _hide_cell_tip(self, *_args) -> None:
        tip = getattr(self, "_cell_tip", None)
        timer = getattr(self, "_cell_tip_timer", None)
        if timer is not None:
            timer.stop()
        if tip is not None:
            tip.hide()

    def _show_cell_tip_near(self, row: int, column: int, text: str) -> None:
        tip = getattr(self, "_cell_tip", None)
        if tip is None:
            return
        tip.setText(text)
        tip.adjustSize()
        index = self._table.model().index(row, column)
        cell_rect = self._table.visualRect(index)
        if not cell_rect.isValid():
            self._hide_cell_tip()
            return
        # Ancora al bordo destro della cella, leggermente sotto.
        anchor = self._table.viewport().mapToGlobal(
            QtCore.QPoint(cell_rect.right() + 8, cell_rect.top() - 4)
        )
        tip_w = tip.width()
        tip_h = tip.height()
        screen = QtGui.QGuiApplication.screenAt(anchor)
        if screen is None:
            screen = QtGui.QGuiApplication.primaryScreen()
        if screen is not None:
            avail = screen.availableGeometry()
            x = min(anchor.x(), avail.right() - tip_w - 6)
            y = min(anchor.y(), avail.bottom() - tip_h - 6)
            x = max(avail.left() + 6, x)
            y = max(avail.top() + 6, y)
            # Se non c'è spazio a destra, metti a sinistra della cella.
            if anchor.x() + tip_w > avail.right() - 6:
                left_anchor = self._table.viewport().mapToGlobal(
                    QtCore.QPoint(cell_rect.left() - tip_w - 8, cell_rect.top() - 4)
                )
                x = max(avail.left() + 6, left_anchor.x())
            tip.move(x, y)
        else:
            tip.move(anchor)
        tip.show()
        tip.raise_()
        timer = getattr(self, "_cell_tip_timer", None)
        if timer is not None:
            timer.start()

    def _partner_location_text(
        self, grid: DromocronaGridData, partner: tuple[int, int]
    ) -> str:
        ch, file_idx = int(partner[0]), int(partner[1])
        if 0 <= file_idx < len(grid.column_labels):
            col_lbl = short_column_label(grid.column_labels[file_idx])
        else:
            col_lbl = "—"
        return f"colonna «{col_lbl}», sensore {ch}"

    def _on_grid_cell_clicked(self, row: int, column: int) -> None:
        """Clic su FAIL: etichetta flottante vicino alla cella (niente snap)."""
        grid = getattr(self, "_last_grid", None)
        marks = getattr(self, "_last_reciprocal_marks", None)
        if grid is None or marks is None or column <= 0:
            self._hide_cell_tip()
            return
        if row < 0 or row >= len(grid.row_channels):
            self._hide_cell_tip()
            return
        ch = int(grid.row_channels[row])
        file_idx = int(column) - 1
        if ch <= 0 or file_idx < 0 or file_idx >= len(grid.column_labels):
            self._hide_cell_tip()
            return
        key = (ch, file_idx)
        mark = marks.get(key)
        if mark is None or not mark.failed:
            self._hide_cell_tip()
            return
        here = self._partner_location_text(grid, key)
        partners = tuple(
            p for p in mark.partner_keys if p in marks and marks[p].failed
        )
        if not partners:
            partners = tuple(mark.partner_keys)
        if not partners:
            text = (
                f"FAIL su {here}:\n"
                "non è disponibile la posizione dell’altro capo."
            )
        elif len(partners) == 1:
            other = self._partner_location_text(grid, partners[0])
            text = (
                f"FAIL su {here}.\n"
                f"Cerca l’altro capo in {other}."
            )
        else:
            lines = [f"FAIL su {here}.", "Cerca gli altri capi qui:"]
            for partner in partners:
                lines.append(f"• {self._partner_location_text(grid, partner)}")
            text = "\n".join(lines)
        self._show_cell_tip_near(row, column, text)

    def current_grid_data(self) -> DromocronaGridData | None:
        return getattr(self, "_last_grid", None)

    def export_excel(self, *, parent: QtWidgets.QWidget | None = None) -> bool:
        self.refresh()
        grid = self.current_grid_data()
        if grid is None or not grid.column_labels:
            QtWidgets.QMessageBox.information(
                parent or self,
                "Esporta griglia dromocrone",
                "Nessuna dromocrona da esportare. Apri il monitor dromocrone e carica i .fbp.",
            )
            return False
        folder: Path | None = None
        if self._get_folder is not None:
            try:
                folder = self._get_folder()
            except Exception:
                folder = None
        return run_dromocrona_grid_export_dialog(
            parent or self,
            grid,
            folder=folder,
        )

    def showEvent(self, event: QtGui.QShowEvent) -> None:
        self.refresh()
        super().showEvent(event)

    def hideEvent(self, event: QtGui.QHideEvent) -> None:
        self._hide_cell_tip()
        super().hideEvent(event)
